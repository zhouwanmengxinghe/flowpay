# FlowPay 300 题覆盖矩阵

> 由 `scripts/build_benchmark_design.py` 从冻结的 75 个 Scenario Family 生成。  
> 本文件是设计覆盖检查，不进入业务向量库。

## 1. 验证摘要

- Questions：300（Dev 60 / Test 240）。
- Scenario Families：75（Dev 15 / Test 60；每个 Family 4 题）。
- Published Documents：100/100 均为至少一道题的 Required Evidence。
- Canonical Rules：110/110 均有 Required Assertion 覆盖。
- Logical Tools：9/9 均有 Required Tool 覆盖。
- 所有题均在数据生成前冻结，并包含 Negative Assertion。

## 2. 题型配额

| Split | Simple | Multi-doc | Multi-hop | Multi-source | Temporal | Diagnostic | Total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| dev | 14 | 10 | 12 | 14 | 5 | 5 | 60 |
| test | 56 | 40 | 48 | 56 | 20 | 20 | 240 |

## 3. 逻辑工具与 Operation 覆盖

| Tool / Operation | Questions | 示例题 |
| --- | ---: | --- |
| `get_runtime_state` | 137 | FP-BM-MH-0003, FP-BM-MS-0004, FP-BM-MH-0007 |
| `query_accounts` | 70 | FP-BM-MH-0003, FP-BM-MS-0004, FP-BM-MH-0007 |
| `query_payments` | 106 | FP-BM-MH-0003, FP-BM-MS-0004, FP-BM-MH-0007 |
| `query_webhooks` | 58 | FP-BM-MH-0035, FP-BM-MS-0036, FP-BM-MH-0087 |
| `search_api_docs` | 225 | FP-BM-MD-0002, FP-BM-MH-0003, FP-BM-MS-0004 |
| `search_business_rules` | 221 | FP-BM-SR-0001, FP-BM-MH-0003, FP-BM-MS-0004 |
| `search_release_notes` | 14 | FP-BM-MD-0046, FP-BM-MS-0048, FP-BM-MD-0050 |
| `search_support_cases` | 25 | FP-BM-MD-0006, FP-BM-MS-0008, FP-BM-MS-0016 |
| `search_troubleshooting` | 89 | FP-BM-MD-0002, FP-BM-MS-0004, FP-BM-MS-0008 |
| `get_runtime_state.get_delivery_timeline` | 38 | FP-BM-MH-0087, FP-BM-MS-0088, FP-BM-MH-0218 |
| `get_runtime_state.get_request` | 59 | FP-BM-MH-0003, FP-BM-MS-0004, FP-BM-MH-0007 |
| `get_runtime_state.get_service_status` | 8 | FP-BM-MH-0119, FP-BM-TV-0120, FP-BM-MH-0278 |
| `get_runtime_state.get_usage` | 8 | FP-BM-MH-0075, FP-BM-MS-0076, FP-BM-MH-0079 |
| `get_runtime_state.list_requests` | 46 | FP-BM-MH-0015, FP-BM-MS-0016, FP-BM-MH-0023 |
| `query_accounts.get_account` | 49 | FP-BM-MH-0003, FP-BM-MS-0004, FP-BM-MH-0011 |
| `query_accounts.get_feature_flags` | 12 | FP-BM-MH-0027, FP-BM-MS-0028, FP-BM-MH-0031 |
| `query_accounts.get_plan_timeline` | 11 | FP-BM-MH-0031, FP-BM-MS-0032, FP-BM-MH-0035 |
| `query_accounts.list_api_keys` | 16 | FP-BM-MH-0007, FP-BM-MS-0008, FP-BM-MH-0011 |
| `query_payments.get_customer` | 15 | FP-BM-MH-0007, FP-BM-MS-0008, FP-BM-MH-0019 |
| `query_payments.get_invoice_timeline` | 18 | FP-BM-MH-0190, FP-BM-MS-0191, FP-BM-TV-0192 |
| `query_payments.get_payment` | 71 | FP-BM-MH-0003, FP-BM-MS-0004, FP-BM-MH-0023 |
| `query_payments.get_refund` | 18 | FP-BM-MS-0135, FP-BM-TV-0136, FP-BM-MS-0139 |
| `query_payments.get_subscription` | 25 | FP-BM-MH-0027, FP-BM-MS-0028, FP-BM-MH-0031 |
| `query_payments.list_customers` | 4 | FP-BM-MH-0091, FP-BM-MS-0092, FP-BM-MH-0099 |
| `query_payments.list_payments` | 22 | FP-BM-MH-0059, FP-BM-MS-0060, FP-BM-MH-0063 |
| `query_webhooks.get_delivery` | 44 | FP-BM-MH-0087, FP-BM-MS-0088, FP-BM-MH-0218 |
| `query_webhooks.get_endpoint` | 36 | FP-BM-MH-0214, FP-BM-MS-0215, FP-BM-DG-0216 |
| `query_webhooks.get_event` | 24 | FP-BM-MH-0218, FP-BM-MS-0219, FP-BM-DG-0220 |
| `query_webhooks.list_endpoints` | 11 | FP-BM-MH-0035, FP-BM-MS-0036, FP-BM-MH-0210 |

## 4. 100 份 Published 文档覆盖

| Doc ID | Title | Required by | 示例题 |
| --- | --- | ---: | --- |
| KB-API-001 | FlowPay API 快速开始 | 4 | FP-BM-SR-0005, FP-BM-MD-0006, FP-BM-MH-0007 |
| KB-API-002 | API 基础 URL 与请求格式 | 2 | FP-BM-MD-0022, FP-BM-MS-0024 |
| KB-API-003 | 使用 Secret Key 认证 | 7 | FP-BM-MS-0008, FP-BM-MD-0038, FP-BM-MH-0039 |
| KB-API-004 | Sandbox 测试环境 | 3 | FP-BM-MD-0074, FP-BM-MH-0075, FP-BM-MS-0076 |
| KB-API-005 | Production 启用与暂停 | 9 | FP-BM-MD-0010, FP-BM-MH-0011, FP-BM-MS-0012 |
| KB-API-006 | 使用 FlowPay-Version Header | 3 | FP-BM-SR-0045, FP-BM-MH-0047, FP-BM-MS-0048 |
| KB-API-007 | Request ID 与请求追踪 | 4 | FP-BM-MD-0285, FP-BM-MH-0286, FP-BM-MS-0287 |
| KB-API-008 | API 错误响应格式 | 5 | FP-BM-MH-0278, FP-BM-MS-0279, FP-BM-DG-0280 |
| KB-API-009 | Customer 对象 | 7 | FP-BM-SR-0089, FP-BM-MD-0090, FP-BM-MH-0091 |
| KB-API-010 | 创建 Customer | 2 | FP-BM-MD-0098, FP-BM-MS-0100 |
| KB-API-011 | 更新与删除 Customer | 4 | FP-BM-MD-0090, FP-BM-MS-0092, FP-BM-MH-0095 |
| KB-API-012 | Payment 对象 | 3 | FP-BM-TV-0104, FP-BM-MH-0115, FP-BM-TV-0116 |
| KB-API-013 | 创建 Payment | 10 | FP-BM-SR-0021, FP-BM-MH-0023, FP-BM-MS-0024 |
| KB-API-014 | 查询 Payment | 8 | FP-BM-MD-0002, FP-BM-MH-0003, FP-BM-MS-0004 |
| KB-API-015 | 确认 requires_action Payment | 6 | FP-BM-MD-0102, FP-BM-MH-0103, FP-BM-TV-0104 |
| KB-API-016 | 取消 Payment | 3 | FP-BM-MD-0110, FP-BM-MH-0111, FP-BM-TV-0112 |
| KB-API-017 | Payment 列表、过滤与分页 | 3 | FP-BM-MD-0102, FP-BM-TV-0104, FP-BM-TV-0116 |
| KB-API-018 | Payment Method 参数与版本兼容 | 12 | FP-BM-MD-0050, FP-BM-MH-0051, FP-BM-MS-0052 |
| KB-API-019 | Refund 对象 | 11 | FP-BM-SR-0133, FP-BM-MD-0134, FP-BM-MS-0135 |
| KB-API-020 | 创建全额 Refund | 5 | FP-BM-MD-0138, FP-BM-MS-0139, FP-BM-TV-0140 |
| KB-API-021 | 创建部分 Refund | 14 | FP-BM-MD-0138, FP-BM-TV-0140, FP-BM-MD-0142 |
| KB-API-022 | 查询 Refund 与可退款额度 | 7 | FP-BM-SR-0141, FP-BM-MD-0142, FP-BM-TV-0144 |
| KB-API-023 | Subscription 对象 | 4 | FP-BM-SR-0185, FP-BM-MH-0186, FP-BM-MS-0187 |
| KB-API-024 | 创建 Subscription | 11 | FP-BM-MD-0026, FP-BM-MH-0027, FP-BM-MS-0028 |
| KB-API-025 | 取消 Subscription | 7 | FP-BM-MD-0178, FP-BM-MS-0179, FP-BM-TV-0180 |
| KB-API-026 | Invoice 对象 | 10 | FP-BM-MH-0190, FP-BM-MS-0191, FP-BM-TV-0192 |
| KB-API-027 | Invoice 扣费生命周期 | 9 | FP-BM-SR-0189, FP-BM-TV-0192, FP-BM-MH-0194 |
| KB-API-028 | 查询 Invoice 与关联 Payment | 3 | FP-BM-TV-0192, FP-BM-TV-0196, FP-BM-TV-0200 |
| KB-API-029 | Webhook Endpoint 管理 | 12 | FP-BM-MD-0034, FP-BM-MH-0035, FP-BM-MS-0036 |
| KB-API-030 | 订阅 Webhook Event Type | 10 | FP-BM-MH-0222, FP-BM-MS-0223, FP-BM-DG-0224 |
| KB-API-031 | 验证 Webhook 签名 | 14 | FP-BM-SR-0261, FP-BM-MH-0262, FP-BM-MS-0263 |
| KB-API-032 | Webhook 重试与 Event 去重 | 25 | FP-BM-MD-0086, FP-BM-MS-0088, FP-BM-MH-0234 |
| KB-API-033 | 使用 Idempotency-Key | 10 | FP-BM-SR-0061, FP-BM-MD-0062, FP-BM-MH-0063 |
| KB-API-034 | Rate Limit Header 与退避 | 10 | FP-BM-SR-0073, FP-BM-MS-0076, FP-BM-MD-0078 |
| KB-BR-001 | FlowPay 产品范围与租户隔离 | 6 | FP-BM-SR-0001, FP-BM-MH-0003, FP-BM-MS-0004 |
| KB-BR-002 | Sandbox 与 Production 环境策略 | 6 | FP-BM-MH-0007, FP-BM-MS-0008, FP-BM-MH-0011 |
| KB-BR-003 | 服务地区、支持币种与金额规则 | 9 | FP-BM-SR-0017, FP-BM-MD-0018, FP-BM-MH-0019 |
| KB-BR-004 | 商户套餐与功能权限 | 19 | FP-BM-SR-0025, FP-BM-MH-0027, FP-BM-MS-0028 |
| KB-BR-005 | API Rate Limit 策略 | 10 | FP-BM-MH-0075, FP-BM-MS-0076, FP-BM-MH-0079 |
| KB-BR-006 | API Key 生命周期与轮换 | 8 | FP-BM-SR-0037, FP-BM-MH-0039, FP-BM-MS-0040 |
| KB-BR-007 | API Version 选择与支持策略 | 7 | FP-BM-MH-0047, FP-BM-MS-0048, FP-BM-SR-0049 |
| KB-BR-008 | 幂等请求策略 | 8 | FP-BM-MD-0062, FP-BM-MH-0063, FP-BM-MS-0064 |
| KB-BR-009 | Customer 生命周期 | 7 | FP-BM-MH-0091, FP-BM-MS-0092, FP-BM-MH-0095 |
| KB-BR-010 | Payment 生命周期与状态机 | 17 | FP-BM-MH-0059, FP-BM-MS-0060, FP-BM-SR-0101 |
| KB-BR-011 | Payment 失败分类与处置边界 | 16 | FP-BM-MH-0119, FP-BM-TV-0120, FP-BM-SR-0121 |
| KB-BR-012 | Refund 资格、额度与时限 | 22 | FP-BM-MS-0135, FP-BM-TV-0136, FP-BM-MS-0139 |
| KB-BR-013 | Subscription 生命周期 | 15 | FP-BM-SR-0169, FP-BM-MS-0171, FP-BM-TV-0172 |
| KB-BR-014 | Invoice 扣费与重试策略 | 17 | FP-BM-MH-0190, FP-BM-MS-0191, FP-BM-TV-0192 |
| KB-BR-015 | Webhook 事件、Endpoint 与投递策略 | 51 | FP-BM-MH-0210, FP-BM-MS-0211, FP-BM-DG-0212 |
| KB-BR-016 | Webhook 签名验证与 Signing Secret 轮换 | 13 | FP-BM-MH-0262, FP-BM-MS-0263, FP-BM-DG-0264 |
| KB-CASE-001 | Sandbox Key 被用于 Production Payment | 2 | FP-BM-MD-0006, FP-BM-MS-0008 |
| KB-CASE-002 | API Key 轮换中过早撤销旧 Key | 2 | FP-BM-MD-0038, FP-BM-MS-0040 |
| KB-CASE-003 | Production 暂停被误认为套餐降级 | 1 | FP-BM-MS-0016 |
| KB-CASE-004 | 修改金额后复用 Idempotency Key | 1 | FP-BM-MS-0068 |
| KB-CASE-005 | Growth Account 流量峰值触发 Rate Limit | 2 | FP-BM-SR-0077, FP-BM-MS-0080 |
| KB-CASE-006 | 429 重试风暴被误认为套餐降级 | 2 | FP-BM-MD-0082, FP-BM-MS-0084 |
| KB-CASE-007 | source 在 2026-07-01 中被移除 | 1 | FP-BM-MS-0056 |
| KB-CASE-008 | 升级后 Webhook 签名 Header 不匹配 | 1 | FP-BM-DG-0264 |
| KB-CASE-009 | failed Payment 被错误地原地重试 | 2 | FP-BM-MD-0114, FP-BM-TV-0116 |
| KB-CASE-010 | 对 processing Payment 发起 Refund | 2 | FP-BM-MD-0134, FP-BM-TV-0136 |
| KB-CASE-011 | Starter Account 尝试部分 Refund | 2 | FP-BM-SR-0137, FP-BM-TV-0140 |
| KB-CASE-012 | Refund 超过 180 天窗口 | 2 | FP-BM-MD-0154, FP-BM-TV-0156 |
| KB-CASE-013 | Invoice 重试成功后 Subscription 恢复 active | 1 | FP-BM-TV-0192 |
| KB-CASE-014 | Invoice 重试耗尽导致 Subscription 取消 | 1 | FP-BM-TV-0200 |
| KB-CASE-015 | Endpoint 未订阅新版 Payment 成功事件 | 2 | FP-BM-SR-0221, FP-BM-DG-0224 |
| KB-CASE-016 | 503 被误诊为 Merchant Webhook 配置错误 | 1 | FP-BM-DG-0280 |
| KB-REL-001 | 2025-10-01 初始 API Release | 2 | FP-BM-MD-0046, FP-BM-MS-0048 |
| KB-REL-002 | 2026-01-15 Release Notes | 1 | FP-BM-MS-0060 |
| KB-REL-003 | 迁移至 2026-01-15 | 4 | FP-BM-SR-0057, FP-BM-MS-0060, FP-BM-MD-0130 |
| KB-REL-004 | 2026-04-01 Release Notes | 1 | FP-BM-MS-0052 |
| KB-REL-005 | source 到 payment_method 迁移指南 | 2 | FP-BM-MD-0050, FP-BM-MS-0052 |
| KB-REL-006 | Webhook 签名 Header 迁移指南 | 3 | FP-BM-DG-0264, FP-BM-SR-0273, FP-BM-DG-0276 |
| KB-REL-007 | 2026-07-01 Release Notes | 2 | FP-BM-MS-0056, FP-BM-DG-0228 |
| KB-REL-008 | 迁移至 2026-07-01 | 1 | FP-BM-MS-0056 |
| KB-REL-009 | Payment 成功 Event 名称迁移指南 | 2 | FP-BM-DG-0228, FP-BM-DG-0232 |
| KB-REL-010 | API Version 支持与弃用时间线 | 1 | FP-BM-MS-0048 |
| KB-TS-001 | FP-4001 Invalid Request Parameters | 7 | FP-BM-MD-0018, FP-BM-MH-0019, FP-BM-MS-0020 |
| KB-TS-002 | FP-4002 Unsupported API Version | 2 | FP-BM-MD-0046, FP-BM-MS-0048 |
| KB-TS-003 | FP-4003 Removed Parameter | 2 | FP-BM-MD-0054, FP-BM-MS-0056 |
| KB-TS-004 | FP-4011 Invalid API Key | 4 | FP-BM-SR-0041, FP-BM-MD-0042, FP-BM-MS-0044 |
| KB-TS-005 | FP-4012 Environment Mismatch | 1 | FP-BM-MS-0008 |
| KB-TS-006 | FP-4021 Payment Method Declined | 3 | FP-BM-SR-0117, FP-BM-MD-0118, FP-BM-TV-0120 |
| KB-TS-007 | FP-4022 Insufficient Funds | 3 | FP-BM-MD-0122, FP-BM-MS-0123, FP-BM-TV-0124 |
| KB-TS-008 | FP-4023 Customer Action Required | 4 | FP-BM-MD-0058, FP-BM-MS-0060, FP-BM-MD-0130 |
| KB-TS-009 | FP-4024 Payment Method Expired | 4 | FP-BM-SR-0125, FP-BM-MD-0126, FP-BM-MS-0127 |
| KB-TS-010 | FP-4031 Feature Unavailable for Plan | 11 | FP-BM-SR-0009, FP-BM-MD-0010, FP-BM-MS-0012 |
| KB-TS-011 | FP-4032 Production Access Suspended | 2 | FP-BM-MD-0014, FP-BM-MS-0016 |
| KB-TS-012 | FP-4041 Resource Not Found or Not Visible | 4 | FP-BM-MD-0002, FP-BM-MS-0004, FP-BM-MD-0289 |
| KB-TS-013 | FP-4091 Duplicate Idempotency Key | 5 | FP-BM-MD-0066, FP-BM-MS-0068, FP-BM-SR-0069 |
| KB-TS-014 | FP-4221 Invalid Payment State | 6 | FP-BM-SR-0093, FP-BM-MD-0094, FP-BM-MS-0096 |
| KB-TS-015 | FP-4222 Refund Window Expired | 3 | FP-BM-SR-0153, FP-BM-MD-0154, FP-BM-TV-0156 |
| KB-TS-016 | FP-4291 Rate Limit Exceeded | 2 | FP-BM-MD-0074, FP-BM-MS-0076 |
| KB-TS-017 | FP-5001 Internal Processing Error | 1 | FP-BM-DG-0280 |
| KB-TS-018 | FP-5031 Service Temporarily Degraded | 6 | FP-BM-SR-0277, FP-BM-DG-0280, FP-BM-MD-0281 |
| KB-TS-019 | 401 认证失败诊断决策树 | 2 | FP-BM-MS-0044, FP-BM-DG-0288 |
| KB-TS-020 | 403 套餐权限与 Production 暂停诊断 | 3 | FP-BM-SR-0013, FP-BM-MD-0014, FP-BM-MS-0016 |
| KB-TS-021 | Payment 失败与状态错误诊断 | 7 | FP-BM-SR-0113, FP-BM-MD-0114, FP-BM-TV-0116 |
| KB-TS-022 | 套餐用量、Runtime 保留期与 429 重试诊断 | 8 | FP-BM-MD-0078, FP-BM-MS-0080, FP-BM-MD-0082 |
| KB-TS-023 | Webhook 未收到与签名失败诊断 | 8 | FP-BM-DG-0220, FP-BM-DG-0224, FP-BM-SR-0237 |
| KB-TS-024 | 区分 500 内部错误与 503 服务降级 | 3 | FP-BM-DG-0280, FP-BM-MD-0281, FP-BM-DG-0284 |

## 5. 110 条 Canonical Rules 覆盖

| Rule ID | Questions | 示例题 |
| --- | ---: | --- |
| RULE-AUTH-001 | 17 | FP-BM-SR-0005, FP-BM-MD-0006, FP-BM-MH-0007 |
| RULE-AUTH-002 | 12 | FP-BM-MD-0006, FP-BM-MS-0008, FP-BM-SR-0037 |
| RULE-AUTH-003 | 12 | FP-BM-MS-0008, FP-BM-SR-0037, FP-BM-MD-0038 |
| RULE-AUTH-004 | 12 | FP-BM-MS-0008, FP-BM-SR-0037, FP-BM-MD-0038 |
| RULE-AUTH-005 | 11 | FP-BM-MS-0008, FP-BM-SR-0037, FP-BM-MD-0038 |
| RULE-AUTH-006 | 21 | FP-BM-MH-0007, FP-BM-MS-0008, FP-BM-MD-0010 |
| RULE-AUTH-007 | 23 | FP-BM-MH-0007, FP-BM-MS-0008, FP-BM-MD-0010 |
| RULE-AUTH-008 | 26 | FP-BM-MH-0007, FP-BM-MS-0008, FP-BM-MD-0010 |
| RULE-CUSTOMER-001 | 10 | FP-BM-SR-0089, FP-BM-MD-0090, FP-BM-MH-0091 |
| RULE-CUSTOMER-002 | 10 | FP-BM-SR-0089, FP-BM-MD-0090, FP-BM-MH-0091 |
| RULE-CUSTOMER-003 | 17 | FP-BM-SR-0089, FP-BM-MD-0090, FP-BM-MH-0091 |
| RULE-CUSTOMER-004 | 21 | FP-BM-MD-0026, FP-BM-MH-0027, FP-BM-MS-0028 |
| RULE-CUSTOMER-005 | 10 | FP-BM-SR-0089, FP-BM-MD-0090, FP-BM-MH-0091 |
| RULE-ENV-001 | 22 | FP-BM-MD-0002, FP-BM-MS-0004, FP-BM-SR-0005 |
| RULE-ENV-002 | 11 | FP-BM-SR-0005, FP-BM-MD-0006, FP-BM-MH-0007 |
| RULE-ENV-003 | 12 | FP-BM-MH-0007, FP-BM-MS-0008, FP-BM-MD-0010 |
| RULE-ENV-004 | 65 | FP-BM-MH-0007, FP-BM-MS-0008, FP-BM-MH-0011 |
| RULE-ENV-005 | 17 | FP-BM-MD-0006, FP-BM-MH-0007, FP-BM-MS-0008 |
| RULE-ERROR-001 | 29 | FP-BM-MD-0018, FP-BM-MH-0019, FP-BM-MS-0020 |
| RULE-ERROR-002 | 40 | FP-BM-MD-0014, FP-BM-MS-0016, FP-BM-MD-0018 |
| RULE-ERROR-003 | 20 | FP-BM-MH-0119, FP-BM-TV-0120, FP-BM-SR-0121 |
| RULE-ERROR-004 | 16 | FP-BM-MH-0119, FP-BM-TV-0120, FP-BM-SR-0121 |
| RULE-IDEMP-001 | 52 | FP-BM-SR-0021, FP-BM-MH-0023, FP-BM-MS-0024 |
| RULE-IDEMP-002 | 12 | FP-BM-SR-0061, FP-BM-MD-0062, FP-BM-MH-0063 |
| RULE-IDEMP-003 | 12 | FP-BM-SR-0061, FP-BM-MD-0062, FP-BM-MH-0063 |
| RULE-IDEMP-004 | 44 | FP-BM-SR-0021, FP-BM-MH-0023, FP-BM-MS-0024 |
| RULE-IDEMP-005 | 23 | FP-BM-SR-0021, FP-BM-MH-0023, FP-BM-MS-0024 |
| RULE-IDEMP-006 | 12 | FP-BM-SR-0061, FP-BM-MD-0062, FP-BM-MH-0063 |
| RULE-INVOICE-001 | 20 | FP-BM-SR-0189, FP-BM-MH-0190, FP-BM-MS-0191 |
| RULE-INVOICE-002 | 20 | FP-BM-SR-0189, FP-BM-MH-0190, FP-BM-MS-0191 |
| RULE-INVOICE-003 | 20 | FP-BM-SR-0189, FP-BM-MH-0190, FP-BM-MS-0191 |
| RULE-INVOICE-004 | 19 | FP-BM-SR-0189, FP-BM-MH-0190, FP-BM-MS-0191 |
| RULE-INVOICE-005 | 19 | FP-BM-SR-0189, FP-BM-MH-0190, FP-BM-MS-0191 |
| RULE-INVOICE-006 | 19 | FP-BM-SR-0189, FP-BM-MH-0190, FP-BM-MS-0191 |
| RULE-INVOICE-007 | 18 | FP-BM-MH-0190, FP-BM-MS-0191, FP-BM-TV-0192 |
| RULE-INVOICE-008 | 18 | FP-BM-MH-0190, FP-BM-MS-0191, FP-BM-TV-0192 |
| RULE-MONEY-001 | 36 | FP-BM-SR-0017, FP-BM-MD-0018, FP-BM-MH-0019 |
| RULE-MONEY-002 | 36 | FP-BM-SR-0017, FP-BM-MD-0018, FP-BM-MH-0019 |
| RULE-MONEY-003 | 34 | FP-BM-SR-0017, FP-BM-MD-0018, FP-BM-MH-0019 |
| RULE-MONEY-004 | 36 | FP-BM-SR-0017, FP-BM-MD-0018, FP-BM-MH-0019 |
| RULE-PAY-001 | 59 | FP-BM-MD-0002, FP-BM-MH-0003, FP-BM-MS-0004 |
| RULE-PAY-002 | 57 | FP-BM-SR-0057, FP-BM-MD-0058, FP-BM-MH-0059 |
| RULE-PAY-003 | 32 | FP-BM-SR-0057, FP-BM-MH-0059, FP-BM-MS-0060 |
| RULE-PAY-004 | 29 | FP-BM-MH-0059, FP-BM-MS-0060, FP-BM-SR-0093 |
| RULE-PAY-005 | 56 | FP-BM-SR-0021, FP-BM-MH-0023, FP-BM-MS-0024 |
| RULE-PAY-006 | 26 | FP-BM-SR-0021, FP-BM-MH-0023, FP-BM-MS-0024 |
| RULE-PAY-007 | 28 | FP-BM-MS-0056, FP-BM-MH-0059, FP-BM-MS-0060 |
| RULE-PLAN-001 | 43 | FP-BM-SR-0009, FP-BM-MD-0010, FP-BM-MS-0012 |
| RULE-PLAN-002 | 33 | FP-BM-SR-0009, FP-BM-MD-0010, FP-BM-MH-0011 |
| RULE-PLAN-003 | 65 | FP-BM-SR-0025, FP-BM-MH-0027, FP-BM-MS-0028 |
| RULE-PLAN-004 | 53 | FP-BM-SR-0009, FP-BM-MD-0010, FP-BM-MS-0012 |
| RULE-PLAN-005 | 31 | FP-BM-SR-0025, FP-BM-MH-0027, FP-BM-MS-0028 |
| RULE-RATE-001 | 16 | FP-BM-SR-0073, FP-BM-MD-0074, FP-BM-MH-0075 |
| RULE-RATE-002 | 15 | FP-BM-SR-0073, FP-BM-MD-0074, FP-BM-MH-0075 |
| RULE-RATE-003 | 16 | FP-BM-SR-0073, FP-BM-MD-0074, FP-BM-MH-0075 |
| RULE-RATE-004 | 16 | FP-BM-SR-0073, FP-BM-MD-0074, FP-BM-MH-0075 |
| RULE-RATE-005 | 15 | FP-BM-SR-0073, FP-BM-MD-0074, FP-BM-MH-0075 |
| RULE-RATE-006 | 15 | FP-BM-SR-0073, FP-BM-MD-0074, FP-BM-MH-0075 |
| RULE-RATE-007 | 21 | FP-BM-MS-0056, FP-BM-SR-0073, FP-BM-MD-0074 |
| RULE-REFUND-001 | 40 | FP-BM-MS-0056, FP-BM-SR-0093, FP-BM-MD-0094 |
| RULE-REFUND-002 | 27 | FP-BM-MS-0135, FP-BM-TV-0136, FP-BM-SR-0137 |
| RULE-REFUND-003 | 27 | FP-BM-MS-0135, FP-BM-TV-0136, FP-BM-SR-0137 |
| RULE-REFUND-004 | 32 | FP-BM-SR-0133, FP-BM-MD-0134, FP-BM-MS-0135 |
| RULE-REFUND-005 | 34 | FP-BM-SR-0133, FP-BM-MD-0134, FP-BM-MS-0135 |
| RULE-REFUND-006 | 30 | FP-BM-SR-0133, FP-BM-MD-0134, FP-BM-MS-0135 |
| RULE-REFUND-007 | 26 | FP-BM-MS-0135, FP-BM-TV-0136, FP-BM-MD-0138 |
| RULE-REFUND-008 | 29 | FP-BM-SR-0093, FP-BM-MD-0094, FP-BM-MS-0096 |
| RULE-REGION-001 | 17 | FP-BM-SR-0017, FP-BM-MD-0018, FP-BM-MH-0019 |
| RULE-REGION-002 | 9 | FP-BM-SR-0017, FP-BM-MD-0018, FP-BM-MH-0019 |
| RULE-REGION-003 | 19 | FP-BM-SR-0009, FP-BM-MD-0010, FP-BM-MS-0012 |
| RULE-REQ-001 | 15 | FP-BM-SR-0005, FP-BM-MD-0006, FP-BM-MH-0007 |
| RULE-REQ-002 | 4 | FP-BM-MD-0285, FP-BM-MH-0286, FP-BM-MS-0287 |
| RULE-REQ-003 | 22 | FP-BM-MD-0002, FP-BM-MH-0003, FP-BM-MS-0004 |
| RULE-SUB-001 | 22 | FP-BM-MD-0026, FP-BM-MH-0027, FP-BM-MS-0028 |
| RULE-SUB-002 | 22 | FP-BM-MD-0026, FP-BM-MH-0027, FP-BM-MS-0028 |
| RULE-SUB-003 | 22 | FP-BM-MD-0026, FP-BM-MH-0027, FP-BM-MS-0028 |
| RULE-SUB-004 | 17 | FP-BM-SR-0169, FP-BM-MS-0171, FP-BM-TV-0172 |
| RULE-SUB-005 | 19 | FP-BM-SR-0169, FP-BM-MS-0171, FP-BM-TV-0172 |
| RULE-SUB-006 | 22 | FP-BM-MD-0026, FP-BM-MH-0027, FP-BM-MS-0028 |
| RULE-TENANT-001 | 16 | FP-BM-SR-0001, FP-BM-MH-0003, FP-BM-MS-0004 |
| RULE-TENANT-002 | 9 | FP-BM-SR-0001, FP-BM-MD-0002, FP-BM-MH-0003 |
| RULE-TENANT-003 | 23 | FP-BM-SR-0001, FP-BM-MD-0002, FP-BM-MH-0003 |
| RULE-TENANT-004 | 20 | FP-BM-SR-0001, FP-BM-MD-0002, FP-BM-MH-0003 |
| RULE-VERSION-001 | 21 | FP-BM-SR-0005, FP-BM-MD-0006, FP-BM-MH-0007 |
| RULE-VERSION-002 | 21 | FP-BM-MD-0022, FP-BM-MS-0024, FP-BM-SR-0045 |
| RULE-VERSION-003 | 15 | FP-BM-SR-0005, FP-BM-MD-0006, FP-BM-MH-0007 |
| RULE-VERSION-004 | 14 | FP-BM-SR-0045, FP-BM-MD-0046, FP-BM-MH-0047 |
| RULE-VERSION-005 | 35 | FP-BM-MD-0002, FP-BM-MH-0003, FP-BM-MS-0004 |
| RULE-VERSION-006 | 8 | FP-BM-MD-0046, FP-BM-MH-0047, FP-BM-MS-0048 |
| RULE-VERSION-007 | 7 | FP-BM-MH-0047, FP-BM-MS-0048, FP-BM-SR-0049 |
| RULE-VERSION-008 | 7 | FP-BM-MH-0047, FP-BM-MS-0048, FP-BM-SR-0049 |
| RULE-VERSION-009 | 18 | FP-BM-SR-0045, FP-BM-MH-0047, FP-BM-MS-0048 |
| RULE-WEBHOOK-001 | 58 | FP-BM-MD-0034, FP-BM-MH-0035, FP-BM-MS-0036 |
| RULE-WEBHOOK-002 | 59 | FP-BM-MD-0034, FP-BM-MH-0035, FP-BM-MS-0036 |
| RULE-WEBHOOK-003 | 58 | FP-BM-MD-0034, FP-BM-MH-0035, FP-BM-MS-0036 |
| RULE-WEBHOOK-004 | 58 | FP-BM-MD-0034, FP-BM-MH-0035, FP-BM-MS-0036 |
| RULE-WEBHOOK-005 | 60 | FP-BM-MD-0034, FP-BM-MH-0035, FP-BM-MS-0036 |
| RULE-WEBHOOK-006 | 56 | FP-BM-MD-0086, FP-BM-MS-0088, FP-BM-MH-0210 |
| RULE-WEBHOOK-007 | 56 | FP-BM-MD-0086, FP-BM-MS-0088, FP-BM-MH-0210 |
| RULE-WEBHOOK-008 | 56 | FP-BM-MD-0086, FP-BM-MS-0088, FP-BM-MH-0210 |
| RULE-WEBHOOK-009 | 58 | FP-BM-MD-0046, FP-BM-MS-0048, FP-BM-MD-0086 |
| RULE-WEBHOOK-010 | 54 | FP-BM-MD-0086, FP-BM-MS-0088, FP-BM-MH-0210 |
| RULE-WEBHOOK-011 | 54 | FP-BM-MD-0086, FP-BM-MS-0088, FP-BM-MH-0210 |
| RULE-WEBHOOK-012 | 56 | FP-BM-MD-0086, FP-BM-MS-0088, FP-BM-MH-0210 |
| RULE-WEBHOOK-013 | 23 | FP-BM-DG-0220, FP-BM-DG-0224, FP-BM-SR-0237 |
| RULE-WEBHOOK-014 | 16 | FP-BM-SR-0261, FP-BM-MH-0262, FP-BM-MS-0263 |
| RULE-WEBHOOK-015 | 23 | FP-BM-DG-0220, FP-BM-DG-0224, FP-BM-SR-0237 |
| RULE-WEBHOOK-016 | 26 | FP-BM-MS-0052, FP-BM-MS-0056, FP-BM-DG-0220 |
| RULE-WEBHOOK-017 | 70 | FP-BM-MS-0052, FP-BM-MH-0210, FP-BM-MS-0211 |
| RULE-WEBHOOK-018 | 44 | FP-BM-MD-0086, FP-BM-MS-0088, FP-BM-DG-0220 |

## 6. 逐题矩阵

| Question | Split | Family | Type | Docs | Rules | Tools / Operations |
| --- | --- | --- | --- | --- | --- | --- |
| FP-BM-SR-0001 | dev | 001 | simple_retrieval | KB-BR-001 | RULE-TENANT-001, RULE-TENANT-002, RULE-TENANT-003, RULE-TENANT-004 | search_business_rules |
| FP-BM-MD-0002 | dev | 001 | multi_document | KB-API-014, KB-TS-012 | RULE-ENV-001, RULE-PAY-001, RULE-REQ-003, RULE-TENANT-002, RULE-TENANT-003, RULE-TENANT-004, RULE-VERSION-005 | search_api_docs, search_troubleshooting |
| FP-BM-MH-0003 | dev | 001 | multi_hop | KB-BR-001, KB-API-014 | RULE-PAY-001, RULE-REQ-003, RULE-TENANT-001, RULE-TENANT-002, RULE-TENANT-003, RULE-TENANT-004, RULE-VERSION-005 | query_accounts.get_account, query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-MS-0004 | dev | 001 | multi_source | KB-BR-001, KB-API-014, KB-TS-012 | RULE-ENV-001, RULE-PAY-001, RULE-REQ-003, RULE-TENANT-001, RULE-TENANT-002, RULE-TENANT-003, RULE-TENANT-004, RULE-VERSION-005 | query_accounts.get_account, query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-SR-0005 | test | 002 | simple_retrieval | KB-API-001 | RULE-AUTH-001, RULE-ENV-001, RULE-ENV-002, RULE-REQ-001, RULE-VERSION-001, RULE-VERSION-003 | search_api_docs |
| FP-BM-MD-0006 | test | 002 | multi_document | KB-CASE-001, KB-API-001 | RULE-AUTH-001, RULE-AUTH-002, RULE-ENV-001, RULE-ENV-002, RULE-ENV-005, RULE-REQ-001, RULE-TENANT-004, RULE-VERSION-001, RULE-VERSION-003 | search_support_cases, search_api_docs |
| FP-BM-MH-0007 | test | 002 | multi_hop | KB-BR-002, KB-API-001 | RULE-AUTH-001, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-002, RULE-ENV-003, RULE-ENV-004, RULE-ENV-005, RULE-REQ-001, RULE-VERSION-001, RULE-VERSION-003 | query_accounts.list_api_keys, query_payments.get_customer, get_runtime_state.get_request |
| FP-BM-MS-0008 | test | 002 | multi_source | KB-BR-002, KB-API-001, KB-API-003, KB-TS-005, KB-CASE-001 | RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-002, RULE-ENV-003, RULE-ENV-004, RULE-ENV-005, RULE-REQ-001, RULE-TENANT-004, RULE-VERSION-001, RULE-VERSION-003 | query_accounts.list_api_keys, query_payments.get_customer, get_runtime_state.get_request |
| FP-BM-SR-0009 | test | 003 | simple_retrieval | KB-TS-010 | RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004, RULE-REGION-003 | search_troubleshooting |
| FP-BM-MD-0010 | test | 003 | multi_document | KB-API-005, KB-TS-010 | RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-003, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004, RULE-REGION-003 | search_api_docs, search_troubleshooting |
| FP-BM-MH-0011 | test | 003 | multi_hop | KB-BR-002, KB-API-005 | RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-002, RULE-ENV-003, RULE-ENV-004, RULE-ENV-005, RULE-PLAN-002 | query_accounts.get_account, query_accounts.list_api_keys |
| FP-BM-MS-0012 | test | 003 | multi_source | KB-BR-002, KB-API-005, KB-TS-010 | RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-002, RULE-ENV-003, RULE-ENV-004, RULE-ENV-005, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004, RULE-REGION-003 | query_accounts.get_account, query_accounts.list_api_keys |
| FP-BM-SR-0013 | test | 004 | simple_retrieval | KB-TS-020 | RULE-AUTH-007, RULE-AUTH-008, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004 | search_troubleshooting |
| FP-BM-MD-0014 | test | 004 | multi_document | KB-TS-011, KB-TS-020 | RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-003, RULE-ERROR-002, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004 | search_troubleshooting |
| FP-BM-MH-0015 | test | 004 | multi_hop | KB-BR-002, KB-API-005 | RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-002, RULE-ENV-003, RULE-ENV-004, RULE-ENV-005, RULE-PLAN-002 | query_accounts.get_account, query_accounts.list_api_keys, get_runtime_state.list_requests |
| FP-BM-MS-0016 | test | 004 | multi_source | KB-BR-002, KB-API-005, KB-TS-011, KB-TS-020, KB-CASE-003 | RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-002, RULE-ENV-003, RULE-ENV-004, RULE-ENV-005, RULE-ERROR-002, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004 | query_accounts.get_account, query_accounts.list_api_keys, get_runtime_state.list_requests |
| FP-BM-SR-0017 | test | 005 | simple_retrieval | KB-BR-003 | RULE-MONEY-001, RULE-MONEY-002, RULE-MONEY-003, RULE-MONEY-004, RULE-REGION-001, RULE-REGION-002, RULE-REGION-003 | search_business_rules |
| FP-BM-MD-0018 | test | 005 | multi_document | KB-BR-003, KB-TS-001 | RULE-ERROR-001, RULE-ERROR-002, RULE-MONEY-001, RULE-MONEY-002, RULE-MONEY-003, RULE-MONEY-004, RULE-REGION-001, RULE-REGION-002, RULE-REGION-003 | search_business_rules, search_troubleshooting |
| FP-BM-MH-0019 | test | 005 | multi_hop | KB-BR-003, KB-TS-001 | RULE-ERROR-001, RULE-ERROR-002, RULE-MONEY-001, RULE-MONEY-002, RULE-MONEY-003, RULE-MONEY-004, RULE-REGION-001, RULE-REGION-002, RULE-REGION-003 | query_accounts.get_account, query_payments.get_customer, get_runtime_state.get_request |
| FP-BM-MS-0020 | test | 005 | multi_source | KB-BR-003, KB-TS-001 | RULE-ERROR-001, RULE-ERROR-002, RULE-MONEY-001, RULE-MONEY-002, RULE-MONEY-003, RULE-MONEY-004, RULE-REGION-001, RULE-REGION-002, RULE-REGION-003 | query_accounts.get_account, query_payments.get_customer, get_runtime_state.get_request |
| FP-BM-SR-0021 | dev | 006 | simple_retrieval | KB-API-013 | RULE-IDEMP-001, RULE-IDEMP-004, RULE-IDEMP-005, RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-005, RULE-PAY-006, RULE-REGION-001 | search_api_docs |
| FP-BM-MD-0022 | dev | 006 | multi_document | KB-API-002, KB-TS-001 | RULE-AUTH-001, RULE-ERROR-001, RULE-ERROR-002, RULE-MONEY-001, RULE-MONEY-002, RULE-REQ-001, RULE-VERSION-002, RULE-VERSION-003 | search_api_docs, search_troubleshooting |
| FP-BM-MH-0023 | dev | 006 | multi_hop | KB-BR-003, KB-API-013 | RULE-IDEMP-001, RULE-IDEMP-004, RULE-IDEMP-005, RULE-MONEY-001, RULE-MONEY-002, RULE-MONEY-003, RULE-MONEY-004, RULE-PAY-005, RULE-PAY-006, RULE-REGION-001, RULE-REGION-002, RULE-REGION-003 | query_payments.get_payment, get_runtime_state.list_requests |
| FP-BM-MS-0024 | dev | 006 | multi_source | KB-BR-003, KB-API-013, KB-API-002, KB-TS-001 | RULE-AUTH-001, RULE-ERROR-001, RULE-ERROR-002, RULE-IDEMP-001, RULE-IDEMP-004, RULE-IDEMP-005, RULE-MONEY-001, RULE-MONEY-002, RULE-MONEY-003, RULE-MONEY-004, RULE-PAY-005, RULE-PAY-006, RULE-REGION-001, RULE-REGION-002, RULE-REGION-003, RULE-REQ-001, RULE-VERSION-002, RULE-VERSION-003 | query_payments.get_payment, get_runtime_state.list_requests |
| FP-BM-SR-0025 | test | 007 | simple_retrieval | KB-BR-004 | RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005 | search_business_rules |
| FP-BM-MD-0026 | test | 007 | multi_document | KB-API-024, KB-TS-010 | RULE-CUSTOMER-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004, RULE-REGION-003, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-006 | search_api_docs, search_troubleshooting |
| FP-BM-MH-0027 | test | 007 | multi_hop | KB-BR-004, KB-API-024 | RULE-CUSTOMER-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-006 | query_accounts.get_account, query_accounts.get_feature_flags, query_payments.get_subscription, get_runtime_state.get_request |
| FP-BM-MS-0028 | test | 007 | multi_source | KB-BR-004, KB-API-024, KB-TS-010 | RULE-CUSTOMER-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005, RULE-REGION-003, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-006 | query_accounts.get_account, query_accounts.get_feature_flags, query_payments.get_subscription, get_runtime_state.get_request |
| FP-BM-SR-0029 | test | 008 | simple_retrieval | KB-API-005 | RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-003, RULE-PLAN-002 | search_api_docs |
| FP-BM-MD-0030 | test | 008 | multi_document | KB-BR-004, KB-API-005 | RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-003, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005 | search_business_rules, search_api_docs |
| FP-BM-MH-0031 | test | 008 | multi_hop | KB-BR-004, KB-API-005 | RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-003, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005 | query_accounts.get_plan_timeline, query_accounts.get_feature_flags, query_payments.get_subscription |
| FP-BM-MS-0032 | test | 008 | multi_source | KB-BR-004, KB-API-005 | RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-003, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005 | query_accounts.get_plan_timeline, query_accounts.get_feature_flags, query_payments.get_subscription |
| FP-BM-SR-0033 | test | 009 | simple_retrieval | KB-BR-004 | RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005 | search_business_rules |
| FP-BM-MD-0034 | test | 009 | multi_document | KB-BR-004, KB-API-029 | RULE-ENV-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005 | search_business_rules, search_api_docs |
| FP-BM-MH-0035 | test | 009 | multi_hop | KB-BR-004, KB-API-029 | RULE-ENV-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005 | query_accounts.get_plan_timeline, query_webhooks.list_endpoints |
| FP-BM-MS-0036 | test | 009 | multi_source | KB-BR-004, KB-API-029 | RULE-ENV-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005 | query_accounts.get_plan_timeline, query_webhooks.list_endpoints |
| FP-BM-SR-0037 | test | 010 | simple_retrieval | KB-BR-006 | RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008 | search_business_rules |
| FP-BM-MD-0038 | test | 010 | multi_document | KB-CASE-002, KB-API-003 | RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-005 | search_support_cases, search_api_docs |
| FP-BM-MH-0039 | test | 010 | multi_hop | KB-BR-006, KB-API-003 | RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-005 | query_accounts.list_api_keys, get_runtime_state.list_requests |
| FP-BM-MS-0040 | test | 010 | multi_source | KB-BR-006, KB-API-003, KB-CASE-002 | RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-005 | query_accounts.list_api_keys, get_runtime_state.list_requests |
| FP-BM-SR-0041 | dev | 011 | simple_retrieval | KB-TS-004 | RULE-AUTH-001, RULE-AUTH-003, RULE-AUTH-004, RULE-ERROR-002 | search_troubleshooting |
| FP-BM-MD-0042 | dev | 011 | multi_document | KB-API-003, KB-TS-004 | RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-005, RULE-ERROR-002 | search_api_docs, search_troubleshooting |
| FP-BM-MH-0043 | dev | 011 | multi_hop | KB-BR-006, KB-API-003 | RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-005 | query_accounts.list_api_keys, get_runtime_state.get_request |
| FP-BM-MS-0044 | dev | 011 | multi_source | KB-BR-006, KB-API-003, KB-TS-004, KB-TS-019 | RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-005, RULE-ERROR-002 | query_accounts.list_api_keys, get_runtime_state.get_request |
| FP-BM-SR-0045 | test | 012 | simple_retrieval | KB-API-006 | RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-VERSION-005, RULE-VERSION-009 | search_api_docs |
| FP-BM-MD-0046 | test | 012 | multi_document | KB-TS-002, KB-REL-001 | RULE-ERROR-001, RULE-IDEMP-001, RULE-PAY-001, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-VERSION-006, RULE-WEBHOOK-009 | search_troubleshooting, search_release_notes |
| FP-BM-MH-0047 | test | 012 | multi_hop | KB-BR-007, KB-API-006 | RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-VERSION-005, RULE-VERSION-006, RULE-VERSION-007, RULE-VERSION-008, RULE-VERSION-009 | query_accounts.get_account, get_runtime_state.get_request |
| FP-BM-MS-0048 | test | 012 | multi_source | KB-BR-007, KB-API-006, KB-TS-002, KB-REL-001, KB-REL-010 | RULE-ERROR-001, RULE-IDEMP-001, RULE-PAY-001, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-VERSION-005, RULE-VERSION-006, RULE-VERSION-007, RULE-VERSION-008, RULE-VERSION-009, RULE-WEBHOOK-009 | query_accounts.get_account, get_runtime_state.get_request |
| FP-BM-SR-0049 | test | 013 | simple_retrieval | KB-BR-007 | RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-VERSION-005, RULE-VERSION-006, RULE-VERSION-007, RULE-VERSION-008, RULE-VERSION-009 | search_business_rules |
| FP-BM-MD-0050 | test | 013 | multi_document | KB-REL-005, KB-API-018 | RULE-PAY-005, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009 | search_release_notes, search_api_docs |
| FP-BM-MH-0051 | test | 013 | multi_hop | KB-BR-007, KB-API-018 | RULE-PAY-005, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-VERSION-005, RULE-VERSION-006, RULE-VERSION-007, RULE-VERSION-008, RULE-VERSION-009 | query_accounts.get_account, query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-MS-0052 | test | 013 | multi_source | KB-BR-007, KB-API-018, KB-REL-004, KB-REL-005 | RULE-PAY-005, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-VERSION-005, RULE-VERSION-006, RULE-VERSION-007, RULE-VERSION-008, RULE-VERSION-009, RULE-WEBHOOK-016, RULE-WEBHOOK-017 | query_accounts.get_account, query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-SR-0053 | test | 014 | simple_retrieval | KB-API-018 | RULE-PAY-005, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009 | search_api_docs |
| FP-BM-MD-0054 | test | 014 | multi_document | KB-API-018, KB-TS-003 | RULE-PAY-005, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009 | search_api_docs, search_troubleshooting |
| FP-BM-MH-0055 | test | 014 | multi_hop | KB-BR-007, KB-API-018 | RULE-PAY-005, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-VERSION-005, RULE-VERSION-006, RULE-VERSION-007, RULE-VERSION-008, RULE-VERSION-009 | query_accounts.get_account, query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-MS-0056 | test | 014 | multi_source | KB-BR-007, KB-API-018, KB-TS-003, KB-REL-007, KB-REL-008, KB-CASE-007 | RULE-PAY-005, RULE-PAY-007, RULE-RATE-007, RULE-REFUND-001, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-VERSION-005, RULE-VERSION-006, RULE-VERSION-007, RULE-VERSION-008, RULE-VERSION-009, RULE-WEBHOOK-016 | query_accounts.get_account, query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-SR-0057 | test | 015 | simple_retrieval | KB-REL-003 | RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-005, RULE-VERSION-002, RULE-VERSION-009 | search_release_notes |
| FP-BM-MD-0058 | test | 015 | multi_document | KB-API-018, KB-TS-008 | RULE-PAY-001, RULE-PAY-002, RULE-PAY-005, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009 | search_api_docs, search_troubleshooting |
| FP-BM-MH-0059 | test | 015 | multi_hop | KB-BR-010, KB-API-018 | RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.list_requests |
| FP-BM-MS-0060 | test | 015 | multi_source | KB-BR-010, KB-API-018, KB-TS-008, KB-REL-002, KB-REL-003 | RULE-IDEMP-005, RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.list_requests |
| FP-BM-SR-0061 | dev | 016 | simple_retrieval | KB-API-033 | RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006, RULE-REQ-003 | search_api_docs |
| FP-BM-MD-0062 | dev | 016 | multi_document | KB-BR-008, KB-API-033 | RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006, RULE-REQ-003 | search_business_rules, search_api_docs |
| FP-BM-MH-0063 | dev | 016 | multi_hop | KB-BR-008, KB-API-033 | RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006, RULE-REQ-003 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.list_requests |
| FP-BM-MS-0064 | dev | 016 | multi_source | KB-BR-008, KB-API-033 | RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006, RULE-REQ-003 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.list_requests |
| FP-BM-SR-0065 | test | 017 | simple_retrieval | KB-BR-008 | RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006 | search_business_rules |
| FP-BM-MD-0066 | test | 017 | multi_document | KB-API-033, KB-TS-013 | RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006, RULE-REQ-003 | search_api_docs, search_troubleshooting |
| FP-BM-MH-0067 | test | 017 | multi_hop | KB-BR-008, KB-API-033 | RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006, RULE-REQ-003 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.list_requests |
| FP-BM-MS-0068 | test | 017 | multi_source | KB-BR-008, KB-API-033, KB-TS-013, KB-CASE-004 | RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006, RULE-REQ-003 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.list_requests |
| FP-BM-SR-0069 | test | 018 | simple_retrieval | KB-TS-013 | RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006 | search_troubleshooting |
| FP-BM-MD-0070 | test | 018 | multi_document | KB-TS-013, KB-API-033 | RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006, RULE-REQ-003 | search_troubleshooting, search_api_docs |
| FP-BM-MH-0071 | test | 018 | multi_hop | KB-BR-008, KB-API-033 | RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006, RULE-REQ-003 | query_payments.list_payments, get_runtime_state.list_requests |
| FP-BM-MS-0072 | test | 018 | multi_source | KB-BR-008, KB-API-033, KB-TS-013 | RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006, RULE-REQ-003 | query_payments.list_payments, get_runtime_state.list_requests |
| FP-BM-SR-0073 | test | 019 | simple_retrieval | KB-API-034 | RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | search_api_docs |
| FP-BM-MD-0074 | test | 019 | multi_document | KB-TS-016, KB-API-004 | RULE-AUTH-008, RULE-ENV-001, RULE-ENV-002, RULE-ENV-004, RULE-ENV-005, RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | search_troubleshooting, search_api_docs |
| FP-BM-MH-0075 | test | 019 | multi_hop | KB-BR-005, KB-API-004 | RULE-AUTH-008, RULE-ENV-001, RULE-ENV-002, RULE-ENV-004, RULE-ENV-005, RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | query_accounts.get_account, get_runtime_state.get_usage, get_runtime_state.list_requests |
| FP-BM-MS-0076 | test | 019 | multi_source | KB-BR-005, KB-API-004, KB-API-034, KB-TS-016 | RULE-AUTH-008, RULE-ENV-001, RULE-ENV-002, RULE-ENV-004, RULE-ENV-005, RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | query_accounts.get_account, get_runtime_state.get_usage, get_runtime_state.list_requests |
| FP-BM-SR-0077 | test | 020 | simple_retrieval | KB-CASE-005 | RULE-PLAN-005, RULE-RATE-001, RULE-RATE-003, RULE-RATE-004, RULE-RATE-007 | search_support_cases |
| FP-BM-MD-0078 | test | 020 | multi_document | KB-API-034, KB-TS-022 | RULE-PLAN-001, RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | search_api_docs, search_troubleshooting |
| FP-BM-MH-0079 | test | 020 | multi_hop | KB-BR-005, KB-API-034 | RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | query_accounts.get_account, query_accounts.get_plan_timeline, get_runtime_state.get_usage, get_runtime_state.list_requests |
| FP-BM-MS-0080 | test | 020 | multi_source | KB-BR-005, KB-API-034, KB-TS-022, KB-CASE-005 | RULE-PLAN-001, RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | query_accounts.get_account, query_accounts.get_plan_timeline, get_runtime_state.get_usage, get_runtime_state.list_requests |
| FP-BM-SR-0081 | dev | 021 | simple_retrieval | KB-BR-005 | RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | search_business_rules |
| FP-BM-MD-0082 | dev | 021 | multi_document | KB-TS-022, KB-CASE-006 | RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | search_troubleshooting, search_support_cases |
| FP-BM-MH-0083 | dev | 021 | multi_hop | KB-BR-005, KB-API-034 | RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | query_accounts.get_plan_timeline, get_runtime_state.get_usage, get_runtime_state.list_requests |
| FP-BM-MS-0084 | dev | 021 | multi_source | KB-BR-005, KB-API-034, KB-TS-022, KB-CASE-006 | RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | query_accounts.get_plan_timeline, get_runtime_state.get_usage, get_runtime_state.list_requests |
| FP-BM-SR-0085 | test | 022 | simple_retrieval | KB-BR-005 | RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | search_business_rules |
| FP-BM-MD-0086 | test | 022 | multi_document | KB-API-032, KB-API-034 | RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-018 | search_api_docs |
| FP-BM-MH-0087 | test | 022 | multi_hop | KB-BR-005, KB-API-034 | RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007 | query_webhooks.get_delivery, get_runtime_state.get_usage, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0088 | test | 022 | multi_source | KB-BR-005, KB-API-034, KB-API-032 | RULE-PLAN-005, RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-018 | query_webhooks.get_delivery, get_runtime_state.get_usage, get_runtime_state.get_delivery_timeline |
| FP-BM-SR-0089 | test | 023 | simple_retrieval | KB-API-009 | RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005, RULE-TENANT-001, RULE-TENANT-004 | search_api_docs |
| FP-BM-MD-0090 | test | 023 | multi_document | KB-API-009, KB-API-011 | RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005, RULE-TENANT-001, RULE-TENANT-003, RULE-TENANT-004 | search_api_docs |
| FP-BM-MH-0091 | test | 023 | multi_hop | KB-BR-009, KB-API-009 | RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005, RULE-TENANT-001, RULE-TENANT-004 | query_payments.get_customer, query_payments.list_customers, query_payments.get_payment |
| FP-BM-MS-0092 | test | 023 | multi_source | KB-BR-009, KB-API-009, KB-API-011 | RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005, RULE-TENANT-001, RULE-TENANT-003, RULE-TENANT-004 | query_payments.get_customer, query_payments.list_customers, query_payments.get_payment |
| FP-BM-SR-0093 | test | 024 | simple_retrieval | KB-TS-014 | RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-REFUND-001, RULE-REFUND-008 | search_troubleshooting |
| FP-BM-MD-0094 | test | 024 | multi_document | KB-API-013, KB-TS-014 | RULE-IDEMP-001, RULE-IDEMP-004, RULE-IDEMP-005, RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-REFUND-001, RULE-REFUND-008, RULE-REGION-001 | search_api_docs, search_troubleshooting |
| FP-BM-MH-0095 | test | 024 | multi_hop | KB-BR-009, KB-API-011 | RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005, RULE-TENANT-003 | query_payments.get_customer, query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-MS-0096 | test | 024 | multi_source | KB-BR-009, KB-API-011, KB-API-013, KB-TS-014 | RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005, RULE-IDEMP-001, RULE-IDEMP-004, RULE-IDEMP-005, RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-REFUND-001, RULE-REFUND-008, RULE-REGION-001, RULE-TENANT-003 | query_payments.get_customer, query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-SR-0097 | test | 025 | simple_retrieval | KB-BR-009 | RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005 | search_business_rules |
| FP-BM-MD-0098 | test | 025 | multi_document | KB-API-009, KB-API-010 | RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005, RULE-REQ-001, RULE-TENANT-001, RULE-TENANT-004 | search_api_docs |
| FP-BM-MH-0099 | test | 025 | multi_hop | KB-BR-009, KB-API-009 | RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005, RULE-TENANT-001, RULE-TENANT-004 | query_payments.get_customer, query_payments.list_customers, query_payments.list_payments |
| FP-BM-MS-0100 | test | 025 | multi_source | KB-BR-009, KB-API-009, KB-API-010 | RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005, RULE-REQ-001, RULE-TENANT-001, RULE-TENANT-004 | query_payments.get_customer, query_payments.list_customers, query_payments.list_payments |
| FP-BM-SR-0101 | dev | 026 | simple_retrieval | KB-BR-010 | RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007 | search_business_rules |
| FP-BM-MD-0102 | dev | 026 | multi_document | KB-API-017, KB-API-015 | RULE-PAY-001, RULE-PAY-003, RULE-PAY-005, RULE-TENANT-001, RULE-TENANT-004 | search_api_docs |
| FP-BM-MH-0103 | dev | 026 | multi_hop | KB-BR-010, KB-API-015 | RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.get_request |
| FP-BM-TV-0104 | dev | 026 | temporal_versioned | KB-BR-010, KB-API-015, KB-API-012, KB-API-014, KB-API-017 | RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007, RULE-REQ-003, RULE-TENANT-001, RULE-TENANT-002, RULE-TENANT-003, RULE-TENANT-004, RULE-VERSION-005 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.get_request |
| FP-BM-SR-0105 | test | 027 | simple_retrieval | KB-BR-010 | RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007 | search_business_rules |
| FP-BM-MD-0106 | test | 027 | multi_document | KB-BR-010, KB-API-015 | RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007 | search_business_rules, search_api_docs |
| FP-BM-MH-0107 | test | 027 | multi_hop | KB-BR-010, KB-API-015 | RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007 | query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-TV-0108 | test | 027 | temporal_versioned | KB-BR-010, KB-API-015 | RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007 | query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-SR-0109 | test | 028 | simple_retrieval | KB-BR-010 | RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007 | search_business_rules |
| FP-BM-MD-0110 | test | 028 | multi_document | KB-TS-014, KB-API-016 | RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-REFUND-001, RULE-REFUND-008 | search_troubleshooting, search_api_docs |
| FP-BM-MH-0111 | test | 028 | multi_hop | KB-BR-010, KB-API-016 | RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007 | query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-TV-0112 | test | 028 | temporal_versioned | KB-BR-010, KB-API-016, KB-TS-014 | RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007, RULE-REFUND-001, RULE-REFUND-008 | query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-SR-0113 | test | 029 | simple_retrieval | KB-TS-021 | RULE-ERROR-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005 | search_troubleshooting |
| FP-BM-MD-0114 | test | 029 | multi_document | KB-TS-021, KB-CASE-009 | RULE-ERROR-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005 | search_troubleshooting, search_support_cases |
| FP-BM-MH-0115 | test | 029 | multi_hop | KB-BR-010, KB-API-012 | RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.list_requests |
| FP-BM-TV-0116 | test | 029 | temporal_versioned | KB-BR-010, KB-API-012, KB-API-017, KB-TS-021, KB-CASE-009 | RULE-ERROR-002, RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007, RULE-TENANT-001, RULE-TENANT-004 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.list_requests |
| FP-BM-SR-0117 | test | 030 | simple_retrieval | KB-TS-006 | RULE-ERROR-002, RULE-PAY-001, RULE-PAY-002 | search_troubleshooting |
| FP-BM-MD-0118 | test | 030 | multi_document | KB-TS-006, KB-API-013 | RULE-ERROR-002, RULE-IDEMP-001, RULE-IDEMP-004, RULE-IDEMP-005, RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005, RULE-PAY-006, RULE-REGION-001 | search_troubleshooting, search_api_docs |
| FP-BM-MH-0119 | test | 030 | multi_hop | KB-BR-011, KB-API-013 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-IDEMP-005, RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005, RULE-PAY-006, RULE-REGION-001 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.get_request, get_runtime_state.get_service_status |
| FP-BM-TV-0120 | test | 030 | temporal_versioned | KB-BR-011, KB-API-013, KB-TS-006 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-IDEMP-005, RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005, RULE-PAY-006, RULE-REGION-001 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.get_request, get_runtime_state.get_service_status |
| FP-BM-SR-0121 | dev | 031 | simple_retrieval | KB-BR-011 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005 | search_business_rules |
| FP-BM-MD-0122 | dev | 031 | multi_document | KB-TS-007, KB-TS-021 | RULE-ERROR-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005 | search_troubleshooting |
| FP-BM-MS-0123 | dev | 031 | multi_source | KB-BR-011, KB-TS-007 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.get_request |
| FP-BM-TV-0124 | dev | 031 | temporal_versioned | KB-BR-011, KB-TS-007, KB-TS-021 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.get_request |
| FP-BM-SR-0125 | test | 032 | simple_retrieval | KB-TS-009 | RULE-ERROR-002, RULE-PAY-001, RULE-PAY-002 | search_troubleshooting |
| FP-BM-MD-0126 | test | 032 | multi_document | KB-TS-021, KB-TS-009 | RULE-ERROR-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005 | search_troubleshooting |
| FP-BM-MS-0127 | test | 032 | multi_source | KB-BR-011, KB-TS-009 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.get_request |
| FP-BM-TV-0128 | test | 032 | temporal_versioned | KB-BR-011, KB-TS-009, KB-TS-021 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005 | query_payments.get_payment, query_payments.list_payments, get_runtime_state.get_request |
| FP-BM-SR-0129 | test | 033 | simple_retrieval | KB-BR-011 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005 | search_business_rules |
| FP-BM-MD-0130 | test | 033 | multi_document | KB-TS-008, KB-REL-003 | RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-005, RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009 | search_troubleshooting, search_release_notes |
| FP-BM-MS-0131 | test | 033 | multi_source | KB-BR-011, KB-API-018 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009 | query_accounts.get_account, query_payments.list_payments, get_runtime_state.list_requests |
| FP-BM-TV-0132 | test | 033 | temporal_versioned | KB-BR-011, KB-API-018, KB-TS-008, KB-REL-003 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-005, RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009 | query_accounts.get_account, query_payments.list_payments, get_runtime_state.list_requests |
| FP-BM-SR-0133 | test | 034 | simple_retrieval | KB-API-019 | RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006 | search_api_docs |
| FP-BM-MD-0134 | test | 034 | multi_document | KB-CASE-010, KB-API-019 | RULE-MONEY-003, RULE-MONEY-004, RULE-PAY-001, RULE-PAY-004, RULE-REFUND-001, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-008 | search_support_cases, search_api_docs |
| FP-BM-MS-0135 | test | 034 | multi_source | KB-BR-012, KB-API-019 | RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | query_payments.get_payment, query_payments.get_refund, get_runtime_state.get_request |
| FP-BM-TV-0136 | test | 034 | temporal_versioned | KB-BR-012, KB-API-019, KB-TS-014, KB-CASE-010 | RULE-MONEY-003, RULE-MONEY-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | query_payments.get_payment, query_payments.get_refund, get_runtime_state.get_request |
| FP-BM-SR-0137 | test | 035 | simple_retrieval | KB-CASE-011 | RULE-PLAN-001, RULE-PLAN-004, RULE-REFUND-002, RULE-REFUND-003 | search_support_cases |
| FP-BM-MD-0138 | test | 035 | multi_document | KB-API-020, KB-API-021 | RULE-IDEMP-001, RULE-IDEMP-004, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | search_api_docs |
| FP-BM-MS-0139 | test | 035 | multi_source | KB-BR-012, KB-API-020 | RULE-IDEMP-001, RULE-IDEMP-004, RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | query_accounts.get_account, query_payments.get_payment, query_payments.get_refund, get_runtime_state.get_request |
| FP-BM-TV-0140 | test | 035 | temporal_versioned | KB-BR-012, KB-API-020, KB-API-021, KB-TS-010, KB-CASE-011 | RULE-IDEMP-001, RULE-IDEMP-004, RULE-MONEY-003, RULE-MONEY-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008, RULE-REGION-003 | query_accounts.get_account, query_payments.get_payment, query_payments.get_refund, get_runtime_state.get_request |
| FP-BM-SR-0141 | dev | 036 | simple_retrieval | KB-API-022 | RULE-MONEY-004, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-TENANT-003 | search_api_docs |
| FP-BM-MD-0142 | dev | 036 | multi_document | KB-API-022, KB-API-021 | RULE-IDEMP-001, RULE-MONEY-004, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-TENANT-003 | search_api_docs |
| FP-BM-MS-0143 | dev | 036 | multi_source | KB-BR-012, KB-API-021 | RULE-IDEMP-001, RULE-MONEY-003, RULE-MONEY-004, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | query_accounts.get_account, query_payments.get_payment, query_payments.get_refund |
| FP-BM-TV-0144 | dev | 036 | temporal_versioned | KB-BR-012, KB-API-021, KB-API-022 | RULE-IDEMP-001, RULE-MONEY-003, RULE-MONEY-004, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008, RULE-TENANT-003 | query_accounts.get_account, query_payments.get_payment, query_payments.get_refund |
| FP-BM-SR-0145 | test | 037 | simple_retrieval | KB-BR-012 | RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | search_business_rules |
| FP-BM-MD-0146 | test | 037 | multi_document | KB-API-019, KB-API-022 | RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-TENANT-003 | search_api_docs |
| FP-BM-MS-0147 | test | 037 | multi_source | KB-BR-012, KB-API-019 | RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | query_payments.get_payment, query_payments.get_refund |
| FP-BM-TV-0148 | test | 037 | temporal_versioned | KB-BR-012, KB-API-019, KB-API-022 | RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008, RULE-TENANT-003 | query_payments.get_payment, query_payments.get_refund |
| FP-BM-SR-0149 | test | 038 | simple_retrieval | KB-API-019 | RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006 | search_api_docs |
| FP-BM-MD-0150 | test | 038 | multi_document | KB-API-022, KB-API-019 | RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-TENANT-003 | search_api_docs |
| FP-BM-MS-0151 | test | 038 | multi_source | KB-BR-012, KB-API-019 | RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | query_payments.get_payment, query_payments.get_refund |
| FP-BM-TV-0152 | test | 038 | temporal_versioned | KB-BR-012, KB-API-019, KB-API-022 | RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008, RULE-TENANT-003 | query_payments.get_payment, query_payments.get_refund |
| FP-BM-SR-0153 | test | 039 | simple_retrieval | KB-TS-015 | RULE-REFUND-001, RULE-REFUND-005 | search_troubleshooting |
| FP-BM-MD-0154 | test | 039 | multi_document | KB-TS-015, KB-CASE-012 | RULE-REFUND-001, RULE-REFUND-005 | search_troubleshooting, search_support_cases |
| FP-BM-MS-0155 | test | 039 | multi_source | KB-BR-012, KB-API-020 | RULE-IDEMP-001, RULE-IDEMP-004, RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | query_payments.get_payment, query_payments.get_refund, get_runtime_state.get_request |
| FP-BM-TV-0156 | test | 039 | temporal_versioned | KB-BR-012, KB-API-020, KB-TS-015, KB-CASE-012 | RULE-IDEMP-001, RULE-IDEMP-004, RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | query_payments.get_payment, query_payments.get_refund, get_runtime_state.get_request |
| FP-BM-SR-0157 | test | 040 | simple_retrieval | KB-API-021 | RULE-IDEMP-001, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-007 | search_api_docs |
| FP-BM-MD-0158 | test | 040 | multi_document | KB-BR-012, KB-API-021 | RULE-IDEMP-001, RULE-MONEY-003, RULE-MONEY-004, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | search_business_rules, search_api_docs |
| FP-BM-MS-0159 | test | 040 | multi_source | KB-BR-012, KB-API-021 | RULE-IDEMP-001, RULE-MONEY-003, RULE-MONEY-004, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | query_accounts.get_account, query_accounts.get_feature_flags, query_payments.get_payment, query_payments.get_refund |
| FP-BM-TV-0160 | test | 040 | temporal_versioned | KB-BR-012, KB-API-021 | RULE-IDEMP-001, RULE-MONEY-003, RULE-MONEY-004, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | query_accounts.get_account, query_accounts.get_feature_flags, query_payments.get_payment, query_payments.get_refund |
| FP-BM-SR-0161 | dev | 041 | simple_retrieval | KB-BR-003 | RULE-MONEY-001, RULE-MONEY-002, RULE-MONEY-003, RULE-MONEY-004, RULE-REGION-001, RULE-REGION-002, RULE-REGION-003 | search_business_rules |
| FP-BM-MD-0162 | dev | 041 | multi_document | KB-BR-012, KB-API-021 | RULE-IDEMP-001, RULE-MONEY-003, RULE-MONEY-004, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | search_business_rules, search_api_docs |
| FP-BM-MS-0163 | dev | 041 | multi_source | KB-BR-003, KB-BR-012 | RULE-MONEY-001, RULE-MONEY-002, RULE-MONEY-003, RULE-MONEY-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008, RULE-REGION-001, RULE-REGION-002, RULE-REGION-003 | query_accounts.get_account, query_accounts.get_feature_flags, query_payments.get_payment, query_payments.get_refund |
| FP-BM-TV-0164 | dev | 041 | temporal_versioned | KB-BR-003, KB-BR-012, KB-API-021, KB-TS-010 | RULE-IDEMP-001, RULE-MONEY-001, RULE-MONEY-002, RULE-MONEY-003, RULE-MONEY-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008, RULE-REGION-001, RULE-REGION-002, RULE-REGION-003 | query_accounts.get_account, query_accounts.get_feature_flags, query_payments.get_payment, query_payments.get_refund |
| FP-BM-SR-0165 | test | 042 | simple_retrieval | KB-API-021 | RULE-IDEMP-001, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-007 | search_api_docs |
| FP-BM-MD-0166 | test | 042 | multi_document | KB-API-021, KB-BR-012 | RULE-IDEMP-001, RULE-MONEY-003, RULE-MONEY-004, RULE-PLAN-004, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | search_api_docs, search_business_rules |
| FP-BM-MS-0167 | test | 042 | multi_source | KB-BR-004, KB-BR-012 | RULE-MONEY-003, RULE-MONEY-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | query_accounts.get_account, query_accounts.get_feature_flags, query_payments.get_payment, query_payments.get_refund, get_runtime_state.list_requests |
| FP-BM-TV-0168 | test | 042 | temporal_versioned | KB-BR-004, KB-BR-012, KB-API-021 | RULE-IDEMP-001, RULE-MONEY-003, RULE-MONEY-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005, RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008 | query_accounts.get_account, query_accounts.get_feature_flags, query_payments.get_payment, query_payments.get_refund, get_runtime_state.list_requests |
| FP-BM-SR-0169 | test | 043 | simple_retrieval | KB-BR-013 | RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | search_business_rules |
| FP-BM-MD-0170 | test | 043 | multi_document | KB-API-024, KB-TS-010 | RULE-CUSTOMER-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004, RULE-REGION-003, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-006 | search_api_docs, search_troubleshooting |
| FP-BM-MS-0171 | test | 043 | multi_source | KB-BR-013, KB-API-024 | RULE-CUSTOMER-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-PLAN-001, RULE-PLAN-004, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | query_accounts.get_account, query_accounts.get_feature_flags, query_payments.get_customer, query_payments.get_subscription, get_runtime_state.get_request |
| FP-BM-TV-0172 | test | 043 | temporal_versioned | KB-BR-013, KB-API-024, KB-TS-010 | RULE-CUSTOMER-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004, RULE-REGION-003, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | query_accounts.get_account, query_accounts.get_feature_flags, query_payments.get_customer, query_payments.get_subscription, get_runtime_state.get_request |
| FP-BM-SR-0173 | test | 044 | simple_retrieval | KB-API-024 | RULE-CUSTOMER-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-PLAN-001, RULE-PLAN-004, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-006 | search_api_docs |
| FP-BM-MD-0174 | test | 044 | multi_document | KB-TS-001, KB-API-024 | RULE-CUSTOMER-004, RULE-ERROR-001, RULE-ERROR-002, RULE-IDEMP-001, RULE-IDEMP-004, RULE-MONEY-001, RULE-MONEY-002, RULE-PLAN-001, RULE-PLAN-004, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-006 | search_troubleshooting, search_api_docs |
| FP-BM-MS-0175 | test | 044 | multi_source | KB-BR-013, KB-API-024 | RULE-CUSTOMER-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-PLAN-001, RULE-PLAN-004, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | query_payments.get_subscription, get_runtime_state.list_requests |
| FP-BM-TV-0176 | test | 044 | temporal_versioned | KB-BR-013, KB-API-024, KB-TS-001 | RULE-CUSTOMER-004, RULE-ERROR-001, RULE-ERROR-002, RULE-IDEMP-001, RULE-IDEMP-004, RULE-MONEY-001, RULE-MONEY-002, RULE-PLAN-001, RULE-PLAN-004, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | query_payments.get_subscription, get_runtime_state.list_requests |
| FP-BM-SR-0177 | test | 045 | simple_retrieval | KB-BR-013 | RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | search_business_rules |
| FP-BM-MD-0178 | test | 045 | multi_document | KB-BR-013, KB-API-025 | RULE-CUSTOMER-003, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | search_business_rules, search_api_docs |
| FP-BM-MS-0179 | test | 045 | multi_source | KB-BR-013, KB-API-025 | RULE-CUSTOMER-003, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | query_payments.get_subscription |
| FP-BM-TV-0180 | test | 045 | temporal_versioned | KB-BR-013, KB-API-025 | RULE-CUSTOMER-003, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | query_payments.get_subscription |
| FP-BM-SR-0181 | dev | 046 | simple_retrieval | KB-API-025 | RULE-CUSTOMER-003, RULE-SUB-004, RULE-SUB-005 | search_api_docs |
| FP-BM-MH-0182 | dev | 046 | multi_hop | KB-BR-013, KB-API-025 | RULE-CUSTOMER-003, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | query_payments.get_subscription, get_runtime_state.list_requests |
| FP-BM-MS-0183 | dev | 046 | multi_source | KB-BR-013, KB-API-025 | RULE-CUSTOMER-003, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | query_payments.get_subscription, get_runtime_state.list_requests |
| FP-BM-TV-0184 | dev | 046 | temporal_versioned | KB-BR-013, KB-API-025 | RULE-CUSTOMER-003, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | query_payments.get_subscription, get_runtime_state.list_requests |
| FP-BM-SR-0185 | test | 047 | simple_retrieval | KB-API-023 | RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | search_api_docs |
| FP-BM-MH-0186 | test | 047 | multi_hop | KB-BR-013, KB-API-023 | RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | query_payments.get_customer, query_payments.get_subscription, get_runtime_state.get_request |
| FP-BM-MS-0187 | test | 047 | multi_source | KB-BR-013, KB-API-023 | RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | query_payments.get_customer, query_payments.get_subscription, get_runtime_state.get_request |
| FP-BM-TV-0188 | test | 047 | temporal_versioned | KB-BR-013, KB-API-023, KB-API-024 | RULE-CUSTOMER-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-PLAN-001, RULE-PLAN-004, RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006 | query_payments.get_customer, query_payments.get_subscription, get_runtime_state.get_request |
| FP-BM-SR-0189 | test | 048 | simple_retrieval | KB-API-027 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-PAY-002 | search_api_docs |
| FP-BM-MH-0190 | test | 048 | multi_hop | KB-BR-014, KB-API-026 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008 | query_payments.get_payment, query_payments.get_subscription, query_payments.get_invoice_timeline |
| FP-BM-MS-0191 | test | 048 | multi_source | KB-BR-014, KB-API-026 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008 | query_payments.get_payment, query_payments.get_subscription, query_payments.get_invoice_timeline |
| FP-BM-TV-0192 | test | 048 | temporal_versioned | KB-BR-014, KB-API-026, KB-API-027, KB-API-028, KB-CASE-013 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008, RULE-PAY-002, RULE-SUB-005, RULE-TENANT-003 | query_payments.get_payment, query_payments.get_subscription, query_payments.get_invoice_timeline |
| FP-BM-SR-0193 | test | 049 | simple_retrieval | KB-BR-014 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008 | search_business_rules |
| FP-BM-MH-0194 | test | 049 | multi_hop | KB-BR-014, KB-API-027 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008, RULE-PAY-002 | query_payments.get_payment, query_payments.get_subscription, query_payments.get_invoice_timeline |
| FP-BM-MS-0195 | test | 049 | multi_source | KB-BR-014, KB-API-027 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008, RULE-PAY-002 | query_payments.get_payment, query_payments.get_subscription, query_payments.get_invoice_timeline |
| FP-BM-TV-0196 | test | 049 | temporal_versioned | KB-BR-014, KB-API-027, KB-API-028 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008, RULE-PAY-002, RULE-TENANT-003 | query_payments.get_payment, query_payments.get_subscription, query_payments.get_invoice_timeline |
| FP-BM-SR-0197 | test | 050 | simple_retrieval | KB-API-027 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-PAY-002 | search_api_docs |
| FP-BM-MH-0198 | test | 050 | multi_hop | KB-BR-014, KB-API-027 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008, RULE-PAY-002 | query_payments.get_payment, query_payments.get_subscription, query_payments.get_invoice_timeline |
| FP-BM-MS-0199 | test | 050 | multi_source | KB-BR-014, KB-API-027 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008, RULE-PAY-002 | query_payments.get_payment, query_payments.get_subscription, query_payments.get_invoice_timeline |
| FP-BM-TV-0200 | test | 050 | temporal_versioned | KB-BR-014, KB-API-027, KB-API-028, KB-CASE-014 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008, RULE-PAY-002, RULE-SUB-005, RULE-TENANT-003 | query_payments.get_payment, query_payments.get_subscription, query_payments.get_invoice_timeline |
| FP-BM-SR-0201 | dev | 051 | simple_retrieval | KB-BR-014 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008 | search_business_rules |
| FP-BM-MH-0202 | dev | 051 | multi_hop | KB-BR-014, KB-API-026 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008 | query_payments.get_invoice_timeline, get_runtime_state.get_request |
| FP-BM-MS-0203 | dev | 051 | multi_source | KB-BR-014, KB-API-026 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008 | query_payments.get_invoice_timeline, get_runtime_state.get_request |
| FP-BM-DG-0204 | dev | 051 | tool_use_diagnostic | KB-BR-014, KB-API-026 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008 | query_payments.get_invoice_timeline, get_runtime_state.get_request |
| FP-BM-SR-0205 | test | 052 | simple_retrieval | KB-API-026 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-007, RULE-INVOICE-008 | search_api_docs |
| FP-BM-MH-0206 | test | 052 | multi_hop | KB-BR-014, KB-API-026 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008 | query_payments.get_invoice_timeline, get_runtime_state.list_requests |
| FP-BM-MS-0207 | test | 052 | multi_source | KB-BR-014, KB-API-026 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008 | query_payments.get_invoice_timeline, get_runtime_state.list_requests |
| FP-BM-DG-0208 | test | 052 | tool_use_diagnostic | KB-BR-014, KB-API-026 | RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008 | query_payments.get_invoice_timeline, get_runtime_state.list_requests |
| FP-BM-SR-0209 | test | 053 | simple_retrieval | KB-API-029 | RULE-ENV-004, RULE-PLAN-003, RULE-PLAN-004, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005 | search_api_docs |
| FP-BM-MH-0210 | test | 053 | multi_hop | KB-BR-015, KB-API-029 | RULE-ENV-004, RULE-PLAN-003, RULE-PLAN-004, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_accounts.get_account, query_webhooks.list_endpoints, get_runtime_state.get_request |
| FP-BM-MS-0211 | test | 053 | multi_source | KB-BR-015, KB-API-029 | RULE-ENV-004, RULE-PLAN-003, RULE-PLAN-004, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_accounts.get_account, query_webhooks.list_endpoints, get_runtime_state.get_request |
| FP-BM-DG-0212 | test | 053 | tool_use_diagnostic | KB-BR-015, KB-API-029, KB-TS-010 | RULE-ENV-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-REGION-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_accounts.get_account, query_webhooks.list_endpoints, get_runtime_state.get_request |
| FP-BM-SR-0213 | test | 054 | simple_retrieval | KB-API-029 | RULE-ENV-004, RULE-PLAN-003, RULE-PLAN-004, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005 | search_api_docs |
| FP-BM-MH-0214 | test | 054 | multi_hop | KB-BR-004, KB-BR-015 | RULE-ENV-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_accounts.get_plan_timeline, query_webhooks.list_endpoints, query_webhooks.get_endpoint |
| FP-BM-MS-0215 | test | 054 | multi_source | KB-BR-004, KB-BR-015 | RULE-ENV-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_accounts.get_plan_timeline, query_webhooks.list_endpoints, query_webhooks.get_endpoint |
| FP-BM-DG-0216 | test | 054 | tool_use_diagnostic | KB-BR-004, KB-BR-015, KB-API-029 | RULE-ENV-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_accounts.get_plan_timeline, query_webhooks.list_endpoints, query_webhooks.get_endpoint |
| FP-BM-SR-0217 | test | 055 | simple_retrieval | KB-BR-015 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | search_business_rules |
| FP-BM-MH-0218 | test | 055 | multi_hop | KB-BR-015, KB-API-029 | RULE-ENV-004, RULE-PLAN-003, RULE-PLAN-004, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_webhooks.get_endpoint, query_webhooks.get_event, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0219 | test | 055 | multi_source | KB-BR-015, KB-API-029 | RULE-ENV-004, RULE-PLAN-003, RULE-PLAN-004, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_webhooks.get_endpoint, query_webhooks.get_event, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-DG-0220 | test | 055 | tool_use_diagnostic | KB-BR-015, KB-API-029, KB-TS-023 | RULE-ENV-004, RULE-PLAN-003, RULE-PLAN-004, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-013, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_event, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-SR-0221 | dev | 056 | simple_retrieval | KB-CASE-015 | RULE-PAY-007, RULE-WEBHOOK-002, RULE-WEBHOOK-005, RULE-WEBHOOK-017 | search_support_cases |
| FP-BM-MH-0222 | dev | 056 | multi_hop | KB-BR-015, KB-API-030 | RULE-ENV-004, RULE-PAY-007, RULE-PLAN-003, RULE-VERSION-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_payments.get_payment, query_webhooks.list_endpoints, query_webhooks.get_event, query_webhooks.get_delivery |
| FP-BM-MS-0223 | dev | 056 | multi_source | KB-BR-015, KB-API-030 | RULE-ENV-004, RULE-PAY-007, RULE-PLAN-003, RULE-VERSION-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_payments.get_payment, query_webhooks.list_endpoints, query_webhooks.get_event, query_webhooks.get_delivery |
| FP-BM-DG-0224 | dev | 056 | tool_use_diagnostic | KB-BR-015, KB-API-030, KB-TS-023, KB-CASE-015 | RULE-ENV-004, RULE-PAY-007, RULE-PLAN-003, RULE-VERSION-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-013, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_payments.get_payment, query_webhooks.list_endpoints, query_webhooks.get_event, query_webhooks.get_delivery |
| FP-BM-SR-0225 | test | 057 | simple_retrieval | KB-BR-015 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | search_business_rules |
| FP-BM-MH-0226 | test | 057 | multi_hop | KB-BR-015, KB-API-030 | RULE-ENV-004, RULE-PAY-007, RULE-PLAN-003, RULE-VERSION-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_payments.get_payment, query_webhooks.get_endpoint, query_webhooks.get_event, query_webhooks.get_delivery |
| FP-BM-MS-0227 | test | 057 | multi_source | KB-BR-015, KB-API-030 | RULE-ENV-004, RULE-PAY-007, RULE-PLAN-003, RULE-VERSION-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_payments.get_payment, query_webhooks.get_endpoint, query_webhooks.get_event, query_webhooks.get_delivery |
| FP-BM-DG-0228 | test | 057 | tool_use_diagnostic | KB-BR-015, KB-API-030, KB-REL-007, KB-REL-009 | RULE-ENV-004, RULE-PAY-007, RULE-PLAN-003, RULE-RATE-007, RULE-REFUND-001, RULE-VERSION-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-016, RULE-WEBHOOK-017 | query_payments.get_payment, query_webhooks.get_endpoint, query_webhooks.get_event, query_webhooks.get_delivery |
| FP-BM-SR-0229 | test | 058 | simple_retrieval | KB-BR-015 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | search_business_rules |
| FP-BM-MH-0230 | test | 058 | multi_hop | KB-BR-015, KB-API-030 | RULE-ENV-004, RULE-PAY-007, RULE-PLAN-003, RULE-VERSION-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_accounts.get_account, query_payments.get_invoice_timeline, query_webhooks.get_event |
| FP-BM-MS-0231 | test | 058 | multi_source | KB-BR-015, KB-API-030 | RULE-ENV-004, RULE-PAY-007, RULE-PLAN-003, RULE-VERSION-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_accounts.get_account, query_payments.get_invoice_timeline, query_webhooks.get_event |
| FP-BM-DG-0232 | test | 058 | tool_use_diagnostic | KB-BR-015, KB-API-030, KB-REL-009 | RULE-ENV-004, RULE-PAY-007, RULE-PLAN-003, RULE-VERSION-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_accounts.get_account, query_payments.get_invoice_timeline, query_webhooks.get_event |
| FP-BM-SR-0233 | test | 059 | simple_retrieval | KB-BR-015 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | search_business_rules |
| FP-BM-MH-0234 | test | 059 | multi_hop | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0235 | test | 059 | multi_source | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-DG-0236 | test | 059 | tool_use_diagnostic | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-SR-0237 | test | 060 | simple_retrieval | KB-TS-023 | RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-012, RULE-WEBHOOK-013, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | search_troubleshooting |
| FP-BM-MH-0238 | test | 060 | multi_hop | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0239 | test | 060 | multi_source | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-DG-0240 | test | 060 | tool_use_diagnostic | KB-BR-015, KB-API-032, KB-TS-023 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-013, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-SR-0241 | dev | 061 | simple_retrieval | KB-BR-015 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | search_business_rules |
| FP-BM-MH-0242 | dev | 061 | multi_hop | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0243 | dev | 061 | multi_source | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-DG-0244 | dev | 061 | tool_use_diagnostic | KB-BR-015, KB-API-032, KB-TS-023 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-013, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-SR-0245 | test | 062 | simple_retrieval | KB-API-032 | RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-018 | search_api_docs |
| FP-BM-MH-0246 | test | 062 | multi_hop | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_event, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0247 | test | 062 | multi_source | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_event, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-DG-0248 | test | 062 | tool_use_diagnostic | KB-BR-015, KB-API-032, KB-TS-023 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-013, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_event, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-SR-0249 | test | 063 | simple_retrieval | KB-BR-015 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | search_business_rules |
| FP-BM-MH-0250 | test | 063 | multi_hop | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0251 | test | 063 | multi_source | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-DG-0252 | test | 063 | tool_use_diagnostic | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-SR-0253 | test | 064 | simple_retrieval | KB-BR-015 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | search_business_rules |
| FP-BM-MH-0254 | test | 064 | multi_hop | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_accounts.get_account, query_webhooks.get_endpoint, get_runtime_state.list_requests |
| FP-BM-MS-0255 | test | 064 | multi_source | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_accounts.get_account, query_webhooks.get_endpoint, get_runtime_state.list_requests |
| FP-BM-DG-0256 | test | 064 | tool_use_diagnostic | KB-BR-015, KB-API-032, KB-TS-010 | RULE-ENV-004, RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-REGION-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_accounts.get_account, query_webhooks.get_endpoint, get_runtime_state.list_requests |
| FP-BM-SR-0257 | test | 065 | simple_retrieval | KB-BR-015 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | search_business_rules |
| FP-BM-MH-0258 | test | 065 | multi_hop | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_event, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0259 | test | 065 | multi_source | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_event, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-DG-0260 | test | 065 | tool_use_diagnostic | KB-BR-015, KB-API-032 | RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_event, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-SR-0261 | dev | 066 | simple_retrieval | KB-API-031 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | search_api_docs |
| FP-BM-MH-0262 | dev | 066 | multi_hop | KB-BR-016, KB-API-031 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_event, query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0263 | dev | 066 | multi_source | KB-BR-016, KB-API-031 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_event, query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-DG-0264 | dev | 066 | tool_use_diagnostic | KB-BR-016, KB-API-031, KB-REL-006, KB-CASE-008 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_event, query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-SR-0265 | test | 067 | simple_retrieval | KB-BR-016 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | search_business_rules |
| FP-BM-MH-0266 | test | 067 | multi_hop | KB-BR-016, KB-API-031 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0267 | test | 067 | multi_source | KB-BR-016, KB-API-031 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-DG-0268 | test | 067 | tool_use_diagnostic | KB-BR-016, KB-API-031, KB-TS-023 | RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-012, RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-SR-0269 | test | 068 | simple_retrieval | KB-API-031 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | search_api_docs |
| FP-BM-MH-0270 | test | 068 | multi_hop | KB-BR-016, KB-API-031 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0271 | test | 068 | multi_source | KB-BR-016, KB-API-031 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-DG-0272 | test | 068 | tool_use_diagnostic | KB-BR-016, KB-API-031 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-SR-0273 | test | 069 | simple_retrieval | KB-REL-006 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | search_release_notes |
| FP-BM-MH-0274 | test | 069 | multi_hop | KB-BR-016, KB-API-031 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0275 | test | 069 | multi_source | KB-BR-016, KB-API-031 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-DG-0276 | test | 069 | tool_use_diagnostic | KB-BR-016, KB-API-031, KB-REL-006 | RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_webhooks.get_endpoint, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-SR-0277 | test | 070 | simple_retrieval | KB-TS-018 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-IDEMP-004 | search_troubleshooting |
| FP-BM-MH-0278 | test | 070 | multi_hop | KB-BR-011, KB-API-008 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005, RULE-REQ-001, RULE-VERSION-004 | query_accounts.get_account, get_runtime_state.get_request, get_runtime_state.list_requests, get_runtime_state.get_service_status |
| FP-BM-MS-0279 | test | 070 | multi_source | KB-BR-011, KB-API-008 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005, RULE-REQ-001, RULE-VERSION-004 | query_accounts.get_account, get_runtime_state.get_request, get_runtime_state.list_requests, get_runtime_state.get_service_status |
| FP-BM-DG-0280 | test | 070 | tool_use_diagnostic | KB-BR-011, KB-API-008, KB-TS-017, KB-TS-018, KB-TS-024, KB-CASE-016 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-IDEMP-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005, RULE-RATE-007, RULE-REQ-001, RULE-VERSION-004, RULE-WEBHOOK-005 | query_accounts.get_account, get_runtime_state.get_request, get_runtime_state.list_requests, get_runtime_state.get_service_status |
| FP-BM-MD-0281 | dev | 071 | multi_document | KB-TS-024, KB-TS-018 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-IDEMP-004, RULE-RATE-007 | search_troubleshooting |
| FP-BM-MH-0282 | dev | 071 | multi_hop | KB-BR-011, KB-TS-018 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-IDEMP-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005 | get_runtime_state.list_requests, get_runtime_state.get_service_status |
| FP-BM-MS-0283 | dev | 071 | multi_source | KB-BR-011, KB-TS-018 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-IDEMP-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005 | get_runtime_state.list_requests, get_runtime_state.get_service_status |
| FP-BM-DG-0284 | dev | 071 | tool_use_diagnostic | KB-BR-011, KB-TS-018, KB-TS-024 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004, RULE-IDEMP-004, RULE-PAY-001, RULE-PAY-002, RULE-PAY-005, RULE-RATE-007 | get_runtime_state.list_requests, get_runtime_state.get_service_status |
| FP-BM-MD-0285 | test | 072 | multi_document | KB-API-007, KB-API-008 | RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-REQ-001, RULE-REQ-002, RULE-REQ-003, RULE-VERSION-004 | search_api_docs |
| FP-BM-MH-0286 | test | 072 | multi_hop | KB-BR-006, KB-API-007 | RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-REQ-001, RULE-REQ-002, RULE-REQ-003 | query_accounts.list_api_keys, get_runtime_state.get_request, get_runtime_state.list_requests |
| FP-BM-MS-0287 | test | 072 | multi_source | KB-BR-006, KB-API-007 | RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-REQ-001, RULE-REQ-002, RULE-REQ-003 | query_accounts.list_api_keys, get_runtime_state.get_request, get_runtime_state.list_requests |
| FP-BM-DG-0288 | test | 072 | tool_use_diagnostic | KB-BR-006, KB-API-007, KB-API-008, KB-TS-004, KB-TS-019 | RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-005, RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-REQ-001, RULE-REQ-002, RULE-REQ-003, RULE-VERSION-004 | query_accounts.list_api_keys, get_runtime_state.get_request, get_runtime_state.list_requests |
| FP-BM-MD-0289 | test | 073 | multi_document | KB-TS-012, KB-API-014 | RULE-ENV-001, RULE-PAY-001, RULE-REQ-003, RULE-TENANT-002, RULE-TENANT-003, RULE-TENANT-004, RULE-VERSION-005 | search_troubleshooting, search_api_docs |
| FP-BM-MH-0290 | test | 073 | multi_hop | KB-BR-001, KB-API-014 | RULE-PAY-001, RULE-REQ-003, RULE-TENANT-001, RULE-TENANT-002, RULE-TENANT-003, RULE-TENANT-004, RULE-VERSION-005 | query_accounts.list_api_keys, query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-MS-0291 | test | 073 | multi_source | KB-BR-001, KB-API-014 | RULE-PAY-001, RULE-REQ-003, RULE-TENANT-001, RULE-TENANT-002, RULE-TENANT-003, RULE-TENANT-004, RULE-VERSION-005 | query_accounts.list_api_keys, query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-DG-0292 | test | 073 | tool_use_diagnostic | KB-BR-001, KB-API-014, KB-TS-012 | RULE-ENV-001, RULE-PAY-001, RULE-REQ-003, RULE-TENANT-001, RULE-TENANT-002, RULE-TENANT-003, RULE-TENANT-004, RULE-VERSION-005 | query_accounts.list_api_keys, query_payments.get_payment, get_runtime_state.get_request |
| FP-BM-MD-0293 | test | 074 | multi_document | KB-BR-004, KB-TS-022 | RULE-PLAN-001 | search_business_rules, search_troubleshooting |
| FP-BM-MH-0294 | test | 074 | multi_hop | KB-BR-004, KB-TS-022 | RULE-PLAN-001 | query_accounts.get_account, get_runtime_state.get_request |
| FP-BM-MS-0295 | test | 074 | multi_source | KB-BR-004, KB-TS-022 | RULE-PLAN-001 | query_accounts.get_account, get_runtime_state.get_request |
| FP-BM-DG-0296 | test | 074 | tool_use_diagnostic | KB-BR-004, KB-TS-022 | RULE-PLAN-001 | query_accounts.get_account, get_runtime_state.get_request |
| FP-BM-MD-0297 | test | 075 | multi_document | KB-BR-015, KB-API-013 | RULE-ENV-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-IDEMP-005, RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-005, RULE-PAY-006, RULE-PLAN-003, RULE-REGION-001, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | search_business_rules, search_api_docs |
| FP-BM-MH-0298 | test | 075 | multi_hop | KB-BR-010, KB-BR-015 | RULE-ENV-004, RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_payments.get_payment, query_webhooks.get_endpoint, query_webhooks.get_event, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-MS-0299 | test | 075 | multi_source | KB-BR-010, KB-BR-015 | RULE-ENV-004, RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017 | query_payments.get_payment, query_webhooks.get_endpoint, query_webhooks.get_event, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
| FP-BM-DG-0300 | test | 075 | tool_use_diagnostic | KB-BR-010, KB-BR-015, KB-API-013, KB-API-030, KB-API-032, KB-TS-023 | RULE-ENV-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-IDEMP-005, RULE-MONEY-001, RULE-MONEY-002, RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007, RULE-PLAN-003, RULE-REGION-001, RULE-VERSION-005, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-013, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018 | query_payments.get_payment, query_webhooks.get_endpoint, query_webhooks.get_event, query_webhooks.get_delivery, get_runtime_state.get_delivery_timeline |
