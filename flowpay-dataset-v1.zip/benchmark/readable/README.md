# FlowPay benchmark 题库

共 **300 道**，渲染自 `benchmark/resolved/resolved_blueprints.jsonl`。
单轮 120 道，多轮 180 道；难度 1:70／2:50／3:60／4:95／5:25；dev 60／test 240。

| 题型 | 道数 | 文件 |
| --- | --- | --- |
| 单点检索（`simple_retrieval`） | 70 | [01-simple_retrieval.md](01-simple_retrieval.md) |
| 跨文档（`multi_document`） | 50 | [02-multi_document.md](02-multi_document.md) |
| 多跳（`multi_hop`） | 60 | [03-multi_hop.md](03-multi_hop.md) |
| 时效版本（`temporal_versioned`） | 25 | [04-temporal_versioned.md](04-temporal_versioned.md) |
| 工具诊断（`tool_use_diagnostic`） | 25 | [05-tool_use_diagnostic.md](05-tool_use_diagnostic.md) |
| 跨数据源（`multi_source`） | 70 | [06-multi_source.md](06-multi_source.md) |

## 全部题目

| ID | 题型 | 难度 | 轮次 | 题面 |
| --- | --- | --- | --- | --- |
| [FP-BM-SR-0001](01-simple_retrieval.md#fp-bm-sr-0001) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：这个账户使用自己的 Production Key 查询另一个 A… |
| [FP-BM-SR-0005](01-simple_retrieval.md#fp-bm-sr-0005) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：这个账户的部署加载了 Sandbox Key，却尝试为 Prod… |
| [FP-BM-SR-0009](01-simple_retrieval.md#fp-bm-sr-0009) | 单点检索 | 1 | 单轮 | 客户反馈Starter Account 这个账户尚未启用 Production，却请… |
| [FP-BM-SR-0013](01-simple_retrieval.md#fp-bm-sr-0013) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：这个账户仍持有 active 的那把密钥，Production … |
| [FP-BM-SR-0017](01-simple_retrieval.md#fp-bm-sr-0017) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。EU Account 这个账户为 这位客户创建 USD Paymen… |
| [FP-BM-SR-0021](01-simple_retrieval.md#fp-bm-sr-0021) | 单点检索 | 1 | 单轮 | 客户反馈这个账户连续提交 amount=49 和 amount=100000001 … |
| [FP-BM-SR-0025](01-simple_retrieval.md#fp-bm-sr-0025) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。Starter Account 这个账户的 subscription… |
| [FP-BM-SR-0029](01-simple_retrieval.md#fp-bm-sr-0029) | 单点检索 | 1 | 单轮 | 目前能确认的是：这个账户在 10:00 从 Starter 升级为 Growth，1… |
| [FP-BM-SR-0033](01-simple_retrieval.md#fp-bm-sr-0033) | 单点检索 | 1 | 单轮 | 想咨询一个问题：Scale Account 这个账户在周期中申请降为 Starter… |
| [FP-BM-SR-0037](01-simple_retrieval.md#fp-bm-sr-0037) | 单点检索 | 1 | 单轮 | 目前能确认的是：这个账户创建新 那把密钥后，旧 Key 进入 expiring；发布… |
| [FP-BM-SR-0041](01-simple_retrieval.md#fp-bm-sr-0041) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：那把密钥被撤销后，这个账户尝试把它重新标记 active，并继续… |
| [FP-BM-SR-0045](01-simple_retrieval.md#fp-bm-sr-0045) | 单点检索 | 1 | 单轮 | 客户反馈这个账户默认版本为 新版接口，那次请求显式发送 FlowPay-Versio… |
| [FP-BM-SR-0049](01-simple_retrieval.md#fp-bm-sr-0049) | 单点检索 | 1 | 单轮 | 想咨询一个问题：这个账户使用 API Version 当前部署使用的接口版本 和 s… |
| [FP-BM-SR-0053](01-simple_retrieval.md#fp-bm-sr-0053) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：这个账户升级到 当前部署使用的接口版本 后仍用 source 创… |
| [FP-BM-SR-0057](01-simple_retrieval.md#fp-bm-sr-0057) | 单点检索 | 1 | 单轮 | 客户反馈同一客户操作场景分别由 旧版接口 与 新版接口 请求创建 Payment。这… |
| [FP-BM-SR-0061](01-simple_retrieval.md#fp-bm-sr-0061) | 单点检索 | 1 | 单轮 | 想咨询一个问题：这个账户在网络超时后用相同参数和相同 Idempotency Key… |
| [FP-BM-SR-0065](01-simple_retrieval.md#fp-bm-sr-0065) | 单点检索 | 1 | 单轮 | 想咨询一个问题：这个账户先用 amount=5000 创建那笔支付，随后用同一 Ke… |
| [FP-BM-SR-0069](01-simple_retrieval.md#fp-bm-sr-0069) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。这个账户在首次创建那笔支付的 25 小时后，以相同参数和同一 Key… |
| [FP-BM-SR-0073](01-simple_retrieval.md#fp-bm-sr-0073) | 单点检索 | 1 | 单轮 | 想咨询一个问题：Scale Account 这个账户在 Sandbox 一分钟发送 … |
| [FP-BM-SR-0077](01-simple_retrieval.md#fp-bm-sr-0077) | 单点检索 | 1 | 单轮 | 想咨询一个问题：Growth Account 这个账户在一分钟内产生 1,420 个… |
| [FP-BM-SR-0081](01-simple_retrieval.md#fp-bm-sr-0081) | 单点检索 | 1 | 单轮 | 目前能确认的是：这个账户首次接近 Growth 上限后，客户端对每个 429 立即并… |
| [FP-BM-SR-0085](01-simple_retrieval.md#fp-bm-sr-0085) | 单点检索 | 1 | 单轮 | 目前能确认的是：这个账户同一分钟有 900 次 API 请求和 700 次 Webh… |
| [FP-BM-SR-0089](01-simple_retrieval.md#fp-bm-sr-0089) | 单点检索 | 1 | 单轮 | 目前能确认的是：这位客户被删除后，历史 那笔支付仍能被 这个账户查询并显示原 Cus… |
| [FP-BM-SR-0093](01-simple_retrieval.md#fp-bm-sr-0093) | 单点检索 | 1 | 单轮 | 想咨询一个问题：这位客户已 deleted，这个账户随后尝试创建新 那笔支付，请求返… |
| [FP-BM-SR-0097](01-simple_retrieval.md#fp-bm-sr-0097) | 单点检索 | 1 | 单轮 | 客户反馈这个账户中有两个 active Customer 使用相同 Email，其中… |
| [FP-BM-SR-0101](01-simple_retrieval.md#fp-bm-sr-0101) | 单点检索 | 1 | 单轮 | 客户反馈那笔支付已 succeeded，之后客户端尝试再次 confirm，并在列表… |
| [FP-BM-SR-0105](01-simple_retrieval.md#fp-bm-sr-0105) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。当前部署使用的接口版本 Payment 那笔支付处于 require… |
| [FP-BM-SR-0109](01-simple_retrieval.md#fp-bm-sr-0109) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：这个账户尝试取消 processing 的那笔支付，那次请求返回… |
| [FP-BM-SR-0113](01-simple_retrieval.md#fp-bm-sr-0113) | 单点检索 | 1 | 单轮 | 想咨询一个问题：那笔支付因支付方式被拒绝进入 failed；商户对原 ID 再次 c… |
| [FP-BM-SR-0117](01-simple_retrieval.md#fp-bm-sr-0117) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：那笔支付返回 FP-4021，Request 那次请求没有平台 … |
| [FP-BM-SR-0121](01-simple_retrieval.md#fp-bm-sr-0121) | 单点检索 | 1 | 单轮 | 客户反馈那笔支付返回 FP-4022；同一客户此前另一笔 Payment 曾返回 F… |
| [FP-BM-SR-0125](01-simple_retrieval.md#fp-bm-sr-0125) | 单点检索 | 1 | 单轮 | 想咨询一个问题：那笔支付使用已过期支付方式并返回 FP-4024，商户准备重放同一请… |
| [FP-BM-SR-0129](01-simple_retrieval.md#fp-bm-sr-0129) | 单点检索 | 1 | 单轮 | 目前能确认的是：这个账户的旧客户端与新客户端对同一类验证场景分别创建 Payment… |
| [FP-BM-SR-0133](01-simple_retrieval.md#fp-bm-sr-0133) | 单点检索 | 1 | 单轮 | 想咨询一个问题：那笔支付仍为 processing，这个账户为它创建那笔退款，那次请… |
| [FP-BM-SR-0137](01-simple_retrieval.md#fp-bm-sr-0137) | 单点检索 | 1 | 单轮 | 客户反馈Starter Account 这个账户对 succeeded 的那笔支付申… |
| [FP-BM-SR-0141](01-simple_retrieval.md#fp-bm-sr-0141) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：Growth Account 这个账户对 10,000 的那笔支… |
| [FP-BM-SR-0145](01-simple_retrieval.md#fp-bm-sr-0145) | 单点检索 | 1 | 单轮 | 目前能确认的是：10,000 的那笔支付已有 6,000 pending 那笔退款，… |
| [FP-BM-SR-0149](01-simple_retrieval.md#fp-bm-sr-0149) | 单点检索 | 1 | 单轮 | 目前能确认的是：那笔支付的 4,000 pending 那笔退款随后 failed；… |
| [FP-BM-SR-0153](01-simple_retrieval.md#fp-bm-sr-0153) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：那笔支付在 181 天前 succeeded，当前仍有全部金额未… |
| [FP-BM-SR-0157](01-simple_retrieval.md#fp-bm-sr-0157) | 单点检索 | 1 | 单轮 | 想咨询一个问题：NA Scale Account 这个账户已开启 instant_r… |
| [FP-BM-SR-0161](01-simple_retrieval.md#fp-bm-sr-0161) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。APAC Scale Account 这个账户开启 Flag 后，对… |
| [FP-BM-SR-0165](01-simple_retrieval.md#fp-bm-sr-0165) | 单点检索 | 1 | 单轮 | 想咨询一个问题：EU Scale Account 这个账户的 Flag 起初关闭，随… |
| [FP-BM-SR-0169](01-simple_retrieval.md#fp-bm-sr-0169) | 单点检索 | 1 | 单轮 | 目前能确认的是：Starter Account 这个账户使用 active 这位客户… |
| [FP-BM-SR-0173](01-simple_retrieval.md#fp-bm-sr-0173) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。这个账户先尝试以 trial_days=31 创建 这份订阅，之后又… |
| [FP-BM-SR-0177](01-simple_retrieval.md#fp-bm-sr-0177) | 单点检索 | 1 | 单轮 | 想咨询一个问题：这份订阅在周期中收到默认取消请求，当前时间尚未到 period_en… |
| [FP-BM-SR-0181](01-simple_retrieval.md#fp-bm-sr-0181) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。这个账户对 active 的 这份订阅发送 immediate=tr… |
| [FP-BM-SR-0185](01-simple_retrieval.md#fp-bm-sr-0185) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：这份订阅已绑定 这位客户和 USD，这个账户尝试改成另一个 Cu… |
| [FP-BM-SR-0189](01-simple_retrieval.md#fp-bm-sr-0189) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。那张账单首次 Payment 失败使 这份订阅past_due，第 … |
| [FP-BM-SR-0193](01-simple_retrieval.md#fp-bm-sr-0193) | 单点检索 | 1 | 单轮 | 想咨询一个问题：那张账单首次与第 1 天 Payment 失败，第 3 天 Paym… |
| [FP-BM-SR-0197](01-simple_retrieval.md#fp-bm-sr-0197) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：那张账单的四次 Payment 全部 failed，这份订阅仍显… |
| [FP-BM-SR-0201](01-simple_retrieval.md#fp-bm-sr-0201) | 单点检索 | 1 | 单轮 | 想咨询一个问题：那张账单已 paid，这个账户为纠正账单说明而调用 void。Inv… |
| [FP-BM-SR-0205](01-simple_retrieval.md#fp-bm-sr-0205) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。那张账单已 open 但尚未支付，这个账户决定作废它。我们想知道vo… |
| [FP-BM-SR-0209](01-simple_retrieval.md#fp-bm-sr-0209) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：Starter Account 这个账户已有两个 enabled… |
| [FP-BM-SR-0213](01-simple_retrieval.md#fp-bm-sr-0213) | 单点检索 | 1 | 单轮 | 想咨询一个问题：这个账户从 Growth 降至 Starter，原有五个 Endpo… |
| [FP-BM-SR-0217](01-simple_retrieval.md#fp-bm-sr-0217) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。这个回调地址在 Event 那个事件发生前已 disabled，商户… |
| [FP-BM-SR-0221](01-simple_retrieval.md#fp-bm-sr-0221) | 单点检索 | 1 | 单轮 | 目前能确认的是：那笔支付成功并产生 那个事件，enabled 的 这个回调地址只订阅… |
| [FP-BM-SR-0225](01-simple_retrieval.md#fp-bm-sr-0225) | 单点检索 | 1 | 单轮 | 客户反馈那笔支付由 当前部署使用的接口版本 请求创建并成功，这个回调地址只订阅 pa… |
| [FP-BM-SR-0229](01-simple_retrieval.md#fp-bm-sr-0229) | 单点检索 | 1 | 单轮 | 目前能确认的是：这个账户默认版本为 当前部署使用的接口版本；Scheduler 生成… |
| [FP-BM-SR-0233](01-simple_retrieval.md#fp-bm-sr-0233) | 单点检索 | 1 | 单轮 | 客户反馈那次投递第一次 Attempt 收到 HTTP 204，系统仍安排下一次重试… |
| [FP-BM-SR-0237](01-simple_retrieval.md#fp-bm-sr-0237) | 单点检索 | 1 | 单轮 | 客户反馈这个回调地址对 那次投递返回 HTTP 302 和 Location，团队认… |
| [FP-BM-SR-0241](01-simple_retrieval.md#fp-bm-sr-0241) | 单点检索 | 1 | 单轮 | 目前能确认的是：那次投递首次收到 HTTP 400，这个回调地址仍 enabled。… |
| [FP-BM-SR-0245](01-simple_retrieval.md#fp-bm-sr-0245) | 单点检索 | 1 | 单轮 | 目前能确认的是：那次投递第一次收到 HTTP 410，之后又为同一 Endpoint… |
| [FP-BM-SR-0249](01-simple_retrieval.md#fp-bm-sr-0249) | 单点检索 | 1 | 单轮 | 目前能确认的是：那次投递首次失败且六个默认重试均返回 500。接下来需要判断最终状态… |
| [FP-BM-SR-0253](01-simple_retrieval.md#fp-bm-sr-0253) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。Scale Account 这个账户先配置 9 次自定义重试，随后改… |
| [FP-BM-SR-0257](01-simple_retrieval.md#fp-bm-sr-0257) | 单点检索 | 1 | 单轮 | 客户反馈那个事件的首次 那次投递已被 Merchant 处理，但响应丢失导致 Flo… |
| [FP-BM-SR-0261](01-simple_retrieval.md#fp-bm-sr-0261) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。那个事件使用 当前部署使用的接口版本，这个回调地址的接收端仍只读取 … |
| [FP-BM-SR-0265](01-simple_retrieval.md#fp-bm-sr-0265) | 单点检索 | 1 | 单轮 | 想咨询一个问题：那次投递的签名摘要正确，但接收端验证时与 signature_tim… |
| [FP-BM-SR-0269](01-simple_retrieval.md#fp-bm-sr-0269) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：这个回调地址在 10:00 轮换 Secret；10:05 的新… |
| [FP-BM-SR-0273](01-simple_retrieval.md#fp-bm-sr-0273) | 单点检索 | 1 | 单轮 | 我们遇到了这种情况：那次投递首次失败后，这个回调地址在下一次重试前轮换 Secret… |
| [FP-BM-SR-0277](01-simple_retrieval.md#fp-bm-sr-0277) | 单点检索 | 1 | 单轮 | 请帮忙确认一下。这个账户的一个 那次请求返回 FP-5001，随后同地区大量请求返回… |
| [FP-BM-MD-0002](02-multi_document.md#fp-bm-md-0002) | 跨文档 | 2 | 单轮 | 请帮忙确认一下。这个账户使用自己的 Production Key 查询另一个 Acc… |
| [FP-BM-MD-0006](02-multi_document.md#fp-bm-md-0006) | 跨文档 | 2 | 单轮 | 请帮忙确认一下。这个账户的部署加载了 Sandbox Key，却尝试为 Produc… |
| [FP-BM-MD-0010](02-multi_document.md#fp-bm-md-0010) | 跨文档 | 2 | 单轮 | 目前能确认的是：Starter Account 这个账户尚未启用 Productio… |
| [FP-BM-MD-0014](02-multi_document.md#fp-bm-md-0014) | 跨文档 | 2 | 单轮 | 请帮忙确认一下。这个账户仍持有 active 的那把密钥，Production 请求… |
| [FP-BM-MD-0018](02-multi_document.md#fp-bm-md-0018) | 跨文档 | 2 | 单轮 | 想咨询一个问题：EU Account 这个账户为 这位客户创建 USD Paymen… |
| [FP-BM-MD-0022](02-multi_document.md#fp-bm-md-0022) | 跨文档 | 2 | 单轮 | 目前能确认的是：这个账户连续提交 amount=49 和 amount=100000… |
| [FP-BM-MD-0026](02-multi_document.md#fp-bm-md-0026) | 跨文档 | 2 | 单轮 | 想咨询一个问题：Starter Account 这个账户的 subscription… |
| [FP-BM-MD-0030](02-multi_document.md#fp-bm-md-0030) | 跨文档 | 2 | 单轮 | 我们遇到了这种情况：这个账户在 10:00 从 Starter 升级为 Growth… |
| [FP-BM-MD-0034](02-multi_document.md#fp-bm-md-0034) | 跨文档 | 2 | 单轮 | 客户反馈Scale Account 这个账户在周期中申请降为 Starter；申请后… |
| [FP-BM-MD-0038](02-multi_document.md#fp-bm-md-0038) | 跨文档 | 2 | 单轮 | 我们遇到了这种情况：这个账户创建新 那把密钥后，旧 Key 进入 expiring；… |
| [FP-BM-MD-0042](02-multi_document.md#fp-bm-md-0042) | 跨文档 | 2 | 单轮 | 请帮忙确认一下。那把密钥被撤销后，这个账户尝试把它重新标记 active，并继续发送… |
| [FP-BM-MD-0046](02-multi_document.md#fp-bm-md-0046) | 跨文档 | 2 | 单轮 | 目前能确认的是：这个账户默认版本为 新版接口，那次请求显式发送 FlowPay-Ve… |
| [FP-BM-MD-0050](02-multi_document.md#fp-bm-md-0050) | 跨文档 | 2 | 单轮 | 客户反馈这个账户使用 API Version 当前部署使用的接口版本 和 sourc… |
| [FP-BM-MD-0054](02-multi_document.md#fp-bm-md-0054) | 跨文档 | 2 | 单轮 | 请帮忙确认一下。这个账户升级到 当前部署使用的接口版本 后仍用 source 创建那… |
| [FP-BM-MD-0058](02-multi_document.md#fp-bm-md-0058) | 跨文档 | 2 | 单轮 | 目前能确认的是：同一客户操作场景分别由 旧版接口 与 新版接口 请求创建 Payme… |
| [FP-BM-MD-0062](02-multi_document.md#fp-bm-md-0062) | 跨文档 | 2 | 单轮 | 客户反馈这个账户在网络超时后用相同参数和相同 Idempotency Key 重试创… |
| [FP-BM-MD-0066](02-multi_document.md#fp-bm-md-0066) | 跨文档 | 2 | 单轮 | 客户反馈这个账户先用 amount=5000 创建那笔支付，随后用同一 Key 把 … |
| [FP-BM-MD-0070](02-multi_document.md#fp-bm-md-0070) | 跨文档 | 2 | 单轮 | 想咨询一个问题：这个账户在首次创建那笔支付的 25 小时后，以相同参数和同一 Key… |
| [FP-BM-MD-0074](02-multi_document.md#fp-bm-md-0074) | 跨文档 | 2 | 单轮 | 客户反馈Scale Account 这个账户在 Sandbox 一分钟发送 200 … |
| [FP-BM-MD-0078](02-multi_document.md#fp-bm-md-0078) | 跨文档 | 2 | 单轮 | 客户反馈Growth Account 这个账户在一分钟内产生 1,420 个请求，1… |
| [FP-BM-MD-0082](02-multi_document.md#fp-bm-md-0082) | 跨文档 | 2 | 单轮 | 我们遇到了这种情况：这个账户首次接近 Growth 上限后，客户端对每个 429 立… |
| [FP-BM-MD-0086](02-multi_document.md#fp-bm-md-0086) | 跨文档 | 2 | 单轮 | 我们遇到了这种情况：这个账户同一分钟有 900 次 API 请求和 700 次 We… |
| [FP-BM-MD-0090](02-multi_document.md#fp-bm-md-0090) | 跨文档 | 2 | 单轮 | 我们遇到了这种情况：这位客户被删除后，历史 那笔支付仍能被 这个账户查询并显示原 C… |
| [FP-BM-MD-0094](02-multi_document.md#fp-bm-md-0094) | 跨文档 | 2 | 单轮 | 客户反馈这位客户已 deleted，这个账户随后尝试创建新 那笔支付，请求返回状态错… |
| [FP-BM-MD-0098](02-multi_document.md#fp-bm-md-0098) | 跨文档 | 2 | 单轮 | 目前能确认的是：这个账户中有两个 active Customer 使用相同 Emai… |
| [FP-BM-MD-0102](02-multi_document.md#fp-bm-md-0102) | 跨文档 | 2 | 单轮 | 目前能确认的是：那笔支付已 succeeded，之后客户端尝试再次 confirm，… |
| [FP-BM-MD-0106](02-multi_document.md#fp-bm-md-0106) | 跨文档 | 2 | 单轮 | 想咨询一个问题：当前部署使用的接口版本 Payment 那笔支付处于 require… |
| [FP-BM-MD-0110](02-multi_document.md#fp-bm-md-0110) | 跨文档 | 2 | 单轮 | 请帮忙确认一下。这个账户尝试取消 processing 的那笔支付，那次请求返回 F… |
| [FP-BM-MD-0114](02-multi_document.md#fp-bm-md-0114) | 跨文档 | 2 | 单轮 | 客户反馈那笔支付因支付方式被拒绝进入 failed；商户对原 ID 再次 confi… |
| [FP-BM-MD-0118](02-multi_document.md#fp-bm-md-0118) | 跨文档 | 2 | 单轮 | 请帮忙确认一下。那笔支付返回 FP-4021，Request 那次请求没有平台 In… |
| [FP-BM-MD-0122](02-multi_document.md#fp-bm-md-0122) | 跨文档 | 2 | 单轮 | 目前能确认的是：那笔支付返回 FP-4022；同一客户此前另一笔 Payment 曾… |
| [FP-BM-MD-0126](02-multi_document.md#fp-bm-md-0126) | 跨文档 | 2 | 单轮 | 客户反馈那笔支付使用已过期支付方式并返回 FP-4024，商户准备重放同一请求。这种… |
| [FP-BM-MD-0130](02-multi_document.md#fp-bm-md-0130) | 跨文档 | 2 | 单轮 | 我们遇到了这种情况：这个账户的旧客户端与新客户端对同一类验证场景分别创建 Payme… |
| [FP-BM-MD-0134](02-multi_document.md#fp-bm-md-0134) | 跨文档 | 2 | 单轮 | 客户反馈那笔支付仍为 processing，这个账户为它创建那笔退款，那次请求返回 … |
| [FP-BM-MD-0138](02-multi_document.md#fp-bm-md-0138) | 跨文档 | 2 | 单轮 | 目前能确认的是：Starter Account 这个账户对 succeeded 的那… |
| [FP-BM-MD-0142](02-multi_document.md#fp-bm-md-0142) | 跨文档 | 2 | 单轮 | 请帮忙确认一下。Growth Account 这个账户对 10,000 的那笔支付先… |
| [FP-BM-MD-0146](02-multi_document.md#fp-bm-md-0146) | 跨文档 | 2 | 单轮 | 我们遇到了这种情况：10,000 的那笔支付已有 6,000 pending 那笔退… |
| [FP-BM-MD-0150](02-multi_document.md#fp-bm-md-0150) | 跨文档 | 2 | 单轮 | 我们遇到了这种情况：那笔支付的 4,000 pending 那笔退款随后 faile… |
| [FP-BM-MD-0154](02-multi_document.md#fp-bm-md-0154) | 跨文档 | 2 | 单轮 | 请帮忙确认一下。那笔支付在 181 天前 succeeded，当前仍有全部金额未退；… |
| [FP-BM-MD-0158](02-multi_document.md#fp-bm-md-0158) | 跨文档 | 2 | 单轮 | 客户反馈NA Scale Account 这个账户已开启 instant_refun… |
| [FP-BM-MD-0162](02-multi_document.md#fp-bm-md-0162) | 跨文档 | 2 | 单轮 | 想咨询一个问题：APAC Scale Account 这个账户开启 Flag 后，对… |
| [FP-BM-MD-0166](02-multi_document.md#fp-bm-md-0166) | 跨文档 | 2 | 单轮 | 客户反馈EU Scale Account 这个账户的 Flag 起初关闭，随后开启但… |
| [FP-BM-MD-0170](02-multi_document.md#fp-bm-md-0170) | 跨文档 | 2 | 单轮 | 我们遇到了这种情况：Starter Account 这个账户使用 active 这位… |
| [FP-BM-MD-0174](02-multi_document.md#fp-bm-md-0174) | 跨文档 | 2 | 单轮 | 想咨询一个问题：这个账户先尝试以 trial_days=31 创建 这份订阅，之后又… |
| [FP-BM-MD-0178](02-multi_document.md#fp-bm-md-0178) | 跨文档 | 2 | 单轮 | 客户反馈这份订阅在周期中收到默认取消请求，当前时间尚未到 period_end。这种… |
| [FP-BM-MD-0281](02-multi_document.md#fp-bm-md-0281) | 跨文档 | 2 | 单轮 | 想咨询一个问题：NA payments 服务在时间窗内有 这次服务异常；NA 多个 … |
| [FP-BM-MD-0285](02-multi_document.md#fp-bm-md-0285) | 跨文档 | 2 | 单轮 | 想咨询一个问题：那次请求使用格式错误的那把密钥，返回 FP-4011；客户端认为认证… |
| [FP-BM-MD-0289](02-multi_document.md#fp-bm-md-0289) | 跨文档 | 2 | 单轮 | 请帮忙确认一下。这个账户的 Sandbox Key 查询一个 Production … |
| [FP-BM-MD-0293](02-multi_document.md#fp-bm-md-0293) | 跨文档 | 2 | 单轮 | 目前能确认的是：Starter Account 这个账户查询 20 天前的请求 那次… |
| [FP-BM-MD-0297](02-multi_document.md#fp-bm-md-0297) | 跨文档 | 2 | 单轮 | 想咨询一个问题：那笔支付已 succeeded 并生成 那个事件；这个回调地址已订阅… |
| [FP-BM-MH-0003](03-multi_hop.md#fp-bm-mh-0003) | 多跳 | 3 | 多轮 | 我们排查时发现：后台里明明能看到一笔支付，但我们从服务里查询时一直提示找不到。我们现… |
| [FP-BM-MH-0007](03-multi_hop.md#fp-bm-mh-0007) | 多跳 | 3 | 多轮 | 我们排查时发现：测试时一直正常，可一上线创建支付就变成认证失败了。我们现在只掌握这些… |
| [FP-BM-MH-0011](03-multi_hop.md#fp-bm-mh-0011) | 多跳 | 3 | 多轮 | 客服转来一个问题：我们刚开好账户，准备接正式环境，但创建正式密钥时被拒绝了。我们现在… |
| [FP-BM-MH-0015](03-multi_hop.md#fp-bm-mh-0015) | 多跳 | 3 | 多轮 | 我们排查时发现：正式环境的请求突然全都被拒绝了，可测试环境还是正常的。我们现在只掌握… |
| [FP-BM-MH-0019](03-multi_hop.md#fp-bm-mh-0019) | 多跳 | 3 | 多轮 | 有个欧洲客户下单时支付创建失败，我们怀疑是币种设置的问题。我们现在只掌握这些表面现象… |
| [FP-BM-MH-0023](03-multi_hop.md#fp-bm-mh-0023) | 多跳 | 3 | 多轮 | 客服转来一个问题：有两笔金额很特殊的支付怎么都建不出来，普通金额却没问题。我们现在只… |
| [FP-BM-MH-0027](03-multi_hop.md#fp-bm-mh-0027) | 多跳 | 3 | 多轮 | 我们已经把订阅功能开关打开了，但创建订阅仍然提示没有权限。我们现在只掌握这些表面现象… |
| [FP-BM-MH-0031](03-multi_hop.md#fp-bm-mh-0031) | 多跳 | 3 | 多轮 | 客户那边反馈：我们刚升级套餐，紧接着使用新功能时，不确定系统有没有按新套餐处理。我们… |
| [FP-BM-MH-0035](03-multi_hop.md#fp-bm-mh-0035) | 多跳 | 3 | 多轮 | 线上同事发现：我们提交了降级，之后又新增了一个回调地址，不确定它会不会受新套餐限制。… |
| [FP-BM-MH-0039](03-multi_hop.md#fp-bm-mh-0039) | 多跳 | 3 | 多轮 | 客户那边反馈：我们正在更换线上密钥，担心新旧实例切换期间会中断请求。我们现在只掌握这… |
| [FP-BM-MH-0043](03-multi_hop.md#fp-bm-mh-0043) | 多跳 | 3 | 多轮 | 我们排查时发现：有把线上密钥误操作停用了，现在旧部署全部认证失败。我们现在只掌握这些… |
| [FP-BM-MH-0047](03-multi_hop.md#fp-bm-mh-0047) | 多跳 | 3 | 多轮 | 客服转来一个问题：有一批请求突然报版本不支持，但账户里的默认版本看起来没问题。我们现… |
| [FP-BM-MH-0051](03-multi_hop.md#fp-bm-mh-0051) | 多跳 | 3 | 多轮 | 线上同事发现：支付还能创建成功，不过响应里一直提示一个参数快不能用了。我们现在只掌握… |
| [FP-BM-MH-0055](03-multi_hop.md#fp-bm-mh-0055) | 多跳 | 3 | 多轮 | 我们排查时发现：升级接口版本以后，原来能用的支付参数突然全部报错。我们现在只掌握这些… |
| [FP-BM-MH-0059](03-multi_hop.md#fp-bm-mh-0059) | 多跳 | 3 | 多轮 | 客服转来一个问题：同一种需要客户确认的支付，在两套客户端里表现成了完全不同的状态。我… |
| [FP-BM-MH-0063](03-multi_hop.md#fp-bm-mh-0063) | 多跳 | 3 | 多轮 | 线上同事发现：一次创建支付超时后我们重试了，现在担心系统生成了两笔支付。我们现在只掌… |
| [FP-BM-MH-0067](03-multi_hop.md#fp-bm-mh-0067) | 多跳 | 3 | 多轮 | 线上同事发现：我们重试创建支付时改了金额，结果既没更新也没新建。我们现在只掌握这些表… |
| [FP-BM-MH-0071](03-multi_hop.md#fp-bm-mh-0071) | 多跳 | 3 | 多轮 | 隔了一天多重试同一笔业务后，系统里好像多出了一笔支付。我们现在只掌握这些表面现象，不… |
| [FP-BM-MH-0075](03-multi_hop.md#fp-bm-mh-0075) | 多跳 | 3 | 多轮 | 线上同事发现：压测测试环境时很快就被限流了，降低并发后还是容易触发。我们现在只掌握这… |
| [FP-BM-MH-0079](03-multi_hop.md#fp-bm-mh-0079) | 多跳 | 3 | 多轮 | 线上同事发现：线上流量短时间冲高后开始大量限流，但平时的请求量并不大。我们现在只掌握… |
| [FP-BM-MH-0083](03-multi_hop.md#fp-bm-mh-0083) | 多跳 | 3 | 多轮 | 客户那边反馈：服务被限流后，客户端越重试错误越多，流量反而一直降不下来。我们现在只掌… |
| [FP-BM-MH-0087](03-multi_hop.md#fp-bm-mh-0087) | 多跳 | 3 | 多轮 | 客户那边反馈：业务接口被限流的同时，回调还在持续收到，我们不确定这是否正常。我们现在… |
| [FP-BM-MH-0091](03-multi_hop.md#fp-bm-mh-0091) | 多跳 | 3 | 多轮 | 客户那边反馈：客户被删除后后台仍能查到以前的支付，我们担心删除没有生效。我们现在只掌… |
| [FP-BM-MH-0095](03-multi_hop.md#fp-bm-mh-0095) | 多跳 | 3 | 多轮 | 线上同事发现：一个已经删除的客户仍被业务系统拿来创建新支付，结果一直失败。我们现在只… |
| [FP-BM-MH-0099](03-multi_hop.md#fp-bm-mh-0099) | 多跳 | 3 | 多轮 | 客服转来一个问题：同一个邮箱似乎对应了两个客户，我们不知道支付该关联哪一个。我们现在… |
| [FP-BM-MH-0103](03-multi_hop.md#fp-bm-mh-0103) | 多跳 | 3 | 多轮 | 客服转来一个问题：一笔已经成功的支付后来又收到状态更新，我们担心它被改回处理中。我们… |
| [FP-BM-MH-0107](03-multi_hop.md#fp-bm-mh-0107) | 多跳 | 3 | 多轮 | 客户已经完成验证，但那笔待确认支付仍没有继续成功。我们现在只掌握这些表面现象，不确定… |
| [FP-BM-MH-0111](03-multi_hop.md#fp-bm-mh-0111) | 多跳 | 3 | 多轮 | 我们排查时发现：我们想取消一笔支付，接口却说当前状态不允许取消。我们现在只掌握这些表… |
| [FP-BM-MH-0115](03-multi_hop.md#fp-bm-mh-0115) | 多跳 | 3 | 多轮 | 线上同事发现：一笔失败支付修好原因后，我们反复重试原对象还是没有变化。我们现在只掌握… |
| [FP-BM-MH-0119](03-multi_hop.md#fp-bm-mh-0119) | 多跳 | 3 | 多轮 | 我们排查时发现：客户付款时被拒绝了，但我们看不出是平台故障还是支付方式的问题。我们现… |
| [FP-BM-MH-0182](03-multi_hop.md#fp-bm-mh-0182) | 多跳 | 3 | 多轮 | 客服执行立即取消后，客户仍在问这一期是否还会继续计费。我们现在只掌握这些表面现象，不… |
| [FP-BM-MH-0186](03-multi_hop.md#fp-bm-mh-0186) | 多跳 | 3 | 多轮 | 我们排查时发现：业务想把现有订阅转给另一个客户，同时顺便换结算币种。我们现在只掌握这… |
| [FP-BM-MH-0190](03-multi_hop.md#fp-bm-mh-0190) | 多跳 | 3 | 多轮 | 订阅扣款第一次失败后很快恢复了，我们想确认账单是否还会继续重试。我们现在只掌握这些表… |
| [FP-BM-MH-0194](03-multi_hop.md#fp-bm-mh-0194) | 多跳 | 3 | 多轮 | 线上同事发现：订阅账单连续失败了几次，后来客户补足余额，不确定系统接下来怎么处理。我… |
| [FP-BM-MH-0198](03-multi_hop.md#fp-bm-mh-0198) | 多跳 | 3 | 多轮 | 我们排查时发现：一张订阅账单多次扣款失败后就不再尝试了，订阅状态也变了。我们现在只掌… |
| [FP-BM-MH-0202](03-multi_hop.md#fp-bm-mh-0202) | 多跳 | 3 | 多轮 | 线上同事发现：客服想作废一张账单，但系统提示它当前不能作废。我们现在只掌握这些表面现… |
| [FP-BM-MH-0206](03-multi_hop.md#fp-bm-mh-0206) | 多跳 | 3 | 多轮 | 客户不再需要一张尚未支付的账单，客服想确认能否直接作废。我们现在只掌握这些表面现象，… |
| [FP-BM-MH-0210](03-multi_hop.md#fp-bm-mh-0210) | 多跳 | 3 | 多轮 | 我们排查时发现：我们给账户新增回调地址时突然提示数量已到上限。我们现在只掌握这些表面… |
| [FP-BM-MH-0214](03-multi_hop.md#fp-bm-mh-0214) | 多跳 | 3 | 多轮 | 线上同事发现：套餐降级后，部分回调地址还在，部分却不再接收新事件。我们现在只掌握这些… |
| [FP-BM-MH-0218](03-multi_hop.md#fp-bm-mh-0218) | 多跳 | 3 | 多轮 | 一个已停用的回调地址似乎还和事件有关，我们想确认会不会继续产生投递。我们现在只掌握这… |
| [FP-BM-MH-0222](03-multi_hop.md#fp-bm-mh-0222) | 多跳 | 3 | 多轮 | 客户那边反馈：支付已经成功，但其中一个回调地址始终收不到对应事件。我们现在只掌握这些… |
| [FP-BM-MH-0226](03-multi_hop.md#fp-bm-mh-0226) | 多跳 | 3 | 多轮 | 客服转来一个问题：支付成功以后，新旧回调消费者收到的事件名称不一样。我们现在只掌握这… |
| [FP-BM-MH-0230](03-multi_hop.md#fp-bm-mh-0230) | 多跳 | 3 | 多轮 | 客户那边反馈：系统自动产生的事件版本和我们最近一次接口请求的版本对不上。我们现在只掌… |
| [FP-BM-MH-0234](03-multi_hop.md#fp-bm-mh-0234) | 多跳 | 3 | 多轮 | 客服转来一个问题：回调服务返回成功后，我们偶尔仍看到重复事件，不确定平台是否认为投递… |
| [FP-BM-MH-0238](03-multi_hop.md#fp-bm-mh-0238) | 多跳 | 3 | 多轮 | 客服转来一个问题：回调地址做了跳转以后，平台没有跟过去，反而不断重试。我们现在只掌握… |
| [FP-BM-MH-0242](03-multi_hop.md#fp-bm-mh-0242) | 多跳 | 3 | 多轮 | 客户那边反馈：回调服务明确返回客户端错误，平台却还是继续重试投递。我们现在只掌握这些… |
| [FP-BM-MH-0246](03-multi_hop.md#fp-bm-mh-0246) | 多跳 | 3 | 多轮 | 客户那边反馈：回调服务返回资源已删除后，这个地址突然被系统停用了。我们现在只掌握这些… |
| [FP-BM-MH-0250](03-multi_hop.md#fp-bm-mh-0250) | 多跳 | 3 | 多轮 | 客户那边反馈：一个回调地址故障很久后，平台似乎已经停止继续投递。我们现在只掌握这些表… |
| [FP-BM-MH-0254](03-multi_hop.md#fp-bm-mh-0254) | 多跳 | 3 | 多轮 | 我们给高级套餐配置了自己的回调重试节奏，但实际重试时间和预期不一致。我们现在只掌握这… |
| [FP-BM-MH-0258](03-multi_hop.md#fp-bm-mh-0258) | 多跳 | 3 | 多轮 | 客服转来一个问题：业务收到两次内容相同的回调，担心系统重复执行了付款逻辑。我们现在只… |
| [FP-BM-MH-0262](03-multi_hop.md#fp-bm-mh-0262) | 多跳 | 3 | 多轮 | 升级回调版本后，验签程序突然找不到原来的签名请求头。我们现在只掌握这些表面现象，不确… |
| [FP-BM-MH-0266](03-multi_hop.md#fp-bm-mh-0266) | 多跳 | 3 | 多轮 | 线上同事发现：回调内容和密钥看起来都对，但验签仍提示时间不合法。我们现在只掌握这些表… |
| [FP-BM-MH-0270](03-multi_hop.md#fp-bm-mh-0270) | 多跳 | 3 | 多轮 | 我们排查时发现：我们正在轮换回调密钥，担心切换期间旧实例会突然验签失败。我们现在只掌… |
| [FP-BM-MH-0274](03-multi_hop.md#fp-bm-mh-0274) | 多跳 | 3 | 多轮 | 我们排查时发现：同一个回调事件重试时签名发生了变化，接收方把它当成篡改。我们现在只掌… |
| [FP-BM-MH-0278](03-multi_hop.md#fp-bm-mh-0278) | 多跳 | 3 | 多轮 | 线上请求有时返回内部错误，有时又显示服务暂不可用，我们不知道处理方式是否一样。我们现… |
| [FP-BM-MH-0282](03-multi_hop.md#fp-bm-mh-0282) | 多跳 | 3 | 多轮 | 只有某个地区的线上请求明显变慢并报错，其他地区基本正常。我们现在只掌握这些表面现象，… |
| [FP-BM-MH-0286](03-multi_hop.md#fp-bm-mh-0286) | 多跳 | 3 | 多轮 | 请求在认证阶段就失败了，开发同学说因此没法继续排查。我们现在只掌握这些表面现象，不确… |
| [FP-BM-MH-0290](03-multi_hop.md#fp-bm-mh-0290) | 多跳 | 3 | 多轮 | 我们排查时发现：查询资源时统一提示不存在，但我们不确定是编号错了还是权限问题。我们现… |
| [FP-BM-MH-0294](03-multi_hop.md#fp-bm-mh-0294) | 多跳 | 3 | 多轮 | 客服转来一个问题：我们想排查一段时间以前的请求，但控制台已经查不到记录了。我们现在只… |
| [FP-BM-MH-0298](03-multi_hop.md#fp-bm-mh-0298) | 多跳 | 3 | 多轮 | 客户已经付款成功，但业务系统一直没有收到对应的回调通知。我们现在只掌握这些表面现象，… |
| [FP-BM-TV-0104](04-temporal_versioned.md#fp-bm-tv-0104) | 时效版本 | 4 | 多轮 | 一笔已经成功的支付后来又收到状态更新，我们担心它被改回处理中。这不是刚刚发生的问题，… |
| [FP-BM-TV-0108](04-temporal_versioned.md#fp-bm-tv-0108) | 时效版本 | 4 | 多轮 | 客户那边反馈：客户已经完成验证，但那笔待确认支付仍没有继续成功。这不是刚刚发生的问题… |
| [FP-BM-TV-0112](04-temporal_versioned.md#fp-bm-tv-0112) | 时效版本 | 4 | 多轮 | 客服转来一个问题：我们想取消一笔支付，接口却说当前状态不允许取消。这不是刚刚发生的问… |
| [FP-BM-TV-0116](04-temporal_versioned.md#fp-bm-tv-0116) | 时效版本 | 4 | 多轮 | 我们排查时发现：一笔失败支付修好原因后，我们反复重试原对象还是没有变化。这不是刚刚发… |
| [FP-BM-TV-0120](04-temporal_versioned.md#fp-bm-tv-0120) | 时效版本 | 4 | 多轮 | 客服转来一个问题：客户付款时被拒绝了，但我们看不出是平台故障还是支付方式的问题。这不… |
| [FP-BM-TV-0124](04-temporal_versioned.md#fp-bm-tv-0124) | 时效版本 | 4 | 多轮 | 客户说卡能正常使用，可这笔支付一直提示资金方面的问题。这不是刚刚发生的问题，我们不确… |
| [FP-BM-TV-0128](04-temporal_versioned.md#fp-bm-tv-0128) | 时效版本 | 4 | 多轮 | 我们排查时发现：一批老客户最近付款失败，似乎都和保存过的支付方式有关。这不是刚刚发生… |
| [FP-BM-TV-0132](04-temporal_versioned.md#fp-bm-tv-0132) | 时效版本 | 4 | 多轮 | 线上同事发现：同一类客户验证问题，在新旧客户端里一个显示失败，一个显示待操作。这不是… |
| [FP-BM-TV-0136](04-temporal_versioned.md#fp-bm-tv-0136) | 时效版本 | 4 | 多轮 | 我们排查时发现：支付还在处理中，客服就发起了退款，系统没有接受。这不是刚刚发生的问题… |
| [FP-BM-TV-0140](04-temporal_versioned.md#fp-bm-tv-0140) | 时效版本 | 4 | 多轮 | 客服想给客户退一部分金额，但退款接口一直拒绝。这不是刚刚发生的问题，我们不确定当时的… |
| [FP-BM-TV-0144](04-temporal_versioned.md#fp-bm-tv-0144) | 时效版本 | 4 | 多轮 | 客服转来一个问题：同一笔支付已经退过一部分，现在第二次部分退款出现了额度问题。这不是… |
| [FP-BM-TV-0148](04-temporal_versioned.md#fp-bm-tv-0148) | 时效版本 | 4 | 多轮 | 线上同事发现：一笔退款还没处理完，客服又发起退款时发现可退金额变少了。这不是刚刚发生… |
| [FP-BM-TV-0152](04-temporal_versioned.md#fp-bm-tv-0152) | 时效版本 | 4 | 多轮 | 线上同事发现：之前的退款失败了，但客服不确定那部分金额还能不能重新退。这不是刚刚发生… |
| [FP-BM-TV-0156](04-temporal_versioned.md#fp-bm-tv-0156) | 时效版本 | 4 | 多轮 | 客服转来一个问题：客服在给一笔很久以前的支付退款时被拒绝了。这不是刚刚发生的问题，我… |
| [FP-BM-TV-0160](04-temporal_versioned.md#fp-bm-tv-0160) | 时效版本 | 4 | 多轮 | 我们排查时发现：我们给北美客户做快速退款，但结果没有按预期立刻完成。这不是刚刚发生的… |
| [FP-BM-TV-0164](04-temporal_versioned.md#fp-bm-tv-0164) | 时效版本 | 4 | 多轮 | 客户那边反馈：亚太地区的一笔退款勾选了快速到账，却一直无法提交。这不是刚刚发生的问题… |
| [FP-BM-TV-0168](04-temporal_versioned.md#fp-bm-tv-0168) | 时效版本 | 4 | 多轮 | 我们排查时发现：快速退款偶尔能用、偶尔被拒绝，我们怀疑和账户配置或金额有关。这不是刚… |
| [FP-BM-TV-0172](04-temporal_versioned.md#fp-bm-tv-0172) | 时效版本 | 4 | 多轮 | 线上同事发现：普通支付没问题，但一创建订阅就提示当前账户不能使用。这不是刚刚发生的问… |
| [FP-BM-TV-0176](04-temporal_versioned.md#fp-bm-tv-0176) | 时效版本 | 4 | 多轮 | 客户那边反馈：创建带试用期的订阅时，某些天数可以，某些天数直接报参数错误。这不是刚刚… |
| [FP-BM-TV-0180](04-temporal_versioned.md#fp-bm-tv-0180) | 时效版本 | 4 | 多轮 | 我们排查时发现：客户选择到期取消订阅，但我们担心系统会立即停掉服务。这不是刚刚发生的… |
| [FP-BM-TV-0184](04-temporal_versioned.md#fp-bm-tv-0184) | 时效版本 | 4 | 多轮 | 客户那边反馈：客服执行立即取消后，客户仍在问这一期是否还会继续计费。这不是刚刚发生的… |
| [FP-BM-TV-0188](04-temporal_versioned.md#fp-bm-tv-0188) | 时效版本 | 4 | 多轮 | 客服转来一个问题：业务想把现有订阅转给另一个客户，同时顺便换结算币种。这不是刚刚发生… |
| [FP-BM-TV-0192](04-temporal_versioned.md#fp-bm-tv-0192) | 时效版本 | 4 | 多轮 | 客户那边反馈：订阅扣款第一次失败后很快恢复了，我们想确认账单是否还会继续重试。这不是… |
| [FP-BM-TV-0196](04-temporal_versioned.md#fp-bm-tv-0196) | 时效版本 | 4 | 多轮 | 我们排查时发现：订阅账单连续失败了几次，后来客户补足余额，不确定系统接下来怎么处理。… |
| [FP-BM-TV-0200](04-temporal_versioned.md#fp-bm-tv-0200) | 时效版本 | 4 | 多轮 | 客服转来一个问题：一张订阅账单多次扣款失败后就不再尝试了，订阅状态也变了。这不是刚刚… |
| [FP-BM-DG-0204](05-tool_use_diagnostic.md#fp-bm-dg-0204) | 工具诊断 | 5 | 多轮 | 客服想作废一张账单，但系统提示它当前不能作废。基础配置已经看过了，但还判断不出是客户… |
| [FP-BM-DG-0208](05-tool_use_diagnostic.md#fp-bm-dg-0208) | 工具诊断 | 5 | 多轮 | 我们排查时发现：客户不再需要一张尚未支付的账单，客服想确认能否直接作废。基础配置已经… |
| [FP-BM-DG-0212](05-tool_use_diagnostic.md#fp-bm-dg-0212) | 工具诊断 | 5 | 多轮 | 客户那边反馈：我们给账户新增回调地址时突然提示数量已到上限。基础配置已经看过了，但还… |
| [FP-BM-DG-0216](05-tool_use_diagnostic.md#fp-bm-dg-0216) | 工具诊断 | 5 | 多轮 | 套餐降级后，部分回调地址还在，部分却不再接收新事件。基础配置已经看过了，但还判断不出… |
| [FP-BM-DG-0220](05-tool_use_diagnostic.md#fp-bm-dg-0220) | 工具诊断 | 5 | 多轮 | 我们排查时发现：一个已停用的回调地址似乎还和事件有关，我们想确认会不会继续产生投递。… |
| [FP-BM-DG-0224](05-tool_use_diagnostic.md#fp-bm-dg-0224) | 工具诊断 | 5 | 多轮 | 客服转来一个问题：支付已经成功，但其中一个回调地址始终收不到对应事件。基础配置已经看… |
| [FP-BM-DG-0228](05-tool_use_diagnostic.md#fp-bm-dg-0228) | 工具诊断 | 5 | 多轮 | 线上同事发现：支付成功以后，新旧回调消费者收到的事件名称不一样。基础配置已经看过了，… |
| [FP-BM-DG-0232](05-tool_use_diagnostic.md#fp-bm-dg-0232) | 工具诊断 | 5 | 多轮 | 客服转来一个问题：系统自动产生的事件版本和我们最近一次接口请求的版本对不上。基础配置… |
| [FP-BM-DG-0236](05-tool_use_diagnostic.md#fp-bm-dg-0236) | 工具诊断 | 5 | 多轮 | 线上同事发现：回调服务返回成功后，我们偶尔仍看到重复事件，不确定平台是否认为投递失败… |
| [FP-BM-DG-0240](05-tool_use_diagnostic.md#fp-bm-dg-0240) | 工具诊断 | 5 | 多轮 | 线上同事发现：回调地址做了跳转以后，平台没有跟过去，反而不断重试。基础配置已经看过了… |
| [FP-BM-DG-0244](05-tool_use_diagnostic.md#fp-bm-dg-0244) | 工具诊断 | 5 | 多轮 | 客服转来一个问题：回调服务明确返回客户端错误，平台却还是继续重试投递。基础配置已经看… |
| [FP-BM-DG-0248](05-tool_use_diagnostic.md#fp-bm-dg-0248) | 工具诊断 | 5 | 多轮 | 客服转来一个问题：回调服务返回资源已删除后，这个地址突然被系统停用了。基础配置已经看… |
| [FP-BM-DG-0252](05-tool_use_diagnostic.md#fp-bm-dg-0252) | 工具诊断 | 5 | 多轮 | 客服转来一个问题：一个回调地址故障很久后，平台似乎已经停止继续投递。基础配置已经看过… |
| [FP-BM-DG-0256](05-tool_use_diagnostic.md#fp-bm-dg-0256) | 工具诊断 | 5 | 多轮 | 我们排查时发现：我们给高级套餐配置了自己的回调重试节奏，但实际重试时间和预期不一致。… |
| [FP-BM-DG-0260](05-tool_use_diagnostic.md#fp-bm-dg-0260) | 工具诊断 | 5 | 多轮 | 线上同事发现：业务收到两次内容相同的回调，担心系统重复执行了付款逻辑。基础配置已经看… |
| [FP-BM-DG-0264](05-tool_use_diagnostic.md#fp-bm-dg-0264) | 工具诊断 | 5 | 多轮 | 我们排查时发现：升级回调版本后，验签程序突然找不到原来的签名请求头。基础配置已经看过… |
| [FP-BM-DG-0268](05-tool_use_diagnostic.md#fp-bm-dg-0268) | 工具诊断 | 5 | 多轮 | 回调内容和密钥看起来都对，但验签仍提示时间不合法。基础配置已经看过了，但还判断不出是… |
| [FP-BM-DG-0272](05-tool_use_diagnostic.md#fp-bm-dg-0272) | 工具诊断 | 5 | 多轮 | 客户那边反馈：我们正在轮换回调密钥，担心切换期间旧实例会突然验签失败。基础配置已经看… |
| [FP-BM-DG-0276](05-tool_use_diagnostic.md#fp-bm-dg-0276) | 工具诊断 | 5 | 多轮 | 客户那边反馈：同一个回调事件重试时签名发生了变化，接收方把它当成篡改。基础配置已经看… |
| [FP-BM-DG-0280](05-tool_use_diagnostic.md#fp-bm-dg-0280) | 工具诊断 | 5 | 多轮 | 我们排查时发现：线上请求有时返回内部错误，有时又显示服务暂不可用，我们不知道处理方式… |
| [FP-BM-DG-0284](05-tool_use_diagnostic.md#fp-bm-dg-0284) | 工具诊断 | 5 | 多轮 | 我们排查时发现：只有某个地区的线上请求明显变慢并报错，其他地区基本正常。基础配置已经… |
| [FP-BM-DG-0288](05-tool_use_diagnostic.md#fp-bm-dg-0288) | 工具诊断 | 5 | 多轮 | 我们排查时发现：请求在认证阶段就失败了，开发同学说因此没法继续排查。基础配置已经看过… |
| [FP-BM-DG-0292](05-tool_use_diagnostic.md#fp-bm-dg-0292) | 工具诊断 | 5 | 多轮 | 客户那边反馈：查询资源时统一提示不存在，但我们不确定是编号错了还是权限问题。基础配置… |
| [FP-BM-DG-0296](05-tool_use_diagnostic.md#fp-bm-dg-0296) | 工具诊断 | 5 | 多轮 | 线上同事发现：我们想排查一段时间以前的请求，但控制台已经查不到记录了。基础配置已经看… |
| [FP-BM-DG-0300](05-tool_use_diagnostic.md#fp-bm-dg-0300) | 工具诊断 | 5 | 多轮 | 我们排查时发现：客户已经付款成功，但业务系统一直没有收到对应的回调通知。基础配置已经… |
| [FP-BM-MS-0004](06-multi_source.md#fp-bm-ms-0004) | 跨数据源 | 4 | 多轮 | 我们排查时发现：后台里明明能看到一笔支付，但我们从服务里查询时一直提示找不到。业务侧… |
| [FP-BM-MS-0008](06-multi_source.md#fp-bm-ms-0008) | 跨数据源 | 4 | 多轮 | 我们排查时发现：测试时一直正常，可一上线创建支付就变成认证失败了。业务侧看到的结果和… |
| [FP-BM-MS-0012](06-multi_source.md#fp-bm-ms-0012) | 跨数据源 | 4 | 多轮 | 客服转来一个问题：我们刚开好账户，准备接正式环境，但创建正式密钥时被拒绝了。业务侧看… |
| [FP-BM-MS-0016](06-multi_source.md#fp-bm-ms-0016) | 跨数据源 | 4 | 多轮 | 我们排查时发现：正式环境的请求突然全都被拒绝了，可测试环境还是正常的。业务侧看到的结… |
| [FP-BM-MS-0020](06-multi_source.md#fp-bm-ms-0020) | 跨数据源 | 4 | 多轮 | 有个欧洲客户下单时支付创建失败，我们怀疑是币种设置的问题。业务侧看到的结果和接口表现… |
| [FP-BM-MS-0024](06-multi_source.md#fp-bm-ms-0024) | 跨数据源 | 4 | 多轮 | 客服转来一个问题：有两笔金额很特殊的支付怎么都建不出来，普通金额却没问题。业务侧看到… |
| [FP-BM-MS-0028](06-multi_source.md#fp-bm-ms-0028) | 跨数据源 | 4 | 多轮 | 我们已经把订阅功能开关打开了，但创建订阅仍然提示没有权限。业务侧看到的结果和接口表现… |
| [FP-BM-MS-0032](06-multi_source.md#fp-bm-ms-0032) | 跨数据源 | 4 | 多轮 | 客户那边反馈：我们刚升级套餐，紧接着使用新功能时，不确定系统有没有按新套餐处理。业务… |
| [FP-BM-MS-0036](06-multi_source.md#fp-bm-ms-0036) | 跨数据源 | 4 | 多轮 | 线上同事发现：我们提交了降级，之后又新增了一个回调地址，不确定它会不会受新套餐限制。… |
| [FP-BM-MS-0040](06-multi_source.md#fp-bm-ms-0040) | 跨数据源 | 4 | 多轮 | 客户那边反馈：我们正在更换线上密钥，担心新旧实例切换期间会中断请求。业务侧看到的结果… |
| [FP-BM-MS-0044](06-multi_source.md#fp-bm-ms-0044) | 跨数据源 | 4 | 多轮 | 我们排查时发现：有把线上密钥误操作停用了，现在旧部署全部认证失败。业务侧看到的结果和… |
| [FP-BM-MS-0048](06-multi_source.md#fp-bm-ms-0048) | 跨数据源 | 4 | 多轮 | 客服转来一个问题：有一批请求突然报版本不支持，但账户里的默认版本看起来没问题。业务侧… |
| [FP-BM-MS-0052](06-multi_source.md#fp-bm-ms-0052) | 跨数据源 | 4 | 多轮 | 线上同事发现：支付还能创建成功，不过响应里一直提示一个参数快不能用了。业务侧看到的结… |
| [FP-BM-MS-0056](06-multi_source.md#fp-bm-ms-0056) | 跨数据源 | 4 | 多轮 | 我们排查时发现：升级接口版本以后，原来能用的支付参数突然全部报错。业务侧看到的结果和… |
| [FP-BM-MS-0060](06-multi_source.md#fp-bm-ms-0060) | 跨数据源 | 4 | 多轮 | 客服转来一个问题：同一种需要客户确认的支付，在两套客户端里表现成了完全不同的状态。业… |
| [FP-BM-MS-0064](06-multi_source.md#fp-bm-ms-0064) | 跨数据源 | 4 | 多轮 | 线上同事发现：一次创建支付超时后我们重试了，现在担心系统生成了两笔支付。业务侧看到的… |
| [FP-BM-MS-0068](06-multi_source.md#fp-bm-ms-0068) | 跨数据源 | 4 | 多轮 | 线上同事发现：我们重试创建支付时改了金额，结果既没更新也没新建。业务侧看到的结果和接… |
| [FP-BM-MS-0072](06-multi_source.md#fp-bm-ms-0072) | 跨数据源 | 4 | 多轮 | 隔了一天多重试同一笔业务后，系统里好像多出了一笔支付。业务侧看到的结果和接口表现对不… |
| [FP-BM-MS-0076](06-multi_source.md#fp-bm-ms-0076) | 跨数据源 | 4 | 多轮 | 线上同事发现：压测测试环境时很快就被限流了，降低并发后还是容易触发。业务侧看到的结果… |
| [FP-BM-MS-0080](06-multi_source.md#fp-bm-ms-0080) | 跨数据源 | 4 | 多轮 | 线上同事发现：线上流量短时间冲高后开始大量限流，但平时的请求量并不大。业务侧看到的结… |
| [FP-BM-MS-0084](06-multi_source.md#fp-bm-ms-0084) | 跨数据源 | 4 | 多轮 | 客户那边反馈：服务被限流后，客户端越重试错误越多，流量反而一直降不下来。业务侧看到的… |
| [FP-BM-MS-0088](06-multi_source.md#fp-bm-ms-0088) | 跨数据源 | 4 | 多轮 | 客户那边反馈：业务接口被限流的同时，回调还在持续收到，我们不确定这是否正常。业务侧看… |
| [FP-BM-MS-0092](06-multi_source.md#fp-bm-ms-0092) | 跨数据源 | 4 | 多轮 | 客户那边反馈：客户被删除后后台仍能查到以前的支付，我们担心删除没有生效。业务侧看到的… |
| [FP-BM-MS-0096](06-multi_source.md#fp-bm-ms-0096) | 跨数据源 | 4 | 多轮 | 线上同事发现：一个已经删除的客户仍被业务系统拿来创建新支付，结果一直失败。业务侧看到… |
| [FP-BM-MS-0100](06-multi_source.md#fp-bm-ms-0100) | 跨数据源 | 4 | 多轮 | 客服转来一个问题：同一个邮箱似乎对应了两个客户，我们不知道支付该关联哪一个。业务侧看… |
| [FP-BM-MS-0123](06-multi_source.md#fp-bm-ms-0123) | 跨数据源 | 4 | 多轮 | 客服转来一个问题：客户说卡能正常使用，可这笔支付一直提示资金方面的问题。业务侧看到的… |
| [FP-BM-MS-0127](06-multi_source.md#fp-bm-ms-0127) | 跨数据源 | 4 | 多轮 | 线上同事发现：一批老客户最近付款失败，似乎都和保存过的支付方式有关。业务侧看到的结果… |
| [FP-BM-MS-0131](06-multi_source.md#fp-bm-ms-0131) | 跨数据源 | 4 | 多轮 | 客户那边反馈：同一类客户验证问题，在新旧客户端里一个显示失败，一个显示待操作。业务侧… |
| [FP-BM-MS-0135](06-multi_source.md#fp-bm-ms-0135) | 跨数据源 | 4 | 多轮 | 线上同事发现：支付还在处理中，客服就发起了退款，系统没有接受。业务侧看到的结果和接口… |
| [FP-BM-MS-0139](06-multi_source.md#fp-bm-ms-0139) | 跨数据源 | 4 | 多轮 | 客服转来一个问题：客服想给客户退一部分金额，但退款接口一直拒绝。业务侧看到的结果和接… |
| [FP-BM-MS-0143](06-multi_source.md#fp-bm-ms-0143) | 跨数据源 | 4 | 多轮 | 我们排查时发现：同一笔支付已经退过一部分，现在第二次部分退款出现了额度问题。业务侧看… |
| [FP-BM-MS-0147](06-multi_source.md#fp-bm-ms-0147) | 跨数据源 | 4 | 多轮 | 客户那边反馈：一笔退款还没处理完，客服又发起退款时发现可退金额变少了。业务侧看到的结… |
| [FP-BM-MS-0151](06-multi_source.md#fp-bm-ms-0151) | 跨数据源 | 4 | 多轮 | 客户那边反馈：之前的退款失败了，但客服不确定那部分金额还能不能重新退。业务侧看到的结… |
| [FP-BM-MS-0155](06-multi_source.md#fp-bm-ms-0155) | 跨数据源 | 4 | 多轮 | 我们排查时发现：客服在给一笔很久以前的支付退款时被拒绝了。业务侧看到的结果和接口表现… |
| [FP-BM-MS-0159](06-multi_source.md#fp-bm-ms-0159) | 跨数据源 | 4 | 多轮 | 线上同事发现：我们给北美客户做快速退款，但结果没有按预期立刻完成。业务侧看到的结果和… |
| [FP-BM-MS-0163](06-multi_source.md#fp-bm-ms-0163) | 跨数据源 | 4 | 多轮 | 亚太地区的一笔退款勾选了快速到账，却一直无法提交。业务侧看到的结果和接口表现对不上，… |
| [FP-BM-MS-0167](06-multi_source.md#fp-bm-ms-0167) | 跨数据源 | 4 | 多轮 | 线上同事发现：快速退款偶尔能用、偶尔被拒绝，我们怀疑和账户配置或金额有关。业务侧看到… |
| [FP-BM-MS-0171](06-multi_source.md#fp-bm-ms-0171) | 跨数据源 | 4 | 多轮 | 客户那边反馈：普通支付没问题，但一创建订阅就提示当前账户不能使用。业务侧看到的结果和… |
| [FP-BM-MS-0175](06-multi_source.md#fp-bm-ms-0175) | 跨数据源 | 4 | 多轮 | 创建带试用期的订阅时，某些天数可以，某些天数直接报参数错误。业务侧看到的结果和接口表… |
| [FP-BM-MS-0179](06-multi_source.md#fp-bm-ms-0179) | 跨数据源 | 4 | 多轮 | 线上同事发现：客户选择到期取消订阅，但我们担心系统会立即停掉服务。业务侧看到的结果和… |
| [FP-BM-MS-0183](06-multi_source.md#fp-bm-ms-0183) | 跨数据源 | 4 | 多轮 | 客服执行立即取消后，客户仍在问这一期是否还会继续计费。业务侧看到的结果和接口表现对不… |
| [FP-BM-MS-0187](06-multi_source.md#fp-bm-ms-0187) | 跨数据源 | 4 | 多轮 | 我们排查时发现：业务想把现有订阅转给另一个客户，同时顺便换结算币种。业务侧看到的结果… |
| [FP-BM-MS-0191](06-multi_source.md#fp-bm-ms-0191) | 跨数据源 | 4 | 多轮 | 订阅扣款第一次失败后很快恢复了，我们想确认账单是否还会继续重试。业务侧看到的结果和接… |
| [FP-BM-MS-0195](06-multi_source.md#fp-bm-ms-0195) | 跨数据源 | 4 | 多轮 | 线上同事发现：订阅账单连续失败了几次，后来客户补足余额，不确定系统接下来怎么处理。业… |
| [FP-BM-MS-0199](06-multi_source.md#fp-bm-ms-0199) | 跨数据源 | 4 | 多轮 | 我们排查时发现：一张订阅账单多次扣款失败后就不再尝试了，订阅状态也变了。业务侧看到的… |
| [FP-BM-MS-0203](06-multi_source.md#fp-bm-ms-0203) | 跨数据源 | 4 | 多轮 | 线上同事发现：客服想作废一张账单，但系统提示它当前不能作废。业务侧看到的结果和接口表… |
| [FP-BM-MS-0207](06-multi_source.md#fp-bm-ms-0207) | 跨数据源 | 4 | 多轮 | 客户不再需要一张尚未支付的账单，客服想确认能否直接作废。业务侧看到的结果和接口表现对… |
| [FP-BM-MS-0211](06-multi_source.md#fp-bm-ms-0211) | 跨数据源 | 4 | 多轮 | 我们排查时发现：我们给账户新增回调地址时突然提示数量已到上限。业务侧看到的结果和接口… |
| [FP-BM-MS-0215](06-multi_source.md#fp-bm-ms-0215) | 跨数据源 | 4 | 多轮 | 线上同事发现：套餐降级后，部分回调地址还在，部分却不再接收新事件。业务侧看到的结果和… |
| [FP-BM-MS-0219](06-multi_source.md#fp-bm-ms-0219) | 跨数据源 | 4 | 多轮 | 一个已停用的回调地址似乎还和事件有关，我们想确认会不会继续产生投递。业务侧看到的结果… |
| [FP-BM-MS-0223](06-multi_source.md#fp-bm-ms-0223) | 跨数据源 | 4 | 多轮 | 客户那边反馈：支付已经成功，但其中一个回调地址始终收不到对应事件。业务侧看到的结果和… |
| [FP-BM-MS-0227](06-multi_source.md#fp-bm-ms-0227) | 跨数据源 | 4 | 多轮 | 客服转来一个问题：支付成功以后，新旧回调消费者收到的事件名称不一样。业务侧看到的结果… |
| [FP-BM-MS-0231](06-multi_source.md#fp-bm-ms-0231) | 跨数据源 | 4 | 多轮 | 客户那边反馈：系统自动产生的事件版本和我们最近一次接口请求的版本对不上。业务侧看到的… |
| [FP-BM-MS-0235](06-multi_source.md#fp-bm-ms-0235) | 跨数据源 | 4 | 多轮 | 客服转来一个问题：回调服务返回成功后，我们偶尔仍看到重复事件，不确定平台是否认为投递… |
| [FP-BM-MS-0239](06-multi_source.md#fp-bm-ms-0239) | 跨数据源 | 4 | 多轮 | 客服转来一个问题：回调地址做了跳转以后，平台没有跟过去，反而不断重试。业务侧看到的结… |
| [FP-BM-MS-0243](06-multi_source.md#fp-bm-ms-0243) | 跨数据源 | 4 | 多轮 | 客户那边反馈：回调服务明确返回客户端错误，平台却还是继续重试投递。业务侧看到的结果和… |
| [FP-BM-MS-0247](06-multi_source.md#fp-bm-ms-0247) | 跨数据源 | 4 | 多轮 | 客户那边反馈：回调服务返回资源已删除后，这个地址突然被系统停用了。业务侧看到的结果和… |
| [FP-BM-MS-0251](06-multi_source.md#fp-bm-ms-0251) | 跨数据源 | 4 | 多轮 | 客户那边反馈：一个回调地址故障很久后，平台似乎已经停止继续投递。业务侧看到的结果和接… |
| [FP-BM-MS-0255](06-multi_source.md#fp-bm-ms-0255) | 跨数据源 | 4 | 多轮 | 我们给高级套餐配置了自己的回调重试节奏，但实际重试时间和预期不一致。业务侧看到的结果… |
| [FP-BM-MS-0259](06-multi_source.md#fp-bm-ms-0259) | 跨数据源 | 4 | 多轮 | 客服转来一个问题：业务收到两次内容相同的回调，担心系统重复执行了付款逻辑。业务侧看到… |
| [FP-BM-MS-0263](06-multi_source.md#fp-bm-ms-0263) | 跨数据源 | 4 | 多轮 | 升级回调版本后，验签程序突然找不到原来的签名请求头。业务侧看到的结果和接口表现对不上… |
| [FP-BM-MS-0267](06-multi_source.md#fp-bm-ms-0267) | 跨数据源 | 4 | 多轮 | 线上同事发现：回调内容和密钥看起来都对，但验签仍提示时间不合法。业务侧看到的结果和接… |
| [FP-BM-MS-0271](06-multi_source.md#fp-bm-ms-0271) | 跨数据源 | 4 | 多轮 | 我们排查时发现：我们正在轮换回调密钥，担心切换期间旧实例会突然验签失败。业务侧看到的… |
| [FP-BM-MS-0275](06-multi_source.md#fp-bm-ms-0275) | 跨数据源 | 4 | 多轮 | 我们排查时发现：同一个回调事件重试时签名发生了变化，接收方把它当成篡改。业务侧看到的… |
| [FP-BM-MS-0279](06-multi_source.md#fp-bm-ms-0279) | 跨数据源 | 4 | 多轮 | 线上请求有时返回内部错误，有时又显示服务暂不可用，我们不知道处理方式是否一样。业务侧… |
| [FP-BM-MS-0283](06-multi_source.md#fp-bm-ms-0283) | 跨数据源 | 4 | 多轮 | 只有某个地区的线上请求明显变慢并报错，其他地区基本正常。业务侧看到的结果和接口表现对… |
| [FP-BM-MS-0287](06-multi_source.md#fp-bm-ms-0287) | 跨数据源 | 4 | 多轮 | 请求在认证阶段就失败了，开发同学说因此没法继续排查。业务侧看到的结果和接口表现对不上… |
| [FP-BM-MS-0291](06-multi_source.md#fp-bm-ms-0291) | 跨数据源 | 4 | 多轮 | 我们排查时发现：查询资源时统一提示不存在，但我们不确定是编号错了还是权限问题。业务侧… |
| [FP-BM-MS-0295](06-multi_source.md#fp-bm-ms-0295) | 跨数据源 | 4 | 多轮 | 客服转来一个问题：我们想排查一段时间以前的请求，但控制台已经查不到记录了。业务侧看到… |
| [FP-BM-MS-0299](06-multi_source.md#fp-bm-ms-0299) | 跨数据源 | 4 | 多轮 | 客户已经付款成功，但业务系统一直没有收到对应的回调通知。业务侧看到的结果和接口表现对… |
