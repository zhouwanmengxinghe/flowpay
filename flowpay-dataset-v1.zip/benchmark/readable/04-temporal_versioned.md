# 时效版本　`temporal_versioned`　25 道

## FP-BM-TV-0104

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-026-payment_success_terminal`
- 快照时点 `as_of`：2026-08-01T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_success_terminal`

### 开场白

> 一笔已经成功的支付后来又收到状态更新，我们担心它被改回处理中。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Payment 是否会重新进入 processing。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付已 succeeded，之后客户端尝试再次 confirm，并在列表与详情接口中查询它。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 1 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_026，那笔支付的编号是 pay_bm_026，那次请求的编号是 req_bm_026_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`before_knowledge`，取 `account_context`）先确认支付所属环境，以及账户当前套餐和主地区。
3. （`before_knowledge`，取 `api_version`）这次调用使用的是哪个接口版本？如果没有显式设置，也请说明账户默认版本。
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对实际支付记录，请提供大概发生时间，以及能找到的支付或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不会；succeeded 是终态，再次 confirm 不得逆转状态，列表与详情应显示同一业务状态。 处理方式：保留原 Payment，若有新的收费意图应创建新 Payment。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0104-A1` 不会；succeeded 是终态，再次 confirm 不得逆转状态，列表与详情应显示同一业务状态。
- `FP-BM-TV-0104-A2` 保留原 Payment，若有新的收费意图应创建新 Payment。

禁止结论（说了就算错）：

- 不得认定：再次 confirm 可以重新处理已成功 Payment

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-010`、`KB-API-015`、`KB-API-012`、`KB-API-014`、`KB-API-017`
- 操作：`query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.get_request`
- 规则：`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-PAY-007`、`RULE-REQ-003`、`RULE-TENANT-001`、`RULE-TENANT-002`、`RULE-TENANT-003`、`RULE-TENANT-004`、`RULE-VERSION-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`、`search_api_docs`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不会；succeeded 是终态，再次 confirm 不得逆转状态，列表与详情应显示同一业务状态。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-01T12:00:00Z、`payment_id`=pay_bm_026 | `exactly_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_026、`as_of`=2026-08-01T12:00:00Z | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-01T12:00:00Z、`request_id`=req_bm_026_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-01T11:20:04.000Z` 支付 pay_bm_026 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-01T11:20:04.000Z` 支付 pay_bm_026 状态 succeeded，金额 10000 USD
- `2026-08-01T11:50:00.000Z` 请求 req_bm_026_01 在 2026 年 08 月 01 日 11:50 UTC 以 POST 调用 /v1/payments/pay_bm_026/confirm，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 payment_id=pay_bm_026

查到的实例事实：

- `get_payment` 支付 pay_bm_026 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `list_payments` 支付 pay_bm_026 状态 succeeded，金额 10000 USD。
- `get_request` 请求 req_bm_026_01 在 2026 年 08 月 01 日 11:50 UTC 以 POST 调用 /v1/payments/pay_bm_026/confirm，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 payment_id=pay_bm_026。

证据 ID：`doc:KB-BR-010#c004`、`doc:KB-API-015#c006`、`doc:KB-API-012#c003`、`doc:KB-API-014#c004`、`doc:KB-API-017#c005`、`sql:payment:pay_bm_026`、`runtime:req:req_bm_026_01`

## FP-BM-TV-0108

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-027-confirm_requires_action`
- 快照时点 `as_of`：2026-08-02T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`confirm_requires_action`

### 开场白

> 客户那边反馈：客户已经完成验证，但那笔待确认支付仍没有继续成功。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认confirm 后允许发生什么状态变化。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 当前部署使用的接口版本 Payment 那笔支付处于 requires_action，客户完成验证后发送 confirm。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 2 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_027，那笔支付的编号是 pay_bm_027，那次请求的编号是 req_bm_027_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`before_knowledge`，取 `account_context`）这笔业务发生在测试还是正式环境？账户套餐和主地区能确认吗？
3. （`before_knowledge`，取 `api_version`）部署里配置的 API 版本或版本请求头是什么？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步需要查看这笔支付的状态变化。大概是什么时候，支付编号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 允许从 requires_action 进入 processing，再由处理结果进入 succeeded 或 failed。 处理方式：只对 requires_action 调用 confirm，并继续查询状态或处理 Webhook。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0108-A1` 允许从 requires_action 进入 processing，再由处理结果进入 succeeded 或 failed。
- `FP-BM-TV-0108-A2` 只对 requires_action 调用 confirm，并继续查询状态或处理 Webhook。

禁止结论（说了就算错）：

- 不得认定：confirm 会直接把任何 Payment 强制改成 succeeded

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-010`、`KB-API-015`
- 操作：`query_payments.get_payment`、`get_runtime_state.get_request`
- 规则：`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-PAY-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：允许从 requires_action 进入 processing，再由处理结果进入 succeeded 或 failed。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-02T12:00:00Z、`payment_id`=pay_bm_027 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-02T12:00:00Z、`request_id`=req_bm_027_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-02T11:50:00.000Z` 支付 pay_bm_027 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-02T11:50:00.000Z` 请求 req_bm_027_01 在 2026 年 08 月 02 日 11:50 UTC 以 POST 调用 /v1/payments/pay_bm_027/confirm，返回 HTTP 200，响应对象为 pay_bm_027，请求参数 payment_id=pay_bm_027

查到的实例事实：

- `get_payment` 支付 pay_bm_027 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_request` 请求 req_bm_027_01 在 2026 年 08 月 02 日 11:50 UTC 以 POST 调用 /v1/payments/pay_bm_027/confirm，返回 HTTP 200，响应对象为 pay_bm_027，请求参数 payment_id=pay_bm_027。

证据 ID：`doc:KB-BR-010#c004`、`doc:KB-API-015#c002`、`sql:payment:pay_bm_027`、`runtime:req:req_bm_027_01`

## FP-BM-TV-0112

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-028-cancel_payment_state_guard`
- 快照时点 `as_of`：2026-08-03T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`cancel_payment_state_guard`

### 开场白

> 客服转来一个问题：我们想取消一笔支付，接口却说当前状态不允许取消。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认是否应该把 Payment 改成 canceled。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户尝试取消 processing 的那笔支付，那次请求返回 FP-4221。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 3 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_028，那笔支付的编号是 pay_bm_028，那次请求的编号是 req_bm_028_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`before_knowledge`，取 `account_context`）先确认支付所属环境，以及账户当前套餐和主地区。
3. （`before_knowledge`，取 `api_version`）能确认当时客户端使用的接口版本吗？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需要把规则和实际交易对应起来。请给时间范围及支付或请求号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应该；processing 不允许主动取消，原状态保持不变。 处理方式：等待处理完成并根据最终状态采取后续操作。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0112-A1` 不应该；processing 不允许主动取消，原状态保持不变。
- `FP-BM-TV-0112-A2` 等待处理完成并根据最终状态采取后续操作。

禁止结论（说了就算错）：

- 不得认定：所有未成功 Payment 都可以取消

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-010`、`KB-API-016`、`KB-TS-014`
- 操作：`query_payments.get_payment`、`get_runtime_state.get_request`
- 规则：`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-PAY-007`、`RULE-REFUND-001`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应该；processing 不允许主动取消，原状态保持不变。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-03T12:00:00Z、`payment_id`=pay_bm_028 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-03T12:00:00Z、`request_id`=req_bm_028_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-03T11:20:04.000Z` 支付 pay_bm_028 状态 processing，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-03T11:50:00.000Z` 请求 req_bm_028_01 在 2026 年 08 月 03 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 422、错误码 FP-4221，响应对象为 无

查到的实例事实：

- `get_payment` 支付 pay_bm_028 状态 processing，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_request` 请求 req_bm_028_01 在 2026 年 08 月 03 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 422、错误码 FP-4221，响应对象为 无。

证据 ID：`doc:KB-BR-010#c006`、`doc:KB-API-016#c004`、`doc:KB-TS-014#c002`、`sql:payment:pay_bm_028`、`runtime:req:req_bm_028_01`

## FP-BM-TV-0116

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-029-failed_payment_new_retry`
- 快照时点 `as_of`：2026-08-04T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`failed_payment_new_retry`

### 开场白

> 我们排查时发现：一笔失败支付修好原因后，我们反复重试原对象还是没有变化。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认正确的重试模型是什么。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付因支付方式被拒绝进入 failed；商户对原 ID 再次 confirm，并在 Payment 列表查找后续尝试。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 4 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_029，那笔支付的编号是 pay_bm_029 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`before_knowledge`，取 `account_context`）这笔业务发生在测试还是正式环境？账户套餐和主地区能确认吗？
3. （`before_knowledge`，取 `api_version`）部署里配置的 API 版本或版本请求头是什么？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步需要查看这笔支付的状态变化。大概是什么时候，支付编号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 原 Payment 保持 failed；新的收费尝试必须有新的 Payment ID。 处理方式：创建新的 Payment，并在商户业务层关联两次尝试。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0116-A1` 原 Payment 保持 failed；新的收费尝试必须有新的 Payment ID。
- `FP-BM-TV-0116-A2` 创建新的 Payment，并在商户业务层关联两次尝试。

禁止结论（说了就算错）：

- 不得认定：把 failed Payment 原地改回 processing 能保持订单连续性

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`support_cases`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-010`、`KB-API-012`、`KB-API-017`、`KB-TS-021`、`KB-CASE-009`
- 操作：`query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.list_requests`
- 规则：`RULE-ERROR-002`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-PAY-007`、`RULE-TENANT-001`、`RULE-TENANT-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：原 Payment 保持 failed；新的收费尝试必须有新的 Payment ID。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-04T12:00:00Z、`payment_id`=pay_bm_029 | `exactly_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_029、`as_of`=2026-08-04T12:00:00Z | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_029、`as_of`=2026-08-04T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-04T11:20:04.000Z` 支付 pay_bm_029 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000
- `2026-08-04T11:20:04.000Z` 支付 pay_bm_029 状态 failed，金额 10000 USD，失败码 FP-4021
- `2026-08-04T11:50:00.000Z` 支付 pay_bm_029_retry 状态 succeeded，金额 10000 USD
- `2026-08-04T11:50:00.000Z` 请求 req_bm_029_01 在 2026 年 08 月 04 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_029_retry，请求参数 retry_of_payment_id=pay_bm_029

查到的实例事实：

- `get_payment` 支付 pay_bm_029 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000。
- `list_payments` 支付 pay_bm_029 状态 failed，金额 10000 USD，失败码 FP-4021；支付 pay_bm_029_retry 状态 succeeded，金额 10000 USD。
- `list_requests` 请求 req_bm_029_01 在 2026 年 08 月 04 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_029_retry，请求参数 retry_of_payment_id=pay_bm_029。

证据 ID：`doc:KB-BR-010#c004`、`doc:KB-API-012#c002`、`doc:KB-API-017#c005`、`doc:KB-TS-021#c002`、`doc:KB-CASE-009#c003`、`sql:payment:pay_bm_029`、`sql:payment:pay_bm_029_retry`、`runtime:req:req_bm_029_01`

## FP-BM-TV-0120

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-030-payment_method_declined`
- 快照时点 `as_of`：2026-08-05T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_method_declined`

### 开场白

> 客服转来一个问题：客户付款时被拒绝了，但我们看不出是平台故障还是支付方式的问题。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认根因类别和正确处置是什么。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付返回 FP-4021，Request 那次请求没有平台 Incident，客户认为稍后重试同一 Payment 即可。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 5 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_030，那笔支付的编号是 pay_bm_030，那次请求的编号是 req_bm_030_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`before_knowledge`，取 `account_context`）先确认支付所属环境，以及账户当前套餐和主地区。
3. （`before_knowledge`，取 `api_version`）这次调用使用的是哪个接口版本？如果没有显式设置，也请说明账户默认版本。
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对实际支付记录，请提供大概发生时间，以及能找到的支付或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 这是 Payment Method Declined；原 Payment 已 failed，应让客户更换支付方式并创建新 Payment。 处理方式：收集失败码，提示更换支付方式，不要无限重试原 Payment。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0120-A1` 这是 Payment Method Declined；原 Payment 已 failed，应让客户更换支付方式并创建新 Payment。
- `FP-BM-TV-0120-A2` 收集失败码，提示更换支付方式，不要无限重试原 Payment。

禁止结论（说了就算错）：

- 不得认定：FP-4021 表示 FlowPay 服务降级

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-011`、`KB-API-013`、`KB-TS-006`
- 操作：`query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.get_request`、`get_runtime_state.get_service_status`
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-REGION-001`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.get_request`、`get_runtime_state.get_service_status`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：这是 Payment Method Declined；原 Payment 已 failed，应让客户更换支付方式并创建新 Payment。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-05T12:00:00Z、`payment_id`=pay_bm_030 | `exactly_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_030、`as_of`=2026-08-05T12:00:00Z | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-05T12:00:00Z、`request_id`=req_bm_030_01 | `exactly_one` |
| `get_service_status` | `runtime` | `get_runtime_state.get_service_status` | `account_id`=acct_bm_030、`as_of`=2026-08-05T12:00:00Z | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-05T11:20:04.000Z` 支付 pay_bm_030 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000
- `2026-08-05T11:20:04.000Z` 支付 pay_bm_030 状态 failed，金额 10000 USD，失败码 FP-4021
- `2026-08-05T11:50:00.000Z` 请求 req_bm_030_01 在 2026 年 08 月 05 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4021，响应对象为 无

查到的实例事实：

- `get_payment` 支付 pay_bm_030 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000。
- `list_payments` 支付 pay_bm_030 状态 failed，金额 10000 USD，失败码 FP-4021。
- `get_request` 请求 req_bm_030_01 在 2026 年 08 月 05 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4021，响应对象为 无。
- `get_service_status` 在限定范围（as_of=2026-08-05T12:00:00Z）内没有查到 get_service_status 对应记录。

证据 ID：`doc:KB-BR-011#c003`、`doc:KB-API-013#c006`、`doc:KB-TS-006#c004`、`sql:payment:pay_bm_030`、`runtime:req:req_bm_030_01`、`negative:runtime:service_incident:b99caca3102c92b05cea`

## FP-BM-TV-0124

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-031-payment_insufficient_funds`
- 快照时点 `as_of`：2026-08-06T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_insufficient_funds`

### 开场白

> 客户说卡能正常使用，可这笔支付一直提示资金方面的问题。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这次能否沿用上次的拒绝根因。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付返回 FP-4022；同一客户此前另一笔 Payment 曾返回 FP-4021。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 6 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_031，那笔支付的编号是 pay_bm_031，那次请求的编号是 req_bm_031_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。
2. （`before_knowledge`，取 `account_context`）先确认支付所属环境，以及账户当前套餐和主地区。
3. （`before_knowledge`，取 `api_version`）这次调用使用的是哪个接口版本？如果没有显式设置，也请说明账户默认版本。
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对实际支付记录，请提供大概发生时间，以及能找到的支付或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；本次明确是 Insufficient Funds，应按 FP-4022 处理。 处理方式：向客户说明余额不足，新的支付尝试必须创建新 Payment。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0124-A1` 不能；本次明确是 Insufficient Funds，应按 FP-4022 处理。
- `FP-BM-TV-0124-A2` 向客户说明余额不足，新的支付尝试必须创建新 Payment。

禁止结论（说了就算错）：

- 不得认定：相同 HTTP 402 的所有错误根因都相同

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`troubleshooting`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_troubleshooting`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-011`、`KB-TS-007`、`KB-TS-021`
- 操作：`query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.get_request`
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_troubleshooting`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；本次明确是 Insufficient Funds，应按 FP-4022 处理。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-06T12:00:00Z、`payment_id`=pay_bm_031 | `exactly_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_031、`as_of`=2026-08-06T12:00:00Z | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-06T12:00:00Z、`request_id`=req_bm_031_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-06T11:20:04.000Z` 支付 pay_bm_031 状态 failed，金额 10000 USD，失败码 FP-4022，已占用退款额度 0、当前可退 10000
- `2026-08-06T11:20:04.000Z` 支付 pay_bm_031 状态 failed，金额 10000 USD，失败码 FP-4022
- `2026-08-06T11:50:00.000Z` 请求 req_bm_031_01 在 2026 年 08 月 06 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4022，响应对象为 无

查到的实例事实：

- `get_payment` 支付 pay_bm_031 状态 failed，金额 10000 USD，失败码 FP-4022，已占用退款额度 0、当前可退 10000。
- `list_payments` 支付 pay_bm_031 状态 failed，金额 10000 USD，失败码 FP-4022。
- `get_request` 请求 req_bm_031_01 在 2026 年 08 月 06 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4022，响应对象为 无。

证据 ID：`doc:KB-BR-011#c003`、`doc:KB-TS-007#c004`、`doc:KB-TS-021#c002`、`sql:payment:pay_bm_031`、`runtime:req:req_bm_031_01`

## FP-BM-TV-0128

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-032-payment_method_expired`
- 快照时点 `as_of`：2026-08-07T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_method_expired`

### 开场白

> 我们排查时发现：一批老客户最近付款失败，似乎都和保存过的支付方式有关。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认原样重放是否可能成功。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付使用已过期支付方式并返回 FP-4024，商户准备重放同一请求。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 7 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_032，那笔支付的编号是 pay_bm_032，那次请求的编号是 req_bm_032_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`before_knowledge`，取 `account_context`）这笔业务发生在测试还是正式环境？账户套餐和主地区能确认吗？
3. （`before_knowledge`，取 `api_version`）部署里配置的 API 版本或版本请求头是什么？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步需要查看这笔支付的状态变化。大概是什么时候，支付编号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不会改变已过期支付方式，也不会复活 failed Payment；应更新支付方式并创建新 Payment。 处理方式：获取新的有效支付方式后发起新的收费尝试。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0128-A1` 不会改变已过期支付方式，也不会复活 failed Payment；应更新支付方式并创建新 Payment。
- `FP-BM-TV-0128-A2` 获取新的有效支付方式后发起新的收费尝试。

禁止结论（说了就算错）：

- 不得认定：FP-4024 可以通过 API 重试退避自动恢复

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`troubleshooting`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_troubleshooting`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-011`、`KB-TS-009`、`KB-TS-021`
- 操作：`query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.get_request`
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_troubleshooting`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不会改变已过期支付方式，也不会复活 failed Payment；应更新支付方式并创建新 Payment。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-07T12:00:00Z、`payment_id`=pay_bm_032 | `exactly_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_032、`as_of`=2026-08-07T12:00:00Z | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-07T12:00:00Z、`request_id`=req_bm_032_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-07T11:20:04.000Z` 支付 pay_bm_032 状态 failed，金额 10000 USD，失败码 FP-4024，已占用退款额度 0、当前可退 10000
- `2026-08-07T11:20:04.000Z` 支付 pay_bm_032 状态 failed，金额 10000 USD，失败码 FP-4024
- `2026-08-07T11:50:00.000Z` 请求 req_bm_032_01 在 2026 年 08 月 07 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4024，响应对象为 无

查到的实例事实：

- `get_payment` 支付 pay_bm_032 状态 failed，金额 10000 USD，失败码 FP-4024，已占用退款额度 0、当前可退 10000。
- `list_payments` 支付 pay_bm_032 状态 failed，金额 10000 USD，失败码 FP-4024。
- `get_request` 请求 req_bm_032_01 在 2026 年 08 月 07 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4024，响应对象为 无。

证据 ID：`doc:KB-BR-011#c003`、`doc:KB-TS-009#c004`、`doc:KB-TS-021#c003`、`sql:payment:pay_bm_032`、`runtime:req:req_bm_032_01`

## FP-BM-TV-0132

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-033-action_required_old_and_new`
- 快照时点 `as_of`：2026-08-08T12:00:00Z　接口版本：2026-01-15
- 标签：`payments`、`action_required_old_and_new`

### 开场白

> 线上同事发现：同一类客户验证问题，在新旧客户端里一个显示失败，一个显示待操作。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认为什么两个 Payment 的状态不同，是否是数据不一致。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户的旧客户端与新客户端对同一类验证场景分别创建 Payment。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 8 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-01-15。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_033 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。
2. （`before_knowledge`，取 `account_context`）先确认支付所属环境，以及账户当前套餐和主地区。
3. （`before_knowledge`，取 `api_version`）部署里配置的 API 版本或版本请求头是什么？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步需要查看这笔支付的状态变化。大概是什么时候，支付编号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不是数据不一致；差异由请求 API Version 决定，旧版 failed + FP-4023，新版 requires_action。 处理方式：客户端按各自版本实现处理，并按迁移指南升级。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0132-A1` 不是数据不一致；差异由请求 API Version 决定，旧版 failed + FP-4023，新版 requires_action。
- `FP-BM-TV-0132-A2` 客户端按各自版本实现处理，并按迁移指南升级。

禁止结论（说了就算错）：

- 不得认定：同一业务原因必须在所有版本中有完全相同状态字段

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`release_notes`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_release_notes`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-011`、`KB-API-018`、`KB-TS-008`、`KB-REL-003`
- 操作：`query_accounts.get_account`、`query_payments.list_payments`、`get_runtime_state.list_requests`
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-005`、`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-005`、`RULE-VERSION-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_release_notes`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_payments.list_payments`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不是数据不一致；差异由请求 API Version 决定，旧版 failed + FP-4023，新版 requires_action。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_033、`as_of`=2026-08-08T12:00:00Z | `exactly_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_033、`as_of`=2026-08-08T12:00:00Z | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_033、`as_of`=2026-08-08T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-08T11:20:04.000Z` 支付 pay_bm_033 状态 requires_action，金额 10000 USD
- `2026-08-08T11:49:59.000Z` 请求 req_bm_033_01 在 2026 年 08 月 08 日 11:49 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4023，响应对象为 pay_bm_033_old，请求参数 payment_id=pay_bm_033_old、representation=legacy_failed
- `2026-08-08T11:50:00.000Z` 支付 pay_bm_033_old 状态 failed，金额 10000 USD，失败码 FP-4023
- `2026-08-08T11:50:00.000Z` 请求 req_d0b8895175_000002 在 2026 年 08 月 08 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_033，请求参数 payment_id=pay_bm_033、representation=requires_action

查到的实例事实：

- `get_account` 账户 acct_bm_033 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-01-15。
- `list_payments` 支付 pay_bm_033 状态 requires_action，金额 10000 USD；支付 pay_bm_033_old 状态 failed，金额 10000 USD，失败码 FP-4023。
- `list_requests` 请求 req_bm_033_01 在 2026 年 08 月 08 日 11:49 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4023，响应对象为 pay_bm_033_old，请求参数 payment_id=pay_bm_033_old、representation=legacy_failed；请求 req_d0b8895175_000002 在 2026 年 08 月 08 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_033，请求参数 payment_id=pay_bm_033、representation=requires_action。

证据 ID：`doc:KB-BR-011#c007`、`doc:KB-API-018#c004`、`doc:KB-TS-008#c006`、`doc:KB-REL-003#c006`、`sql:account:acct_bm_033`、`sql:payment:pay_bm_033`、`sql:payment:pay_bm_033_old`、`runtime:req:req_bm_033_01`、`runtime:req:req_d0b8895175_000002`

## FP-BM-TV-0136

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-034-refund_processing_payment`
- 快照时点 `as_of`：2026-08-09T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`refund_processing_payment`

### 开场白

> 我们排查时发现：支付还在处理中，客服就发起了退款，系统没有接受。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认是否已创建 pending Refund，以及正确等待条件是什么。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付仍为 processing，这个账户为它创建那笔退款，那次请求返回 FP-4221。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 9 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_034，那笔支付的编号是 pay_bm_034，那笔退款的编号是 re_bm_034，那次请求的编号是 req_bm_034_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`before_knowledge`，取 `account_context`）这笔退款属于测试还是真实交易？相关账户是什么套餐和地区？
3. （`before_knowledge`，取 `api_version`）这次调用使用的是哪个接口版本？如果没有显式设置，也请说明账户默认版本。
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需要确认实际退款链路。大概是什么时候，退款或原支付的编号能提供吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 没有创建 Refund；必须等待 Payment succeeded 后再申请退款。 处理方式：查询 Payment 最终状态，仅在 succeeded 后发起 Refund。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0136-A1` 没有创建 Refund；必须等待 Payment succeeded 后再申请退款。
- `FP-BM-TV-0136-A2` 查询 Payment 最终状态，仅在 succeeded 后发起 Refund。

禁止结论（说了就算错）：

- 不得认定：processing 已代表扣款完成，可以先占用退款额度

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`support_cases`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-012`、`KB-API-019`、`KB-TS-014`、`KB-CASE-010`
- 操作：`query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.get_request`
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：没有创建 Refund；必须等待 Payment succeeded 后再申请退款。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-09T12:00:00Z、`payment_id`=pay_bm_034 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-09T12:00:00Z、`refund_id`=re_bm_034 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-09T12:00:00Z、`request_id`=req_bm_034_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-09T11:20:04.000Z` 支付 pay_bm_034 状态 processing，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-09T11:50:00.000Z` 请求 req_bm_034_01 在 2026 年 08 月 09 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 mode=standard、payment_id=pay_bm_034、refund_id=re_bm_034

查到的实例事实：

- `get_payment` 支付 pay_bm_034 状态 processing，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_refund` 在限定范围（as_of=2026-08-09T12:00:00Z、refund_id=re_bm_034、account_id=acct_bm_034、environment=production）内没有查到 get_refund 对应记录。
- `get_request` 请求 req_bm_034_01 在 2026 年 08 月 09 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 mode=standard、payment_id=pay_bm_034、refund_id=re_bm_034。

证据 ID：`doc:KB-BR-012#c004`、`doc:KB-API-019#c006`、`doc:KB-TS-014#c004`、`doc:KB-CASE-010#c007`、`sql:payment:pay_bm_034`、`negative:sql:refund:4be8f746f3e07597566a`、`runtime:req:req_bm_034_01`

## FP-BM-TV-0140

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-035-starter_full_refund_only`
- 快照时点 `as_of`：2026-08-10T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`starter_full_refund_only`

### 开场白

> 客服想给客户退一部分金额，但退款接口一直拒绝。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Payment 可退款为何请求仍失败。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Starter Account 这个账户对 succeeded 的那笔支付申请小于剩余金额的那笔退款，返回 FP-4031。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Starter，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 10 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_035，那笔支付的编号是 pay_bm_035，那笔退款的编号是 re_bm_035，那次请求的编号是 req_bm_035_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。
2. （`before_knowledge`，取 `account_context`）这笔退款属于测试还是真实交易？相关账户是什么套餐和地区？
3. （`before_knowledge`，取 `api_version`）部署里配置的 API 版本或版本请求头是什么？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来要核对可退金额和退款状态。请提供时间范围及退款编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> Payment 状态合格，但 Starter 不支持部分退款；必须一次退还全部剩余可退金额。 处理方式：按剩余可退金额发起一次全额 Refund，或先合法升级套餐。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0140-A1` Payment 状态合格，但 Starter 不支持部分退款；必须一次退还全部剩余可退金额。
- `FP-BM-TV-0140-A2` 按剩余可退金额发起一次全额 Refund，或先合法升级套餐。

禁止结论（说了就算错）：

- 不得认定：只要 Payment succeeded，任何套餐都支持部分退款

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`support_cases`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-012`、`KB-API-020`、`KB-API-021`、`KB-TS-010`、`KB-CASE-011`
- 操作：`query_accounts.get_account`、`query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.get_request`
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`、`RULE-REGION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：Payment 状态合格，但 Starter 不支持部分退款；必须一次退还全部剩余可退金额。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_035、`as_of`=2026-08-10T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-10T12:00:00Z、`payment_id`=pay_bm_035 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-10T12:00:00Z、`refund_id`=re_bm_035 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-10T12:00:00Z、`request_id`=req_bm_035_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-10T11:20:04.000Z` 支付 pay_bm_035 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-10T11:50:00.000Z` 请求 req_bm_035_01 在 2026 年 08 月 10 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 403、错误码 FP-4031，响应对象为 无，请求参数 mode=standard、payment_id=pay_bm_035、refund_id=re_bm_035

查到的实例事实：

- `get_account` 账户 acct_bm_035 当时套餐为 Starter、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_payment` 支付 pay_bm_035 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_refund` 在限定范围（as_of=2026-08-10T12:00:00Z、refund_id=re_bm_035、account_id=acct_bm_035、environment=production）内没有查到 get_refund 对应记录。
- `get_request` 请求 req_bm_035_01 在 2026 年 08 月 10 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 403、错误码 FP-4031，响应对象为 无，请求参数 mode=standard、payment_id=pay_bm_035、refund_id=re_bm_035。

证据 ID：`doc:KB-BR-012#c003`、`doc:KB-API-020#c005`、`doc:KB-API-021#c006`、`doc:KB-TS-010#c003`、`doc:KB-CASE-011#c007`、`sql:account:acct_bm_035`、`sql:payment:pay_bm_035`、`negative:sql:refund:3adf5827423aebeee834`、`runtime:req:req_bm_035_01`

## FP-BM-TV-0144

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-036-growth_multiple_partial_refunds`
- 快照时点 `as_of`：2026-08-11T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`growth_multiple_partial_refunds`

### 开场白

> 客服转来一个问题：同一笔支付已经退过一部分，现在第二次部分退款出现了额度问题。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认第二笔部分 Refund 是否允许，剩余可退金额是多少。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Growth Account 这个账户对 10,000 的那笔支付先成功退款 2,000，再申请 3,000。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 11 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_036，那笔支付的编号是 pay_bm_036，那笔退款的编号是 re_bm_036 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`before_knowledge`，取 `account_context`）退款发生在哪个环境？账户套餐和所属地区分别是什么？
3. （`before_knowledge`，取 `api_version`）这次调用使用的是哪个接口版本？如果没有显式设置，也请说明账户默认版本。
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需要确认实际退款链路。大概是什么时候，退款或原支付的编号能提供吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 允许；第二笔后已占用 5,000，剩余可退金额为 5,000。 处理方式：每次创建前查询当前 pending+succeeded 占用与可退余额。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0144-A1` 允许；第二笔后已占用 5,000，剩余可退金额为 5,000。
- `FP-BM-TV-0144-A2` 每次创建前查询当前 pending+succeeded 占用与可退余额。

禁止结论（说了就算错）：

- 不得认定：部分退款只能发生一次

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_payments`
- 文档：`KB-BR-012`、`KB-API-021`、`KB-API-022`
- 操作：`query_accounts.get_account`、`query_payments.get_payment`、`query_payments.get_refund`
- 规则：`RULE-IDEMP-001`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`、`RULE-TENANT-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_payments.get_payment`、`query_payments.get_refund`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：允许；第二笔后已占用 5,000，剩余可退金额为 5,000。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_036、`as_of`=2026-08-11T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-11T12:00:00Z、`payment_id`=pay_bm_036 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-11T12:00:00Z、`refund_id`=re_bm_036 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-11T11:20:04.000Z` 支付 pay_bm_036 状态 succeeded，金额 10000 USD，已占用退款额度 5000、当前可退 5000
- `2026-08-11T11:50:00.000Z` 退款 re_bm_036 状态为 pending，金额 3000，关联支付为 pay_bm_036。

查到的实例事实：

- `get_account` 账户 acct_bm_036 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_payment` 支付 pay_bm_036 状态 succeeded，金额 10000 USD，已占用退款额度 5000、当前可退 5000。
- `get_refund` 退款 re_bm_036 状态为 pending，金额 3000，关联支付为 pay_bm_036。

证据 ID：`doc:KB-BR-012#c003`、`doc:KB-API-021#c006`、`doc:KB-API-022#c007`、`sql:account:acct_bm_036`、`sql:payment:pay_bm_036`、`sql:refund:re_bm_036`

## FP-BM-TV-0148

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-037-pending_refund_reserves_amount`
- 快照时点 `as_of`：2026-08-12T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`pending_refund_reserves_amount`

### 开场白

> 线上同事发现：一笔退款还没处理完，客服又发起退款时发现可退金额变少了。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认第二次请求能否通过。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 10,000 的那笔支付已有 6,000 pending 那笔退款，这个账户又申请 5,000。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 12 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_037，那笔支付的编号是 pay_bm_037，那笔退款的编号是 re_bm_037 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`before_knowledge`，取 `account_context`）这笔退款属于测试还是真实交易？相关账户是什么套餐和地区？
3. （`before_knowledge`，取 `api_version`）能确认当时客户端使用的接口版本吗？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了查看退款前后的金额变化，请给出大概日期和原支付或退款号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；pending 已占用 6,000，只剩 4,000 可退。 处理方式：等待 pending 完成或失败后重新查询可退金额。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0148-A1` 不能；pending 已占用 6,000，只剩 4,000 可退。
- `FP-BM-TV-0148-A2` 等待 pending 完成或失败后重新查询可退金额。

禁止结论（说了就算错）：

- 不得认定：pending 尚未成功，所以不影响可退余额

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`
- 文档：`KB-BR-012`、`KB-API-019`、`KB-API-022`
- 操作：`query_payments.get_payment`、`query_payments.get_refund`
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`、`RULE-TENANT-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_refund`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；pending 已占用 6,000，只剩 4,000 可退。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-12T12:00:00Z、`payment_id`=pay_bm_037 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-12T12:00:00Z、`refund_id`=re_bm_037 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-12T11:50:00.000Z` 支付 pay_bm_037 状态 succeeded，金额 10000 USD，已占用退款额度 6000、当前可退 4000
- `2026-08-12T11:50:00.000Z` 退款 re_bm_037 状态为 pending，金额 6000，关联支付为 pay_bm_037。

查到的实例事实：

- `get_payment` 支付 pay_bm_037 状态 succeeded，金额 10000 USD，已占用退款额度 6000、当前可退 4000。
- `get_refund` 退款 re_bm_037 状态为 pending，金额 6000，关联支付为 pay_bm_037。

证据 ID：`doc:KB-BR-012#c003`、`doc:KB-API-019#c004`、`doc:KB-API-022#c006`、`sql:payment:pay_bm_037`、`sql:refund:re_bm_037`

## FP-BM-TV-0152

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-038-failed_refund_releases_amount`
- 快照时点 `as_of`：2026-08-13T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`failed_refund_releases_amount`

### 开场白

> 线上同事发现：之前的退款失败了，但客服不确定那部分金额还能不能重新退。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这 4,000 是否仍被占用。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付的 4,000 pending 那笔退款随后 failed；商户再次查询可退金额。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 13 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_038，那笔支付的编号是 pay_bm_038，那笔退款的编号是 re_bm_038 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`before_knowledge`，取 `account_context`）退款发生在哪个环境？账户套餐和所属地区分别是什么？
3. （`before_knowledge`，取 `api_version`）这次调用使用的是哪个接口版本？如果没有显式设置，也请说明账户默认版本。
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需要确认实际退款链路。大概是什么时候，退款或原支付的编号能提供吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不再占用；failed Refund 释放额度，可退金额应相应增加。 处理方式：确认 Refund 终态后重新计算 succeeded+pending 占用。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0152-A1` 不再占用；failed Refund 释放额度，可退金额应相应增加。
- `FP-BM-TV-0152-A2` 确认 Refund 终态后重新计算 succeeded+pending 占用。

禁止结论（说了就算错）：

- 不得认定：Refund 一旦创建就永久占用额度

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`
- 文档：`KB-BR-012`、`KB-API-019`、`KB-API-022`
- 操作：`query_payments.get_payment`、`query_payments.get_refund`
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`、`RULE-TENANT-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_refund`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不再占用；failed Refund 释放额度，可退金额应相应增加。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-13T12:00:00Z、`payment_id`=pay_bm_038 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-13T12:00:00Z、`refund_id`=re_bm_038 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-13T11:20:05.000Z` 退款 re_bm_038 状态为 failed，金额 4000，关联支付为 pay_bm_038。
- `2026-08-13T11:50:00.000Z` 支付 pay_bm_038 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000

查到的实例事实：

- `get_payment` 支付 pay_bm_038 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_refund` 退款 re_bm_038 状态为 failed，金额 4000，关联支付为 pay_bm_038。

证据 ID：`doc:KB-BR-012#c004`、`doc:KB-API-019#c002`、`doc:KB-API-022#c003`、`sql:payment:pay_bm_038`、`sql:refund:re_bm_038`

## FP-BM-TV-0156

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-039-refund_window_expired`
- 快照时点 `as_of`：2026-08-14T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`refund_window_expired`

### 开场白

> 客服转来一个问题：客服在给一笔很久以前的支付退款时被拒绝了。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认有剩余金额是否足以使退款成功。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付在 181 天前 succeeded，当前仍有全部金额未退；这个账户创建那笔退款返回 FP-4222。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 14 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_039，那笔支付的编号是 pay_bm_039，那笔退款的编号是 re_bm_039，那次请求的编号是 req_bm_039_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。
2. （`before_knowledge`，取 `account_context`）这笔退款属于测试还是真实交易？相关账户是什么套餐和地区？
3. （`before_knowledge`，取 `api_version`）部署里配置的 API 版本或版本请求头是什么？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来要核对可退金额和退款状态。请提供时间范围及退款编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不足；退款窗口已经超过 180 天，即使余额完整也不具备资格。 处理方式：核对 succeeded_at 与请求时间，不要重试过期 Refund。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0156-A1` 不足；退款窗口已经超过 180 天，即使余额完整也不具备资格。
- `FP-BM-TV-0156-A2` 核对 succeeded_at 与请求时间，不要重试过期 Refund。

禁止结论（说了就算错）：

- 不得认定：可退余额大于零就代表永远可退款

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`support_cases`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-012`、`KB-API-020`、`KB-TS-015`、`KB-CASE-012`
- 操作：`query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.get_request`
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不足；退款窗口已经超过 180 天，即使余额完整也不具备资格。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-14T12:00:00Z、`payment_id`=pay_bm_039 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-14T12:00:00Z、`refund_id`=re_bm_039 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-14T12:00:00Z、`request_id`=req_bm_039_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-14T11:20:04.000Z` 支付 pay_bm_039 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-14T11:50:00.000Z` 请求 req_bm_039_01 在 2026 年 08 月 14 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 422、错误码 FP-4222，响应对象为 无，请求参数 mode=standard、payment_id=pay_bm_039、refund_id=re_bm_039

查到的实例事实：

- `get_payment` 支付 pay_bm_039 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_refund` 在限定范围（as_of=2026-08-14T12:00:00Z、refund_id=re_bm_039、account_id=acct_bm_039、environment=production）内没有查到 get_refund 对应记录。
- `get_request` 请求 req_bm_039_01 在 2026 年 08 月 14 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 422、错误码 FP-4222，响应对象为 无，请求参数 mode=standard、payment_id=pay_bm_039、refund_id=re_bm_039。

证据 ID：`doc:KB-BR-012#c003`、`doc:KB-API-020#c005`、`doc:KB-TS-015#c009`、`doc:KB-CASE-012#c007`、`sql:payment:pay_bm_039`、`negative:sql:refund:e7e8be654169995b12f5`、`runtime:req:req_bm_039_01`

## FP-BM-TV-0160

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-040-instant_refund_scale_na`
- 快照时点 `as_of`：2026-08-15T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`instant_refund_scale_na`

### 开场白

> 我们排查时发现：我们给北美客户做快速退款，但结果没有按预期立刻完成。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认该请求是否具备 Instant Refund 资格。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | NA Scale Account 这个账户已开启 instant_refund，对 那笔支付申请 80,000 的那笔退款。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Scale，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 15 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_040，那笔支付的编号是 pay_bm_040，那笔退款的编号是 re_bm_040 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`before_knowledge`，取 `account_context`）这笔退款属于测试还是真实交易？相关账户是什么套餐和地区？
3. （`before_knowledge`，取 `api_version`）部署里配置的 API 版本或版本请求头是什么？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来要核对可退金额和退款状态。请提供时间范围及退款编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 具备；套餐、地区、Flag、金额和 Payment 状态均满足时可使用 Instant Refund。 处理方式：在调用前同时验证地区、Flag、金额和可退余额。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0160-A1` 具备；套餐、地区、Flag、金额和 Payment 状态均满足时可使用 Instant Refund。
- `FP-BM-TV-0160-A2` 在调用前同时验证地区、Flag、金额和可退余额。

禁止结论（说了就算错）：

- 不得认定：Instant Refund 只由 Scale 套餐单一条件决定

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_payments`
- 文档：`KB-BR-012`、`KB-API-021`
- 操作：`query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_payment`、`query_payments.get_refund`
- 规则：`RULE-IDEMP-001`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_payment`、`query_payments.get_refund`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：具备；套餐、地区、Flag、金额和 Payment 状态均满足时可使用 Instant Refund。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_040、`as_of`=2026-08-15T12:00:00Z | `exactly_one` |
| `get_feature_flags` | `sql` | `query_accounts.get_feature_flags` | `account_id`=acct_bm_040、`as_of`=2026-08-15T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-15T12:00:00Z、`payment_id`=pay_bm_040 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-15T12:00:00Z、`refund_id`=re_bm_040 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-15T11:20:04.000Z` 支付 pay_bm_040 状态 succeeded，金额 10000 USD，已占用退款额度 4000、当前可退 6000
- `2026-08-15T11:20:05.000Z` 退款 re_bm_040 状态为 succeeded，金额 4000，关联支付为 pay_bm_040。

查到的实例事实：

- `get_account` 账户 acct_bm_040 当时套餐为 Scale、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_feature_flags` 功能 instant_refund 的配置值为 True，实际生效值为 True，套餐抑制为 False。
- `get_payment` 支付 pay_bm_040 状态 succeeded，金额 10000 USD，已占用退款额度 4000、当前可退 6000。
- `get_refund` 退款 re_bm_040 状态为 succeeded，金额 4000，关联支付为 pay_bm_040。

证据 ID：`doc:KB-BR-012#c003`、`doc:KB-API-021#c006`、`sql:account:acct_bm_040`、`sql:feature_flag:acct_bm_040:production:instant_refund`、`sql:payment:pay_bm_040`、`sql:refund:re_bm_040`

## FP-BM-TV-0164

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-041-instant_refund_apac`
- 快照时点 `as_of`：2026-08-16T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`instant_refund_apac`

### 开场白

> 客户那边反馈：亚太地区的一笔退款勾选了快速到账，却一直无法提交。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认请求是否应因 Scale 身份而成功。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | APAC Scale Account 这个账户开启 Flag 后，对 那笔支付请求 50,000 Instant Refund。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Scale，主地区是 APAC。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 16 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_041，那笔支付的编号是 pay_bm_041，那笔退款的编号是 re_bm_041 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`before_knowledge`，取 `account_context`）退款发生在哪个环境？账户套餐和所属地区分别是什么？
3. （`before_knowledge`，取 `api_version`）部署里配置的 API 版本或版本请求头是什么？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来要核对可退金额和退款状态。请提供时间范围及退款编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应；APAC 不在 Instant Refund 支持地区内。 处理方式：改用标准 Refund 流程，不要尝试修改 Account 主地区。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0164-A1` 不应；APAC 不在 Instant Refund 支持地区内。
- `FP-BM-TV-0164-A2` 改用标准 Refund 流程，不要尝试修改 Account 主地区。

禁止结论（说了就算错）：

- 不得认定：Scale 可以覆盖地区限制

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_accounts_sql`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_accounts`、`query_payments`
- 文档：`KB-BR-003`、`KB-BR-012`、`KB-API-021`、`KB-TS-010`
- 操作：`query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_payment`、`query_payments.get_refund`
- 规则：`RULE-IDEMP-001`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`、`RULE-REGION-001`、`RULE-REGION-002`、`RULE-REGION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_payment`、`query_payments.get_refund`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应；APAC 不在 Instant Refund 支持地区内。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_041、`as_of`=2026-08-16T12:00:00Z | `exactly_one` |
| `get_feature_flags` | `sql` | `query_accounts.get_feature_flags` | `account_id`=acct_bm_041、`as_of`=2026-08-16T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-16T12:00:00Z、`payment_id`=pay_bm_041 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-16T12:00:00Z、`refund_id`=re_bm_041 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-16T11:20:04.000Z` 支付 pay_bm_041 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000

查到的实例事实：

- `get_account` 账户 acct_bm_041 当时套餐为 Scale、主地区为 APAC，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_feature_flags` 功能 instant_refund 的配置值为 True，实际生效值为 True，套餐抑制为 False。
- `get_payment` 支付 pay_bm_041 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_refund` 在限定范围（as_of=2026-08-16T12:00:00Z、refund_id=re_bm_041、account_id=acct_bm_041、environment=production）内没有查到 get_refund 对应记录。

证据 ID：`doc:KB-BR-003#c003`、`doc:KB-BR-012#c003`、`doc:KB-API-021#c006`、`doc:KB-TS-010#c006`、`sql:account:acct_bm_041`、`sql:feature_flag:acct_bm_041:production:instant_refund`、`sql:payment:pay_bm_041`、`negative:sql:refund:285196e61de8e15093b1`

## FP-BM-TV-0168

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-042-instant_refund_flag_and_amount`
- 快照时点 `as_of`：2026-08-17T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`instant_refund_flag_and_amount`

### 开场白

> 我们排查时发现：快速退款偶尔能用、偶尔被拒绝，我们怀疑和账户配置或金额有关。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认两次尝试分别为什么不具备资格。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | EU Scale Account 这个账户的 Flag 起初关闭，随后开启但请求 120,000 的 Instant Refund。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Scale，主地区是 EU。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 17 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_042，那笔支付的编号是 pay_bm_042，那笔退款的编号是 re_bm_042 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`before_knowledge`，取 `account_context`）退款发生在哪个环境？账户套餐和所属地区分别是什么？
3. （`before_knowledge`，取 `api_version`）能确认当时客户端使用的接口版本吗？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了查看退款前后的金额变化，请给出大概日期和原支付或退款号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 第一次缺少 Flag；第二次金额超过 100,000。两次都不能使用 Instant Refund。 处理方式：开启 Flag后把金额控制在上限内，或改用标准 Refund。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0168-A1` 第一次缺少 Flag；第二次金额超过 100,000。两次都不能使用 Instant Refund。
- `FP-BM-TV-0168-A2` 开启 Flag后把金额控制在上限内，或改用标准 Refund。

禁止结论（说了就算错）：

- 不得认定：只要后续打开 Flag，之前和超额请求都会自动合法

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-004`、`KB-BR-012`、`KB-API-021`
- 操作：`query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.list_requests`
- 规则：`RULE-IDEMP-001`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-PLAN-005`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：第一次缺少 Flag；第二次金额超过 100,000。两次都不能使用 Instant Refund。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_042、`as_of`=2026-08-17T12:00:00Z | `exactly_one` |
| `get_feature_flags` | `sql` | `query_accounts.get_feature_flags` | `account_id`=acct_bm_042、`as_of`=2026-08-17T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-17T12:00:00Z、`payment_id`=pay_bm_042 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-17T12:00:00Z、`refund_id`=re_bm_042 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_042、`as_of`=2026-08-17T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-17T11:20:04.000Z` 支付 pay_bm_042 状态 succeeded，金额 200000 USD，已占用退款额度 0、当前可退 200000
- `2026-08-17T11:49:59.000Z` 请求 req_bm_042_01 在 2026 年 08 月 17 日 11:49 UTC 以 POST 调用 /v1/refunds，返回 HTTP 403、错误码 FP-4031，响应对象为 无，请求参数 amount=50000、instant_refund_flag=False、mode=instant
- `2026-08-17T11:50:00.000Z` 请求 req_39d71c463c_000002 在 2026 年 08 月 17 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 403、错误码 FP-4031，响应对象为 无，请求参数 amount=120000、instant_refund_flag=True、mode=instant

查到的实例事实：

- `get_account` 账户 acct_bm_042 当时套餐为 Scale、主地区为 EU，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_feature_flags` 功能 instant_refund 的配置值为 True，实际生效值为 True，套餐抑制为 False。
- `get_payment` 支付 pay_bm_042 状态 succeeded，金额 200000 USD，已占用退款额度 0、当前可退 200000。
- `get_refund` 在限定范围（as_of=2026-08-17T12:00:00Z、refund_id=re_bm_042、account_id=acct_bm_042、environment=production）内没有查到 get_refund 对应记录。
- `list_requests` 请求 req_bm_042_01 在 2026 年 08 月 17 日 11:49 UTC 以 POST 调用 /v1/refunds，返回 HTTP 403、错误码 FP-4031，响应对象为 无，请求参数 amount=50000、instant_refund_flag=False、mode=instant；请求 req_39d71c463c_000002 在 2026 年 08 月 17 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 403、错误码 FP-4031，响应对象为 无，请求参数 amount=120000、instant_refund_flag=True、mode=instant。

证据 ID：`doc:KB-BR-004#c006`、`doc:KB-BR-012#c004`、`doc:KB-API-021#c004`、`sql:account:acct_bm_042`、`sql:feature_flag:acct_bm_042:production:instant_refund`、`sql:payment:pay_bm_042`、`negative:sql:refund:d9e7cd17a04cfaac8f68`、`runtime:req:req_bm_042_01`、`runtime:req:req_39d71c463c_000002`

## FP-BM-TV-0172

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-043-starter_subscription_blocked`
- 快照时点 `as_of`：2026-08-18T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`starter_subscription_blocked`

### 开场白

> 线上同事发现：普通支付没问题，但一创建订阅就提示当前账户不能使用。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Customer active 是否足以使创建成功。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Starter Account 这个账户使用 active 这位客户创建 这份订阅，请求参数都合法。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Starter，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 18 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_043，这位客户的编号是 cus_bm_043，这份订阅的编号是 sub_bm_043，那次请求的编号是 req_bm_043_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`before_knowledge`，取 `account_context`）订阅来自哪个环境和地区？账户当前使用什么套餐？
3. （`before_knowledge`，取 `api_version`）部署里配置的 API 版本或版本请求头是什么？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要查看订阅当时的状态。大概何时发生，能提供订阅编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不足；套餐不支持 Subscription，应返回 FP-4031。 处理方式：升级到 Growth/Scale并确认 subscriptions Flag 后重新创建。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0172-A1` 不足；套餐不支持 Subscription，应返回 FP-4031。
- `FP-BM-TV-0172-A2` 升级到 Growth/Scale并确认 subscriptions Flag 后重新创建。

禁止结论（说了就算错）：

- 不得认定：参数合法就能绕过套餐权限

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-013`、`KB-API-024`、`KB-TS-010`
- 操作：`query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_customer`、`query_payments.get_subscription`、`get_runtime_state.get_request`
- 规则：`RULE-CUSTOMER-004`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-004`、`RULE-REGION-003`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_customer`、`query_payments.get_subscription`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不足；套餐不支持 Subscription，应返回 FP-4031。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_043、`as_of`=2026-08-18T12:00:00Z | `exactly_one` |
| `get_feature_flags` | `sql` | `query_accounts.get_feature_flags` | `account_id`=acct_bm_043、`as_of`=2026-08-18T12:00:00Z | `exactly_one` |
| `get_customer` | `sql` | `query_payments.get_customer` | `as_of`=2026-08-18T12:00:00Z、`customer_id`=cus_bm_043 | `exactly_one` |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-18T12:00:00Z、`subscription_id`=sub_bm_043 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-18T12:00:00Z、`request_id`=req_bm_043_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-18T11:50:00.000Z` 请求 req_bm_043_01 在 2026 年 08 月 18 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 403、错误码 FP-4031，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_043 当时套餐为 Starter、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_feature_flags` 功能 subscriptions 的配置值为 True，实际生效值为 False，套餐抑制为 True。
- `get_customer` 客户 cus_bm_043 状态为 active，Email 为 cus_bm_043@example.test，所属账户为 acct_bm_043、环境为 production。
- `get_subscription` 在限定范围（as_of=2026-08-18T12:00:00Z、subscription_id=sub_bm_043、account_id=acct_bm_043、environment=production）内没有查到 get_subscription 对应记录。
- `get_request` 请求 req_bm_043_01 在 2026 年 08 月 18 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 403、错误码 FP-4031，响应对象为 无。

证据 ID：`doc:KB-BR-013#c005`、`doc:KB-API-024#c005`、`doc:KB-TS-010#c002`、`sql:account:acct_bm_043`、`sql:feature_flag:acct_bm_043:production:subscriptions`、`sql:customer:cus_bm_043`、`negative:sql:subscription:cca729e5a3c87eed3745`、`runtime:req:req_bm_043_01`

## FP-BM-TV-0176

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-044-subscription_trial_bounds`
- 快照时点 `as_of`：2026-08-19T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_trial_bounds`

### 开场白

> 客户那边反馈：创建带试用期的订阅时，某些天数可以，某些天数直接报参数错误。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认两种操作是否允许。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户先尝试以 trial_days=31 创建 这份订阅，之后又想给已 active 的 Subscription 补加试用期。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 19 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_044，这份订阅的编号是 sub_bm_044 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`before_knowledge`，取 `account_context`）订阅来自哪个环境和地区？账户当前使用什么套餐？
3. （`before_knowledge`，取 `api_version`）部署里配置的 API 版本或版本请求头是什么？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要查看订阅当时的状态。大概何时发生，能提供订阅编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 都不允许；31 天越界，且试用期不能在创建后追加。 处理方式：创建时使用 1～30 天范围；已创建资源需按现有周期处理。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0176-A1` 都不允许；31 天越界，且试用期不能在创建后追加。
- `FP-BM-TV-0176-A2` 创建时使用 1～30 天范围；已创建资源需按现有周期处理。

禁止结论（说了就算错）：

- 不得认定：试用期可在任意时间延长

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-013`、`KB-API-024`、`KB-TS-001`
- 操作：`query_payments.get_subscription`、`get_runtime_state.list_requests`
- 规则：`RULE-CUSTOMER-004`、`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PLAN-001`、`RULE-PLAN-004`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_subscription`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：都不允许；31 天越界，且试用期不能在创建后追加。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-19T12:00:00Z、`subscription_id`=sub_bm_044 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_044、`as_of`=2026-08-19T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-19T11:20:06.000Z` 订阅 sub_bm_044 状态为 active，客户为 cus_bm_044，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 18 日 11:20 UTC。
- `2026-08-19T11:49:59.000Z` 请求 req_bm_044_01 在 2026 年 08 月 19 日 11:49 UTC 以 POST 调用 /v1/subscriptions，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 trial_days=31
- `2026-08-19T11:50:00.000Z` 请求 req_8a1a242e28_000002 在 2026 年 08 月 19 日 11:50 UTC 以 PATCH 调用 /v1/subscriptions/sub_bm_044，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 operation=append_trial_after_creation、trial_days=14

查到的实例事实：

- `get_subscription` 订阅 sub_bm_044 状态为 active，客户为 cus_bm_044，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 18 日 11:20 UTC。
- `list_requests` 请求 req_bm_044_01 在 2026 年 08 月 19 日 11:49 UTC 以 POST 调用 /v1/subscriptions，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 trial_days=31；请求 req_8a1a242e28_000002 在 2026 年 08 月 19 日 11:50 UTC 以 PATCH 调用 /v1/subscriptions/sub_bm_044，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 operation=append_trial_after_creation、trial_days=14。

证据 ID：`doc:KB-BR-013#c004`、`doc:KB-API-024#c004`、`doc:KB-TS-001#c006`、`sql:subscription:sub_bm_044`、`runtime:req:req_bm_044_01`、`runtime:req:req_8a1a242e28_000002`

## FP-BM-TV-0180

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-045-subscription_cancel_period_end`
- 快照时点 `as_of`：2026-08-20T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_cancel_period_end`

### 开场白

> 我们排查时发现：客户选择到期取消订阅，但我们担心系统会立即停掉服务。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认它应立即 canceled 还是继续 active。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这份订阅在周期中收到默认取消请求，当前时间尚未到 period_end。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 20 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_045，这份订阅的编号是 sub_bm_045 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`before_knowledge`，取 `account_context`）订阅来自哪个环境和地区？账户当前使用什么套餐？
3. （`before_knowledge`，取 `api_version`）能确认当时客户端使用的接口版本吗？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对订阅与账单关系，请补充时间范围和相关对象编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应继续 active 到周期末，届时再进入 canceled。 处理方式：向用户展示 scheduled cancellation 与实际生效时间。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0180-A1` 应继续 active 到周期末，届时再进入 canceled。
- `FP-BM-TV-0180-A2` 向用户展示 scheduled cancellation 与实际生效时间。

禁止结论（说了就算错）：

- 不得认定：所有取消请求都立即终止服务

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`
- 文档：`KB-BR-013`、`KB-API-025`
- 操作：`query_payments.get_subscription`
- 规则：`RULE-CUSTOMER-003`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_subscription`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应继续 active 到周期末，届时再进入 canceled。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-20T12:00:00Z、`subscription_id`=sub_bm_045 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-20T11:20:06.000Z` 订阅 sub_bm_045 状态为 active，客户为 cus_bm_045，币种为 USD，周期末取消标记为 True，当前周期结束于 2026 年 09 月 19 日 11:20 UTC。

查到的实例事实：

- `get_subscription` 订阅 sub_bm_045 状态为 active，客户为 cus_bm_045，币种为 USD，周期末取消标记为 True，当前周期结束于 2026 年 09 月 19 日 11:20 UTC。

证据 ID：`doc:KB-BR-013#c006`、`doc:KB-API-025#c004`、`sql:subscription:sub_bm_045`

## FP-BM-TV-0184

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-046-subscription_cancel_immediately`
- 快照时点 `as_of`：2026-08-21T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_cancel_immediately`

### 开场白

> 客户那边反馈：客服执行立即取消后，客户仍在问这一期是否还会继续计费。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认取消与恢复请求应如何处理。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户对 active 的 这份订阅发送 immediate=true 取消，随后尝试恢复。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 21 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_046，这份订阅的编号是 sub_bm_046 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`before_knowledge`，取 `account_context`）请补充订阅所属环境、账户套餐和主地区。
3. （`before_knowledge`，取 `api_version`）能确认当时客户端使用的接口版本吗？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对订阅与账单关系，请补充时间范围和相关对象编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> Subscription 立即 canceled，且不能恢复；需要继续订阅必须创建新 Subscription。 处理方式：创建新的 Subscription，不要修改终态资源。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0184-A1` Subscription 立即 canceled，且不能恢复；需要继续订阅必须创建新 Subscription。
- `FP-BM-TV-0184-A2` 创建新的 Subscription，不要修改终态资源。

禁止结论（说了就算错）：

- 不得认定：canceled Subscription 可以切回 active

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-013`、`KB-API-025`
- 操作：`query_payments.get_subscription`、`get_runtime_state.list_requests`
- 规则：`RULE-CUSTOMER-003`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_subscription`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：Subscription 立即 canceled，且不能恢复；需要继续订阅必须创建新 Subscription。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-21T12:00:00Z、`subscription_id`=sub_bm_046 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_046、`as_of`=2026-08-21T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-21T11:20:06.000Z` 订阅 sub_bm_046 状态为 canceled，客户为 cus_bm_046，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 20 日 11:20 UTC。
- `2026-08-21T11:49:59.000Z` 请求 req_bm_046_01 在 2026 年 08 月 21 日 11:49 UTC 以 POST 调用 /v1/subscriptions/sub_bm_046/cancel，返回 HTTP 200，响应对象为 sub_bm_046，请求参数 immediate=True
- `2026-08-21T11:50:00.000Z` 请求 req_0a756ce509_000002 在 2026 年 08 月 21 日 11:50 UTC 以 PATCH 调用 /v1/subscriptions/sub_bm_046，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 operation=restore_canceled_subscription、status=active

查到的实例事实：

- `get_subscription` 订阅 sub_bm_046 状态为 canceled，客户为 cus_bm_046，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 20 日 11:20 UTC。
- `list_requests` 请求 req_bm_046_01 在 2026 年 08 月 21 日 11:49 UTC 以 POST 调用 /v1/subscriptions/sub_bm_046/cancel，返回 HTTP 200，响应对象为 sub_bm_046，请求参数 immediate=True；请求 req_0a756ce509_000002 在 2026 年 08 月 21 日 11:50 UTC 以 PATCH 调用 /v1/subscriptions/sub_bm_046，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 operation=restore_canceled_subscription、status=active。

证据 ID：`doc:KB-BR-013#c006`、`doc:KB-API-025#c004`、`sql:subscription:sub_bm_046`、`runtime:req:req_bm_046_01`、`runtime:req:req_0a756ce509_000002`

## FP-BM-TV-0188

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-047-subscription_immutable_identity`
- 快照时点 `as_of`：2026-08-22T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_immutable_identity`

### 开场白

> 客服转来一个问题：业务想把现有订阅转给另一个客户，同时顺便换结算币种。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认能否直接更新这两个字段。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这份订阅已绑定 这位客户和 USD，这个账户尝试改成另一个 Customer 与 CAD。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 22 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_047，这位客户的编号是 cus_bm_047，这份订阅的编号是 sub_bm_047，那次请求的编号是 req_bm_047_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`before_knowledge`，取 `account_context`）请补充订阅所属环境、账户套餐和主地区。
3. （`before_knowledge`，取 `api_version`）能确认当时客户端使用的接口版本吗？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对订阅与账单关系，请补充时间范围和相关对象编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；Customer 与币种是不可变身份字段。 处理方式：按取消规则处理原 Subscription，并为新 Customer/币种创建新资源。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0188-A1` 不能；Customer 与币种是不可变身份字段。
- `FP-BM-TV-0188-A2` 按取消规则处理原 Subscription，并为新 Customer/币种创建新资源。

禁止结论（说了就算错）：

- 不得认定：active Subscription 的所有字段都可更新

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-013`、`KB-API-023`、`KB-API-024`
- 操作：`query_payments.get_customer`、`query_payments.get_subscription`、`get_runtime_state.get_request`
- 规则：`RULE-CUSTOMER-004`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-PLAN-001`、`RULE-PLAN-004`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_customer`、`query_payments.get_subscription`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；Customer 与币种是不可变身份字段。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_customer` | `sql` | `query_payments.get_customer` | `as_of`=2026-08-22T12:00:00Z、`customer_id`=cus_bm_047 | `exactly_one` |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-22T12:00:00Z、`subscription_id`=sub_bm_047 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-22T12:00:00Z、`request_id`=req_bm_047_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-22T11:20:06.000Z` 订阅 sub_bm_047 状态为 active，客户为 cus_bm_047，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 21 日 11:20 UTC。
- `2026-08-22T11:50:00.000Z` 请求 req_bm_047_01 在 2026 年 08 月 22 日 11:50 UTC 以 PATCH 调用 /v1/subscriptions/sub_bm_047，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 currency=CAD、customer_id=cus_bm_047_other

查到的实例事实：

- `get_customer` 客户 cus_bm_047 状态为 active，Email 为 cus_bm_047@example.test，所属账户为 acct_bm_047、环境为 production。
- `get_subscription` 订阅 sub_bm_047 状态为 active，客户为 cus_bm_047，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 21 日 11:20 UTC。
- `get_request` 请求 req_bm_047_01 在 2026 年 08 月 22 日 11:50 UTC 以 PATCH 调用 /v1/subscriptions/sub_bm_047，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 currency=CAD、customer_id=cus_bm_047_other。

证据 ID：`doc:KB-BR-013#c002`、`doc:KB-API-023#c006`、`doc:KB-API-024#c006`、`sql:customer:cus_bm_047`、`sql:subscription:sub_bm_047`、`runtime:req:req_bm_047_01`

## FP-BM-TV-0192

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-048-invoice_retry_day1_success`
- 快照时点 `as_of`：2026-08-23T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`invoice_retry_day1_success`

### 开场白

> 客户那边反馈：订阅扣款第一次失败后很快恢复了，我们想确认账单是否还会继续重试。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Invoice 与 Subscription 最终应是什么状态。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那张账单首次 Payment 失败使 这份订阅past_due，第 1 天新 那笔支付成功。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 23 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_048，这份订阅的编号是 sub_bm_048，那张账单的编号是 in_bm_048，那笔支付的编号是 pay_bm_048 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`before_knowledge`，取 `account_context`）这张账单属于测试还是真实业务？账户套餐和主地区是什么？
3. （`before_knowledge`，取 `api_version`）部署里配置的 API 版本或版本请求头是什么？
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需要核对实际扣款记录。请提供日期范围和账单编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> Invoice 应为 paid，Subscription 应恢复 active；首次 failed Payment 保持终态。 处理方式：停止后续重试，并保留两次 Payment 的时间线。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0192-A1` Invoice 应为 paid，Subscription 应恢复 active；首次 failed Payment 保持终态。
- `FP-BM-TV-0192-A2` 停止后续重试，并保留两次 Payment 的时间线。

禁止结论（说了就算错）：

- 不得认定：重试成功后仍要执行第 3、7 天重试

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`support_cases`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`search_support_cases`、`query_payments`
- 文档：`KB-BR-014`、`KB-API-026`、`KB-API-027`、`KB-API-028`、`KB-CASE-013`
- 操作：`query_payments.get_payment`、`query_payments.get_subscription`、`query_payments.get_invoice_timeline`
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-INVOICE-007`、`RULE-INVOICE-008`、`RULE-PAY-002`、`RULE-SUB-005`、`RULE-TENANT-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`、`search_api_docs`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_subscription`、`query_payments.get_invoice_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：Invoice 应为 paid，Subscription 应恢复 active；首次 failed Payment 保持终态。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-23T12:00:00Z、`payment_id`=pay_bm_048 | `exactly_one` |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-23T12:00:00Z、`subscription_id`=sub_bm_048 | `exactly_one` |
| `get_invoice_timeline` | `sql` | `query_payments.get_invoice_timeline` | `as_of`=2026-08-23T12:00:00Z、`invoice_id`=in_bm_048 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-23T11:20:06.000Z` 订阅 sub_bm_048 状态为 active，客户为 cus_bm_048，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 22 日 11:20 UTC。
- `2026-08-23T11:50:00.000Z` 支付 pay_bm_048 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000
- `2026-08-23T11:50:00.000Z` 账单第 0 次扣款 failed
- `2026-08-24T11:50:00.000Z` 账单第 1 次扣款 succeeded

查到的实例事实：

- `get_payment` 支付 pay_bm_048 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000。
- `get_subscription` 订阅 sub_bm_048 状态为 active，客户为 cus_bm_048，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 22 日 11:20 UTC。
- `get_invoice_timeline` 账单 in_bm_048 当前状态为 paid，应付 2500、已付 2500；第 0 次在 2026 年 08 月 23 日 11:50 UTC failed；第 1 次在 2026 年 08 月 24 日 11:50 UTC succeeded。

证据 ID：`doc:KB-BR-014#c004`、`doc:KB-API-026#c005`、`doc:KB-API-027#c006`、`doc:KB-API-028#c003`、`doc:KB-CASE-013#c002`、`sql:payment:pay_bm_048`、`sql:subscription:sub_bm_048`、`sql:invoice:in_bm_048`、`sql:invoice_attempt:in_bm_048:0`、`sql:invoice_attempt:in_bm_048:1`

## FP-BM-TV-0196

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-049-invoice_retry_day3_success`
- 快照时点 `as_of`：2026-08-24T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`invoice_retry_day3_success`

### 开场白

> 我们排查时发现：订阅账单连续失败了几次，后来客户补足余额，不确定系统接下来怎么处理。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认应该存在几笔 Payment，是否继续第 7 天重试。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那张账单首次与第 1 天 Payment 失败，第 3 天 Payment 成功。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 24 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_049，这份订阅的编号是 sub_bm_049，那张账单的编号是 in_bm_049，那笔支付的编号是 pay_bm_049 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`before_knowledge`，取 `account_context`）这张账单属于测试还是真实业务？账户套餐和主地区是什么？
3. （`before_knowledge`，取 `api_version`）这次调用使用的是哪个接口版本？如果没有显式设置，也请说明账户默认版本。
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了查看账单时间线，请提供大概发生时间和账单或订阅编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应有三笔不同 Payment；第 3 天成功后不再执行第 7 天重试。 处理方式：保留三笔关联记录并取消剩余调度。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0196-A1` 应有三笔不同 Payment；第 3 天成功后不再执行第 7 天重试。
- `FP-BM-TV-0196-A2` 保留三笔关联记录并取消剩余调度。

禁止结论（说了就算错）：

- 不得认定：重试应复用第一笔 failed Payment ID

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`
- 文档：`KB-BR-014`、`KB-API-027`、`KB-API-028`
- 操作：`query_payments.get_payment`、`query_payments.get_subscription`、`query_payments.get_invoice_timeline`
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-INVOICE-007`、`RULE-INVOICE-008`、`RULE-PAY-002`、`RULE-TENANT-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_subscription`、`query_payments.get_invoice_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应有三笔不同 Payment；第 3 天成功后不再执行第 7 天重试。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-24T12:00:00Z、`payment_id`=pay_bm_049 | `exactly_one` |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-24T12:00:00Z、`subscription_id`=sub_bm_049 | `exactly_one` |
| `get_invoice_timeline` | `sql` | `query_payments.get_invoice_timeline` | `as_of`=2026-08-24T12:00:00Z、`invoice_id`=in_bm_049 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-24T11:20:06.000Z` 订阅 sub_bm_049 状态为 active，客户为 None，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 23 日 11:20 UTC。
- `2026-08-24T11:50:00.000Z` 支付 pay_bm_049 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000
- `2026-08-24T11:50:00.000Z` 账单第 0 次扣款 failed
- `2026-08-25T11:50:00.000Z` 账单第 1 次扣款 failed
- `2026-08-27T11:50:00.000Z` 账单第 2 次扣款 succeeded

查到的实例事实：

- `get_payment` 支付 pay_bm_049 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000。
- `get_subscription` 订阅 sub_bm_049 状态为 active，客户为 None，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 23 日 11:20 UTC。
- `get_invoice_timeline` 账单 in_bm_049 当前状态为 paid，应付 2500、已付 2500；第 0 次在 2026 年 08 月 24 日 11:50 UTC failed；第 1 次在 2026 年 08 月 25 日 11:50 UTC failed；第 2 次在 2026 年 08 月 27 日 11:50 UTC succeeded。

证据 ID：`doc:KB-BR-014#c007`、`doc:KB-API-027#c006`、`doc:KB-API-028#c004`、`sql:payment:pay_bm_049`、`sql:subscription:sub_bm_049`、`sql:invoice:in_bm_049`、`sql:invoice_attempt:in_bm_049:0`、`sql:invoice_attempt:in_bm_049:1`、`sql:invoice_attempt:in_bm_049:2`

## FP-BM-TV-0200

**时效版本**（`temporal_versioned`） · 难度 4 · 多轮 · `test`

- 场景：`SC-050-invoice_retries_exhausted`
- 快照时点 `as_of`：2026-08-25T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`invoice_retries_exhausted`

### 开场白

> 客服转来一个问题：一张订阅账单多次扣款失败后就不再尝试了，订阅状态也变了。这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。

### 对话脚本（最多追问 4 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这个状态是否符合规则。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那张账单的四次 Payment 全部 failed，这份订阅仍显示 past_due。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 25 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_050，这份订阅的编号是 sub_bm_050，那张账单的编号是 in_bm_050，那笔支付的编号是 pay_bm_050 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`before_knowledge`，取 `account_context`）这张账单属于测试还是真实业务？账户套餐和主地区是什么？
3. （`before_knowledge`，取 `api_version`）这次调用使用的是哪个接口版本？如果没有显式设置，也请说明账户默认版本。
4. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了查看账单时间线，请提供大概发生时间和账单或订阅编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不符合；重试耗尽后 Invoice 应为 uncollectible，Subscription 应为 canceled。 处理方式：执行终态投影并停止继续扣费。

必需结论（全部要被证据支持）：

- `FP-BM-TV-0200-A1` 不符合；重试耗尽后 Invoice 应为 uncollectible，Subscription 应为 canceled。
- `FP-BM-TV-0200-A2` 执行终态投影并停止继续扣费。

禁止结论（说了就算错）：

- 不得认定：重试耗尽后 Subscription 会无限保持 past_due

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`support_cases`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`search_support_cases`、`query_payments`
- 文档：`KB-BR-014`、`KB-API-027`、`KB-API-028`、`KB-CASE-014`
- 操作：`query_payments.get_payment`、`query_payments.get_subscription`、`query_payments.get_invoice_timeline`
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-INVOICE-007`、`RULE-INVOICE-008`、`RULE-PAY-002`、`RULE-SUB-005`、`RULE-TENANT-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_subscription`、`query_payments.get_invoice_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不符合；重试耗尽后 Invoice 应为 uncollectible，Subscription 应为 canceled。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-25T12:00:00Z、`payment_id`=pay_bm_050 | `exactly_one` |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-25T12:00:00Z、`subscription_id`=sub_bm_050 | `exactly_one` |
| `get_invoice_timeline` | `sql` | `query_payments.get_invoice_timeline` | `as_of`=2026-08-25T12:00:00Z、`invoice_id`=in_bm_050 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-25T11:20:06.000Z` 订阅 sub_bm_050 状态为 canceled，客户为 None，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 24 日 11:20 UTC。
- `2026-08-25T11:50:00.000Z` 支付 pay_bm_050 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000
- `2026-08-25T11:50:00.000Z` 账单第 0 次扣款 failed
- `2026-08-26T11:50:00.000Z` 账单第 1 次扣款 failed
- `2026-08-28T11:50:00.000Z` 账单第 2 次扣款 failed
- `2026-09-01T11:50:00.000Z` 账单第 3 次扣款 failed

查到的实例事实：

- `get_payment` 支付 pay_bm_050 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000。
- `get_subscription` 订阅 sub_bm_050 状态为 canceled，客户为 None，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 24 日 11:20 UTC。
- `get_invoice_timeline` 账单 in_bm_050 当前状态为 uncollectible，应付 2500、已付 0；第 0 次在 2026 年 08 月 25 日 11:50 UTC failed；第 1 次在 2026 年 08 月 26 日 11:50 UTC failed；第 2 次在 2026 年 08 月 28 日 11:50 UTC failed；第 3 次在 2026 年 09 月 01 日 11:50 UTC failed。

证据 ID：`doc:KB-BR-014#c004`、`doc:KB-API-027#c004`、`doc:KB-API-028#c004`、`doc:KB-CASE-014#c005`、`sql:payment:pay_bm_050`、`sql:subscription:sub_bm_050`、`sql:invoice:in_bm_050`、`sql:invoice_attempt:in_bm_050:0`、`sql:invoice_attempt:in_bm_050:1`、`sql:invoice_attempt:in_bm_050:2`、`sql:invoice_attempt:in_bm_050:3`
