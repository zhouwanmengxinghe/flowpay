# 跨数据源　`multi_source`　70 道

## FP-BM-MS-0004

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-001-cross_tenant_payment_visibility`
- 快照时点 `as_of`：2026-08-02T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`cross_tenant_payment_visibility`

### 开场白

> 我们排查时发现：后台里明明能看到一笔支付，但我们从服务里查询时一直提示找不到。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认FP-4041 是否能证明 Payment ID 不存在，以及应如何判断这次访问。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户使用自己的 Production Key 查询另一个 Account 所属的那笔支付，请求得到 FP-4041。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 2 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_001，那笔支付的编号是 pay_bm_001，那次请求的编号是 req_bm_001_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认账户背景：使用什么套餐，主地区在哪里，问题出现在哪个环境？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）结合目前的规则，还需要核对实际账户记录。问题大概何时发生，控制台里的账户或请求编号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能证明 ID 不存在；该访问越过租户边界，应拒绝且不得泄漏目标资源是否存在。 处理方式：核对调用 Key 的 Account、环境和 Payment 所属关系，不要尝试枚举其他租户资源。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0004-A1` 不能证明 ID 不存在；该访问越过租户边界，应拒绝且不得泄漏目标资源是否存在。
- `FP-BM-MS-0004-A2` 核对调用 Key 的 Account、环境和 Payment 所属关系，不要尝试枚举其他租户资源。

禁止结论（说了就算错）：

- 不得认定：把 FP-4041 直接解释为 Payment ID 拼写错误

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-001`、`KB-API-014`、`KB-TS-012`
- 操作：`query_accounts.get_account`、`query_payments.get_payment`、`get_runtime_state.get_request`
- 规则：`RULE-ENV-001`、`RULE-PAY-001`、`RULE-REQ-003`、`RULE-TENANT-001`、`RULE-TENANT-002`、`RULE-TENANT-003`、`RULE-TENANT-004`、`RULE-VERSION-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_payments.get_payment`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能证明 ID 不存在；该访问越过租户边界，应拒绝且不得泄漏目标资源是否存在。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_001、`as_of`=2026-08-02T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-02T12:00:00Z、`payment_id`=pay_bm_001 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-02T12:00:00Z、`request_id`=req_bm_001_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-02T11:50:00.000Z` 请求 req_bm_001_01 在 2026 年 08 月 02 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 404、错误码 FP-4041，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_001 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_payment` 在限定范围（as_of=2026-08-02T12:00:00Z、payment_id=pay_bm_001、account_id=acct_bm_001、environment=production）内没有查到 get_payment 对应记录。
- `get_request` 请求 req_bm_001_01 在 2026 年 08 月 02 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 404、错误码 FP-4041，响应对象为 无。

证据 ID：`doc:KB-BR-001#c006`、`doc:KB-API-014#c004`、`doc:KB-TS-012#c005`、`sql:account:acct_bm_001`、`negative:sql:payment:294c61a6865e5f11ad07`、`runtime:req:req_bm_001_01`

## FP-BM-MS-0008

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-002-sandbox_key_on_production`
- 快照时点 `as_of`：2026-08-03T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`sandbox_key_on_production`

### 开场白

> 我们排查时发现：测试时一直正常，可一上线创建支付就变成认证失败了。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认根因是 Key 无效、Customer 不存在还是环境不匹配。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户的部署加载了 Sandbox Key，却尝试为 Production Customer 这位客户创建 Payment，那次请求返回 FP-4012。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 3 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_002，这位客户的编号是 cus_bm_002，那次请求的编号是 req_bm_002_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 这次调用对应哪个环境？也请补充账户套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了确认请求实际使用的配置，请补充发生时间和控制台中的请求号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> Key 本身有效，但 Key 属于 Sandbox、Customer 属于 Production，因此是环境不匹配。 处理方式：替换为该 Account 的有效 Production Key；不要复制 Sandbox 资源作为修复。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0008-A1` Key 本身有效，但 Key 属于 Sandbox、Customer 属于 Production，因此是环境不匹配。
- `FP-BM-MS-0008-A2` 替换为该 Account 的有效 Production Key；不要复制 Sandbox 资源作为修复。

禁止结论（说了就算错）：

- 不得认定：只要 Key 有效就可以跨环境调用

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`support_cases`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-002`、`KB-API-001`、`KB-API-003`、`KB-TS-005`、`KB-CASE-001`
- 操作：`query_accounts.list_api_keys`、`query_payments.get_customer`、`get_runtime_state.get_request`
- 规则：`RULE-AUTH-001`、`RULE-AUTH-002`、`RULE-AUTH-003`、`RULE-AUTH-004`、`RULE-AUTH-005`、`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-001`、`RULE-ENV-002`、`RULE-ENV-003`、`RULE-ENV-004`、`RULE-ENV-005`、`RULE-REQ-001`、`RULE-TENANT-004`、`RULE-VERSION-001`、`RULE-VERSION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.list_api_keys`、`query_payments.get_customer`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：Key 本身有效，但 Key 属于 Sandbox、Customer 属于 Production，因此是环境不匹配。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `list_api_keys` | `sql` | `query_accounts.list_api_keys` | `account_id`=acct_bm_002、`as_of`=2026-08-03T12:00:00Z | `at_least_one` |
| `get_customer` | `sql` | `query_payments.get_customer` | `as_of`=2026-08-03T12:00:00Z、`customer_id`=cus_bm_002 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-03T12:00:00Z、`request_id`=req_bm_002_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-03T11:50:00.000Z` 请求 req_bm_002_01 在 2026 年 08 月 03 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 401、错误码 FP-4012，响应对象为 无

查到的实例事实：

- `list_api_keys` 在限定范围（as_of=2026-08-03T12:00:00Z、account_id=acct_bm_002、environment=production）内没有查到 list_api_keys 对应记录。
- `get_customer` 客户 cus_bm_002 状态为 active，Email 为 cus_bm_002@example.test，所属账户为 acct_bm_002、环境为 production。
- `get_request` 请求 req_bm_002_01 在 2026 年 08 月 03 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 401、错误码 FP-4012，响应对象为 无。

证据 ID：`doc:KB-BR-002#c002`、`doc:KB-API-001#c008`、`doc:KB-API-003#c001`、`doc:KB-TS-005#c006`、`doc:KB-CASE-001#c005`、`negative:sql:api_key:05116bf6dca11eee8efd`、`sql:customer:cus_bm_002`、`runtime:req:req_bm_002_01`

## FP-BM-MS-0012

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-003-production_not_enabled`
- 快照时点 `as_of`：2026-08-04T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`production_not_enabled`

### 开场白

> 客服转来一个问题：我们刚开好账户，准备接正式环境，但创建正式密钥时被拒绝了。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认该 Key 创建是否应成功，套餐是否是拒绝原因。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Starter Account 这个账户尚未启用 Production，却请求创建那把密钥。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Starter，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 4 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_003 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 先确认账户背景：使用什么套餐，主地区在哪里，问题出现在哪个环境？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）结合目前的规则，还需要核对实际账户记录。问题大概何时发生，控制台里的账户或请求编号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 创建应被拒绝；原因是 Production 尚未启用，而不是 Starter 套餐不支持一次性支付。 处理方式：先完成 Production 启用，再创建新的 Production Key。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0012-A1` 创建应被拒绝；原因是 Production 尚未启用，而不是 Starter 套餐不支持一次性支付。
- `FP-BM-MS-0012-A2` 先完成 Production 启用，再创建新的 Production Key。

禁止结论（说了就算错）：

- 不得认定：Starter 套餐永远不能启用 Production

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_accounts_sql`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_accounts`
- 文档：`KB-BR-002`、`KB-API-005`、`KB-TS-010`
- 操作：`query_accounts.get_account`、`query_accounts.list_api_keys`
- 规则：`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-001`、`RULE-ENV-002`、`RULE-ENV-003`、`RULE-ENV-004`、`RULE-ENV-005`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-004`、`RULE-REGION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_accounts.list_api_keys`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：创建应被拒绝；原因是 Production 尚未启用，而不是 Starter 套餐不支持一次性支付。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_003、`as_of`=2026-08-04T12:00:00Z | `exactly_one` |
| `list_api_keys` | `sql` | `query_accounts.list_api_keys` | `account_id`=acct_bm_003、`as_of`=2026-08-04T12:00:00Z | `at_least_one` |

### 快照里的实况

查到的实例事实：

- `get_account` 账户 acct_bm_003 当时套餐为 Starter、主地区为 NA，Production 状态为 not_enabled，默认接口版本为 2026-07-01。
- `list_api_keys` 在限定范围（as_of=2026-08-04T12:00:00Z、account_id=acct_bm_003、environment=production）内没有查到 list_api_keys 对应记录。

证据 ID：`doc:KB-BR-002#c002`、`doc:KB-API-005#c002`、`doc:KB-TS-010#c002`、`sql:account:acct_bm_003`、`negative:sql:api_key:0a72eee334c583b266ea`

## FP-BM-MS-0016

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-004-production_suspended`
- 快照时点 `as_of`：2026-08-05T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`production_suspended`

### 开场白

> 我们排查时发现：正式环境的请求突然全都被拒绝了，可测试环境还是正常的。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这是 Key 被撤销、套餐降级还是 Production 被暂停。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户仍持有 active 的那把密钥，Production 请求 那次请求全部返回 FP-4032，而 Sandbox 请求正常。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 5 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_004 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 先确认账户背景：使用什么套餐，主地区在哪里，问题出现在哪个环境？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要确认账户当时的状态。请提供大概时间，以及能找到的账户或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 证据符合 Production 被暂停：Live Key 仍存在，Production 返回 FP-4032，Sandbox 正常。 处理方式：查询 Production 状态并解除暂停；不要轮换 Key 或升级套餐来掩盖根因。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0016-A1` 证据符合 Production 被暂停：Live Key 仍存在，Production 返回 FP-4032，Sandbox 正常。
- `FP-BM-MS-0016-A2` 查询 Production 状态并解除暂停；不要轮换 Key 或升级套餐来掩盖根因。

禁止结论（说了就算错）：

- 不得认定：把所有 403 都当作套餐功能限制

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`support_cases`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-002`、`KB-API-005`、`KB-TS-011`、`KB-TS-020`、`KB-CASE-003`
- 操作：`query_accounts.get_account`、`query_accounts.list_api_keys`、`get_runtime_state.list_requests`
- 规则：`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-001`、`RULE-ENV-002`、`RULE-ENV-003`、`RULE-ENV-004`、`RULE-ENV-005`、`RULE-ERROR-002`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_troubleshooting`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_accounts.list_api_keys`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：证据符合 Production 被暂停：Live Key 仍存在，Production 返回 FP-4032，Sandbox 正常。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_004、`as_of`=2026-08-05T12:00:00Z | `exactly_one` |
| `list_api_keys` | `sql` | `query_accounts.list_api_keys` | `account_id`=acct_bm_004、`as_of`=2026-08-05T12:00:00Z | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_004、`as_of`=2026-08-05T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-05T11:50:00.000Z` 请求 req_bm_004_01 在 2026 年 08 月 05 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 403、错误码 FP-4032，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_004 当时套餐为 Growth、主地区为 NA，Production 状态为 suspended，默认接口版本为 2026-07-01。
- `list_api_keys` 账户在该范围查到 1 把 API Key：active 1 条。
- `list_requests` 请求 req_bm_004_01 在 2026 年 08 月 05 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 403、错误码 FP-4032，响应对象为 无。

证据 ID：`doc:KB-BR-002#c008`、`doc:KB-API-005#c002`、`doc:KB-TS-011#c005`、`doc:KB-TS-020#c004`、`doc:KB-CASE-003#c005`、`sql:account:acct_bm_004`、`sql:api_key:key_bm_004`、`runtime:req:req_bm_004_01`

## FP-BM-MS-0020

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-005-region_currency_mismatch`
- 快照时点 `as_of`：2026-08-06T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`region_currency_mismatch`

### 开场白

> 有个欧洲客户下单时支付创建失败，我们怀疑是币种设置的问题。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认是否可以把 Account 临时改成 NA 来完成这笔 USD 支付。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | EU Account 这个账户为 这位客户创建 USD Payment 那笔支付，那次请求返回 FP-4001。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 EU。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 6 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_005，这位客户的编号是 cus_bm_005，那次请求的编号是 req_bm_005_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认支付所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步需要查看这笔支付的状态变化。大概是什么时候，支付编号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；EU 不支持 USD，且主地区不可公开修改。应使用 EU 支持的 EUR/GBP 或另行设计合法账户。 处理方式：按 EU 支持币种重新提交，并保留新的幂等业务意图。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0020-A1` 不能；EU 不支持 USD，且主地区不可公开修改。应使用 EU 支持的 EUR/GBP 或另行设计合法账户。
- `FP-BM-MS-0020-A2` 按 EU 支持币种重新提交，并保留新的幂等业务意图。

禁止结论（说了就算错）：

- 不得认定：通过 API 临时修改主地区即可绕过币种约束

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`troubleshooting`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_troubleshooting`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-003`、`KB-TS-001`
- 操作：`query_accounts.get_account`、`query_payments.get_customer`、`get_runtime_state.get_request`
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REGION-001`、`RULE-REGION-002`、`RULE-REGION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_payments.get_customer`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；EU 不支持 USD，且主地区不可公开修改。应使用 EU 支持的 EUR/GBP 或另行设计合法账户。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_005、`as_of`=2026-08-06T12:00:00Z | `exactly_one` |
| `get_customer` | `sql` | `query_payments.get_customer` | `as_of`=2026-08-06T12:00:00Z、`customer_id`=cus_bm_005 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-06T12:00:00Z、`request_id`=req_bm_005_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-06T11:50:00.000Z` 请求 req_bm_005_01 在 2026 年 08 月 06 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 400、错误码 FP-4001，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_005 当时套餐为 Growth、主地区为 EU，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_customer` 客户 cus_bm_005 状态为 active，Email 为 cus_bm_005@example.test，所属账户为 acct_bm_005、环境为 production。
- `get_request` 请求 req_bm_005_01 在 2026 年 08 月 06 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 400、错误码 FP-4001，响应对象为 无。

证据 ID：`doc:KB-BR-003#c006`、`doc:KB-TS-001#c005`、`sql:account:acct_bm_005`、`sql:customer:cus_bm_005`、`runtime:req:req_bm_005_01`

## FP-BM-MS-0024

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-006-payment_amount_bounds`
- 快照时点 `as_of`：2026-08-07T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_amount_bounds`

### 开场白

> 客服转来一个问题：有两笔金额很特殊的支付怎么都建不出来，普通金额却没问题。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认两次请求为什么失败，重试原请求是否有意义。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户连续提交 amount=49 和 amount=100000001 的 Payment 请求，均未创建那笔支付。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 7 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_006，那笔支付的编号是 pay_bm_006 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认支付所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需要把规则和实际交易对应起来。请给时间范围及支付或请求号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 两次金额分别低于最小值和高于最大值，应返回 FP-4001；原样重试不会成功。 处理方式：修正整数金额后用符合新业务意图的 Idempotency Key 重新提交。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0024-A1` 两次金额分别低于最小值和高于最大值，应返回 FP-4001；原样重试不会成功。
- `FP-BM-MS-0024-A2` 修正整数金额后用符合新业务意图的 Idempotency Key 重新提交。

禁止结论（说了就算错）：

- 不得认定：金额越界属于临时平台错误

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-003`、`KB-API-013`、`KB-API-002`、`KB-TS-001`
- 操作：`query_payments.get_payment`、`get_runtime_state.list_requests`
- 规则：`RULE-AUTH-001`、`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-REGION-001`、`RULE-REGION-002`、`RULE-REGION-003`、`RULE-REQ-001`、`RULE-VERSION-002`、`RULE-VERSION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：两次金额分别低于最小值和高于最大值，应返回 FP-4001；原样重试不会成功。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-07T12:00:00Z、`payment_id`=pay_bm_006 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_006、`as_of`=2026-08-07T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-07T11:49:59.000Z` 请求 req_bm_006_01 在 2026 年 08 月 07 日 11:49 UTC 以 POST 调用 /v1/payments，返回 HTTP 400、错误码 FP-4001，响应对象为 无
- `2026-08-07T11:50:00.000Z` 请求 req_9f096365b1_000002 在 2026 年 08 月 07 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 400、错误码 FP-4001，响应对象为 无

查到的实例事实：

- `get_payment` 在限定范围（as_of=2026-08-07T12:00:00Z、payment_id=pay_bm_006、account_id=acct_bm_006、environment=production）内没有查到 get_payment 对应记录。
- `list_requests` 请求 req_bm_006_01 在 2026 年 08 月 07 日 11:49 UTC 以 POST 调用 /v1/payments，返回 HTTP 400、错误码 FP-4001，响应对象为 无；请求 req_9f096365b1_000002 在 2026 年 08 月 07 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 400、错误码 FP-4001，响应对象为 无。

证据 ID：`doc:KB-BR-003#c006`、`doc:KB-API-013#c006`、`doc:KB-API-002#c003`、`doc:KB-TS-001#c006`、`negative:sql:payment:8af905d8031ae6765c12`、`runtime:req:req_bm_006_01`、`runtime:req:req_9f096365b1_000002`

## FP-BM-MS-0028

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-007-starter_subscription_entitlement`
- 快照时点 `as_of`：2026-08-08T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`starter_subscription_entitlement`

### 开场白

> 我们已经把订阅功能开关打开了，但创建订阅仍然提示没有权限。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Feature Flag 是否足以使创建成功。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Starter Account 这个账户的 subscriptions Flag 被配置为 true，但创建 这份订阅返回 FP-4031。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Starter，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 8 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_007，这份订阅的编号是 sub_bm_007，那次请求的编号是 req_bm_007_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 请补充订阅所属环境、账户套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对订阅与账单关系，请补充时间范围和相关对象编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不足；Starter 不具备订阅套餐权益，Flag 不能越过硬限制。 处理方式：先升级到 Growth 或 Scale，确认升级已生效后再启用并创建 Subscription。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0028-A1` 不足；Starter 不具备订阅套餐权益，Flag 不能越过硬限制。
- `FP-BM-MS-0028-A2` 先升级到 Growth 或 Scale，确认升级已生效后再启用并创建 Subscription。

禁止结论（说了就算错）：

- 不得认定：后台打开 Feature Flag 就能授予任何套餐能力

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-004`、`KB-API-024`、`KB-TS-010`
- 操作：`query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_subscription`、`get_runtime_state.get_request`
- 规则：`RULE-CUSTOMER-004`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-PLAN-005`、`RULE-REGION-003`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_subscription`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不足；Starter 不具备订阅套餐权益，Flag 不能越过硬限制。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_007、`as_of`=2026-08-08T12:00:00Z | `exactly_one` |
| `get_feature_flags` | `sql` | `query_accounts.get_feature_flags` | `account_id`=acct_bm_007、`as_of`=2026-08-08T12:00:00Z | `exactly_one` |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-08T12:00:00Z、`subscription_id`=sub_bm_007 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-08T12:00:00Z、`request_id`=req_bm_007_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-08T11:50:00.000Z` 请求 req_bm_007_01 在 2026 年 08 月 08 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 403、错误码 FP-4031，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_007 当时套餐为 Starter、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_feature_flags` 功能 subscriptions 的配置值为 True，实际生效值为 False，套餐抑制为 True。
- `get_subscription` 在限定范围（as_of=2026-08-08T12:00:00Z、subscription_id=sub_bm_007、account_id=acct_bm_007、environment=production）内没有查到 get_subscription 对应记录。
- `get_request` 请求 req_bm_007_01 在 2026 年 08 月 08 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 403、错误码 FP-4031，响应对象为 无。

证据 ID：`doc:KB-BR-004#c003`、`doc:KB-API-024#c006`、`doc:KB-TS-010#c007`、`sql:account:acct_bm_007`、`sql:feature_flag:acct_bm_007:production:subscriptions`、`negative:sql:subscription:6904e68be34ab497e284`、`runtime:req:req_bm_007_01`

## FP-BM-MS-0032

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-008-plan_upgrade_immediate`
- 快照时点 `as_of`：2026-08-09T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`plan_upgrade_immediate`

### 开场白

> 客户那边反馈：我们刚升级套餐，紧接着使用新功能时，不确定系统有没有按新套餐处理。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认10:01 应按 Starter 还是 Growth 判断权限。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户在 10:00 从 Starter 升级为 Growth，10:01 创建 这份订阅。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Starter，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 9 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_008，这份订阅的编号是 sub_bm_008 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 这是测试环境还是正式环境？账户当前是什么套餐、哪个主地区？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）结合目前的规则，还需要核对实际账户记录。问题大概何时发生，控制台里的账户或请求编号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应按 Growth；升级立即生效，满足其他条件时可创建 Subscription。 处理方式：查询套餐时间线并按请求发生时的有效套餐判断。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0032-A1` 应按 Growth；升级立即生效，满足其他条件时可创建 Subscription。
- `FP-BM-MS-0032-A2` 查询套餐时间线并按请求发生时的有效套餐判断。

禁止结论（说了就算错）：

- 不得认定：升级要等到下个计费周期才生效

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_payments`
- 文档：`KB-BR-004`、`KB-API-005`
- 操作：`query_accounts.get_plan_timeline`、`query_accounts.get_feature_flags`、`query_payments.get_subscription`
- 规则：`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-003`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-PLAN-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_plan_timeline`、`query_accounts.get_feature_flags`、`query_payments.get_subscription`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应按 Growth；升级立即生效，满足其他条件时可创建 Subscription。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_plan_timeline` | `sql` | `query_accounts.get_plan_timeline` | `account_id`=acct_bm_008、`as_of`=2026-08-09T12:00:00Z | `at_least_one` |
| `get_feature_flags` | `sql` | `query_accounts.get_feature_flags` | `account_id`=acct_bm_008、`as_of`=2026-08-09T12:00:00Z | `exactly_one` |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-09T12:00:00Z、`subscription_id`=sub_bm_008 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-09T11:20:06.000Z` 订阅 sub_bm_008 状态为 active，客户为 cus_bm_008，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 08 日 11:20 UTC。
- `2026-08-09T11:50:00.000Z` 2026 年 08 月 09 日 11:50 UTC 申请 Starter→Growth，2026 年 08 月 09 日 11:50 UTC 状态为 effective

查到的实例事实：

- `get_plan_timeline` 套餐轨迹：2026 年 08 月 09 日 11:50 UTC 申请 Starter→Growth，2026 年 08 月 09 日 11:50 UTC 状态为 effective。
- `get_feature_flags` 功能 subscriptions 的配置值为 True，实际生效值为 True，套餐抑制为 False。
- `get_subscription` 订阅 sub_bm_008 状态为 active，客户为 cus_bm_008，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 08 日 11:20 UTC。

证据 ID：`doc:KB-BR-004#c004`、`doc:KB-API-005#c005`、`sql:account_plan:pc_bm_008_02`、`sql:feature_flag:acct_bm_008:production:subscriptions`、`sql:subscription:sub_bm_008`

## FP-BM-MS-0036

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-009-plan_downgrade_deferred`
- 快照时点 `as_of`：2026-08-10T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`plan_downgrade_deferred`

### 开场白

> 线上同事发现：我们提交了降级，之后又新增了一个回调地址，不确定它会不会受新套餐限制。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认新 Endpoint 应按 Scale 还是 Starter 上限判断。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Scale Account 这个账户在周期中申请降为 Starter；申请后、周期结束前又创建了 这个回调地址。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Scale，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 10 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_009 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 先确认账户背景：使用什么套餐，主地区在哪里，问题出现在哪个环境？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了排除账户配置变化，需要一个时间范围和相关账户编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 周期结束前仍按 Scale；降级尚未生效。周期结束后才应用 Starter 上限和 restricted 规则。 处理方式：核对 effective_at，并在周期结束后重新评估 Endpoint 状态。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0036-A1` 周期结束前仍按 Scale；降级尚未生效。周期结束后才应用 Starter 上限和 restricted 规则。
- `FP-BM-MS-0036-A2` 核对 effective_at，并在周期结束后重新评估 Endpoint 状态。

禁止结论（说了就算错）：

- 不得认定：提交降级申请会立刻套用 Starter 上限

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_webhooks_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_webhooks`
- 文档：`KB-BR-004`、`KB-API-029`
- 操作：`query_accounts.get_plan_timeline`、`query_webhooks.list_endpoints`
- 规则：`RULE-ENV-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-PLAN-005`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_plan_timeline`、`query_webhooks.list_endpoints`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：周期结束前仍按 Scale；降级尚未生效。周期结束后才应用 Starter 上限和 restricted 规则。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_plan_timeline` | `sql` | `query_accounts.get_plan_timeline` | `account_id`=acct_bm_009、`as_of`=2026-08-10T12:00:00Z | `at_least_one` |
| `list_endpoints` | `sql` | `query_webhooks.list_endpoints` | `account_id`=acct_bm_009、`as_of`=2026-08-10T12:00:00Z | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-25T11:50:00.000Z` 2026 年 08 月 10 日 11:50 UTC 申请 Scale→Starter，2026 年 08 月 25 日 11:50 UTC 状态为 scheduled

查到的实例事实：

- `get_plan_timeline` 套餐轨迹：2026 年 08 月 10 日 11:50 UTC 申请 Scale→Starter，2026 年 08 月 25 日 11:50 UTC 状态为 scheduled。
- `list_endpoints` 回调地址 we_bm_009 状态 enabled，重试策略 default。

证据 ID：`doc:KB-BR-004#c004`、`doc:KB-API-029#c005`、`sql:account_plan:pc_bm_009_03`、`sql:webhook_endpoint:we_bm_009`

## FP-BM-MS-0040

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-010-api_key_rotation_overlap`
- 快照时点 `as_of`：2026-08-11T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`api_key_rotation_overlap`

### 开场白

> 客户那边反馈：我们正在更换线上密钥，担心新旧实例切换期间会中断请求。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认是否必须立即撤销旧 Key，以及怎样避免发布中断。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户创建新 那把密钥后，旧 Key 进入 expiring；发布仍有部分实例使用旧 Key。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 11 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_010 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 这次调用对应哪个环境？也请补充账户套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还要核对客户端调用记录。大概何时发生，能否提供请求编号？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不必立即撤销；可在最长 24 小时重叠窗口内完成切换，再主动撤销旧 Key。 处理方式：验证所有实例已使用新 Key后再撤销旧 Key。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0040-A1` 不必立即撤销；可在最长 24 小时重叠窗口内完成切换，再主动撤销旧 Key。
- `FP-BM-MS-0040-A2` 验证所有实例已使用新 Key后再撤销旧 Key。

禁止结论（说了就算错）：

- 不得认定：创建新 Key 会自动让旧 Key 立即失效

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`support_cases`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_support_cases`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-006`、`KB-API-003`、`KB-CASE-002`
- 操作：`query_accounts.list_api_keys`、`get_runtime_state.list_requests`
- 规则：`RULE-AUTH-001`、`RULE-AUTH-002`、`RULE-AUTH-003`、`RULE-AUTH-004`、`RULE-AUTH-005`、`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-001`、`RULE-ENV-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.list_api_keys`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不必立即撤销；可在最长 24 小时重叠窗口内完成切换，再主动撤销旧 Key。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `list_api_keys` | `sql` | `query_accounts.list_api_keys` | `account_id`=acct_bm_010、`as_of`=2026-08-11T12:00:00Z | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_010、`as_of`=2026-08-11T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-11T11:50:00.000Z` 请求 req_bm_010_01 在 2026 年 08 月 11 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 200，响应对象为 无

查到的实例事实：

- `list_api_keys` 账户在该范围查到 2 把 API Key：active 1 条、expiring 1 条。
- `list_requests` 请求 req_bm_010_01 在 2026 年 08 月 11 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 200，响应对象为 无。

证据 ID：`doc:KB-BR-006#c004`、`doc:KB-API-003#c005`、`doc:KB-CASE-002#c008`、`sql:api_key:key_bm_010`、`sql:api_key:key_bm_010_new`、`runtime:req:req_bm_010_01`

## FP-BM-MS-0044

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-011-revoked_key_is_terminal`
- 快照时点 `as_of`：2026-08-12T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`revoked_key_is_terminal`

### 开场白

> 我们排查时发现：有把线上密钥误操作停用了，现在旧部署全部认证失败。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认旧 Key 能否恢复使用。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那把密钥被撤销后，这个账户尝试把它重新标记 active，并继续发送 那次请求。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 12 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_011，那次请求的编号是 req_bm_011_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 请求发往测试还是正式环境？相关账户的套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还要核对客户端调用记录。大概何时发生，能否提供请求编号？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；revoked 是不可逆状态，请求应返回 FP-4011。 处理方式：创建新的 Secret Key并更新部署，保留撤销记录。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0044-A1` 不能；revoked 是不可逆状态，请求应返回 FP-4011。
- `FP-BM-MS-0044-A2` 创建新的 Secret Key并更新部署，保留撤销记录。

禁止结论（说了就算错）：

- 不得认定：重新启用 revoked Key 比创建新 Key更安全

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-006`、`KB-API-003`、`KB-TS-004`、`KB-TS-019`
- 操作：`query_accounts.list_api_keys`、`get_runtime_state.get_request`
- 规则：`RULE-AUTH-001`、`RULE-AUTH-002`、`RULE-AUTH-003`、`RULE-AUTH-004`、`RULE-AUTH-005`、`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-001`、`RULE-ENV-005`、`RULE-ERROR-002`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.list_api_keys`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；revoked 是不可逆状态，请求应返回 FP-4011。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `list_api_keys` | `sql` | `query_accounts.list_api_keys` | `account_id`=acct_bm_011、`as_of`=2026-08-12T12:00:00Z | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-12T12:00:00Z、`request_id`=req_bm_011_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-12T11:50:00.000Z` 请求 req_bm_011_01 在 2026 年 08 月 12 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 401、错误码 FP-4011，响应对象为 无

查到的实例事实：

- `list_api_keys` 账户在该范围查到 1 把 API Key：revoked 1 条。
- `get_request` 请求 req_bm_011_01 在 2026 年 08 月 12 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 401、错误码 FP-4011，响应对象为 无。

证据 ID：`doc:KB-BR-006#c004`、`doc:KB-API-003#c001`、`doc:KB-TS-004#c004`、`doc:KB-TS-019#c001`、`sql:api_key:key_bm_011`、`runtime:req:req_bm_011_01`

## FP-BM-MS-0048

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-012-version_header_selection`
- 快照时点 `as_of`：2026-08-13T12:00:00Z　接口版本：2026-04-01
- 标签：`developer_platform`、`version_header_selection`

### 开场白

> 客服转来一个问题：有一批请求突然报版本不支持，但账户里的默认版本看起来没问题。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 3 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认请求应使用默认版本还是失败。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户默认版本为 新版接口，那次请求显式发送 FlowPay-Version: 旧版接口。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 13 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-04-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_012，那次请求的编号是 req_bm_012_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 这次调用对应哪个环境？也请补充账户套餐和主地区。
2. （`before_knowledge`，取 `api_version`）这次调用使用的是哪个接口版本？如果没有显式设置，也请说明账户默认版本。
3. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来需要查看当时的请求。请给一个大概时间范围，以及相关账户或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应返回 FP-4002；显式但不受支持的版本不会回退到 Account 默认版本。 处理方式：改为受支持版本或移除 Header 以使用 Account 默认版本。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0048-A1` 应返回 FP-4002；显式但不受支持的版本不会回退到 Account 默认版本。
- `FP-BM-MS-0048-A2` 改为受支持版本或移除 Header 以使用 Account 默认版本。

禁止结论（说了就算错）：

- 不得认定：错误版本 Header 会被静默忽略

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`release_notes`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_release_notes`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-007`、`KB-API-006`、`KB-TS-002`、`KB-REL-001`、`KB-REL-010`
- 操作：`query_accounts.get_account`、`get_runtime_state.get_request`
- 规则：`RULE-ERROR-001`、`RULE-IDEMP-001`、`RULE-PAY-001`、`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-003`、`RULE-VERSION-004`、`RULE-VERSION-005`、`RULE-VERSION-006`、`RULE-VERSION-007`、`RULE-VERSION-008`、`RULE-VERSION-009`、`RULE-WEBHOOK-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_release_notes`、`search_release_notes`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应返回 FP-4002；显式但不受支持的版本不会回退到 Account 默认版本。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_012、`as_of`=2026-08-13T12:00:00Z | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-13T12:00:00Z、`request_id`=req_bm_012_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-13T11:50:00.000Z` 请求 req_bm_012_01 在 2026 年 08 月 13 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 400、错误码 FP-4002，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_012 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-04-01。
- `get_request` 请求 req_bm_012_01 在 2026 年 08 月 13 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 400、错误码 FP-4002，响应对象为 无。

证据 ID：`doc:KB-BR-007#c002`、`doc:KB-API-006#c002`、`doc:KB-TS-002#c006`、`doc:KB-REL-001#c007`、`doc:KB-REL-010#c003`、`sql:account:acct_bm_012`、`runtime:req:req_bm_012_01`

## FP-BM-MS-0052

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-013-source_deprecated_2026_04`
- 快照时点 `as_of`：2026-08-14T12:00:00Z　接口版本：2026-04-01
- 标签：`payments`、`source_deprecated_2026_04`

### 开场白

> 线上同事发现：支付还能创建成功，不过响应里一直提示一个参数快不能用了。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 3 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这次请求应失败还是成功，迁移时应改什么。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户使用 API Version 当前部署使用的接口版本 和 source 创建那笔支付，响应含弃用提示。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 14 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-04-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_013，那笔支付的编号是 pay_bm_013，那次请求的编号是 req_bm_013_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 先确认支付所属环境，以及账户当前套餐和主地区。
2. （`before_knowledge`，取 `api_version`）能确认当时客户端使用的接口版本吗？
3. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需要把规则和实际交易对应起来。请给时间范围及支付或请求号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> source 在该版本仍兼容，请求可成功；客户端应迁移到 payment_method。 处理方式：在升级到 2026-07-01 前完成 source 到 payment_method 的迁移。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0052-A1` source 在该版本仍兼容，请求可成功；客户端应迁移到 payment_method。
- `FP-BM-MS-0052-A2` 在升级到 2026-07-01 前完成 source 到 payment_method 的迁移。

禁止结论（说了就算错）：

- 不得认定：看到弃用提示就说明该参数已经被移除

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`release_notes`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_release_notes`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-007`、`KB-API-018`、`KB-REL-004`、`KB-REL-005`
- 操作：`query_accounts.get_account`、`query_payments.get_payment`、`get_runtime_state.get_request`
- 规则：`RULE-PAY-005`、`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-003`、`RULE-VERSION-004`、`RULE-VERSION-005`、`RULE-VERSION-006`、`RULE-VERSION-007`、`RULE-VERSION-008`、`RULE-VERSION-009`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_release_notes`、`search_release_notes`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_payments.get_payment`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：source 在该版本仍兼容，请求可成功；客户端应迁移到 payment_method。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_013、`as_of`=2026-08-14T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-14T12:00:00Z、`payment_id`=pay_bm_013 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-14T12:00:00Z、`request_id`=req_bm_013_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-14T11:20:04.000Z` 支付 pay_bm_013 状态 processing，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-14T11:50:00.000Z` 请求 req_bm_013_01 在 2026 年 08 月 14 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_013

查到的实例事实：

- `get_account` 账户 acct_bm_013 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-04-01。
- `get_payment` 支付 pay_bm_013 状态 processing，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_request` 请求 req_bm_013_01 在 2026 年 08 月 14 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_013。

证据 ID：`doc:KB-BR-007#c003`、`doc:KB-API-018#c002`、`doc:KB-REL-004#c003`、`doc:KB-REL-005#c004`、`sql:account:acct_bm_013`、`sql:payment:pay_bm_013`、`runtime:req:req_bm_013_01`

## FP-BM-MS-0056

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-014-source_removed_2026_07`
- 快照时点 `as_of`：2026-08-15T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`source_removed_2026_07`

### 开场白

> 我们排查时发现：升级接口版本以后，原来能用的支付参数突然全部报错。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认是否可以重试相同请求解决问题。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户升级到 当前部署使用的接口版本 后仍用 source 创建那笔支付，那次请求返回 FP-4003。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 15 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_014，那笔支付的编号是 pay_bm_014，那次请求的编号是 req_bm_014_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 先确认支付所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对实际支付记录，请提供大概发生时间，以及能找到的支付或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不可以；参数已从该版本移除，原样重试仍失败且不会创建 Payment。 处理方式：改用 payment_method，并检查所有仍发送 source 的客户端。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0056-A1` 不可以；参数已从该版本移除，原样重试仍失败且不会创建 Payment。
- `FP-BM-MS-0056-A2` 改用 payment_method，并检查所有仍发送 source 的客户端。

禁止结论（说了就算错）：

- 不得认定：FP-4003 是偶发参数校验错误

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`release_notes`、`support_cases`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_release_notes`、`search_support_cases`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-007`、`KB-API-018`、`KB-TS-003`、`KB-REL-007`、`KB-REL-008`、`KB-CASE-007`
- 操作：`query_accounts.get_account`、`query_payments.get_payment`、`get_runtime_state.get_request`
- 规则：`RULE-PAY-005`、`RULE-PAY-007`、`RULE-RATE-007`、`RULE-REFUND-001`、`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-003`、`RULE-VERSION-004`、`RULE-VERSION-005`、`RULE-VERSION-006`、`RULE-VERSION-007`、`RULE-VERSION-008`、`RULE-VERSION-009`、`RULE-WEBHOOK-016`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_release_notes`、`search_release_notes`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_payments.get_payment`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不可以；参数已从该版本移除，原样重试仍失败且不会创建 Payment。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_014、`as_of`=2026-08-15T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-15T12:00:00Z、`payment_id`=pay_bm_014 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-15T12:00:00Z、`request_id`=req_bm_014_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-15T11:50:00.000Z` 请求 req_bm_014_01 在 2026 年 08 月 15 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 400、错误码 FP-4003，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_014 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_payment` 在限定范围（as_of=2026-08-15T12:00:00Z、payment_id=pay_bm_014、account_id=acct_bm_014、environment=production）内没有查到 get_payment 对应记录。
- `get_request` 请求 req_bm_014_01 在 2026 年 08 月 15 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 400、错误码 FP-4003，响应对象为 无。

证据 ID：`doc:KB-BR-007#c003`、`doc:KB-API-018#c005`、`doc:KB-TS-003#c005`、`doc:KB-REL-007#c009`、`doc:KB-REL-008#c003`、`doc:KB-CASE-007#c008`、`sql:account:acct_bm_014`、`negative:sql:payment:cc8ee66d3f5351600177`、`runtime:req:req_bm_014_01`

## FP-BM-MS-0060

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-015-requires_action_version_difference`
- 快照时点 `as_of`：2026-08-16T12:00:00Z　接口版本：2026-01-15
- 标签：`payments`、`requires_action_version_difference`

### 开场白

> 客服转来一个问题：同一种需要客户确认的支付，在两套客户端里表现成了完全不同的状态。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 3 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认两个版本应分别看到什么状态和错误。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 同一客户操作场景分别由 旧版接口 与 新版接口 请求创建 Payment。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 16 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-01-15。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_015，那笔支付的编号是 pay_bm_015 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 这笔业务发生在测试还是正式环境？账户套餐和主地区能确认吗？
2. （`before_knowledge`，取 `api_version`）这次调用使用的是哪个接口版本？如果没有显式设置，也请说明账户默认版本。
3. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对实际支付记录，请提供大概发生时间，以及能找到的支付或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 旧版本看到 failed + FP-4023；新版本看到 requires_action，并可继续 confirm。 处理方式：按请求实际 API Version 处理状态，旧客户端不能套用新状态机。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0060-A1` 旧版本看到 failed + FP-4023；新版本看到 requires_action，并可继续 confirm。
- `FP-BM-MS-0060-A2` 按请求实际 API Version 处理状态，旧客户端不能套用新状态机。

禁止结论（说了就算错）：

- 不得认定：所有版本都会返回 requires_action

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`release_notes`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_release_notes`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-010`、`KB-API-018`、`KB-TS-008`、`KB-REL-002`、`KB-REL-003`
- 操作：`query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.list_requests`
- 规则：`RULE-IDEMP-005`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-PAY-007`、`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-005`、`RULE-VERSION-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_release_notes`、`search_release_notes`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：旧版本看到 failed + FP-4023；新版本看到 requires_action，并可继续 confirm。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-16T12:00:00Z、`payment_id`=pay_bm_015 | `exactly_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_015、`as_of`=2026-08-16T12:00:00Z | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_015、`as_of`=2026-08-16T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-16T11:20:04.000Z` 支付 pay_bm_015 状态 requires_action，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-16T11:20:04.000Z` 支付 pay_bm_015 状态 requires_action，金额 10000 USD
- `2026-08-16T11:49:59.000Z` 请求 req_bm_015_01 在 2026 年 08 月 16 日 11:49 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4023，响应对象为 pay_bm_015_old，请求参数 payment_id=pay_bm_015_old、representation=legacy_failed
- `2026-08-16T11:50:00.000Z` 支付 pay_bm_015_old 状态 failed，金额 10000 USD，失败码 FP-4023
- `2026-08-16T11:50:00.000Z` 请求 req_822a19e78c_000002 在 2026 年 08 月 16 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_015，请求参数 payment_id=pay_bm_015、representation=requires_action

查到的实例事实：

- `get_payment` 支付 pay_bm_015 状态 requires_action，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `list_payments` 支付 pay_bm_015 状态 requires_action，金额 10000 USD；支付 pay_bm_015_old 状态 failed，金额 10000 USD，失败码 FP-4023。
- `list_requests` 请求 req_bm_015_01 在 2026 年 08 月 16 日 11:49 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4023，响应对象为 pay_bm_015_old，请求参数 payment_id=pay_bm_015_old、representation=legacy_failed；请求 req_822a19e78c_000002 在 2026 年 08 月 16 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_015，请求参数 payment_id=pay_bm_015、representation=requires_action。

证据 ID：`doc:KB-BR-010#c004`、`doc:KB-API-018#c004`、`doc:KB-TS-008#c005`、`doc:KB-REL-002#c003`、`doc:KB-REL-003#c006`、`sql:payment:pay_bm_015`、`sql:payment:pay_bm_015_old`、`runtime:req:req_bm_015_01`、`runtime:req:req_822a19e78c_000002`

## FP-BM-MS-0064

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-016-idempotent_replay_same_params`
- 快照时点 `as_of`：2026-08-17T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`idempotent_replay_same_params`

### 开场白

> 线上同事发现：一次创建支付超时后我们重试了，现在担心系统生成了两笔支付。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认是否会创建第二个 Payment。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户在网络超时后用相同参数和相同 Idempotency Key 重试创建那笔支付。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 17 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_016，那笔支付的编号是 pay_bm_016 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 这次调用对应哪个环境？也请补充账户套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还要核对客户端调用记录。大概何时发生，能否提供请求编号？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不会；应返回第一次请求的 Payment 结果，两个 Request ID 指向同一 Payment。 处理方式：保留同一 Key 和完全相同参数，并按 Request ID 核对重放结果。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0064-A1` 不会；应返回第一次请求的 Payment 结果，两个 Request ID 指向同一 Payment。
- `FP-BM-MS-0064-A2` 保留同一 Key 和完全相同参数，并按 Request ID 核对重放结果。

禁止结论（说了就算错）：

- 不得认定：每次 HTTP 重试都会创建新 Payment

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-008`、`KB-API-033`
- 操作：`query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.list_requests`
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-002`、`RULE-IDEMP-003`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-IDEMP-006`、`RULE-REQ-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不会；应返回第一次请求的 Payment 结果，两个 Request ID 指向同一 Payment。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-17T12:00:00Z、`payment_id`=pay_bm_016 | `exactly_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_016、`as_of`=2026-08-17T12:00:00Z | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_016、`as_of`=2026-08-17T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-17T11:20:04.000Z` 支付 pay_bm_016 状态 processing，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-17T11:20:04.000Z` 支付 pay_bm_016 状态 processing，金额 10000 USD
- `2026-08-17T11:49:58.000Z` 请求 req_bm_016_01 在 2026 年 08 月 17 日 11:49 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_016，请求参数 amount=10000
- `2026-08-17T11:50:00.000Z` 请求 req_ab03400a2d_000002 在 2026 年 08 月 17 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_016

查到的实例事实：

- `get_payment` 支付 pay_bm_016 状态 processing，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `list_payments` 支付 pay_bm_016 状态 processing，金额 10000 USD。
- `list_requests` 请求 req_bm_016_01 在 2026 年 08 月 17 日 11:49 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_016，请求参数 amount=10000；请求 req_ab03400a2d_000002 在 2026 年 08 月 17 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_016。

证据 ID：`doc:KB-BR-008#c006`、`doc:KB-API-033#c003`、`sql:payment:pay_bm_016`、`runtime:req:req_bm_016_01`、`runtime:req:req_ab03400a2d_000002`

## FP-BM-MS-0068

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-017-idempotency_conflict`
- 快照时点 `as_of`：2026-08-18T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`idempotency_conflict`

### 开场白

> 线上同事发现：我们重试创建支付时改了金额，结果既没更新也没新建。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认第二次请求应修改原 Payment 还是创建新 Payment。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户先用 amount=5000 创建那笔支付，随后用同一 Key 把 amount 改为 7000。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 18 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_017，那笔支付的编号是 pay_bm_017 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 请求发往测试还是正式环境？相关账户的套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来需要查看当时的请求。请给一个大概时间范围，以及相关账户或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 都不会；第二次应返回 FP-4091，第一次的 Payment 和金额保持不变。 处理方式：为新的 7000 金额请求使用新的 Idempotency Key。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0068-A1` 都不会；第二次应返回 FP-4091，第一次的 Payment 和金额保持不变。
- `FP-BM-MS-0068-A2` 为新的 7000 金额请求使用新的 Idempotency Key。

禁止结论（说了就算错）：

- 不得认定：同一 Key 可以用来表达修改后的业务意图

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`support_cases`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-008`、`KB-API-033`、`KB-TS-013`、`KB-CASE-004`
- 操作：`query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.list_requests`
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-002`、`RULE-IDEMP-003`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-IDEMP-006`、`RULE-REQ-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：都不会；第二次应返回 FP-4091，第一次的 Payment 和金额保持不变。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-18T12:00:00Z、`payment_id`=pay_bm_017 | `exactly_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_017、`as_of`=2026-08-18T12:00:00Z | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_017、`as_of`=2026-08-18T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-18T11:20:04.000Z` 支付 pay_bm_017 状态 processing，金额 5000 USD，已占用退款额度 0、当前可退 5000
- `2026-08-18T11:20:04.000Z` 支付 pay_bm_017 状态 processing，金额 5000 USD
- `2026-08-18T11:49:58.000Z` 请求 req_bm_017_01 在 2026 年 08 月 18 日 11:49 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_017，请求参数 amount=5000
- `2026-08-18T11:50:00.000Z` 请求 req_9d4a22509f_000002 在 2026 年 08 月 18 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 409、错误码 FP-4091，响应对象为 无，请求参数 amount=7000

查到的实例事实：

- `get_payment` 支付 pay_bm_017 状态 processing，金额 5000 USD，已占用退款额度 0、当前可退 5000。
- `list_payments` 支付 pay_bm_017 状态 processing，金额 5000 USD。
- `list_requests` 请求 req_bm_017_01 在 2026 年 08 月 18 日 11:49 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_017，请求参数 amount=5000；请求 req_9d4a22509f_000002 在 2026 年 08 月 18 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 409、错误码 FP-4091，响应对象为 无，请求参数 amount=7000。

证据 ID：`doc:KB-BR-008#c004`、`doc:KB-API-033#c003`、`doc:KB-TS-013#c004`、`doc:KB-CASE-004#c008`、`sql:payment:pay_bm_017`、`runtime:req:req_bm_017_01`、`runtime:req:req_9d4a22509f_000002`

## FP-BM-MS-0072

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-018-idempotency_expired`
- 快照时点 `as_of`：2026-08-19T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`idempotency_expired`

### 开场白

> 隔了一天多重试同一笔业务后，系统里好像多出了一笔支付。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认第二次请求是否仍应返回第一次 Payment。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户在首次创建那笔支付的 25 小时后，以相同参数和同一 Key 再次发送请求。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 19 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_018 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 这次调用对应哪个环境？也请补充账户套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了确认请求实际使用的配置，请补充发生时间和控制台中的请求号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应；24 小时窗口已过，第二次是新请求并可创建新的 Payment。 处理方式：客户端不应在窗口外依赖旧 Key 去重，应保存业务侧订单关联。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0072-A1` 不应；24 小时窗口已过，第二次是新请求并可创建新的 Payment。
- `FP-BM-MS-0072-A2` 客户端不应在窗口外依赖旧 Key 去重，应保存业务侧订单关联。

禁止结论（说了就算错）：

- 不得认定：Idempotency Key 永久全局唯一

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-008`、`KB-API-033`、`KB-TS-013`
- 操作：`query_payments.list_payments`、`get_runtime_state.list_requests`
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-002`、`RULE-IDEMP-003`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-IDEMP-006`、`RULE-REQ-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.list_payments`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应；24 小时窗口已过，第二次是新请求并可创建新的 Payment。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_018、`as_of`=2026-08-19T12:00:00Z | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_018、`as_of`=2026-08-19T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-19T11:20:04.000Z` 支付 pay_bm_018 状态 processing，金额 10000 USD
- `2026-08-19T11:50:00.000Z` 支付 pay_bm_018_after_24h 状态 processing，金额 10000 USD
- `2026-08-19T11:50:00.000Z` 请求 req_77a6ce04b4_000002 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_018_after_24h

查到的实例事实：

- `list_payments` 支付 pay_bm_018 状态 processing，金额 10000 USD；支付 pay_bm_018_after_24h 状态 processing，金额 10000 USD。
- `list_requests` 请求 req_77a6ce04b4_000002 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_018_after_24h。

证据 ID：`doc:KB-BR-008#c006`、`doc:KB-API-033#c003`、`doc:KB-TS-013#c003`、`sql:payment:pay_bm_018`、`sql:payment:pay_bm_018_after_24h`、`runtime:req:req_77a6ce04b4_000002`

## FP-BM-MS-0076

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-019-sandbox_fixed_rate_limit`
- 快照时点 `as_of`：2026-08-20T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`sandbox_fixed_rate_limit`

### 开场白

> 线上同事发现：压测测试环境时很快就被限流了，降低并发后还是容易触发。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认是否应按 Scale 的 5,000 req/min 判断。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Scale Account 这个账户在 Sandbox 一分钟发送 200 个请求并出现 FP-4291。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在测试环境；账户套餐是 Scale，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 20 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_019 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 这次调用对应哪个环境？也请补充账户套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来需要查看当时的请求。请给一个大概时间范围，以及相关账户或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应；Sandbox 使用固定 120 req/min 和 180 burst，因此可能被限流。 处理方式：降低 Sandbox 流量并按退避 Header 重试；不要用升级套餐解决。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0076-A1` 不应；Sandbox 使用固定 120 req/min 和 180 burst，因此可能被限流。
- `FP-BM-MS-0076-A2` 降低 Sandbox 流量并按退避 Header 重试；不要用升级套餐解决。

禁止结论（说了就算错）：

- 不得认定：购买 Scale 会提高 Sandbox 限额

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-005`、`KB-API-004`、`KB-API-034`、`KB-TS-016`
- 操作：`query_accounts.get_account`、`get_runtime_state.get_usage`、`get_runtime_state.list_requests`
- 规则：`RULE-AUTH-008`、`RULE-ENV-001`、`RULE-ENV-002`、`RULE-ENV-004`、`RULE-ENV-005`、`RULE-PLAN-005`、`RULE-RATE-001`、`RULE-RATE-002`、`RULE-RATE-003`、`RULE-RATE-004`、`RULE-RATE-005`、`RULE-RATE-006`、`RULE-RATE-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`get_runtime_state.get_usage`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应；Sandbox 使用固定 120 req/min 和 180 burst，因此可能被限流。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_019、`as_of`=2026-08-20T12:00:00Z | `exactly_one` |
| `get_usage` | `runtime` | `get_runtime_state.get_usage` | `account_id`=acct_bm_019、`as_of`=2026-08-20T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_019、`as_of`=2026-08-20T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-20T11:50:00.000Z` 请求 req_bm_019_01 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-20T11:50:00.030Z` 请求 req_4c43fefb82_000002 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-20T11:50:00.060Z` 请求 req_4c43fefb82_000003 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-20T11:50:00.090Z` 请求 req_4c43fefb82_000004 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-20T11:50:00.120Z` 请求 req_4c43fefb82_000005 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-20T11:50:00.150Z` 请求 req_4c43fefb82_000006 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-20T11:50:00.180Z` 请求 req_4c43fefb82_000007 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-20T11:50:00.210Z` 请求 req_4c43fefb82_000008 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_019 当时套餐为 Scale、主地区为 NA，Production 状态为 not_enabled，默认接口版本为 2026-07-01。
- `get_usage` 2026 年 08 月 20 日 11:50 UTC 共 200 次请求，成功 120、限流 80、错误 80。
- `list_requests` 请求 req_bm_019_01 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_4c43fefb82_000002 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_4c43fefb82_000003 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_4c43fefb82_000004 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_4c43fefb82_000005 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_4c43fefb82_000006 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_4c43fefb82_000007 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_4c43fefb82_000008 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无。

证据 ID：`doc:KB-BR-005#c006`、`doc:KB-API-004#c001`、`doc:KB-API-034#c005`、`doc:KB-TS-016#c005`、`sql:account:acct_bm_019`、`runtime:usage:acct_bm_019:sandbox:2026-08-20T11:50:00.000Z`、`runtime:req:req_bm_019_01`、`runtime:req:req_4c43fefb82_000002`、`runtime:req:req_4c43fefb82_000003`、`runtime:req:req_4c43fefb82_000004`、`runtime:req:req_4c43fefb82_000005`、`runtime:req:req_4c43fefb82_000006`、`runtime:req:req_4c43fefb82_000007`、`runtime:req:req_4c43fefb82_000008`、`runtime:req:req_4c43fefb82_000009`、`runtime:req:req_4c43fefb82_000010`、`runtime:req:req_4c43fefb82_000011`、`runtime:req:req_4c43fefb82_000012`、`runtime:req:req_4c43fefb82_000013`、`runtime:req:req_4c43fefb82_000014`、`runtime:req:req_4c43fefb82_000015`、`runtime:req:req_4c43fefb82_000016`、`runtime:req:req_4c43fefb82_000017`、`runtime:req:req_4c43fefb82_000018`、`runtime:req:req_4c43fefb82_000019`、`runtime:req:req_4c43fefb82_000020`

## FP-BM-MS-0080

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-020-growth_rate_burst`
- 快照时点 `as_of`：2026-08-21T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`growth_rate_burst`

### 开场白

> 线上同事发现：线上流量短时间冲高后开始大量限流，但平时的请求量并不大。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这是否说明套餐被降级。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Growth Account 这个账户在一分钟内产生 1,420 个请求，10 秒峰值未超过 1,500，部分请求返回 FP-4291。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 21 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_020 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 这次调用对应哪个环境？也请补充账户套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来需要查看当时的请求。请给一个大概时间范围，以及相关账户或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不说明；当时仍是 Growth，持续请求量超过 1,200 已足以触发限流。 处理方式：按 Usage 确认流量并实施指数退避；容量长期不足时再评估套餐。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0080-A1` 不说明；当时仍是 Growth，持续请求量超过 1,200 已足以触发限流。
- `FP-BM-MS-0080-A2` 按 Usage 确认流量并实施指数退避；容量长期不足时再评估套餐。

禁止结论（说了就算错）：

- 不得认定：429 是套餐状态发生变化的证据

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`support_cases`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-005`、`KB-API-034`、`KB-TS-022`、`KB-CASE-005`
- 操作：`query_accounts.get_account`、`query_accounts.get_plan_timeline`、`get_runtime_state.get_usage`、`get_runtime_state.list_requests`
- 规则：`RULE-PLAN-001`、`RULE-PLAN-005`、`RULE-RATE-001`、`RULE-RATE-002`、`RULE-RATE-003`、`RULE-RATE-004`、`RULE-RATE-005`、`RULE-RATE-006`、`RULE-RATE-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_accounts.get_plan_timeline`、`get_runtime_state.get_usage`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不说明；当时仍是 Growth，持续请求量超过 1,200 已足以触发限流。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_020、`as_of`=2026-08-21T12:00:00Z | `exactly_one` |
| `get_plan_timeline` | `sql` | `query_accounts.get_plan_timeline` | `account_id`=acct_bm_020、`as_of`=2026-08-21T12:00:00Z | `at_least_one` |
| `get_usage` | `runtime` | `get_runtime_state.get_usage` | `account_id`=acct_bm_020、`as_of`=2026-08-21T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_020、`as_of`=2026-08-21T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-21T11:50:00.000Z` 请求 req_bm_020_01 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-21T11:50:00.030Z` 请求 req_9234bb80a8_000002 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-21T11:50:00.060Z` 请求 req_9234bb80a8_000003 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-21T11:50:00.090Z` 请求 req_9234bb80a8_000004 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-21T11:50:00.120Z` 请求 req_9234bb80a8_000005 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-21T11:50:00.150Z` 请求 req_9234bb80a8_000006 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-21T11:50:00.180Z` 请求 req_9234bb80a8_000007 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-21T11:50:00.210Z` 请求 req_9234bb80a8_000008 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_020 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_plan_timeline` 在限定范围（as_of=2026-08-21T12:00:00Z、account_id=acct_bm_020、environment=production）内没有查到 get_plan_timeline 对应记录。
- `get_usage` 2026 年 08 月 21 日 11:50 UTC 共 1420 次请求，成功 1200、限流 220、错误 220。
- `list_requests` 请求 req_bm_020_01 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_9234bb80a8_000002 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_9234bb80a8_000003 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_9234bb80a8_000004 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_9234bb80a8_000005 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_9234bb80a8_000006 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_9234bb80a8_000007 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_9234bb80a8_000008 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无。

证据 ID：`doc:KB-BR-005#c004`、`doc:KB-API-034#c005`、`doc:KB-TS-022#c004`、`doc:KB-CASE-005#c001`、`sql:account:acct_bm_020`、`negative:sql:account_plan:159109faea9715209006`、`runtime:usage:acct_bm_020:production:2026-08-21T11:50:00.000Z`、`runtime:req:req_bm_020_01`、`runtime:req:req_9234bb80a8_000002`、`runtime:req:req_9234bb80a8_000003`、`runtime:req:req_9234bb80a8_000004`、`runtime:req:req_9234bb80a8_000005`、`runtime:req:req_9234bb80a8_000006`、`runtime:req:req_9234bb80a8_000007`、`runtime:req:req_9234bb80a8_000008`、`runtime:req:req_9234bb80a8_000009`、`runtime:req:req_9234bb80a8_000010`、`runtime:req:req_9234bb80a8_000011`、`runtime:req:req_9234bb80a8_000012`、`runtime:req:req_9234bb80a8_000013`、`runtime:req:req_9234bb80a8_000014`、`runtime:req:req_9234bb80a8_000015`、`runtime:req:req_9234bb80a8_000016`、`runtime:req:req_9234bb80a8_000017`、`runtime:req:req_9234bb80a8_000018`、`runtime:req:req_9234bb80a8_000019`、`runtime:req:req_9234bb80a8_000020`

## FP-BM-MS-0084

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-021-rate_retry_storm`
- 快照时点 `as_of`：2026-08-22T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`rate_retry_storm`

### 开场白

> 客户那边反馈：服务被限流后，客户端越重试错误越多，流量反而一直降不下来。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认持续 429 的主要原因是套餐降级还是客户端重试放大。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户首次接近 Growth 上限后，客户端对每个 429 立即并发重试 5 次，那次请求形成重试链。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 22 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_021 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 这次调用对应哪个环境？也请补充账户套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来需要查看当时的请求。请给一个大概时间范围，以及相关账户或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 主要原因是立即 fan-out 重试放大请求量；套餐在事发时未变化。 处理方式：停止 fan-out，遵守 Reset/Retry-After 提示并使用指数退避。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0084-A1` 主要原因是立即 fan-out 重试放大请求量；套餐在事发时未变化。
- `FP-BM-MS-0084-A2` 停止 fan-out，遵守 Reset/Retry-After 提示并使用指数退避。

禁止结论（说了就算错）：

- 不得认定：只要增加重试次数就能更快恢复

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`support_cases`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-005`、`KB-API-034`、`KB-TS-022`、`KB-CASE-006`
- 操作：`query_accounts.get_plan_timeline`、`get_runtime_state.get_usage`、`get_runtime_state.list_requests`
- 规则：`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-005`、`RULE-RATE-001`、`RULE-RATE-002`、`RULE-RATE-003`、`RULE-RATE-004`、`RULE-RATE-005`、`RULE-RATE-006`、`RULE-RATE-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_plan_timeline`、`get_runtime_state.get_usage`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：主要原因是立即 fan-out 重试放大请求量；套餐在事发时未变化。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_plan_timeline` | `sql` | `query_accounts.get_plan_timeline` | `account_id`=acct_bm_021、`as_of`=2026-08-22T12:00:00Z | `at_least_one` |
| `get_usage` | `runtime` | `get_runtime_state.get_usage` | `account_id`=acct_bm_021、`as_of`=2026-08-22T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_021、`as_of`=2026-08-22T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-22T11:50:00.000Z` 请求 req_bm_021_01 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-22T11:50:00.030Z` 请求 req_146d0bd1d6_000002 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-22T11:50:00.060Z` 请求 req_146d0bd1d6_000003 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-22T11:50:00.090Z` 请求 req_146d0bd1d6_000004 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-22T11:50:00.120Z` 请求 req_146d0bd1d6_000005 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-22T11:50:00.150Z` 请求 req_146d0bd1d6_000006 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-22T11:50:00.180Z` 请求 req_146d0bd1d6_000007 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无
- `2026-08-22T11:50:00.210Z` 请求 req_146d0bd1d6_000008 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无

查到的实例事实：

- `get_plan_timeline` 在限定范围（as_of=2026-08-22T12:00:00Z、account_id=acct_bm_021、environment=production）内没有查到 get_plan_timeline 对应记录。
- `get_usage` 2026 年 08 月 22 日 11:50 UTC 共 1600 次请求，成功 1200、限流 400、错误 400。
- `list_requests` 请求 req_bm_021_01 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_146d0bd1d6_000002 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_146d0bd1d6_000003 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_146d0bd1d6_000004 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_146d0bd1d6_000005 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_146d0bd1d6_000006 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_146d0bd1d6_000007 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无；请求 req_146d0bd1d6_000008 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 无。

证据 ID：`doc:KB-BR-005#c006`、`doc:KB-API-034#c005`、`doc:KB-TS-022#c004`、`doc:KB-CASE-006#c009`、`negative:sql:account_plan:8db228e86dab09a1f27a`、`runtime:usage:acct_bm_021:production:2026-08-22T11:50:00.000Z`、`runtime:req:req_bm_021_01`、`runtime:req:req_146d0bd1d6_000002`、`runtime:req:req_146d0bd1d6_000003`、`runtime:req:req_146d0bd1d6_000004`、`runtime:req:req_146d0bd1d6_000005`、`runtime:req:req_146d0bd1d6_000006`、`runtime:req:req_146d0bd1d6_000007`、`runtime:req:req_146d0bd1d6_000008`、`runtime:req:req_146d0bd1d6_000009`、`runtime:req:req_146d0bd1d6_000010`、`runtime:req:req_146d0bd1d6_000011`、`runtime:req:req_146d0bd1d6_000012`、`runtime:req:req_146d0bd1d6_000013`、`runtime:req:req_146d0bd1d6_000014`、`runtime:req:req_146d0bd1d6_000015`、`runtime:req:req_146d0bd1d6_000016`、`runtime:req:req_146d0bd1d6_000017`、`runtime:req:req_146d0bd1d6_000018`、`runtime:req:req_146d0bd1d6_000019`、`runtime:req:req_146d0bd1d6_000020`

## FP-BM-MS-0088

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-022-webhooks_excluded_from_rate_limit`
- 快照时点 `as_of`：2026-08-23T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhooks_excluded_from_rate_limit`

### 开场白

> 客户那边反馈：业务接口被限流的同时，回调还在持续收到，我们不确定这是否正常。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Rate Limit 计数应是 900 还是 1,600。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户同一分钟有 900 次 API 请求和 700 次 Webhook Delivery Attempt，套餐为 Growth。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 23 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_022，那次投递的编号是 del_bm_022 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认事件所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需查看回调实际尝试记录。大概何时发生，能提供事件或投递编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应是 900；Webhook Delivery Attempt 不计入 Merchant API Rate Limit。 处理方式：分别查询 API Usage 与 Delivery Timeline，不要把两个指标相加。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0088-A1` 应是 900；Webhook Delivery Attempt 不计入 Merchant API Rate Limit。
- `FP-BM-MS-0088-A2` 分别查询 API Usage 与 Delivery Timeline，不要把两个指标相加。

禁止结论（说了就算错）：

- 不得认定：所有 FlowPay 发出的 HTTP 流量都计入商户限流

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-005`、`KB-API-034`、`KB-API-032`
- 操作：`query_webhooks.get_delivery`、`get_runtime_state.get_usage`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-PLAN-005`、`RULE-RATE-001`、`RULE-RATE-002`、`RULE-RATE-003`、`RULE-RATE-004`、`RULE-RATE-005`、`RULE-RATE-006`、`RULE-RATE-007`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_delivery`、`get_runtime_state.get_usage`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应是 900；Webhook Delivery Attempt 不计入 Merchant API Rate Limit。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-23T12:00:00Z、`delivery_id`=del_bm_022 | `exactly_one` |
| `get_usage` | `runtime` | `get_runtime_state.get_usage` | `account_id`=acct_bm_022、`as_of`=2026-08-23T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-23T12:00:00Z、`delivery_id`=del_bm_022 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-23T11:50:00.000Z` 投递 del_bm_022 状态为 delivered，已尝试 1 次，终止原因是 无。
- `2026-08-23T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 23 日 11:50 UTC 返回 HTTP 204，结果状态 delivered

查到的实例事实：

- `get_delivery` 投递 del_bm_022 状态为 delivered，已尝试 1 次，终止原因是 无。
- `get_usage` 2026 年 08 月 23 日 11:50 UTC 共 900 次请求，成功 900、限流 0、错误 0。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 23 日 11:50 UTC 返回 HTTP 204，结果状态 delivered。

证据 ID：`doc:KB-BR-005#c006`、`doc:KB-API-034#c005`、`doc:KB-API-032#c004`、`sql:webhook_delivery:del_bm_022`、`runtime:usage:acct_bm_022:production:2026-08-23T11:50:00.000Z`、`runtime:attempt:att_bm_022_01`

## FP-BM-MS-0092

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-023-customer_soft_delete_history`
- 快照时点 `as_of`：2026-08-24T12:00:00Z　接口版本：2026-07-01
- 标签：`customers`、`customer_soft_delete_history`

### 开场白

> 客户那边反馈：客户被删除后后台仍能查到以前的支付，我们担心删除没有生效。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这是否表示删除失败。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这位客户被删除后，历史 那笔支付仍能被 这个账户查询并显示原 Customer ID。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 24 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_023，这位客户的编号是 cus_bm_023，那笔支付的编号是 pay_bm_023 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 客户对象属于哪个环境？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）需要核对客户及关联对象。请提供大概时间和客户或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不是；软删除只阻止新的业务创建，不移除既有对象的关联。 处理方式：把 Customer 状态显示为 deleted，同时保留审计与历史对象关联。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0092-A1` 不是；软删除只阻止新的业务创建，不移除既有对象的关联。
- `FP-BM-MS-0092-A2` 把 Customer 状态显示为 deleted，同时保留审计与历史对象关联。

禁止结论（说了就算错）：

- 不得认定：删除 Customer 应级联删除所有历史交易

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`
- 文档：`KB-BR-009`、`KB-API-009`、`KB-API-011`
- 操作：`query_payments.get_customer`、`query_payments.list_customers`、`query_payments.get_payment`
- 规则：`RULE-CUSTOMER-001`、`RULE-CUSTOMER-002`、`RULE-CUSTOMER-003`、`RULE-CUSTOMER-004`、`RULE-CUSTOMER-005`、`RULE-TENANT-001`、`RULE-TENANT-003`、`RULE-TENANT-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_customer`、`query_payments.list_customers`、`query_payments.get_payment`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不是；软删除只阻止新的业务创建，不移除既有对象的关联。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_customer` | `sql` | `query_payments.get_customer` | `as_of`=2026-08-24T12:00:00Z、`customer_id`=cus_bm_023 | `exactly_one` |
| `list_customers` | `sql` | `query_payments.list_customers` | `account_id`=acct_bm_023、`as_of`=2026-08-24T12:00:00Z | `at_least_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-24T12:00:00Z、`payment_id`=pay_bm_023 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-24T11:20:04.000Z` 支付 pay_bm_023 状态 processing，金额 10000 USD，已占用退款额度 0、当前可退 10000

查到的实例事实：

- `get_customer` 客户 cus_bm_023 状态为 deleted，Email 为 cus_bm_023@example.test，所属账户为 acct_bm_023、环境为 production。
- `list_customers` 客户 cus_bm_023 状态为 deleted，Email 为 cus_bm_023@example.test，所属账户为 acct_bm_023、环境为 production。
- `get_payment` 支付 pay_bm_023 状态 processing，金额 10000 USD，已占用退款额度 0、当前可退 10000。

证据 ID：`doc:KB-BR-009#c003`、`doc:KB-API-009#c004`、`doc:KB-API-011#c003`、`sql:customer:cus_bm_023`、`sql:payment:pay_bm_023`

## FP-BM-MS-0096

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-024-deleted_customer_new_payment`
- 快照时点 `as_of`：2026-08-25T12:00:00Z　接口版本：2026-07-01
- 标签：`customers`、`deleted_customer_new_payment`

### 开场白

> 线上同事发现：一个已经删除的客户仍被业务系统拿来创建新支付，结果一直失败。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认能否重新使用这个 Customer ID 创建 Payment。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这位客户已 deleted，这个账户随后尝试创建新 那笔支付，请求返回状态错误。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 25 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_024，这位客户的编号是 cus_bm_024，那笔支付的编号是 pay_bm_024，那次请求的编号是 req_bm_024_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 客户对象属于哪个环境？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了确认客户与交易的关联，请补充时间范围和相关客户编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；deleted Customer 不可恢复为 active，也不能用于新 Payment。 处理方式：创建新的 active Customer，并用新 Customer ID 表达后续业务。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0096-A1` 不能；deleted Customer 不可恢复为 active，也不能用于新 Payment。
- `FP-BM-MS-0096-A2` 创建新的 active Customer，并用新 Customer ID 表达后续业务。

禁止结论（说了就算错）：

- 不得认定：既然历史 Payment 可见，Customer 就仍可用于新交易

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-009`、`KB-API-011`、`KB-API-013`、`KB-TS-014`
- 操作：`query_payments.get_customer`、`query_payments.get_payment`、`get_runtime_state.get_request`
- 规则：`RULE-CUSTOMER-001`、`RULE-CUSTOMER-002`、`RULE-CUSTOMER-003`、`RULE-CUSTOMER-004`、`RULE-CUSTOMER-005`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-REFUND-001`、`RULE-REFUND-008`、`RULE-REGION-001`、`RULE-TENANT-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_customer`、`query_payments.get_payment`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；deleted Customer 不可恢复为 active，也不能用于新 Payment。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_customer` | `sql` | `query_payments.get_customer` | `as_of`=2026-08-25T12:00:00Z、`customer_id`=cus_bm_024 | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-25T12:00:00Z、`payment_id`=pay_bm_024 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-25T12:00:00Z、`request_id`=req_bm_024_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-25T11:50:00.000Z` 请求 req_bm_024_01 在 2026 年 08 月 25 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 customer_id=cus_bm_024

查到的实例事实：

- `get_customer` 客户 cus_bm_024 状态为 deleted，Email 为 cus_bm_024@example.test，所属账户为 acct_bm_024、环境为 production。
- `get_payment` 在限定范围（as_of=2026-08-25T12:00:00Z、payment_id=pay_bm_024、account_id=acct_bm_024、environment=production）内没有查到 get_payment 对应记录。
- `get_request` 请求 req_bm_024_01 在 2026 年 08 月 25 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 customer_id=cus_bm_024。

证据 ID：`doc:KB-BR-009#c003`、`doc:KB-API-011#c003`、`doc:KB-API-013#c004`、`doc:KB-TS-014#c004`、`sql:customer:cus_bm_024`、`negative:sql:payment:563ebbe745fa25c510f9`、`runtime:req:req_bm_024_01`

## FP-BM-MS-0100

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-025-duplicate_customer_email`
- 快照时点 `as_of`：2026-08-26T12:00:00Z　接口版本：2026-07-01
- 标签：`customers`、`duplicate_customer_email`

### 开场白

> 客服转来一个问题：同一个邮箱似乎对应了两个客户，我们不知道支付该关联哪一个。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认能否仅用 Email 确定应更新哪个 Customer。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户中有两个 active Customer 使用相同 Email，其中只有 这位客户关联目标 Payment。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 26 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_025，这位客户的编号是 cus_bm_025 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认客户所属环境，以及账户套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）需要核对客户及关联对象。请提供大概时间和客户或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；Email 可重复，必须先取得并使用明确的 Customer ID。 处理方式：按 Customer ID 查询、更新和关联，避免对 Email 做唯一性假设。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0100-A1` 不能；Email 可重复，必须先取得并使用明确的 Customer ID。
- `FP-BM-MS-0100-A2` 按 Customer ID 查询、更新和关联，避免对 Email 做唯一性假设。

禁止结论（说了就算错）：

- 不得认定：相同 Email 代表同一个 Customer

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`
- 文档：`KB-BR-009`、`KB-API-009`、`KB-API-010`
- 操作：`query_payments.get_customer`、`query_payments.list_customers`、`query_payments.list_payments`
- 规则：`RULE-CUSTOMER-001`、`RULE-CUSTOMER-002`、`RULE-CUSTOMER-003`、`RULE-CUSTOMER-004`、`RULE-CUSTOMER-005`、`RULE-REQ-001`、`RULE-TENANT-001`、`RULE-TENANT-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_customer`、`query_payments.list_customers`、`query_payments.list_payments`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；Email 可重复，必须先取得并使用明确的 Customer ID。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_customer` | `sql` | `query_payments.get_customer` | `as_of`=2026-08-26T12:00:00Z、`customer_id`=cus_bm_025 | `exactly_one` |
| `list_customers` | `sql` | `query_payments.list_customers` | `account_id`=acct_bm_025、`as_of`=2026-08-26T12:00:00Z | `at_least_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_025、`as_of`=2026-08-26T12:00:00Z | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-26T11:20:04.000Z` 支付 pay_bm_025 状态 processing，金额 10000 USD

查到的实例事实：

- `get_customer` 客户 cus_bm_025 状态为 active，Email 为 shared-customer@example.test，所属账户为 acct_bm_025、环境为 production。
- `list_customers` 客户 cus_bm_025 状态为 active，Email 为 shared-customer@example.test，所属账户为 acct_bm_025、环境为 production；客户 cus_bm_025_duplicate 状态为 active，Email 为 shared-customer@example.test，所属账户为 acct_bm_025、环境为 production。
- `list_payments` 支付 pay_bm_025 状态 processing，金额 10000 USD。

证据 ID：`doc:KB-BR-009#c004`、`doc:KB-API-009#c002`、`doc:KB-API-010#c005`、`sql:customer:cus_bm_025`、`sql:customer:cus_bm_025_duplicate`、`sql:payment:pay_bm_025`

## FP-BM-MS-0123

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-031-payment_insufficient_funds`
- 快照时点 `as_of`：2026-08-06T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_insufficient_funds`

### 开场白

> 客服转来一个问题：客户说卡能正常使用，可这笔支付一直提示资金方面的问题。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这次能否沿用上次的拒绝根因。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付返回 FP-4022；同一客户此前另一笔 Payment 曾返回 FP-4021。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 6 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_031，那笔支付的编号是 pay_bm_031，那次请求的编号是 req_bm_031_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认支付所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对实际支付记录，请提供大概发生时间，以及能找到的支付或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；本次明确是 Insufficient Funds，应按 FP-4022 处理。 处理方式：向客户说明余额不足，新的支付尝试必须创建新 Payment。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0123-A1` 不能；本次明确是 Insufficient Funds，应按 FP-4022 处理。
- `FP-BM-MS-0123-A2` 向客户说明余额不足，新的支付尝试必须创建新 Payment。

禁止结论（说了就算错）：

- 不得认定：相同 HTTP 402 的所有错误根因都相同

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`troubleshooting`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_troubleshooting`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-011`、`KB-TS-007`
- 操作：`query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.get_request`
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；本次明确是 Insufficient Funds，应按 FP-4022 处理。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-06T12:00:00Z、`payment_id`=pay_bm_031 | `exactly_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_031、`as_of`=2026-08-06T12:00:00Z | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-06T12:00:00Z、`request_id`=req_bm_031_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-06T11:20:04.000Z` 支付 pay_bm_031 状态 failed，金额 10000 USD，失败码 FP-4022，已占用退款额度 0、当前可退 10000
- `2026-08-06T11:20:04.000Z` 支付 pay_bm_031 状态 failed，金额 10000 USD，失败码 FP-4022
- `2026-08-06T11:50:00.000Z` 请求 req_bm_031_01 在 2026 年 08 月 06 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4022，响应对象为 无

查到的实例事实：

- `get_payment` 支付 pay_bm_031 状态 failed，金额 10000 USD，失败码 FP-4022，已占用退款额度 0、当前可退 10000。
- `list_payments` 支付 pay_bm_031 状态 failed，金额 10000 USD，失败码 FP-4022。
- `get_request` 请求 req_bm_031_01 在 2026 年 08 月 06 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4022，响应对象为 无。

证据 ID：`doc:KB-BR-011#c003`、`doc:KB-TS-007#c004`、`sql:payment:pay_bm_031`、`runtime:req:req_bm_031_01`

## FP-BM-MS-0127

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-032-payment_method_expired`
- 快照时点 `as_of`：2026-08-07T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_method_expired`

### 开场白

> 线上同事发现：一批老客户最近付款失败，似乎都和保存过的支付方式有关。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认原样重放是否可能成功。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付使用已过期支付方式并返回 FP-4024，商户准备重放同一请求。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 7 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_032，那笔支付的编号是 pay_bm_032，那次请求的编号是 req_bm_032_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 这笔业务发生在测试还是正式环境？账户套餐和主地区能确认吗？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步需要查看这笔支付的状态变化。大概是什么时候，支付编号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不会改变已过期支付方式，也不会复活 failed Payment；应更新支付方式并创建新 Payment。 处理方式：获取新的有效支付方式后发起新的收费尝试。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0127-A1` 不会改变已过期支付方式，也不会复活 failed Payment；应更新支付方式并创建新 Payment。
- `FP-BM-MS-0127-A2` 获取新的有效支付方式后发起新的收费尝试。

禁止结论（说了就算错）：

- 不得认定：FP-4024 可以通过 API 重试退避自动恢复

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`troubleshooting`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_troubleshooting`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-011`、`KB-TS-009`
- 操作：`query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.get_request`
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.list_payments`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不会改变已过期支付方式，也不会复活 failed Payment；应更新支付方式并创建新 Payment。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-07T12:00:00Z、`payment_id`=pay_bm_032 | `exactly_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_032、`as_of`=2026-08-07T12:00:00Z | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-07T12:00:00Z、`request_id`=req_bm_032_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-07T11:20:04.000Z` 支付 pay_bm_032 状态 failed，金额 10000 USD，失败码 FP-4024，已占用退款额度 0、当前可退 10000
- `2026-08-07T11:20:04.000Z` 支付 pay_bm_032 状态 failed，金额 10000 USD，失败码 FP-4024
- `2026-08-07T11:50:00.000Z` 请求 req_bm_032_01 在 2026 年 08 月 07 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4024，响应对象为 无

查到的实例事实：

- `get_payment` 支付 pay_bm_032 状态 failed，金额 10000 USD，失败码 FP-4024，已占用退款额度 0、当前可退 10000。
- `list_payments` 支付 pay_bm_032 状态 failed，金额 10000 USD，失败码 FP-4024。
- `get_request` 请求 req_bm_032_01 在 2026 年 08 月 07 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4024，响应对象为 无。

证据 ID：`doc:KB-BR-011#c003`、`doc:KB-TS-009#c004`、`sql:payment:pay_bm_032`、`runtime:req:req_bm_032_01`

## FP-BM-MS-0131

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-033-action_required_old_and_new`
- 快照时点 `as_of`：2026-08-08T12:00:00Z　接口版本：2026-01-15
- 标签：`payments`、`action_required_old_and_new`

### 开场白

> 客户那边反馈：同一类客户验证问题，在新旧客户端里一个显示失败，一个显示待操作。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 3 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认为什么两个 Payment 的状态不同，是否是数据不一致。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户的旧客户端与新客户端对同一类验证场景分别创建 Payment。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 8 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-01-15。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_033 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认支付所属环境，以及账户当前套餐和主地区。
2. （`before_knowledge`，取 `api_version`）部署里配置的 API 版本或版本请求头是什么？
3. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步需要查看这笔支付的状态变化。大概是什么时候，支付编号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不是数据不一致；差异由请求 API Version 决定，旧版 failed + FP-4023，新版 requires_action。 处理方式：客户端按各自版本实现处理，并按迁移指南升级。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0131-A1` 不是数据不一致；差异由请求 API Version 决定，旧版 failed + FP-4023，新版 requires_action。
- `FP-BM-MS-0131-A2` 客户端按各自版本实现处理，并按迁移指南升级。

禁止结论（说了就算错）：

- 不得认定：同一业务原因必须在所有版本中有完全相同状态字段

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-011`、`KB-API-018`
- 操作：`query_accounts.get_account`、`query_payments.list_payments`、`get_runtime_state.list_requests`
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-005`、`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-005`、`RULE-VERSION-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_payments.list_payments`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不是数据不一致；差异由请求 API Version 决定，旧版 failed + FP-4023，新版 requires_action。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_033、`as_of`=2026-08-08T12:00:00Z | `exactly_one` |
| `list_payments` | `sql` | `query_payments.list_payments` | `account_id`=acct_bm_033、`as_of`=2026-08-08T12:00:00Z | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_033、`as_of`=2026-08-08T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-08T11:20:04.000Z` 支付 pay_bm_033 状态 requires_action，金额 10000 USD
- `2026-08-08T11:49:59.000Z` 请求 req_bm_033_01 在 2026 年 08 月 08 日 11:49 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4023，响应对象为 pay_bm_033_old，请求参数 payment_id=pay_bm_033_old、representation=legacy_failed
- `2026-08-08T11:50:00.000Z` 支付 pay_bm_033_old 状态 failed，金额 10000 USD，失败码 FP-4023
- `2026-08-08T11:50:00.000Z` 请求 req_d0b8895175_000002 在 2026 年 08 月 08 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_033，请求参数 payment_id=pay_bm_033、representation=requires_action

查到的实例事实：

- `get_account` 账户 acct_bm_033 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-01-15。
- `list_payments` 支付 pay_bm_033 状态 requires_action，金额 10000 USD；支付 pay_bm_033_old 状态 failed，金额 10000 USD，失败码 FP-4023。
- `list_requests` 请求 req_bm_033_01 在 2026 年 08 月 08 日 11:49 UTC 以 POST 调用 /v1/payments，返回 HTTP 402、错误码 FP-4023，响应对象为 pay_bm_033_old，请求参数 payment_id=pay_bm_033_old、representation=legacy_failed；请求 req_d0b8895175_000002 在 2026 年 08 月 08 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 200，响应对象为 pay_bm_033，请求参数 payment_id=pay_bm_033、representation=requires_action。

证据 ID：`doc:KB-BR-011#c007`、`doc:KB-API-018#c004`、`sql:account:acct_bm_033`、`sql:payment:pay_bm_033`、`sql:payment:pay_bm_033_old`、`runtime:req:req_bm_033_01`、`runtime:req:req_d0b8895175_000002`

## FP-BM-MS-0135

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-034-refund_processing_payment`
- 快照时点 `as_of`：2026-08-09T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`refund_processing_payment`

### 开场白

> 线上同事发现：支付还在处理中，客服就发起了退款，系统没有接受。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认是否已创建 pending Refund，以及正确等待条件是什么。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付仍为 processing，这个账户为它创建那笔退款，那次请求返回 FP-4221。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 9 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_034，那笔支付的编号是 pay_bm_034，那笔退款的编号是 re_bm_034，那次请求的编号是 req_bm_034_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 这笔退款属于测试还是真实交易？相关账户是什么套餐和地区？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需要确认实际退款链路。大概是什么时候，退款或原支付的编号能提供吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 没有创建 Refund；必须等待 Payment succeeded 后再申请退款。 处理方式：查询 Payment 最终状态，仅在 succeeded 后发起 Refund。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0135-A1` 没有创建 Refund；必须等待 Payment succeeded 后再申请退款。
- `FP-BM-MS-0135-A2` 查询 Payment 最终状态，仅在 succeeded 后发起 Refund。

禁止结论（说了就算错）：

- 不得认定：processing 已代表扣款完成，可以先占用退款额度

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-012`、`KB-API-019`
- 操作：`query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.get_request`
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：没有创建 Refund；必须等待 Payment succeeded 后再申请退款。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-09T12:00:00Z、`payment_id`=pay_bm_034 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-09T12:00:00Z、`refund_id`=re_bm_034 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-09T12:00:00Z、`request_id`=req_bm_034_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-09T11:20:04.000Z` 支付 pay_bm_034 状态 processing，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-09T11:50:00.000Z` 请求 req_bm_034_01 在 2026 年 08 月 09 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 mode=standard、payment_id=pay_bm_034、refund_id=re_bm_034

查到的实例事实：

- `get_payment` 支付 pay_bm_034 状态 processing，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_refund` 在限定范围（as_of=2026-08-09T12:00:00Z、refund_id=re_bm_034、account_id=acct_bm_034、environment=production）内没有查到 get_refund 对应记录。
- `get_request` 请求 req_bm_034_01 在 2026 年 08 月 09 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 mode=standard、payment_id=pay_bm_034、refund_id=re_bm_034。

证据 ID：`doc:KB-BR-012#c004`、`doc:KB-API-019#c005`、`sql:payment:pay_bm_034`、`negative:sql:refund:4be8f746f3e07597566a`、`runtime:req:req_bm_034_01`

## FP-BM-MS-0139

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-035-starter_full_refund_only`
- 快照时点 `as_of`：2026-08-10T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`starter_full_refund_only`

### 开场白

> 客服转来一个问题：客服想给客户退一部分金额，但退款接口一直拒绝。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Payment 可退款为何请求仍失败。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Starter Account 这个账户对 succeeded 的那笔支付申请小于剩余金额的那笔退款，返回 FP-4031。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Starter，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 10 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_035，那笔支付的编号是 pay_bm_035，那笔退款的编号是 re_bm_035，那次请求的编号是 req_bm_035_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 这笔退款属于测试还是真实交易？相关账户是什么套餐和地区？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来要核对可退金额和退款状态。请提供时间范围及退款编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> Payment 状态合格，但 Starter 不支持部分退款；必须一次退还全部剩余可退金额。 处理方式：按剩余可退金额发起一次全额 Refund，或先合法升级套餐。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0139-A1` Payment 状态合格，但 Starter 不支持部分退款；必须一次退还全部剩余可退金额。
- `FP-BM-MS-0139-A2` 按剩余可退金额发起一次全额 Refund，或先合法升级套餐。

禁止结论（说了就算错）：

- 不得认定：只要 Payment succeeded，任何套餐都支持部分退款

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-012`、`KB-API-020`
- 操作：`query_accounts.get_account`、`query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.get_request`
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：Payment 状态合格，但 Starter 不支持部分退款；必须一次退还全部剩余可退金额。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_035、`as_of`=2026-08-10T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-10T12:00:00Z、`payment_id`=pay_bm_035 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-10T12:00:00Z、`refund_id`=re_bm_035 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-10T12:00:00Z、`request_id`=req_bm_035_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-10T11:20:04.000Z` 支付 pay_bm_035 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-10T11:50:00.000Z` 请求 req_bm_035_01 在 2026 年 08 月 10 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 403、错误码 FP-4031，响应对象为 无，请求参数 mode=standard、payment_id=pay_bm_035、refund_id=re_bm_035

查到的实例事实：

- `get_account` 账户 acct_bm_035 当时套餐为 Starter、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_payment` 支付 pay_bm_035 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_refund` 在限定范围（as_of=2026-08-10T12:00:00Z、refund_id=re_bm_035、account_id=acct_bm_035、environment=production）内没有查到 get_refund 对应记录。
- `get_request` 请求 req_bm_035_01 在 2026 年 08 月 10 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 403、错误码 FP-4031，响应对象为 无，请求参数 mode=standard、payment_id=pay_bm_035、refund_id=re_bm_035。

证据 ID：`doc:KB-BR-012#c003`、`doc:KB-API-020#c005`、`sql:account:acct_bm_035`、`sql:payment:pay_bm_035`、`negative:sql:refund:3adf5827423aebeee834`、`runtime:req:req_bm_035_01`

## FP-BM-MS-0143

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-036-growth_multiple_partial_refunds`
- 快照时点 `as_of`：2026-08-11T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`growth_multiple_partial_refunds`

### 开场白

> 我们排查时发现：同一笔支付已经退过一部分，现在第二次部分退款出现了额度问题。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认第二笔部分 Refund 是否允许，剩余可退金额是多少。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Growth Account 这个账户对 10,000 的那笔支付先成功退款 2,000，再申请 3,000。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 11 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_036，那笔支付的编号是 pay_bm_036，那笔退款的编号是 re_bm_036 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 退款发生在哪个环境？账户套餐和所属地区分别是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需要确认实际退款链路。大概是什么时候，退款或原支付的编号能提供吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 允许；第二笔后已占用 5,000，剩余可退金额为 5,000。 处理方式：每次创建前查询当前 pending+succeeded 占用与可退余额。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0143-A1` 允许；第二笔后已占用 5,000，剩余可退金额为 5,000。
- `FP-BM-MS-0143-A2` 每次创建前查询当前 pending+succeeded 占用与可退余额。

禁止结论（说了就算错）：

- 不得认定：部分退款只能发生一次

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_payments`
- 文档：`KB-BR-012`、`KB-API-021`
- 操作：`query_accounts.get_account`、`query_payments.get_payment`、`query_payments.get_refund`
- 规则：`RULE-IDEMP-001`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_payments.get_payment`、`query_payments.get_refund`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：允许；第二笔后已占用 5,000，剩余可退金额为 5,000。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_036、`as_of`=2026-08-11T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-11T12:00:00Z、`payment_id`=pay_bm_036 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-11T12:00:00Z、`refund_id`=re_bm_036 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-11T11:20:04.000Z` 支付 pay_bm_036 状态 succeeded，金额 10000 USD，已占用退款额度 5000、当前可退 5000
- `2026-08-11T11:50:00.000Z` 退款 re_bm_036 状态为 pending，金额 3000，关联支付为 pay_bm_036。

查到的实例事实：

- `get_account` 账户 acct_bm_036 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_payment` 支付 pay_bm_036 状态 succeeded，金额 10000 USD，已占用退款额度 5000、当前可退 5000。
- `get_refund` 退款 re_bm_036 状态为 pending，金额 3000，关联支付为 pay_bm_036。

证据 ID：`doc:KB-BR-012#c003`、`doc:KB-API-021#c006`、`sql:account:acct_bm_036`、`sql:payment:pay_bm_036`、`sql:refund:re_bm_036`

## FP-BM-MS-0147

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-037-pending_refund_reserves_amount`
- 快照时点 `as_of`：2026-08-12T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`pending_refund_reserves_amount`

### 开场白

> 客户那边反馈：一笔退款还没处理完，客服又发起退款时发现可退金额变少了。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认第二次请求能否通过。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 10,000 的那笔支付已有 6,000 pending 那笔退款，这个账户又申请 5,000。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 12 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_037，那笔支付的编号是 pay_bm_037，那笔退款的编号是 re_bm_037 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 这笔退款属于测试还是真实交易？相关账户是什么套餐和地区？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了查看退款前后的金额变化，请给出大概日期和原支付或退款号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；pending 已占用 6,000，只剩 4,000 可退。 处理方式：等待 pending 完成或失败后重新查询可退金额。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0147-A1` 不能；pending 已占用 6,000，只剩 4,000 可退。
- `FP-BM-MS-0147-A2` 等待 pending 完成或失败后重新查询可退金额。

禁止结论（说了就算错）：

- 不得认定：pending 尚未成功，所以不影响可退余额

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`
- 文档：`KB-BR-012`、`KB-API-019`
- 操作：`query_payments.get_payment`、`query_payments.get_refund`
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_refund`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；pending 已占用 6,000，只剩 4,000 可退。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-12T12:00:00Z、`payment_id`=pay_bm_037 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-12T12:00:00Z、`refund_id`=re_bm_037 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-12T11:50:00.000Z` 支付 pay_bm_037 状态 succeeded，金额 10000 USD，已占用退款额度 6000、当前可退 4000
- `2026-08-12T11:50:00.000Z` 退款 re_bm_037 状态为 pending，金额 6000，关联支付为 pay_bm_037。

查到的实例事实：

- `get_payment` 支付 pay_bm_037 状态 succeeded，金额 10000 USD，已占用退款额度 6000、当前可退 4000。
- `get_refund` 退款 re_bm_037 状态为 pending，金额 6000，关联支付为 pay_bm_037。

证据 ID：`doc:KB-BR-012#c003`、`doc:KB-API-019#c004`、`sql:payment:pay_bm_037`、`sql:refund:re_bm_037`

## FP-BM-MS-0151

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-038-failed_refund_releases_amount`
- 快照时点 `as_of`：2026-08-13T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`failed_refund_releases_amount`

### 开场白

> 客户那边反馈：之前的退款失败了，但客服不确定那部分金额还能不能重新退。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这 4,000 是否仍被占用。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付的 4,000 pending 那笔退款随后 failed；商户再次查询可退金额。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 13 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_038，那笔支付的编号是 pay_bm_038，那笔退款的编号是 re_bm_038 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 退款发生在哪个环境？账户套餐和所属地区分别是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需要确认实际退款链路。大概是什么时候，退款或原支付的编号能提供吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不再占用；failed Refund 释放额度，可退金额应相应增加。 处理方式：确认 Refund 终态后重新计算 succeeded+pending 占用。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0151-A1` 不再占用；failed Refund 释放额度，可退金额应相应增加。
- `FP-BM-MS-0151-A2` 确认 Refund 终态后重新计算 succeeded+pending 占用。

禁止结论（说了就算错）：

- 不得认定：Refund 一旦创建就永久占用额度

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`
- 文档：`KB-BR-012`、`KB-API-019`
- 操作：`query_payments.get_payment`、`query_payments.get_refund`
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_refund`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不再占用；failed Refund 释放额度，可退金额应相应增加。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-13T12:00:00Z、`payment_id`=pay_bm_038 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-13T12:00:00Z、`refund_id`=re_bm_038 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-13T11:20:05.000Z` 退款 re_bm_038 状态为 failed，金额 4000，关联支付为 pay_bm_038。
- `2026-08-13T11:50:00.000Z` 支付 pay_bm_038 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000

查到的实例事实：

- `get_payment` 支付 pay_bm_038 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_refund` 退款 re_bm_038 状态为 failed，金额 4000，关联支付为 pay_bm_038。

证据 ID：`doc:KB-BR-012#c004`、`doc:KB-API-019#c002`、`sql:payment:pay_bm_038`、`sql:refund:re_bm_038`

## FP-BM-MS-0155

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-039-refund_window_expired`
- 快照时点 `as_of`：2026-08-14T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`refund_window_expired`

### 开场白

> 我们排查时发现：客服在给一笔很久以前的支付退款时被拒绝了。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认有剩余金额是否足以使退款成功。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付在 181 天前 succeeded，当前仍有全部金额未退；这个账户创建那笔退款返回 FP-4222。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 14 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_039，那笔支付的编号是 pay_bm_039，那笔退款的编号是 re_bm_039，那次请求的编号是 req_bm_039_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 这笔退款属于测试还是真实交易？相关账户是什么套餐和地区？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来要核对可退金额和退款状态。请提供时间范围及退款编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不足；退款窗口已经超过 180 天，即使余额完整也不具备资格。 处理方式：核对 succeeded_at 与请求时间，不要重试过期 Refund。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0155-A1` 不足；退款窗口已经超过 180 天，即使余额完整也不具备资格。
- `FP-BM-MS-0155-A2` 核对 succeeded_at 与请求时间，不要重试过期 Refund。

禁止结论（说了就算错）：

- 不得认定：可退余额大于零就代表永远可退款

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-012`、`KB-API-020`
- 操作：`query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.get_request`
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不足；退款窗口已经超过 180 天，即使余额完整也不具备资格。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-14T12:00:00Z、`payment_id`=pay_bm_039 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-14T12:00:00Z、`refund_id`=re_bm_039 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-14T12:00:00Z、`request_id`=req_bm_039_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-14T11:20:04.000Z` 支付 pay_bm_039 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-14T11:50:00.000Z` 请求 req_bm_039_01 在 2026 年 08 月 14 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 422、错误码 FP-4222，响应对象为 无，请求参数 mode=standard、payment_id=pay_bm_039、refund_id=re_bm_039

查到的实例事实：

- `get_payment` 支付 pay_bm_039 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_refund` 在限定范围（as_of=2026-08-14T12:00:00Z、refund_id=re_bm_039、account_id=acct_bm_039、environment=production）内没有查到 get_refund 对应记录。
- `get_request` 请求 req_bm_039_01 在 2026 年 08 月 14 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 422、错误码 FP-4222，响应对象为 无，请求参数 mode=standard、payment_id=pay_bm_039、refund_id=re_bm_039。

证据 ID：`doc:KB-BR-012#c003`、`doc:KB-API-020#c005`、`sql:payment:pay_bm_039`、`negative:sql:refund:e7e8be654169995b12f5`、`runtime:req:req_bm_039_01`

## FP-BM-MS-0159

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-040-instant_refund_scale_na`
- 快照时点 `as_of`：2026-08-15T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`instant_refund_scale_na`

### 开场白

> 线上同事发现：我们给北美客户做快速退款，但结果没有按预期立刻完成。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认该请求是否具备 Instant Refund 资格。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | NA Scale Account 这个账户已开启 instant_refund，对 那笔支付申请 80,000 的那笔退款。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Scale，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 15 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_040，那笔支付的编号是 pay_bm_040，那笔退款的编号是 re_bm_040 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 这笔退款属于测试还是真实交易？相关账户是什么套餐和地区？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来要核对可退金额和退款状态。请提供时间范围及退款编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 具备；套餐、地区、Flag、金额和 Payment 状态均满足时可使用 Instant Refund。 处理方式：在调用前同时验证地区、Flag、金额和可退余额。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0159-A1` 具备；套餐、地区、Flag、金额和 Payment 状态均满足时可使用 Instant Refund。
- `FP-BM-MS-0159-A2` 在调用前同时验证地区、Flag、金额和可退余额。

禁止结论（说了就算错）：

- 不得认定：Instant Refund 只由 Scale 套餐单一条件决定

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_payments`
- 文档：`KB-BR-012`、`KB-API-021`
- 操作：`query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_payment`、`query_payments.get_refund`
- 规则：`RULE-IDEMP-001`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_payment`、`query_payments.get_refund`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：具备；套餐、地区、Flag、金额和 Payment 状态均满足时可使用 Instant Refund。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_040、`as_of`=2026-08-15T12:00:00Z | `exactly_one` |
| `get_feature_flags` | `sql` | `query_accounts.get_feature_flags` | `account_id`=acct_bm_040、`as_of`=2026-08-15T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-15T12:00:00Z、`payment_id`=pay_bm_040 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-15T12:00:00Z、`refund_id`=re_bm_040 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-15T11:20:04.000Z` 支付 pay_bm_040 状态 succeeded，金额 10000 USD，已占用退款额度 4000、当前可退 6000
- `2026-08-15T11:20:05.000Z` 退款 re_bm_040 状态为 succeeded，金额 4000，关联支付为 pay_bm_040。

查到的实例事实：

- `get_account` 账户 acct_bm_040 当时套餐为 Scale、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_feature_flags` 功能 instant_refund 的配置值为 True，实际生效值为 True，套餐抑制为 False。
- `get_payment` 支付 pay_bm_040 状态 succeeded，金额 10000 USD，已占用退款额度 4000、当前可退 6000。
- `get_refund` 退款 re_bm_040 状态为 succeeded，金额 4000，关联支付为 pay_bm_040。

证据 ID：`doc:KB-BR-012#c003`、`doc:KB-API-021#c006`、`sql:account:acct_bm_040`、`sql:feature_flag:acct_bm_040:production:instant_refund`、`sql:payment:pay_bm_040`、`sql:refund:re_bm_040`

## FP-BM-MS-0163

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-041-instant_refund_apac`
- 快照时点 `as_of`：2026-08-16T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`instant_refund_apac`

### 开场白

> 亚太地区的一笔退款勾选了快速到账，却一直无法提交。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认请求是否应因 Scale 身份而成功。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | APAC Scale Account 这个账户开启 Flag 后，对 那笔支付请求 50,000 Instant Refund。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Scale，主地区是 APAC。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 16 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_041，那笔支付的编号是 pay_bm_041，那笔退款的编号是 re_bm_041 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 退款发生在哪个环境？账户套餐和所属地区分别是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来要核对可退金额和退款状态。请提供时间范围及退款编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应；APAC 不在 Instant Refund 支持地区内。 处理方式：改用标准 Refund 流程，不要尝试修改 Account 主地区。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0163-A1` 不应；APAC 不在 Instant Refund 支持地区内。
- `FP-BM-MS-0163-A2` 改用标准 Refund 流程，不要尝试修改 Account 主地区。

禁止结论（说了就算错）：

- 不得认定：Scale 可以覆盖地区限制

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`query_accounts_sql`、`query_payments_sql`
- 工具：`search_business_rules`、`query_accounts`、`query_payments`
- 文档：`KB-BR-003`、`KB-BR-012`
- 操作：`query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_payment`、`query_payments.get_refund`
- 规则：`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`、`RULE-REGION-001`、`RULE-REGION-002`、`RULE-REGION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_business_rules`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_payment`、`query_payments.get_refund`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应；APAC 不在 Instant Refund 支持地区内。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_041、`as_of`=2026-08-16T12:00:00Z | `exactly_one` |
| `get_feature_flags` | `sql` | `query_accounts.get_feature_flags` | `account_id`=acct_bm_041、`as_of`=2026-08-16T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-16T12:00:00Z、`payment_id`=pay_bm_041 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-16T12:00:00Z、`refund_id`=re_bm_041 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-16T11:20:04.000Z` 支付 pay_bm_041 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000

查到的实例事实：

- `get_account` 账户 acct_bm_041 当时套餐为 Scale、主地区为 APAC，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_feature_flags` 功能 instant_refund 的配置值为 True，实际生效值为 True，套餐抑制为 False。
- `get_payment` 支付 pay_bm_041 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_refund` 在限定范围（as_of=2026-08-16T12:00:00Z、refund_id=re_bm_041、account_id=acct_bm_041、environment=production）内没有查到 get_refund 对应记录。

证据 ID：`doc:KB-BR-003#c003`、`doc:KB-BR-012#c007`、`sql:account:acct_bm_041`、`sql:feature_flag:acct_bm_041:production:instant_refund`、`sql:payment:pay_bm_041`、`negative:sql:refund:285196e61de8e15093b1`

## FP-BM-MS-0167

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-042-instant_refund_flag_and_amount`
- 快照时点 `as_of`：2026-08-17T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`instant_refund_flag_and_amount`

### 开场白

> 线上同事发现：快速退款偶尔能用、偶尔被拒绝，我们怀疑和账户配置或金额有关。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认两次尝试分别为什么不具备资格。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | EU Scale Account 这个账户的 Flag 起初关闭，随后开启但请求 120,000 的 Instant Refund。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Scale，主地区是 EU。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 17 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_042，那笔支付的编号是 pay_bm_042，那笔退款的编号是 re_bm_042 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 退款发生在哪个环境？账户套餐和所属地区分别是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了查看退款前后的金额变化，请给出大概日期和原支付或退款号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 第一次缺少 Flag；第二次金额超过 100,000。两次都不能使用 Instant Refund。 处理方式：开启 Flag后把金额控制在上限内，或改用标准 Refund。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0167-A1` 第一次缺少 Flag；第二次金额超过 100,000。两次都不能使用 Instant Refund。
- `FP-BM-MS-0167-A2` 开启 Flag后把金额控制在上限内，或改用标准 Refund。

禁止结论（说了就算错）：

- 不得认定：只要后续打开 Flag，之前和超额请求都会自动合法

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-004`、`KB-BR-012`
- 操作：`query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.list_requests`
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-PLAN-005`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_business_rules`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_payment`、`query_payments.get_refund`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：第一次缺少 Flag；第二次金额超过 100,000。两次都不能使用 Instant Refund。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_042、`as_of`=2026-08-17T12:00:00Z | `exactly_one` |
| `get_feature_flags` | `sql` | `query_accounts.get_feature_flags` | `account_id`=acct_bm_042、`as_of`=2026-08-17T12:00:00Z | `exactly_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-17T12:00:00Z、`payment_id`=pay_bm_042 | `exactly_one` |
| `get_refund` | `sql` | `query_payments.get_refund` | `as_of`=2026-08-17T12:00:00Z、`refund_id`=re_bm_042 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_042、`as_of`=2026-08-17T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-17T11:20:04.000Z` 支付 pay_bm_042 状态 succeeded，金额 200000 USD，已占用退款额度 0、当前可退 200000
- `2026-08-17T11:49:59.000Z` 请求 req_bm_042_01 在 2026 年 08 月 17 日 11:49 UTC 以 POST 调用 /v1/refunds，返回 HTTP 403、错误码 FP-4031，响应对象为 无，请求参数 amount=50000、instant_refund_flag=False、mode=instant
- `2026-08-17T11:50:00.000Z` 请求 req_39d71c463c_000002 在 2026 年 08 月 17 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 403、错误码 FP-4031，响应对象为 无，请求参数 amount=120000、instant_refund_flag=True、mode=instant

查到的实例事实：

- `get_account` 账户 acct_bm_042 当时套餐为 Scale、主地区为 EU，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_feature_flags` 功能 instant_refund 的配置值为 True，实际生效值为 True，套餐抑制为 False。
- `get_payment` 支付 pay_bm_042 状态 succeeded，金额 200000 USD，已占用退款额度 0、当前可退 200000。
- `get_refund` 在限定范围（as_of=2026-08-17T12:00:00Z、refund_id=re_bm_042、account_id=acct_bm_042、environment=production）内没有查到 get_refund 对应记录。
- `list_requests` 请求 req_bm_042_01 在 2026 年 08 月 17 日 11:49 UTC 以 POST 调用 /v1/refunds，返回 HTTP 403、错误码 FP-4031，响应对象为 无，请求参数 amount=50000、instant_refund_flag=False、mode=instant；请求 req_39d71c463c_000002 在 2026 年 08 月 17 日 11:50 UTC 以 POST 调用 /v1/refunds，返回 HTTP 403、错误码 FP-4031，响应对象为 无，请求参数 amount=120000、instant_refund_flag=True、mode=instant。

证据 ID：`doc:KB-BR-004#c006`、`doc:KB-BR-012#c004`、`sql:account:acct_bm_042`、`sql:feature_flag:acct_bm_042:production:instant_refund`、`sql:payment:pay_bm_042`、`negative:sql:refund:d9e7cd17a04cfaac8f68`、`runtime:req:req_bm_042_01`、`runtime:req:req_39d71c463c_000002`

## FP-BM-MS-0171

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-043-starter_subscription_blocked`
- 快照时点 `as_of`：2026-08-18T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`starter_subscription_blocked`

### 开场白

> 客户那边反馈：普通支付没问题，但一创建订阅就提示当前账户不能使用。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Customer active 是否足以使创建成功。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Starter Account 这个账户使用 active 这位客户创建 这份订阅，请求参数都合法。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Starter，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 18 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_043，这位客户的编号是 cus_bm_043，这份订阅的编号是 sub_bm_043，那次请求的编号是 req_bm_043_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 订阅来自哪个环境和地区？账户当前使用什么套餐？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要查看订阅当时的状态。大概何时发生，能提供订阅编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不足；套餐不支持 Subscription，应返回 FP-4031。 处理方式：升级到 Growth/Scale并确认 subscriptions Flag 后重新创建。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0171-A1` 不足；套餐不支持 Subscription，应返回 FP-4031。
- `FP-BM-MS-0171-A2` 升级到 Growth/Scale并确认 subscriptions Flag 后重新创建。

禁止结论（说了就算错）：

- 不得认定：参数合法就能绕过套餐权限

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-013`、`KB-API-024`
- 操作：`query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_customer`、`query_payments.get_subscription`、`get_runtime_state.get_request`
- 规则：`RULE-CUSTOMER-004`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-PLAN-001`、`RULE-PLAN-004`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_accounts.get_feature_flags`、`query_payments.get_customer`、`query_payments.get_subscription`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不足；套餐不支持 Subscription，应返回 FP-4031。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_043、`as_of`=2026-08-18T12:00:00Z | `exactly_one` |
| `get_feature_flags` | `sql` | `query_accounts.get_feature_flags` | `account_id`=acct_bm_043、`as_of`=2026-08-18T12:00:00Z | `exactly_one` |
| `get_customer` | `sql` | `query_payments.get_customer` | `as_of`=2026-08-18T12:00:00Z、`customer_id`=cus_bm_043 | `exactly_one` |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-18T12:00:00Z、`subscription_id`=sub_bm_043 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-18T12:00:00Z、`request_id`=req_bm_043_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-18T11:50:00.000Z` 请求 req_bm_043_01 在 2026 年 08 月 18 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 403、错误码 FP-4031，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_043 当时套餐为 Starter、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_feature_flags` 功能 subscriptions 的配置值为 True，实际生效值为 False，套餐抑制为 True。
- `get_customer` 客户 cus_bm_043 状态为 active，Email 为 cus_bm_043@example.test，所属账户为 acct_bm_043、环境为 production。
- `get_subscription` 在限定范围（as_of=2026-08-18T12:00:00Z、subscription_id=sub_bm_043、account_id=acct_bm_043、environment=production）内没有查到 get_subscription 对应记录。
- `get_request` 请求 req_bm_043_01 在 2026 年 08 月 18 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 403、错误码 FP-4031，响应对象为 无。

证据 ID：`doc:KB-BR-013#c005`、`doc:KB-API-024#c005`、`sql:account:acct_bm_043`、`sql:feature_flag:acct_bm_043:production:subscriptions`、`sql:customer:cus_bm_043`、`negative:sql:subscription:cca729e5a3c87eed3745`、`runtime:req:req_bm_043_01`

## FP-BM-MS-0175

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-044-subscription_trial_bounds`
- 快照时点 `as_of`：2026-08-19T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_trial_bounds`

### 开场白

> 创建带试用期的订阅时，某些天数可以，某些天数直接报参数错误。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认两种操作是否允许。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户先尝试以 trial_days=31 创建 这份订阅，之后又想给已 active 的 Subscription 补加试用期。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 19 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_044，这份订阅的编号是 sub_bm_044 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 订阅来自哪个环境和地区？账户当前使用什么套餐？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要查看订阅当时的状态。大概何时发生，能提供订阅编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 都不允许；31 天越界，且试用期不能在创建后追加。 处理方式：创建时使用 1～30 天范围；已创建资源需按现有周期处理。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0175-A1` 都不允许；31 天越界，且试用期不能在创建后追加。
- `FP-BM-MS-0175-A2` 创建时使用 1～30 天范围；已创建资源需按现有周期处理。

禁止结论（说了就算错）：

- 不得认定：试用期可在任意时间延长

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-013`、`KB-API-024`
- 操作：`query_payments.get_subscription`、`get_runtime_state.list_requests`
- 规则：`RULE-CUSTOMER-004`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-PLAN-001`、`RULE-PLAN-004`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_subscription`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：都不允许；31 天越界，且试用期不能在创建后追加。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-19T12:00:00Z、`subscription_id`=sub_bm_044 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_044、`as_of`=2026-08-19T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-19T11:20:06.000Z` 订阅 sub_bm_044 状态为 active，客户为 cus_bm_044，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 18 日 11:20 UTC。
- `2026-08-19T11:49:59.000Z` 请求 req_bm_044_01 在 2026 年 08 月 19 日 11:49 UTC 以 POST 调用 /v1/subscriptions，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 trial_days=31
- `2026-08-19T11:50:00.000Z` 请求 req_8a1a242e28_000002 在 2026 年 08 月 19 日 11:50 UTC 以 PATCH 调用 /v1/subscriptions/sub_bm_044，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 operation=append_trial_after_creation、trial_days=14

查到的实例事实：

- `get_subscription` 订阅 sub_bm_044 状态为 active，客户为 cus_bm_044，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 18 日 11:20 UTC。
- `list_requests` 请求 req_bm_044_01 在 2026 年 08 月 19 日 11:49 UTC 以 POST 调用 /v1/subscriptions，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 trial_days=31；请求 req_8a1a242e28_000002 在 2026 年 08 月 19 日 11:50 UTC 以 PATCH 调用 /v1/subscriptions/sub_bm_044，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 operation=append_trial_after_creation、trial_days=14。

证据 ID：`doc:KB-BR-013#c004`、`doc:KB-API-024#c004`、`sql:subscription:sub_bm_044`、`runtime:req:req_bm_044_01`、`runtime:req:req_8a1a242e28_000002`

## FP-BM-MS-0179

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-045-subscription_cancel_period_end`
- 快照时点 `as_of`：2026-08-20T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_cancel_period_end`

### 开场白

> 线上同事发现：客户选择到期取消订阅，但我们担心系统会立即停掉服务。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认它应立即 canceled 还是继续 active。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这份订阅在周期中收到默认取消请求，当前时间尚未到 period_end。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 20 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_045，这份订阅的编号是 sub_bm_045 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 订阅来自哪个环境和地区？账户当前使用什么套餐？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对订阅与账单关系，请补充时间范围和相关对象编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应继续 active 到周期末，届时再进入 canceled。 处理方式：向用户展示 scheduled cancellation 与实际生效时间。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0179-A1` 应继续 active 到周期末，届时再进入 canceled。
- `FP-BM-MS-0179-A2` 向用户展示 scheduled cancellation 与实际生效时间。

禁止结论（说了就算错）：

- 不得认定：所有取消请求都立即终止服务

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`
- 文档：`KB-BR-013`、`KB-API-025`
- 操作：`query_payments.get_subscription`
- 规则：`RULE-CUSTOMER-003`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_subscription`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应继续 active 到周期末，届时再进入 canceled。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-20T12:00:00Z、`subscription_id`=sub_bm_045 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-20T11:20:06.000Z` 订阅 sub_bm_045 状态为 active，客户为 cus_bm_045，币种为 USD，周期末取消标记为 True，当前周期结束于 2026 年 09 月 19 日 11:20 UTC。

查到的实例事实：

- `get_subscription` 订阅 sub_bm_045 状态为 active，客户为 cus_bm_045，币种为 USD，周期末取消标记为 True，当前周期结束于 2026 年 09 月 19 日 11:20 UTC。

证据 ID：`doc:KB-BR-013#c006`、`doc:KB-API-025#c004`、`sql:subscription:sub_bm_045`

## FP-BM-MS-0183

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-046-subscription_cancel_immediately`
- 快照时点 `as_of`：2026-08-21T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_cancel_immediately`

### 开场白

> 客服执行立即取消后，客户仍在问这一期是否还会继续计费。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认取消与恢复请求应如何处理。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户对 active 的 这份订阅发送 immediate=true 取消，随后尝试恢复。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 21 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_046，这份订阅的编号是 sub_bm_046 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 请补充订阅所属环境、账户套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对订阅与账单关系，请补充时间范围和相关对象编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> Subscription 立即 canceled，且不能恢复；需要继续订阅必须创建新 Subscription。 处理方式：创建新的 Subscription，不要修改终态资源。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0183-A1` Subscription 立即 canceled，且不能恢复；需要继续订阅必须创建新 Subscription。
- `FP-BM-MS-0183-A2` 创建新的 Subscription，不要修改终态资源。

禁止结论（说了就算错）：

- 不得认定：canceled Subscription 可以切回 active

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-013`、`KB-API-025`
- 操作：`query_payments.get_subscription`、`get_runtime_state.list_requests`
- 规则：`RULE-CUSTOMER-003`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_subscription`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：Subscription 立即 canceled，且不能恢复；需要继续订阅必须创建新 Subscription。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-21T12:00:00Z、`subscription_id`=sub_bm_046 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_046、`as_of`=2026-08-21T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-21T11:20:06.000Z` 订阅 sub_bm_046 状态为 canceled，客户为 cus_bm_046，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 20 日 11:20 UTC。
- `2026-08-21T11:49:59.000Z` 请求 req_bm_046_01 在 2026 年 08 月 21 日 11:49 UTC 以 POST 调用 /v1/subscriptions/sub_bm_046/cancel，返回 HTTP 200，响应对象为 sub_bm_046，请求参数 immediate=True
- `2026-08-21T11:50:00.000Z` 请求 req_0a756ce509_000002 在 2026 年 08 月 21 日 11:50 UTC 以 PATCH 调用 /v1/subscriptions/sub_bm_046，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 operation=restore_canceled_subscription、status=active

查到的实例事实：

- `get_subscription` 订阅 sub_bm_046 状态为 canceled，客户为 cus_bm_046，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 20 日 11:20 UTC。
- `list_requests` 请求 req_bm_046_01 在 2026 年 08 月 21 日 11:49 UTC 以 POST 调用 /v1/subscriptions/sub_bm_046/cancel，返回 HTTP 200，响应对象为 sub_bm_046，请求参数 immediate=True；请求 req_0a756ce509_000002 在 2026 年 08 月 21 日 11:50 UTC 以 PATCH 调用 /v1/subscriptions/sub_bm_046，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 operation=restore_canceled_subscription、status=active。

证据 ID：`doc:KB-BR-013#c006`、`doc:KB-API-025#c004`、`sql:subscription:sub_bm_046`、`runtime:req:req_bm_046_01`、`runtime:req:req_0a756ce509_000002`

## FP-BM-MS-0187

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-047-subscription_immutable_identity`
- 快照时点 `as_of`：2026-08-22T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_immutable_identity`

### 开场白

> 我们排查时发现：业务想把现有订阅转给另一个客户，同时顺便换结算币种。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认能否直接更新这两个字段。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这份订阅已绑定 这位客户和 USD，这个账户尝试改成另一个 Customer 与 CAD。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 22 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_047，这位客户的编号是 cus_bm_047，这份订阅的编号是 sub_bm_047，那次请求的编号是 req_bm_047_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 请补充订阅所属环境、账户套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了核对订阅与账单关系，请补充时间范围和相关对象编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；Customer 与币种是不可变身份字段。 处理方式：按取消规则处理原 Subscription，并为新 Customer/币种创建新资源。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0187-A1` 不能；Customer 与币种是不可变身份字段。
- `FP-BM-MS-0187-A2` 按取消规则处理原 Subscription，并为新 Customer/币种创建新资源。

禁止结论（说了就算错）：

- 不得认定：active Subscription 的所有字段都可更新

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-013`、`KB-API-023`
- 操作：`query_payments.get_customer`、`query_payments.get_subscription`、`get_runtime_state.get_request`
- 规则：`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_customer`、`query_payments.get_subscription`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；Customer 与币种是不可变身份字段。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_customer` | `sql` | `query_payments.get_customer` | `as_of`=2026-08-22T12:00:00Z、`customer_id`=cus_bm_047 | `exactly_one` |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-22T12:00:00Z、`subscription_id`=sub_bm_047 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-22T12:00:00Z、`request_id`=req_bm_047_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-22T11:20:06.000Z` 订阅 sub_bm_047 状态为 active，客户为 cus_bm_047，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 21 日 11:20 UTC。
- `2026-08-22T11:50:00.000Z` 请求 req_bm_047_01 在 2026 年 08 月 22 日 11:50 UTC 以 PATCH 调用 /v1/subscriptions/sub_bm_047，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 currency=CAD、customer_id=cus_bm_047_other

查到的实例事实：

- `get_customer` 客户 cus_bm_047 状态为 active，Email 为 cus_bm_047@example.test，所属账户为 acct_bm_047、环境为 production。
- `get_subscription` 订阅 sub_bm_047 状态为 active，客户为 cus_bm_047，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 21 日 11:20 UTC。
- `get_request` 请求 req_bm_047_01 在 2026 年 08 月 22 日 11:50 UTC 以 PATCH 调用 /v1/subscriptions/sub_bm_047，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 currency=CAD、customer_id=cus_bm_047_other。

证据 ID：`doc:KB-BR-013#c002`、`doc:KB-API-023#c006`、`sql:customer:cus_bm_047`、`sql:subscription:sub_bm_047`、`runtime:req:req_bm_047_01`

## FP-BM-MS-0191

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-048-invoice_retry_day1_success`
- 快照时点 `as_of`：2026-08-23T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`invoice_retry_day1_success`

### 开场白

> 订阅扣款第一次失败后很快恢复了，我们想确认账单是否还会继续重试。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Invoice 与 Subscription 最终应是什么状态。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那张账单首次 Payment 失败使 这份订阅past_due，第 1 天新 那笔支付成功。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 23 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_048，这份订阅的编号是 sub_bm_048，那张账单的编号是 in_bm_048，那笔支付的编号是 pay_bm_048 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 这张账单属于测试还是真实业务？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需要核对实际扣款记录。请提供日期范围和账单编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> Invoice 应为 paid，Subscription 应恢复 active；首次 failed Payment 保持终态。 处理方式：停止后续重试，并保留两次 Payment 的时间线。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0191-A1` Invoice 应为 paid，Subscription 应恢复 active；首次 failed Payment 保持终态。
- `FP-BM-MS-0191-A2` 停止后续重试，并保留两次 Payment 的时间线。

禁止结论（说了就算错）：

- 不得认定：重试成功后仍要执行第 3、7 天重试

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`
- 文档：`KB-BR-014`、`KB-API-026`
- 操作：`query_payments.get_payment`、`query_payments.get_subscription`、`query_payments.get_invoice_timeline`
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-INVOICE-007`、`RULE-INVOICE-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_subscription`、`query_payments.get_invoice_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：Invoice 应为 paid，Subscription 应恢复 active；首次 failed Payment 保持终态。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-23T12:00:00Z、`payment_id`=pay_bm_048 | `exactly_one` |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-23T12:00:00Z、`subscription_id`=sub_bm_048 | `exactly_one` |
| `get_invoice_timeline` | `sql` | `query_payments.get_invoice_timeline` | `as_of`=2026-08-23T12:00:00Z、`invoice_id`=in_bm_048 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-23T11:20:06.000Z` 订阅 sub_bm_048 状态为 active，客户为 cus_bm_048，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 22 日 11:20 UTC。
- `2026-08-23T11:50:00.000Z` 支付 pay_bm_048 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000
- `2026-08-23T11:50:00.000Z` 账单第 0 次扣款 failed
- `2026-08-24T11:50:00.000Z` 账单第 1 次扣款 succeeded

查到的实例事实：

- `get_payment` 支付 pay_bm_048 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000。
- `get_subscription` 订阅 sub_bm_048 状态为 active，客户为 cus_bm_048，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 22 日 11:20 UTC。
- `get_invoice_timeline` 账单 in_bm_048 当前状态为 paid，应付 2500、已付 2500；第 0 次在 2026 年 08 月 23 日 11:50 UTC failed；第 1 次在 2026 年 08 月 24 日 11:50 UTC succeeded。

证据 ID：`doc:KB-BR-014#c004`、`doc:KB-API-026#c005`、`sql:payment:pay_bm_048`、`sql:subscription:sub_bm_048`、`sql:invoice:in_bm_048`、`sql:invoice_attempt:in_bm_048:0`、`sql:invoice_attempt:in_bm_048:1`

## FP-BM-MS-0195

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-049-invoice_retry_day3_success`
- 快照时点 `as_of`：2026-08-24T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`invoice_retry_day3_success`

### 开场白

> 线上同事发现：订阅账单连续失败了几次，后来客户补足余额，不确定系统接下来怎么处理。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认应该存在几笔 Payment，是否继续第 7 天重试。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那张账单首次与第 1 天 Payment 失败，第 3 天 Payment 成功。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 24 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_049，这份订阅的编号是 sub_bm_049，那张账单的编号是 in_bm_049，那笔支付的编号是 pay_bm_049 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 这张账单属于测试还是真实业务？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了查看账单时间线，请提供大概发生时间和账单或订阅编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应有三笔不同 Payment；第 3 天成功后不再执行第 7 天重试。 处理方式：保留三笔关联记录并取消剩余调度。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0195-A1` 应有三笔不同 Payment；第 3 天成功后不再执行第 7 天重试。
- `FP-BM-MS-0195-A2` 保留三笔关联记录并取消剩余调度。

禁止结论（说了就算错）：

- 不得认定：重试应复用第一笔 failed Payment ID

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`
- 文档：`KB-BR-014`、`KB-API-027`
- 操作：`query_payments.get_payment`、`query_payments.get_subscription`、`query_payments.get_invoice_timeline`
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-INVOICE-007`、`RULE-INVOICE-008`、`RULE-PAY-002`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_subscription`、`query_payments.get_invoice_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应有三笔不同 Payment；第 3 天成功后不再执行第 7 天重试。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-24T12:00:00Z、`payment_id`=pay_bm_049 | `exactly_one` |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-24T12:00:00Z、`subscription_id`=sub_bm_049 | `exactly_one` |
| `get_invoice_timeline` | `sql` | `query_payments.get_invoice_timeline` | `as_of`=2026-08-24T12:00:00Z、`invoice_id`=in_bm_049 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-24T11:20:06.000Z` 订阅 sub_bm_049 状态为 active，客户为 None，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 23 日 11:20 UTC。
- `2026-08-24T11:50:00.000Z` 支付 pay_bm_049 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000
- `2026-08-24T11:50:00.000Z` 账单第 0 次扣款 failed
- `2026-08-25T11:50:00.000Z` 账单第 1 次扣款 failed
- `2026-08-27T11:50:00.000Z` 账单第 2 次扣款 succeeded

查到的实例事实：

- `get_payment` 支付 pay_bm_049 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000。
- `get_subscription` 订阅 sub_bm_049 状态为 active，客户为 None，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 23 日 11:20 UTC。
- `get_invoice_timeline` 账单 in_bm_049 当前状态为 paid，应付 2500、已付 2500；第 0 次在 2026 年 08 月 24 日 11:50 UTC failed；第 1 次在 2026 年 08 月 25 日 11:50 UTC failed；第 2 次在 2026 年 08 月 27 日 11:50 UTC succeeded。

证据 ID：`doc:KB-BR-014#c007`、`doc:KB-API-027#c004`、`sql:payment:pay_bm_049`、`sql:subscription:sub_bm_049`、`sql:invoice:in_bm_049`、`sql:invoice_attempt:in_bm_049:0`、`sql:invoice_attempt:in_bm_049:1`、`sql:invoice_attempt:in_bm_049:2`

## FP-BM-MS-0199

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-050-invoice_retries_exhausted`
- 快照时点 `as_of`：2026-08-25T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`invoice_retries_exhausted`

### 开场白

> 我们排查时发现：一张订阅账单多次扣款失败后就不再尝试了，订阅状态也变了。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这个状态是否符合规则。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那张账单的四次 Payment 全部 failed，这份订阅仍显示 past_due。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 25 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_050，这份订阅的编号是 sub_bm_050，那张账单的编号是 in_bm_050，那笔支付的编号是 pay_bm_050 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 这张账单属于测试还是真实业务？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了查看账单时间线，请提供大概发生时间和账单或订阅编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不符合；重试耗尽后 Invoice 应为 uncollectible，Subscription 应为 canceled。 处理方式：执行终态投影并停止继续扣费。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0199-A1` 不符合；重试耗尽后 Invoice 应为 uncollectible，Subscription 应为 canceled。
- `FP-BM-MS-0199-A2` 执行终态投影并停止继续扣费。

禁止结论（说了就算错）：

- 不得认定：重试耗尽后 Subscription 会无限保持 past_due

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`
- 文档：`KB-BR-014`、`KB-API-027`
- 操作：`query_payments.get_payment`、`query_payments.get_subscription`、`query_payments.get_invoice_timeline`
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-INVOICE-007`、`RULE-INVOICE-008`、`RULE-PAY-002`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_payments.get_subscription`、`query_payments.get_invoice_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不符合；重试耗尽后 Invoice 应为 uncollectible，Subscription 应为 canceled。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-25T12:00:00Z、`payment_id`=pay_bm_050 | `exactly_one` |
| `get_subscription` | `sql` | `query_payments.get_subscription` | `as_of`=2026-08-25T12:00:00Z、`subscription_id`=sub_bm_050 | `exactly_one` |
| `get_invoice_timeline` | `sql` | `query_payments.get_invoice_timeline` | `as_of`=2026-08-25T12:00:00Z、`invoice_id`=in_bm_050 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-25T11:20:06.000Z` 订阅 sub_bm_050 状态为 canceled，客户为 None，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 24 日 11:20 UTC。
- `2026-08-25T11:50:00.000Z` 支付 pay_bm_050 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000
- `2026-08-25T11:50:00.000Z` 账单第 0 次扣款 failed
- `2026-08-26T11:50:00.000Z` 账单第 1 次扣款 failed
- `2026-08-28T11:50:00.000Z` 账单第 2 次扣款 failed
- `2026-09-01T11:50:00.000Z` 账单第 3 次扣款 failed

查到的实例事实：

- `get_payment` 支付 pay_bm_050 状态 failed，金额 10000 USD，失败码 FP-4021，已占用退款额度 0、当前可退 10000。
- `get_subscription` 订阅 sub_bm_050 状态为 canceled，客户为 None，币种为 USD，周期末取消标记为 False，当前周期结束于 2026 年 09 月 24 日 11:20 UTC。
- `get_invoice_timeline` 账单 in_bm_050 当前状态为 uncollectible，应付 2500、已付 0；第 0 次在 2026 年 08 月 25 日 11:50 UTC failed；第 1 次在 2026 年 08 月 26 日 11:50 UTC failed；第 2 次在 2026 年 08 月 28 日 11:50 UTC failed；第 3 次在 2026 年 09 月 01 日 11:50 UTC failed。

证据 ID：`doc:KB-BR-014#c004`、`doc:KB-API-027#c004`、`sql:payment:pay_bm_050`、`sql:subscription:sub_bm_050`、`sql:invoice:in_bm_050`、`sql:invoice_attempt:in_bm_050:0`、`sql:invoice_attempt:in_bm_050:1`、`sql:invoice_attempt:in_bm_050:2`、`sql:invoice_attempt:in_bm_050:3`

## FP-BM-MS-0203

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-051-paid_invoice_cannot_void`
- 快照时点 `as_of`：2026-08-26T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`paid_invoice_cannot_void`

### 开场白

> 线上同事发现：客服想作废一张账单，但系统提示它当前不能作废。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Invoice 是否应变成 void。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那张账单已 paid，这个账户为纠正账单说明而调用 void。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 26 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_051，那张账单的编号是 in_bm_051，那次请求的编号是 req_bm_051_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 账单来自哪个环境？对应账户的套餐和地区能确认吗？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要查看账单状态变化，大概是什么时候，相关账单或订阅号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应；paid Invoice 不可 void，状态保持 paid。 处理方式：保留 paid 账单，使用业务允许的后续流程处理说明。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0203-A1` 不应；paid Invoice 不可 void，状态保持 paid。
- `FP-BM-MS-0203-A2` 保留 paid 账单，使用业务允许的后续流程处理说明。

禁止结论（说了就算错）：

- 不得认定：void 是可以覆盖任何 Invoice 状态的管理操作

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-014`、`KB-API-026`
- 操作：`query_payments.get_invoice_timeline`、`get_runtime_state.get_request`
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-INVOICE-007`、`RULE-INVOICE-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_invoice_timeline`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应；paid Invoice 不可 void，状态保持 paid。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_invoice_timeline` | `sql` | `query_payments.get_invoice_timeline` | `as_of`=2026-08-26T12:00:00Z、`invoice_id`=in_bm_051 | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-26T12:00:00Z、`request_id`=req_bm_051_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-26T11:50:00.000Z` 请求 req_bm_051_01 在 2026 年 08 月 26 日 11:50 UTC 以 POST 调用 /v1/invoices/in_bm_051/void，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 invoice_id=in_bm_051

查到的实例事实：

- `get_invoice_timeline` 账单 in_bm_051 当前状态为 paid，应付 2500、已付 2500；没有扣款尝试。
- `get_request` 请求 req_bm_051_01 在 2026 年 08 月 26 日 11:50 UTC 以 POST 调用 /v1/invoices/in_bm_051/void，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 invoice_id=in_bm_051。

证据 ID：`doc:KB-BR-014#c007`、`doc:KB-API-026#c004`、`sql:invoice:in_bm_051`、`runtime:req:req_bm_051_01`

## FP-BM-MS-0207

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-052-open_invoice_can_void`
- 快照时点 `as_of`：2026-08-01T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`open_invoice_can_void`

### 开场白

> 客户不再需要一张尚未支付的账单，客服想确认能否直接作废。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认void 是否允许，之后还能否继续扣费。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那张账单已 open 但尚未支付，这个账户决定作废它。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 1 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_052，那张账单的编号是 in_bm_052 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 这张账单属于测试还是真实业务？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了查看账单时间线，请提供大概发生时间和账单或订阅编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 允许进入 void；void 是终态，不应继续为该 Invoice 扣费。 处理方式：取消相关待执行扣费任务，并保留状态时间线。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0207-A1` 允许进入 void；void 是终态，不应继续为该 Invoice 扣费。
- `FP-BM-MS-0207-A2` 取消相关待执行扣费任务，并保留状态时间线。

禁止结论（说了就算错）：

- 不得认定：只有 draft Invoice 才能 void

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-014`、`KB-API-026`
- 操作：`query_payments.get_invoice_timeline`、`get_runtime_state.list_requests`
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-INVOICE-007`、`RULE-INVOICE-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_invoice_timeline`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：允许进入 void；void 是终态，不应继续为该 Invoice 扣费。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_invoice_timeline` | `sql` | `query_payments.get_invoice_timeline` | `as_of`=2026-08-01T12:00:00Z、`invoice_id`=in_bm_052 | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_052、`as_of`=2026-08-01T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-01T11:50:00.000Z` 请求 req_bm_052_01 在 2026 年 08 月 01 日 11:50 UTC 以 POST 调用 /v1/invoices/in_bm_052/void，返回 HTTP 200，响应对象为 无，请求参数 invoice_id=in_bm_052

查到的实例事实：

- `get_invoice_timeline` 账单 in_bm_052 当前状态为 void，应付 2500、已付 0；没有扣款尝试。
- `list_requests` 请求 req_bm_052_01 在 2026 年 08 月 01 日 11:50 UTC 以 POST 调用 /v1/invoices/in_bm_052/void，返回 HTTP 200，响应对象为 无，请求参数 invoice_id=in_bm_052。

证据 ID：`doc:KB-BR-014#c006`、`doc:KB-API-026#c004`、`sql:invoice:in_bm_052`、`runtime:req:req_bm_052_01`

## FP-BM-MS-0211

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-053-starter_endpoint_limit`
- 快照时点 `as_of`：2026-08-02T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`starter_endpoint_limit`

### 开场白

> 我们排查时发现：我们给账户新增回调地址时突然提示数量已到上限。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认第三个 Endpoint 是否应创建。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Starter Account 这个账户已有两个 enabled Endpoint，又尝试创建 这个回调地址。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Starter，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 2 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_053，那次请求的编号是 req_bm_053_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认事件所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需查看回调实际尝试记录。大概何时发生，能提供事件或投递编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应；Starter 上限为 2，应返回 FP-4031。 处理方式：删除或禁用并不会自动改变上限语义；需要按产品操作减少配置或升级套餐。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0211-A1` 不应；Starter 上限为 2，应返回 FP-4031。
- `FP-BM-MS-0211-A2` 删除或禁用并不会自动改变上限语义；需要按产品操作减少配置或升级套餐。

禁止结论（说了就算错）：

- 不得认定：Endpoint 上限只影响投递，不影响创建

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-029`
- 操作：`query_accounts.get_account`、`query_webhooks.list_endpoints`、`get_runtime_state.get_request`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_webhooks.list_endpoints`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应；Starter 上限为 2，应返回 FP-4031。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_053、`as_of`=2026-08-02T12:00:00Z | `exactly_one` |
| `list_endpoints` | `sql` | `query_webhooks.list_endpoints` | `account_id`=acct_bm_053、`as_of`=2026-08-02T12:00:00Z | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-02T12:00:00Z、`request_id`=req_bm_053_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-02T11:50:00.000Z` 请求 req_bm_053_01 在 2026 年 08 月 02 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 403、错误码 FP-4031，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_053 当时套餐为 Starter、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `list_endpoints` 回调地址 we_bm_053_existing_1 状态 enabled，重试策略 default；回调地址 we_bm_053_existing_2 状态 enabled，重试策略 default。
- `get_request` 请求 req_bm_053_01 在 2026 年 08 月 02 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 403、错误码 FP-4031，响应对象为 无。

证据 ID：`doc:KB-BR-015#c002`、`doc:KB-API-029#c005`、`sql:account:acct_bm_053`、`sql:webhook_endpoint:we_bm_053_existing_1`、`sql:webhook_endpoint:we_bm_053_existing_2`、`runtime:req:req_bm_053_01`

## FP-BM-MS-0215

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-054-downgrade_restricts_newer_endpoints`
- 快照时点 `as_of`：2026-08-03T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`downgrade_restricts_newer_endpoints`

### 开场白

> 线上同事发现：套餐降级后，部分回调地址还在，部分却不再接收新事件。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认降级生效后这个 Endpoint 应删除、disabled 还是 restricted。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户从 Growth 降至 Starter，原有五个 Endpoint，其中 这个回调地址是较晚创建的第三个。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 3 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_054，这个回调地址的编号是 we_bm_054 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 这个回调来自测试还是正式环境？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需查看回调实际尝试记录。大概何时发生，能提供事件或投递编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应变为 restricted；最早两个保持可用，历史投递保留。 处理方式：向商户展示 restricted 状态，并要求其调整配置或重新升级。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0215-A1` 应变为 restricted；最早两个保持可用，历史投递保留。
- `FP-BM-MS-0215-A2` 向商户展示 restricted 状态，并要求其调整配置或重新升级。

禁止结论（说了就算错）：

- 不得认定：降级会物理删除所有超额 Endpoint

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`query_accounts_sql`、`query_webhooks_sql`
- 工具：`search_business_rules`、`query_accounts`、`query_webhooks`
- 文档：`KB-BR-004`、`KB-BR-015`
- 操作：`query_accounts.get_plan_timeline`、`query_webhooks.list_endpoints`、`query_webhooks.get_endpoint`
- 规则：`RULE-ENV-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-PLAN-005`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_business_rules`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_plan_timeline`、`query_webhooks.list_endpoints`、`query_webhooks.get_endpoint`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应变为 restricted；最早两个保持可用，历史投递保留。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_plan_timeline` | `sql` | `query_accounts.get_plan_timeline` | `account_id`=acct_bm_054、`as_of`=2026-08-03T12:00:00Z | `at_least_one` |
| `list_endpoints` | `sql` | `query_webhooks.list_endpoints` | `account_id`=acct_bm_054、`as_of`=2026-08-03T12:00:00Z | `at_least_one` |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-03T12:00:00Z、`endpoint_id`=we_bm_054 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-03T11:50:00.000Z` 2026 年 08 月 03 日 11:50 UTC 申请 Growth→Starter，2026 年 08 月 03 日 11:50 UTC 状态为 effective

查到的实例事实：

- `get_plan_timeline` 套餐轨迹：2026 年 08 月 03 日 11:50 UTC 申请 Growth→Starter，2026 年 08 月 03 日 11:50 UTC 状态为 effective。
- `list_endpoints` 回调地址 we_bm_054 状态 restricted，重试策略 default；回调地址 we_bm_054_existing_1 状态 enabled，重试策略 default；回调地址 we_bm_054_existing_2 状态 enabled，重试策略 default；回调地址 we_bm_054_existing_4 状态 restricted，重试策略 default；回调地址 we_bm_054_existing_5 状态 restricted，重试策略 default。
- `get_endpoint` 回调地址 we_bm_054 状态 restricted，重试策略 default。

证据 ID：`doc:KB-BR-004#c004`、`doc:KB-BR-015#c003`、`sql:account_plan:pc_bm_054_01`、`sql:webhook_endpoint:we_bm_054`、`sql:webhook_endpoint:we_bm_054_existing_1`、`sql:webhook_endpoint:we_bm_054_existing_2`、`sql:webhook_endpoint:we_bm_054_existing_4`、`sql:webhook_endpoint:we_bm_054_existing_5`

## FP-BM-MS-0219

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-055-disabled_endpoint_no_delivery`
- 快照时点 `as_of`：2026-08-04T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`disabled_endpoint_no_delivery`

### 开场白

> 一个已停用的回调地址似乎还和事件有关，我们想确认会不会继续产生投递。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认缺少 Delivery 是否说明平台丢失了 Webhook。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个回调地址在 Event 那个事件发生前已 disabled，商户搜索不到 那次投递。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 4 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_055，这个回调地址的编号是 we_bm_055，那个事件的编号是 evt_bm_055，那次投递的编号是 del_bm_055 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认事件所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不说明；Endpoint 在事件发生时 disabled，按规则本就不应创建 Delivery。 处理方式：核对事件时间与 Endpoint 状态时间线，重新启用只影响后续事件。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0219-A1` 不说明；Endpoint 在事件发生时 disabled，按规则本就不应创建 Delivery。
- `FP-BM-MS-0219-A2` 核对事件时间与 Endpoint 状态时间线，重新启用只影响后续事件。

禁止结论（说了就算错）：

- 不得认定：任何已配置 Endpoint 都必须为每个 Event 产生 Delivery

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-029`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不说明；Endpoint 在事件发生时 disabled，按规则本就不应创建 Delivery。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-04T12:00:00Z、`endpoint_id`=we_bm_055 | `exactly_one` |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-04T12:00:00Z、`event_id`=evt_bm_055 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-04T12:00:00Z、`delivery_id`=del_bm_055 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-04T12:00:00Z、`delivery_id`=del_bm_055 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-04T11:20:09.000Z` 事件 evt_bm_055 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 04 日 11:20 UTC，关联投递 0 个。

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_055 状态 disabled，重试策略 default。
- `get_event` 事件 evt_bm_055 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 04 日 11:20 UTC，关联投递 0 个。
- `get_delivery` 在限定范围（as_of=2026-08-04T12:00:00Z、delivery_id=del_bm_055、account_id=acct_bm_055、environment=production）内没有查到 get_delivery 对应记录。
- `get_delivery_timeline` 在限定范围（as_of=2026-08-04T12:00:00Z、delivery_id=del_bm_055、account_id=acct_bm_055、environment=production）内没有查到 get_delivery_timeline 对应记录。

证据 ID：`doc:KB-BR-015#c002`、`doc:KB-API-029#c002`、`sql:webhook_endpoint:we_bm_055`、`sql:event:evt_bm_055`、`negative:sql:webhook_delivery:8ea8e9e40d3b4770caab`、`negative:runtime:delivery_attempt:8ea8e9e40d3b4770caab`

## FP-BM-MS-0223

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-056-endpoint_not_subscribed`
- 快照时点 `as_of`：2026-08-05T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`endpoint_not_subscribed`

### 开场白

> 客户那边反馈：支付已经成功，但其中一个回调地址始终收不到对应事件。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这是投递失败还是配置不匹配。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付成功并产生 那个事件，enabled 的 这个回调地址只订阅 payment.failed，因此没有 那次投递。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 5 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_056，那笔支付的编号是 pay_bm_056，那个事件的编号是 evt_bm_056，那次投递的编号是 del_bm_056 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 这个回调来自测试还是正式环境？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 是订阅配置不匹配；根本没有创建 Delivery，不是重试失败。 处理方式：订阅适用版本的成功事件名；修改只影响后续事件。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0223-A1` 是订阅配置不匹配；根本没有创建 Delivery，不是重试失败。
- `FP-BM-MS-0223-A2` 订阅适用版本的成功事件名；修改只影响后续事件。

禁止结论（说了就算错）：

- 不得认定：Endpoint enabled 就会接收所有 Event Type

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`query_webhooks_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`query_webhooks`
- 文档：`KB-BR-015`、`KB-API-030`
- 操作：`query_payments.get_payment`、`query_webhooks.list_endpoints`、`query_webhooks.get_event`、`query_webhooks.get_delivery`
- 规则：`RULE-ENV-004`、`RULE-PAY-007`、`RULE-PLAN-003`、`RULE-VERSION-005`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_webhooks.list_endpoints`、`query_webhooks.get_event`、`query_webhooks.get_delivery`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：是订阅配置不匹配；根本没有创建 Delivery，不是重试失败。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-05T12:00:00Z、`payment_id`=pay_bm_056 | `exactly_one` |
| `list_endpoints` | `sql` | `query_webhooks.list_endpoints` | `account_id`=acct_bm_056、`as_of`=2026-08-05T12:00:00Z | `at_least_one` |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-05T12:00:00Z、`event_id`=evt_bm_056 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-05T12:00:00Z、`delivery_id`=del_bm_056 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-05T11:20:04.000Z` 支付 pay_bm_056 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-05T11:20:09.000Z` 事件 evt_bm_056 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 05 日 11:20 UTC，关联投递 0 个。

查到的实例事实：

- `get_payment` 支付 pay_bm_056 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `list_endpoints` 回调地址 we_bm_056 状态 enabled，重试策略 default。
- `get_event` 事件 evt_bm_056 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 05 日 11:20 UTC，关联投递 0 个。
- `get_delivery` 在限定范围（as_of=2026-08-05T12:00:00Z、delivery_id=del_bm_056、account_id=acct_bm_056、environment=production）内没有查到 get_delivery 对应记录。

证据 ID：`doc:KB-BR-015#c002`、`doc:KB-API-030#c004`、`sql:payment:pay_bm_056`、`sql:webhook_endpoint:we_bm_056`、`sql:event:evt_bm_056`、`negative:sql:webhook_delivery:6f0bf8b13e772eeb870d`

## FP-BM-MS-0227

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-057-payment_event_name_by_version`
- 快照时点 `as_of`：2026-08-06T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`payment_event_name_by_version`

### 开场白

> 客服转来一个问题：支付成功以后，新旧回调消费者收到的事件名称不一样。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认应生成哪种 Event，为什么 Endpoint 没收到。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付由 当前部署使用的接口版本 请求创建并成功，这个回调地址只订阅 payment.completed。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 6 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_057，那笔支付的编号是 pay_bm_057，这个回调地址的编号是 we_bm_057，那个事件的编号是 evt_bm_057，那次投递的编号是 del_bm_057 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 这个回调来自测试还是正式环境？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应生成 payment.succeeded；Endpoint 未订阅新版事件名，因此不创建 Delivery。 处理方式：迁移订阅到 payment.succeeded，必要时在过渡期同时订阅适用名称。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0227-A1` 应生成 payment.succeeded；Endpoint 未订阅新版事件名，因此不创建 Delivery。
- `FP-BM-MS-0227-A2` 迁移订阅到 payment.succeeded，必要时在过渡期同时订阅适用名称。

禁止结论（说了就算错）：

- 不得认定：Account 创建时间决定 Event 名称

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`query_webhooks_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`query_webhooks`
- 文档：`KB-BR-015`、`KB-API-030`
- 操作：`query_payments.get_payment`、`query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`
- 规则：`RULE-ENV-004`、`RULE-PAY-007`、`RULE-PLAN-003`、`RULE-VERSION-005`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应生成 payment.succeeded；Endpoint 未订阅新版事件名，因此不创建 Delivery。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-06T12:00:00Z、`payment_id`=pay_bm_057 | `exactly_one` |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-06T12:00:00Z、`endpoint_id`=we_bm_057 | `exactly_one` |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-06T12:00:00Z、`event_id`=evt_bm_057 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-06T12:00:00Z、`delivery_id`=del_bm_057 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-06T11:20:04.000Z` 支付 pay_bm_057 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-06T11:20:09.000Z` 事件 evt_bm_057 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 06 日 11:20 UTC，关联投递 0 个。

查到的实例事实：

- `get_payment` 支付 pay_bm_057 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_endpoint` 回调地址 we_bm_057 状态 enabled，重试策略 default。
- `get_event` 事件 evt_bm_057 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 06 日 11:20 UTC，关联投递 0 个。
- `get_delivery` 在限定范围（as_of=2026-08-06T12:00:00Z、delivery_id=del_bm_057、account_id=acct_bm_057、environment=production）内没有查到 get_delivery 对应记录。

证据 ID：`doc:KB-BR-015#c004`、`doc:KB-API-030#c004`、`sql:payment:pay_bm_057`、`sql:webhook_endpoint:we_bm_057`、`sql:event:evt_bm_057`、`negative:sql:webhook_delivery:cd164b4a546606610549`

## FP-BM-MS-0231

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-058-scheduled_event_uses_account_default`
- 快照时点 `as_of`：2026-08-07T12:00:00Z　接口版本：2026-04-01
- 标签：`webhooks`、`scheduled_event_uses_account_default`

### 开场白

> 客户那边反馈：系统自动产生的事件版本和我们最近一次接口请求的版本对不上。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 3 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Event 应采用什么版本，Payment 成功事件名如何判断。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户默认版本为 当前部署使用的接口版本；Scheduler 生成 那张账单并产生 那个事件，没有外部请求 Header。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 7 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-04-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_058，那张账单的编号是 in_bm_058，那个事件的编号是 evt_bm_058 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 先确认事件所属环境，以及账户当前套餐和主地区。
2. （`before_knowledge`，取 `api_version`）能确认当时客户端使用的接口版本吗？
3. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应采用当时 Account 默认 2026-04-01；相关成功事件仍使用 payment.completed。 处理方式：按任务发生时的 Account 默认版本配置 Endpoint 订阅。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0231-A1` 应采用当时 Account 默认 2026-04-01；相关成功事件仍使用 payment.completed。
- `FP-BM-MS-0231-A2` 按任务发生时的 Account 默认版本配置 Endpoint 订阅。

禁止结论（说了就算错）：

- 不得认定：平台内部事件总使用最新版本

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_payments_sql`、`query_webhooks_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_payments`、`query_webhooks`
- 文档：`KB-BR-015`、`KB-API-030`
- 操作：`query_accounts.get_account`、`query_payments.get_invoice_timeline`、`query_webhooks.get_event`
- 规则：`RULE-ENV-004`、`RULE-PAY-007`、`RULE-PLAN-003`、`RULE-VERSION-005`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_payments.get_invoice_timeline`、`query_webhooks.get_event`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应采用当时 Account 默认 2026-04-01；相关成功事件仍使用 payment.completed。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_058、`as_of`=2026-08-07T12:00:00Z | `exactly_one` |
| `get_invoice_timeline` | `sql` | `query_payments.get_invoice_timeline` | `as_of`=2026-08-07T12:00:00Z、`invoice_id`=in_bm_058 | `at_least_one` |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-07T12:00:00Z、`event_id`=evt_bm_058 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-07T11:20:09.000Z` 事件 evt_bm_058 类型为 invoice.created，版本 2026-04-01，产生于 2026 年 08 月 07 日 11:20 UTC，关联投递 0 个。

查到的实例事实：

- `get_account` 账户 acct_bm_058 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-04-01。
- `get_invoice_timeline` 账单 in_bm_058 当前状态为 open，应付 2500、已付 0；没有扣款尝试。
- `get_event` 事件 evt_bm_058 类型为 invoice.created，版本 2026-04-01，产生于 2026 年 08 月 07 日 11:20 UTC，关联投递 0 个。

证据 ID：`doc:KB-BR-015#c004`、`doc:KB-API-030#c004`、`sql:account:acct_bm_058`、`sql:invoice:in_bm_058`、`sql:event:evt_bm_058`

## FP-BM-MS-0235

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-059-webhook_2xx_success`
- 快照时点 `as_of`：2026-08-08T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_2xx_success`

### 开场白

> 客服转来一个问题：回调服务返回成功后，我们偶尔仍看到重复事件，不确定平台是否认为投递失败。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这个重试计划是否正确。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次投递第一次 Attempt 收到 HTTP 204，系统仍安排下一次重试。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 8 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_059，那次投递的编号是 del_bm_059 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 这个回调来自测试还是正式环境？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不正确；204 属于 2xx，应将 Delivery 标记 delivered 并停止重试。 处理方式：修正响应分类并取消多余调度。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0235-A1` 不正确；204 属于 2xx，应将 Delivery 标记 delivered 并停止重试。
- `FP-BM-MS-0235-A2` 修正响应分类并取消多余调度。

禁止结论（说了就算错）：

- 不得认定：只有 HTTP 200 才算成功

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`
- 操作：`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不正确；204 属于 2xx，应将 Delivery 标记 delivered 并停止重试。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-08T12:00:00Z、`delivery_id`=del_bm_059 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-08T12:00:00Z、`delivery_id`=del_bm_059 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-08T11:50:00.000Z` 投递 del_bm_059 状态为 delivered，已尝试 1 次，终止原因是 无。
- `2026-08-08T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 08 日 11:50 UTC 返回 HTTP 204，结果状态 delivered

查到的实例事实：

- `get_delivery` 投递 del_bm_059 状态为 delivered，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 08 日 11:50 UTC 返回 HTTP 204，结果状态 delivered。

证据 ID：`doc:KB-BR-015#c003`、`doc:KB-API-032#c004`、`sql:webhook_delivery:del_bm_059`、`runtime:attempt:att_bm_059_01`

## FP-BM-MS-0239

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-060-webhook_redirect_retry`
- 快照时点 `as_of`：2026-08-09T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_redirect_retry`

### 开场白

> 客服转来一个问题：回调地址做了跳转以后，平台没有跟过去，反而不断重试。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Delivery 应成功还是进入重试。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个回调地址对 那次投递返回 HTTP 302 和 Location，团队认为 FlowPay 会跟随跳转。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 9 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_060，这个回调地址的编号是 we_bm_060，那次投递的编号是 del_bm_060 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 先确认事件所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应进入重试；FlowPay 不跟随 Webhook 重定向。 处理方式：让 Endpoint 直接在已配置 URL 返回 2xx。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0239-A1` 应进入重试；FlowPay 不跟随 Webhook 重定向。
- `FP-BM-MS-0239-A2` 让 Endpoint 直接在已配置 URL 返回 2xx。

禁止结论（说了就算错）：

- 不得认定：提供 Location 就等同于成功投递

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应进入重试；FlowPay 不跟随 Webhook 重定向。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-09T12:00:00Z、`endpoint_id`=we_bm_060 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-09T12:00:00Z、`delivery_id`=del_bm_060 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-09T12:00:00Z、`delivery_id`=del_bm_060 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-09T11:50:00.000Z` 投递 del_bm_060 状态为 retrying，已尝试 1 次，终止原因是 无。
- `2026-08-09T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 09 日 11:50 UTC 返回 HTTP 302，结果状态 retrying

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_060 状态 enabled，重试策略 default。
- `get_delivery` 投递 del_bm_060 状态为 retrying，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 09 日 11:50 UTC 返回 HTTP 302，结果状态 retrying。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-032#c005`、`sql:webhook_endpoint:we_bm_060`、`sql:webhook_delivery:del_bm_060`、`runtime:attempt:att_bm_060_01`

## FP-BM-MS-0243

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-061-webhook_4xx_retry`
- 快照时点 `as_of`：2026-08-10T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_4xx_retry`

### 开场白

> 客户那边反馈：回调服务明确返回客户端错误，平台却还是继续重试投递。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认是否应立即终止 Delivery。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次投递首次收到 HTTP 400，这个回调地址仍 enabled。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 10 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_061，这个回调地址的编号是 we_bm_061，那次投递的编号是 del_bm_061 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认事件所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应；HTTP 400 是可重试失败，应按重试策略继续。 处理方式：修复接收端并观察后续 Attempt；只有 410 触发立即禁用。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0243-A1` 不应；HTTP 400 是可重试失败，应按重试策略继续。
- `FP-BM-MS-0243-A2` 修复接收端并观察后续 Attempt；只有 410 触发立即禁用。

禁止结论（说了就算错）：

- 不得认定：所有 4xx 都永久禁用 Endpoint

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应；HTTP 400 是可重试失败，应按重试策略继续。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-10T12:00:00Z、`endpoint_id`=we_bm_061 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-10T12:00:00Z、`delivery_id`=del_bm_061 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-10T12:00:00Z、`delivery_id`=del_bm_061 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-10T11:50:00.000Z` 投递 del_bm_061 状态为 retrying，已尝试 1 次，终止原因是 无。
- `2026-08-10T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 10 日 11:50 UTC 返回 HTTP 400，结果状态 retrying

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_061 状态 enabled，重试策略 default。
- `get_delivery` 投递 del_bm_061 状态为 retrying，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 10 日 11:50 UTC 返回 HTTP 400，结果状态 retrying。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-032#c004`、`sql:webhook_endpoint:we_bm_061`、`sql:webhook_delivery:del_bm_061`、`runtime:attempt:att_bm_061_01`

## FP-BM-MS-0247

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-062-webhook_410_disables_endpoint`
- 快照时点 `as_of`：2026-08-11T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_410_disables_endpoint`

### 开场白

> 客户那边反馈：回调服务返回资源已删除后，这个地址突然被系统停用了。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这些后续行为是否符合规则。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次投递第一次收到 HTTP 410，之后又为同一 Endpoint 调度重试并接收新 Event。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 11 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_062，这个回调地址的编号是 we_bm_062，那个事件的编号是 evt_bm_062，那次投递的编号是 del_bm_062 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 先确认事件所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不符合；410 后 Endpoint 应立即 disabled，当前 Delivery 不再重试，后续 Event 不创建新 Delivery。 处理方式：修复 Endpoint 状态和调度，并由商户确认 URL 后重新启用。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0247-A1` 不符合；410 后 Endpoint 应立即 disabled，当前 Delivery 不再重试，后续 Event 不创建新 Delivery。
- `FP-BM-MS-0247-A2` 修复 Endpoint 状态和调度，并由商户确认 URL 后重新启用。

禁止结论（说了就算错）：

- 不得认定：410 与 400 一样走默认六次重试

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不符合；410 后 Endpoint 应立即 disabled，当前 Delivery 不再重试，后续 Event 不创建新 Delivery。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-11T12:00:00Z、`endpoint_id`=we_bm_062 | `exactly_one` |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-11T12:00:00Z、`event_id`=evt_bm_062 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-11T12:00:00Z、`delivery_id`=del_bm_062 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-11T12:00:00Z、`delivery_id`=del_bm_062 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-11T11:20:09.000Z` 事件 evt_bm_062 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 11 日 11:20 UTC，关联投递 1 个。
- `2026-08-11T11:50:00.000Z` 投递 del_bm_062 状态为 canceled，已尝试 1 次，终止原因是 无。
- `2026-08-11T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 11 日 11:50 UTC 返回 HTTP 410，结果状态 canceled

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_062 状态 disabled，重试策略 default。
- `get_event` 事件 evt_bm_062 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 11 日 11:20 UTC，关联投递 1 个。
- `get_delivery` 投递 del_bm_062 状态为 canceled，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 11 日 11:50 UTC 返回 HTTP 410，结果状态 canceled。

证据 ID：`doc:KB-BR-015#c002`、`doc:KB-API-032#c002`、`sql:webhook_endpoint:we_bm_062`、`sql:event:evt_bm_062`、`sql:webhook_delivery:del_bm_062`、`runtime:attempt:att_bm_062_01`

## FP-BM-MS-0251

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-063-webhook_default_retry_exhaustion`
- 快照时点 `as_of`：2026-08-12T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_default_retry_exhaustion`

### 开场白

> 客户那边反馈：一个回调地址故障很久后，平台似乎已经停止继续投递。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认最终状态和 Attempt 数量应如何计算。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次投递首次失败且六个默认重试均返回 500。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 12 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_063，那次投递的编号是 del_bm_063 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认事件所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需查看回调实际尝试记录。大概何时发生，能提供事件或投递编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 最终应 exhausted；共有首次 Attempt 加六次重试，共七次 Attempt。 处理方式：停止继续投递并向商户展示完整失败时间线。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0251-A1` 最终应 exhausted；共有首次 Attempt 加六次重试，共七次 Attempt。
- `FP-BM-MS-0251-A2` 停止继续投递并向商户展示完整失败时间线。

禁止结论（说了就算错）：

- 不得认定：六次重试包含首次投递，所以总共只有六次 Attempt

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`
- 操作：`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：最终应 exhausted；共有首次 Attempt 加六次重试，共七次 Attempt。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-12T12:00:00Z、`delivery_id`=del_bm_063 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-12T12:00:00Z、`delivery_id`=del_bm_063 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-12T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 12 日 11:50 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-12T11:51:00.000Z` 第 2 次投递在 2026 年 08 月 12 日 11:51 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-12T11:55:00.000Z` 第 3 次投递在 2026 年 08 月 12 日 11:55 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-12T12:20:00.000Z` 第 4 次投递在 2026 年 08 月 12 日 12:20 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-12T13:50:00.000Z` 第 5 次投递在 2026 年 08 月 12 日 13:50 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-12T19:50:00.000Z` 第 6 次投递在 2026 年 08 月 12 日 19:50 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-13T11:50:00.000Z` 投递 del_bm_063 状态为 exhausted，已尝试 7 次，终止原因是 retry_exhausted。
- `2026-08-13T11:50:00.000Z` 第 7 次投递在 2026 年 08 月 13 日 11:50 UTC 返回 HTTP 500，结果状态 retrying

查到的实例事实：

- `get_delivery` 投递 del_bm_063 状态为 exhausted，已尝试 7 次，终止原因是 retry_exhausted。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 12 日 11:50 UTC 返回 HTTP 500，结果状态 retrying；第 2 次投递在 2026 年 08 月 12 日 11:51 UTC 返回 HTTP 500，结果状态 retrying；第 3 次投递在 2026 年 08 月 12 日 11:55 UTC 返回 HTTP 500，结果状态 retrying；第 4 次投递在 2026 年 08 月 12 日 12:20 UTC 返回 HTTP 500，结果状态 retrying；第 5 次投递在 2026 年 08 月 12 日 13:50 UTC 返回 HTTP 500，结果状态 retrying；第 6 次投递在 2026 年 08 月 12 日 19:50 UTC 返回 HTTP 500，结果状态 retrying；第 7 次投递在 2026 年 08 月 13 日 11:50 UTC 返回 HTTP 500，结果状态 retrying。

证据 ID：`doc:KB-BR-015#c002`、`doc:KB-API-032#c003`、`sql:webhook_delivery:del_bm_063`、`runtime:attempt:att_bm_063_01`、`runtime:attempt:att_bm_063_02`、`runtime:attempt:att_bm_063_03`、`runtime:attempt:att_bm_063_04`、`runtime:attempt:att_bm_063_05`、`runtime:attempt:att_bm_063_06`、`runtime:attempt:att_bm_063_07`

## FP-BM-MS-0255

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-064-scale_custom_retry`
- 快照时点 `as_of`：2026-08-13T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`scale_custom_retry`

### 开场白

> 我们给高级套餐配置了自己的回调重试节奏，但实际重试时间和预期不一致。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认两份配置是否有效。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Scale Account 这个账户先配置 9 次自定义重试，随后改为 8 次但总窗口为 80 小时。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Scale，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 13 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_064，这个回调地址的编号是 we_bm_064 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认事件所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 都无效：第一次超过 8 次上限，第二次的 80 小时超过 72 小时上限。 处理方式：将重试次数和总窗口同时控制在 Scale 的允许范围内。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0255-A1` 都无效：第一次超过 8 次上限，第二次的 80 小时超过 72 小时上限。
- `FP-BM-MS-0255-A2` 将重试次数和总窗口同时控制在 Scale 的允许范围内。

禁止结论（说了就算错）：

- 不得认定：满足次数上限就可以忽略套餐和总窗口

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`
- 操作：`query_accounts.get_account`、`query_webhooks.get_endpoint`、`get_runtime_state.list_requests`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_webhooks.get_endpoint`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：都无效：第一次超过 8 次上限，第二次的 80 小时超过 72 小时上限。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_064、`as_of`=2026-08-13T12:00:00Z | `exactly_one` |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-13T12:00:00Z、`endpoint_id`=we_bm_064 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_064、`as_of`=2026-08-13T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-13T11:49:59.000Z` 请求 req_bm_064_01 在 2026 年 08 月 13 日 11:49 UTC 以 PATCH 调用 /v1/webhook_endpoints/we_bm_064，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 retry_count=9、retry_window_hours=48
- `2026-08-13T11:50:00.000Z` 请求 req_26153730f5_000002 在 2026 年 08 月 13 日 11:50 UTC 以 PATCH 调用 /v1/webhook_endpoints/we_bm_064，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 retry_count=8、retry_window_hours=80

查到的实例事实：

- `get_account` 账户 acct_bm_064 当时套餐为 Scale、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_endpoint` 回调地址 we_bm_064 状态 enabled，重试策略 default。
- `list_requests` 请求 req_bm_064_01 在 2026 年 08 月 13 日 11:49 UTC 以 PATCH 调用 /v1/webhook_endpoints/we_bm_064，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 retry_count=9、retry_window_hours=48；请求 req_26153730f5_000002 在 2026 年 08 月 13 日 11:50 UTC 以 PATCH 调用 /v1/webhook_endpoints/we_bm_064，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 retry_count=8、retry_window_hours=80。

证据 ID：`doc:KB-BR-015#c007`、`doc:KB-API-032#c003`、`sql:account:acct_bm_064`、`sql:webhook_endpoint:we_bm_064`、`runtime:req:req_bm_064_01`、`runtime:req:req_26153730f5_000002`

## FP-BM-MS-0259

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-065-webhook_at_least_once`
- 快照时点 `as_of`：2026-08-14T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_at_least_once`

### 开场白

> 客服转来一个问题：业务收到两次内容相同的回调，担心系统重复执行了付款逻辑。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认第二次是否代表发生了新的 Payment。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那个事件的首次 那次投递已被 Merchant 处理，但响应丢失导致 FlowPay 重试，Merchant 再次收到相同 Event ID。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 14 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_065，那个事件的编号是 evt_bm_065，那次投递的编号是 del_bm_065 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 先确认事件所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不代表；这是同一 Event 的重复投递，应按 event_id 去重。 处理方式：接收端持久化已处理 event_id，并对重复请求安全返回 2xx。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0259-A1` 不代表；这是同一 Event 的重复投递，应按 event_id 去重。
- `FP-BM-MS-0259-A2` 接收端持久化已处理 event_id，并对重复请求安全返回 2xx。

禁止结论（说了就算错）：

- 不得认定：每个 Webhook 请求都代表一个新的业务事件

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`
- 操作：`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不代表；这是同一 Event 的重复投递，应按 event_id 去重。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-14T12:00:00Z、`event_id`=evt_bm_065 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-14T12:00:00Z、`delivery_id`=del_bm_065 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-14T12:00:00Z、`delivery_id`=del_bm_065 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-14T11:20:09.000Z` 事件 evt_bm_065 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 14 日 11:20 UTC，关联投递 1 个。
- `2026-08-14T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 14 日 11:50 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-14T11:51:00.000Z` 投递 del_bm_065 状态为 delivered，已尝试 2 次，终止原因是 无。
- `2026-08-14T11:51:00.000Z` 第 2 次投递在 2026 年 08 月 14 日 11:51 UTC 返回 HTTP 200，结果状态 delivered

查到的实例事实：

- `get_event` 事件 evt_bm_065 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 14 日 11:20 UTC，关联投递 1 个。
- `get_delivery` 投递 del_bm_065 状态为 delivered，已尝试 2 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 14 日 11:50 UTC 返回 HTTP 500，结果状态 retrying；第 2 次投递在 2026 年 08 月 14 日 11:51 UTC 返回 HTTP 200，结果状态 delivered。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-032#c004`、`sql:event:evt_bm_065`、`sql:webhook_delivery:del_bm_065`、`runtime:attempt:att_bm_065_01`、`runtime:attempt:att_bm_065_02`

## FP-BM-MS-0263

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-066-signature_header_by_version`
- 快照时点 `as_of`：2026-08-15T12:00:00Z　接口版本：2026-04-01
- 标签：`webhooks`、`signature_header_by_version`

### 开场白

> 升级回调版本后，验签程序突然找不到原来的签名请求头。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 3 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认FlowPay 是否未签名，还是接收端读取了错误 Header。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那个事件使用 当前部署使用的接口版本，这个回调地址的接收端仍只读取 X-FlowPay-Signature，因而报签名缺失。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 15 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-04-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_066，这个回调地址的编号是 we_bm_066，那个事件的编号是 evt_bm_066，那次投递的编号是 del_bm_066 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 先确认事件所属环境，以及账户当前套餐和主地区。
2. （`before_knowledge`，取 `api_version`）能确认当时客户端使用的接口版本吗？
3. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> FlowPay 使用了新版 FlowPay-Signature；接收端读取旧 Header 才是根因。 处理方式：按 Event API Version 读取对应 Header，并完成迁移。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0263-A1` FlowPay 使用了新版 FlowPay-Signature；接收端读取旧 Header 才是根因。
- `FP-BM-MS-0263-A2` 按 Event API Version 读取对应 Header，并完成迁移。

禁止结论（说了就算错）：

- 不得认定：所有 API Version 都同时发送两个签名 Header

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-016`、`KB-API-031`
- 操作：`query_webhooks.get_event`、`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-WEBHOOK-013`、`RULE-WEBHOOK-014`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_event`、`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：FlowPay 使用了新版 FlowPay-Signature；接收端读取旧 Header 才是根因。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-15T12:00:00Z、`event_id`=evt_bm_066 | `exactly_one` |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-15T12:00:00Z、`endpoint_id`=we_bm_066 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-15T12:00:00Z、`delivery_id`=del_bm_066 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-15T12:00:00Z、`delivery_id`=del_bm_066 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-15T11:20:09.000Z` 事件 evt_bm_066 类型为 payment.succeeded，版本 2026-04-01，产生于 2026 年 08 月 15 日 11:20 UTC，关联投递 1 个。
- `2026-08-15T11:50:00.000Z` 投递 del_bm_066 状态为 retrying，已尝试 1 次，终止原因是 无。
- `2026-08-15T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 15 日 11:50 UTC 返回 HTTP 400，结果状态 retrying，校验信息 client_error=header_missing、client_expected_header=X-FlowPay-Signature、sent_header=FlowPay-Signature

查到的实例事实：

- `get_event` 事件 evt_bm_066 类型为 payment.succeeded，版本 2026-04-01，产生于 2026 年 08 月 15 日 11:20 UTC，关联投递 1 个。
- `get_endpoint` 回调地址 we_bm_066 状态 enabled，重试策略 default。
- `get_delivery` 投递 del_bm_066 状态为 retrying，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 15 日 11:50 UTC 返回 HTTP 400，结果状态 retrying，校验信息 client_error=header_missing、client_expected_header=X-FlowPay-Signature、sent_header=FlowPay-Signature。

证据 ID：`doc:KB-BR-016#c003`、`doc:KB-API-031#c003`、`sql:event:evt_bm_066`、`sql:webhook_endpoint:we_bm_066`、`sql:webhook_delivery:del_bm_066`、`runtime:attempt:att_bm_066_01`

## FP-BM-MS-0267

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-067-signature_timestamp_tolerance`
- 快照时点 `as_of`：2026-08-16T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`signature_timestamp_tolerance`

### 开场白

> 线上同事发现：回调内容和密钥看起来都对，但验签仍提示时间不合法。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认是否应该接受这次请求。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次投递的签名摘要正确，但接收端验证时与 signature_timestamp 相差 8 分钟。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 16 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_067，这个回调地址的编号是 we_bm_067，那次投递的编号是 del_bm_067 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先补充一下实际表现：做了什么操作，随后看到了什么结果？ 先确认事件所属环境，以及账户当前套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应该；8 分钟超过默认 5 分钟容差。 处理方式：校准服务器时钟，并在 5 分钟内完成验证。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0267-A1` 不应该；8 分钟超过默认 5 分钟容差。
- `FP-BM-MS-0267-A2` 校准服务器时钟，并在 5 分钟内完成验证。

禁止结论（说了就算错）：

- 不得认定：只要 HMAC 正确就可以忽略时间戳

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-016`、`KB-API-031`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-WEBHOOK-013`、`RULE-WEBHOOK-014`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应该；8 分钟超过默认 5 分钟容差。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-16T12:00:00Z、`endpoint_id`=we_bm_067 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-16T12:00:00Z、`delivery_id`=del_bm_067 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-16T12:00:00Z、`delivery_id`=del_bm_067 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-16T11:50:00.000Z` 投递 del_bm_067 状态为 retrying，已尝试 1 次，终止原因是 无。
- `2026-08-16T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 16 日 11:50 UTC 返回 HTTP 400，结果状态 retrying，校验信息 timestamp_skew_seconds=480、verification_time=2026-08-16T11:50:00.000Z

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_067 状态 enabled，重试策略 default。
- `get_delivery` 投递 del_bm_067 状态为 retrying，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 16 日 11:50 UTC 返回 HTTP 400，结果状态 retrying，校验信息 timestamp_skew_seconds=480、verification_time=2026-08-16T11:50:00.000Z。

证据 ID：`doc:KB-BR-016#c006`、`doc:KB-API-031#c003`、`sql:webhook_endpoint:we_bm_067`、`sql:webhook_delivery:del_bm_067`、`runtime:attempt:att_bm_067_01`

## FP-BM-MS-0271

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-068-signing_secret_rotation_window`
- 快照时点 `as_of`：2026-08-17T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`signing_secret_rotation_window`

### 开场白

> 我们排查时发现：我们正在轮换回调密钥，担心切换期间旧实例会突然验签失败。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认新投递能否继续只用旧 Secret 验证。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个回调地址在 10:00 轮换 Secret；10:05 的新 那次投递使用新版本，接收端仅配置旧 Secret。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 17 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_068，这个回调地址的编号是 we_bm_068，那次投递的编号是 del_bm_068 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 这个回调来自测试还是正式环境？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需查看回调实际尝试记录。大概何时发生，能提供事件或投递编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；新投递立即使用新 Secret。旧 Secret 的 24 小时窗口只用于兼容验证旧签名。 处理方式：接收端在过渡期同时接受新旧 Secret，并优先部署新 Secret。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0271-A1` 不能；新投递立即使用新 Secret。旧 Secret 的 24 小时窗口只用于兼容验证旧签名。
- `FP-BM-MS-0271-A2` 接收端在过渡期同时接受新旧 Secret，并优先部署新 Secret。

禁止结论（说了就算错）：

- 不得认定：24 小时内所有新投递仍由旧 Secret 签名

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-016`、`KB-API-031`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-WEBHOOK-013`、`RULE-WEBHOOK-014`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；新投递立即使用新 Secret。旧 Secret 的 24 小时窗口只用于兼容验证旧签名。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-17T12:00:00Z、`endpoint_id`=we_bm_068 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-17T12:00:00Z、`delivery_id`=del_bm_068 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-17T12:00:00Z、`delivery_id`=del_bm_068 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-17T11:50:00.000Z` 投递 del_bm_068 状态为 retrying，已尝试 1 次，终止原因是 无。
- `2026-08-17T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 17 日 11:50 UTC 返回 HTTP 401，结果状态 retrying

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_068 状态 enabled，重试策略 default。
- `get_delivery` 投递 del_bm_068 状态为 retrying，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 17 日 11:50 UTC 返回 HTTP 401，结果状态 retrying。

证据 ID：`doc:KB-BR-016#c006`、`doc:KB-API-031#c005`、`sql:webhook_endpoint:we_bm_068`、`sql:webhook_delivery:del_bm_068`、`runtime:attempt:att_bm_068_01`

## FP-BM-MS-0275

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-069-webhook_retry_resigned`
- 快照时点 `as_of`：2026-08-18T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_retry_resigned`

### 开场白

> 我们排查时发现：同一个回调事件重试时签名发生了变化，接收方把它当成篡改。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认重试应使用旧 Secret 还是新 Secret。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次投递首次失败后，这个回调地址在下一次重试前轮换 Secret。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 18 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_069，这个回调地址的编号是 we_bm_069，那次投递的编号是 del_bm_069 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 这个回调来自测试还是正式环境？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需查看回调实际尝试记录。大概何时发生，能提供事件或投递编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应使用重试时的当前新 Secret重新签名。 处理方式：接收端在轮换窗口同时接受新旧 Secret，并逐次按 Header 验证。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0275-A1` 应使用重试时的当前新 Secret重新签名。
- `FP-BM-MS-0275-A2` 接收端在轮换窗口同时接受新旧 Secret，并逐次按 Header 验证。

禁止结论（说了就算错）：

- 不得认定：同一 Delivery 的所有 Attempt 必须复用第一次签名

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-016`、`KB-API-031`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-WEBHOOK-013`、`RULE-WEBHOOK-014`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应使用重试时的当前新 Secret重新签名。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-18T12:00:00Z、`endpoint_id`=we_bm_069 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-18T12:00:00Z、`delivery_id`=del_bm_069 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-18T12:00:00Z、`delivery_id`=del_bm_069 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-18T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 18 日 11:50 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-18T11:51:00.000Z` 投递 del_bm_069 状态为 delivered，已尝试 2 次，终止原因是 无。
- `2026-08-18T11:51:00.000Z` 第 2 次投递在 2026 年 08 月 18 日 11:51 UTC 返回 HTTP 200，结果状态 delivered

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_069 状态 enabled，重试策略 default。
- `get_delivery` 投递 del_bm_069 状态为 delivered，已尝试 2 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 18 日 11:50 UTC 返回 HTTP 500，结果状态 retrying；第 2 次投递在 2026 年 08 月 18 日 11:51 UTC 返回 HTTP 200，结果状态 delivered。

证据 ID：`doc:KB-BR-016#c003`、`doc:KB-API-031#c005`、`sql:webhook_endpoint:we_bm_069`、`sql:webhook_delivery:del_bm_069`、`runtime:attempt:att_bm_069_01`、`runtime:attempt:att_bm_069_02`

## FP-BM-MS-0279

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-070-distinguish_500_and_503`
- 快照时点 `as_of`：2026-08-19T12:00:00Z　接口版本：2026-07-01
- 标签：`operations`、`distinguish_500_and_503`

### 开场白

> 线上请求有时返回内部错误，有时又显示服务暂不可用，我们不知道处理方式是否一样。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认两类错误是否应归为同一个 Merchant 配置问题。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户的一个 那次请求返回 FP-5001，随后同地区大量请求返回 FP-5031 并存在 这次服务异常。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 19 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_070，那次请求的编号是 req_bm_070_01，这次服务异常的编号是 inc_bm_070 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 受影响的是测试还是真实流量？账户套餐和主要地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）需要查看当时的运行记录。请提供大概时间和请求编号；如果有地区异常编号也可以一并提供。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应；单次 FP-5001 与区域性 FP-5031 需要分别判断，后者由服务 Incident 支持。 处理方式：查询 Request ID、服务状态和影响范围；幂等请求按规则安全重试。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0279-A1` 不应；单次 FP-5001 与区域性 FP-5031 需要分别判断，后者由服务 Incident 支持。
- `FP-BM-MS-0279-A2` 查询 Request ID、服务状态和影响范围；幂等请求按规则安全重试。

禁止结论（说了就算错）：

- 不得认定：所有 5xx 都说明 Webhook Endpoint 配置错误

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-011`、`KB-API-008`
- 操作：`query_accounts.get_account`、`get_runtime_state.get_request`、`get_runtime_state.list_requests`、`get_runtime_state.get_service_status`
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-005`、`RULE-REQ-001`、`RULE-VERSION-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`get_runtime_state.get_request`、`get_runtime_state.list_requests`、`get_runtime_state.get_service_status`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应；单次 FP-5001 与区域性 FP-5031 需要分别判断，后者由服务 Incident 支持。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_070、`as_of`=2026-08-19T12:00:00Z | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-19T12:00:00Z、`request_id`=req_bm_070_01 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_070、`as_of`=2026-08-19T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |
| `get_service_status` | `runtime` | `get_runtime_state.get_service_status` | `as_of`=2026-08-19T12:00:00Z、`incident_id`=inc_bm_070 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-19T11:47:00.000Z` 请求 req_bm_070_01 在 2026 年 08 月 19 日 11:47 UTC 以 POST 调用 /v1/payments，返回 HTTP 500、错误码 FP-5001，响应对象为 无
- `2026-08-19T11:47:00.000Z` 请求 req_bm_070_01 在 2026 年 08 月 19 日 11:47 UTC 以 POST 调用 /v1/payments，返回 HTTP 500、错误码 FP-5001，响应对象为 无
- `2026-08-19T11:50:00.000Z` 请求 req_603a57f99d_000002 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 503、错误码 FP-5031，响应对象为 无
- `2026-08-19T11:50:10.000Z` 请求 req_603a57f99d_000003 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 503、错误码 FP-5031，响应对象为 无
- `2026-08-19T11:50:20.000Z` 请求 req_603a57f99d_000004 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 503、错误码 FP-5031，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_070 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_request` 请求 req_bm_070_01 在 2026 年 08 月 19 日 11:47 UTC 以 POST 调用 /v1/payments，返回 HTTP 500、错误码 FP-5001，响应对象为 无。
- `list_requests` 请求 req_bm_070_01 在 2026 年 08 月 19 日 11:47 UTC 以 POST 调用 /v1/payments，返回 HTTP 500、错误码 FP-5001，响应对象为 无；请求 req_603a57f99d_000002 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 503、错误码 FP-5031，响应对象为 无；请求 req_603a57f99d_000003 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 503、错误码 FP-5031，响应对象为 无；请求 req_603a57f99d_000004 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 503、错误码 FP-5031，响应对象为 无。
- `get_service_status` 服务 payments 在 NA 存在状态为 active 的服务事件，影响从 2026 年 08 月 19 日 11:20 UTC 开始。

证据 ID：`doc:KB-BR-011#c003`、`doc:KB-API-008#c003`、`sql:account:acct_bm_070`、`runtime:req:req_bm_070_01`、`runtime:req:req_603a57f99d_000002`、`runtime:req:req_603a57f99d_000003`、`runtime:req:req_603a57f99d_000004`、`runtime:incident:inc_bm_070`

## FP-BM-MS-0283

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `dev`

- 场景：`SC-071-regional_service_incident`
- 快照时点 `as_of`：2026-08-20T12:00:00Z　接口版本：2026-07-01
- 标签：`operations`、`regional_service_incident`

### 开场白

> 只有某个地区的线上请求明显变慢并报错，其他地区基本正常。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认问题范围是单个 Account 还是区域服务。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | NA payments 服务在时间窗内有 这次服务异常；NA 多个 Account 返回 FP-5031，EU 同类请求正常。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 20 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_071，这次服务异常的编号是 inc_bm_071 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？ 受影响的是测试还是真实流量？账户套餐和主要地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对服务状态和请求轨迹。问题大概何时发生，请求号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 证据表明是 NA 区域 payments 服务降级，不是单个 Account 配置。 处理方式：按 Incident 时间线沟通影响，并在恢复后使用幂等重试。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0283-A1` 证据表明是 NA 区域 payments 服务降级，不是单个 Account 配置。
- `FP-BM-MS-0283-A2` 按 Incident 时间线沟通影响，并在恢复后使用幂等重试。

禁止结论（说了就算错）：

- 不得认定：某个 Account 最先报告就说明只有该账户受影响

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`troubleshooting`、`runtime`
- 工具：`search_business_rules`、`search_troubleshooting`、`get_runtime_state`
- 文档：`KB-BR-011`、`KB-TS-018`
- 操作：`get_runtime_state.list_requests`、`get_runtime_state.get_service_status`
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-IDEMP-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `get_runtime_state.list_requests`、`get_runtime_state.get_service_status`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：证据表明是 NA 区域 payments 服务降级，不是单个 Account 配置。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_071、`as_of`=2026-08-20T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |
| `get_service_status` | `runtime` | `get_runtime_state.get_service_status` | `as_of`=2026-08-20T12:00:00Z、`incident_id`=inc_bm_071 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-20T11:50:00.000Z` 请求 req_bm_071_01 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 503、错误码 FP-5031，响应对象为 无

查到的实例事实：

- `list_requests` 请求 req_bm_071_01 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 503、错误码 FP-5031，响应对象为 无。
- `get_service_status` 服务 payments 在 NA 存在状态为 active 的服务事件，影响从 2026 年 08 月 20 日 11:20 UTC 开始。

证据 ID：`doc:KB-BR-011#c007`、`doc:KB-TS-018#c003`、`runtime:req:req_bm_071_01`、`runtime:incident:inc_bm_071`

## FP-BM-MS-0287

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-072-request_id_before_auth`
- 快照时点 `as_of`：2026-08-21T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`request_id_before_auth`

### 开场白

> 请求在认证阶段就失败了，开发同学说因此没法继续排查。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这次失败是否应有 Request ID。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次请求使用格式错误的那把密钥，返回 FP-4011；客户端认为认证失败所以不可能查询请求日志。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 21 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_072，那次请求的编号是 req_bm_072_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 请求发往测试还是正式环境？相关账户的套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来需要查看当时的请求。请给一个大概时间范围，以及相关账户或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应有；Request ID 在认证前分配，可用于查询脱敏日志，但不等于资源 ID。 处理方式：记录响应中的 Request ID，并据此查询失败阶段。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0287-A1` 应有；Request ID 在认证前分配，可用于查询脱敏日志，但不等于资源 ID。
- `FP-BM-MS-0287-A2` 记录响应中的 Request ID，并据此查询失败阶段。

禁止结论（说了就算错）：

- 不得认定：只有成功认证后才生成 Request ID

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-006`、`KB-API-007`
- 操作：`query_accounts.list_api_keys`、`get_runtime_state.get_request`、`get_runtime_state.list_requests`
- 规则：`RULE-AUTH-001`、`RULE-AUTH-002`、`RULE-AUTH-003`、`RULE-AUTH-004`、`RULE-AUTH-005`、`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-REQ-001`、`RULE-REQ-002`、`RULE-REQ-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.list_api_keys`、`get_runtime_state.get_request`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应有；Request ID 在认证前分配，可用于查询脱敏日志，但不等于资源 ID。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `list_api_keys` | `sql` | `query_accounts.list_api_keys` | `account_id`=acct_bm_072、`as_of`=2026-08-21T12:00:00Z | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-21T12:00:00Z、`request_id`=req_bm_072_01 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_072、`as_of`=2026-08-21T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-21T11:50:00.000Z` 请求 req_bm_072_01 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 401、错误码 FP-4011，响应对象为 无
- `2026-08-21T11:50:00.000Z` 请求 req_bm_072_01 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 401、错误码 FP-4011，响应对象为 无

查到的实例事实：

- `list_api_keys` 账户在该范围查到 1 把 API Key：active 1 条。
- `get_request` 请求 req_bm_072_01 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 401、错误码 FP-4011，响应对象为 无。
- `list_requests` 请求 req_bm_072_01 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 401、错误码 FP-4011，响应对象为 无。

证据 ID：`doc:KB-BR-006#c002`、`doc:KB-API-007#c002`、`sql:api_key:key_bm_072`、`runtime:req:req_bm_072_01`

## FP-BM-MS-0291

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-073-resource_not_visible_semantics`
- 快照时点 `as_of`：2026-08-22T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`resource_not_visible_semantics`

### 开场白

> 我们排查时发现：查询资源时统一提示不存在，但我们不确定是编号错了还是权限问题。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认能否据此断言 Payment 已被删除。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户的 Sandbox Key 查询一个 Production 那笔支付，得到 FP-4041。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在测试环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 22 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_073，那笔支付的编号是 pay_bm_073，那次请求的编号是 req_bm_073_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 这次调用对应哪个环境？也请补充账户套餐和主地区。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还要核对客户端调用记录。大概何时发生，能否提供请求编号？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；环境或租户不可见与真实不存在共享该语义。 处理方式：先核对 Key、Account、Environment 和资源 ID，不要求平台泄漏所有权。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0291-A1` 不能；环境或租户不可见与真实不存在共享该语义。
- `FP-BM-MS-0291-A2` 先核对 Key、Account、Environment 和资源 ID，不要求平台泄漏所有权。

禁止结论（说了就算错）：

- 不得认定：FP-4041 会精确告诉调用方资源属于哪个环境

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-001`、`KB-API-014`
- 操作：`query_accounts.list_api_keys`、`query_payments.get_payment`、`get_runtime_state.get_request`
- 规则：`RULE-PAY-001`、`RULE-REQ-003`、`RULE-TENANT-001`、`RULE-TENANT-002`、`RULE-TENANT-003`、`RULE-TENANT-004`、`RULE-VERSION-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.list_api_keys`、`query_payments.get_payment`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；环境或租户不可见与真实不存在共享该语义。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `list_api_keys` | `sql` | `query_accounts.list_api_keys` | `account_id`=acct_bm_073、`as_of`=2026-08-22T12:00:00Z | `at_least_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-22T12:00:00Z、`payment_id`=pay_bm_073 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-22T12:00:00Z、`request_id`=req_bm_073_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-22T11:50:00.000Z` 请求 req_bm_073_01 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 404、错误码 FP-4041，响应对象为 无

查到的实例事实：

- `list_api_keys` 账户在该范围查到 1 把 API Key：active 1 条。
- `get_payment` 在限定范围（as_of=2026-08-22T12:00:00Z、payment_id=pay_bm_073、account_id=acct_bm_073、environment=sandbox）内没有查到 get_payment 对应记录。
- `get_request` 请求 req_bm_073_01 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 404、错误码 FP-4041，响应对象为 无。

证据 ID：`doc:KB-BR-001#c003`、`doc:KB-API-014#c007`、`sql:api_key:key_bm_073`、`negative:sql:payment:452833d92c7b6a86a7b2`、`runtime:req:req_bm_073_01`

## FP-BM-MS-0295

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-074-runtime_retention_by_plan`
- 快照时点 `as_of`：2026-08-23T12:00:00Z　接口版本：2026-07-01
- 标签：`operations`、`runtime_retention_by_plan`

### 开场白

> 客服转来一个问题：我们想排查一段时间以前的请求，但控制台已经查不到记录了。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认能否根据仍然可见的业务对象还原这次请求的完整日志内容。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Starter Account 这个账户查询 20 天前的请求 那次请求时返回 retention_exceeded，但相关业务对象现在仍然可以看到。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Starter，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 23 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_074，那次请求的编号是 req_bm_074_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。 异常出现在哪个环境和地区？相关账户是什么套餐？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了区分单次错误和区域异常，请补充时间范围、地区和可用的请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；Starter 的请求记录查询范围只有 7 天，业务对象仍然可见不等于完整请求日志仍可查询。 处理方式：说明当前可查询的时间范围；如需更长历史，应提前采用符合产品规则的长期留存方案。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0295-A1` 不能；Starter 的请求记录查询范围只有 7 天，业务对象仍然可见不等于完整请求日志仍可查询。
- `FP-BM-MS-0295-A2` 说明当前可查询的时间范围；如需更长历史，应提前采用符合产品规则的长期留存方案。

禁止结论（说了就算错）：

- 不得认定：只要业务对象还在，就一定能还原完整历史请求日志

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`troubleshooting`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_troubleshooting`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-004`、`KB-TS-022`
- 操作：`query_accounts.get_account`、`get_runtime_state.get_request`
- 规则：`RULE-PLAN-001`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；Starter 的请求记录查询范围只有 7 天，业务对象仍然可见不等于完整请求日志仍可查询。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_074、`as_of`=2026-08-23T12:00:00Z | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-23T12:00:00Z、`request_id`=req_bm_074_01 | `exactly_one` |

### 快照里的实况

查到的实例事实：

- `get_account` 账户 acct_bm_074 当时套餐为 Starter、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_request` 请求日志已超过当前套餐的保留范围；现存日志最早从 2026 年 08 月 16 日 12:00 UTC 开始，因此编号 req_bm_074_01 的日志正文不能被返回。

证据 ID：`doc:KB-BR-004#c004`、`doc:KB-TS-022#c002`、`sql:account:acct_bm_074`、`negative:runtime:api_request:29ae4ccb0ec8b0c646ad`

## FP-BM-MS-0299

**跨数据源**（`multi_source`） · 难度 4 · 多轮 · `test`

- 场景：`SC-075-payment_to_webhook_end_to_end`
- 快照时点 `as_of`：2026-08-24T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`payment_to_webhook_end_to_end`

### 开场白

> 客户已经付款成功，但业务系统一直没有收到对应的回调通知。业务侧看到的结果和接口表现对不上，想确认实际发生了什么。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认应如何给出最终业务结论和 Webhook 投递结论。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付已 succeeded 并生成 那个事件；这个回调地址已订阅正确事件，那次投递首次 500、重试 204。商户却认为 Payment 失败。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 24 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_075，那笔支付的编号是 pay_bm_075，这个回调地址的编号是 we_bm_075，那个事件的编号是 evt_bm_075，那次投递的编号是 del_bm_075 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？ 这个回调来自测试还是正式环境？账户套餐和主地区是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> Payment 已成功；Webhook 首次失败但重试 204 后 delivered。投递故障不能反推 Payment 失败。 处理方式：分别引用 Payment、Event、Endpoint 和 Delivery Timeline，按 event_id 做幂等处理。

必需结论（全部要被证据支持）：

- `FP-BM-MS-0299-A1` Payment 已成功；Webhook 首次失败但重试 204 后 delivered。投递故障不能反推 Payment 失败。
- `FP-BM-MS-0299-A2` 分别引用 Payment、Event、Endpoint 和 Delivery Timeline，按 event_id 做幂等处理。

禁止结论（说了就算错）：

- 不得认定：没在首次收到 Webhook 就说明 Payment 未成功

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`query_payments_sql`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`query_payments`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-010`、`KB-BR-015`
- 操作：`query_payments.get_payment`、`query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-PAY-007`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_business_rules`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：Payment 已成功；Webhook 首次失败但重试 204 后 delivered。投递故障不能反推 Payment 失败。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-24T12:00:00Z、`payment_id`=pay_bm_075 | `exactly_one` |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-24T12:00:00Z、`endpoint_id`=we_bm_075 | `exactly_one` |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-24T12:00:00Z、`event_id`=evt_bm_075 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-24T12:00:00Z、`delivery_id`=del_bm_075 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-24T12:00:00Z、`delivery_id`=del_bm_075 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-24T11:20:04.000Z` 支付 pay_bm_075 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-24T11:20:09.000Z` 事件 evt_bm_075 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 24 日 11:20 UTC，关联投递 1 个。
- `2026-08-24T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 24 日 11:50 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-24T11:51:00.000Z` 投递 del_bm_075 状态为 delivered，已尝试 2 次，终止原因是 无。
- `2026-08-24T11:51:00.000Z` 第 2 次投递在 2026 年 08 月 24 日 11:51 UTC 返回 HTTP 204，结果状态 delivered

查到的实例事实：

- `get_payment` 支付 pay_bm_075 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_endpoint` 回调地址 we_bm_075 状态 enabled，重试策略 default。
- `get_event` 事件 evt_bm_075 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 24 日 11:20 UTC，关联投递 1 个。
- `get_delivery` 投递 del_bm_075 状态为 delivered，已尝试 2 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 24 日 11:50 UTC 返回 HTTP 500，结果状态 retrying；第 2 次投递在 2026 年 08 月 24 日 11:51 UTC 返回 HTTP 204，结果状态 delivered。

证据 ID：`doc:KB-BR-010#c005`、`doc:KB-BR-015#c007`、`sql:payment:pay_bm_075`、`sql:webhook_endpoint:we_bm_075`、`sql:event:evt_bm_075`、`sql:webhook_delivery:del_bm_075`、`runtime:attempt:att_bm_075_01`、`runtime:attempt:att_bm_075_02`
