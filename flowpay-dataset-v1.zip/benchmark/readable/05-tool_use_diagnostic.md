# 工具诊断　`tool_use_diagnostic`　25 道

## FP-BM-DG-0204

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `dev`

- 场景：`SC-051-paid_invoice_cannot_void`
- 快照时点 `as_of`：2026-08-26T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`paid_invoice_cannot_void`

### 开场白

> 客服想作废一张账单，但系统提示它当前不能作废。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Invoice 是否应变成 void。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那张账单已 paid，这个账户为纠正账单说明而调用 void。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 26 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_051，那张账单的编号是 in_bm_051，那次请求的编号是 req_bm_051_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）账单来自哪个环境？对应账户的套餐和地区能确认吗？ 这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要查看账单状态变化，大概是什么时候，相关账单或订阅号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应；paid Invoice 不可 void，状态保持 paid。 处理方式：保留 paid 账单，使用业务允许的后续流程处理说明。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0204-A1` 不应；paid Invoice 不可 void，状态保持 paid。
- `FP-BM-DG-0204-A2` 保留 paid 账单，使用业务允许的后续流程处理说明。

禁止结论（说了就算错）：

- 不得认定：void 是可以覆盖任何 Invoice 状态的管理操作

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-014`、`KB-API-026`
- 操作：`query_payments.get_invoice_timeline`、`get_runtime_state.get_request`
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-INVOICE-007`、`RULE-INVOICE-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_invoice_timeline`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应；paid Invoice 不可 void，状态保持 paid。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_invoice_timeline` | `sql` | `query_payments.get_invoice_timeline` | `as_of`=2026-08-26T12:00:00Z、`invoice_id`=in_bm_051 | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-26T12:00:00Z、`request_id`=req_bm_051_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-26T11:50:00.000Z` 请求 req_bm_051_01 在 2026 年 08 月 26 日 11:50 UTC 以 POST 调用 /v1/invoices/in_bm_051/void，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 invoice_id=in_bm_051

查到的实例事实：

- `get_invoice_timeline` 账单 in_bm_051 当前状态为 paid，应付 2500、已付 2500；没有扣款尝试。
- `get_request` 请求 req_bm_051_01 在 2026 年 08 月 26 日 11:50 UTC 以 POST 调用 /v1/invoices/in_bm_051/void，返回 HTTP 422、错误码 FP-4221，响应对象为 无，请求参数 invoice_id=in_bm_051。

证据 ID：`doc:KB-BR-014#c007`、`doc:KB-API-026#c004`、`sql:invoice:in_bm_051`、`runtime:req:req_bm_051_01`

## FP-BM-DG-0208

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-052-open_invoice_can_void`
- 快照时点 `as_of`：2026-08-01T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`open_invoice_can_void`

### 开场白

> 我们排查时发现：客户不再需要一张尚未支付的账单，客服想确认能否直接作废。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认void 是否允许，之后还能否继续扣费。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那张账单已 open 但尚未支付，这个账户决定作废它。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 1 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_052，那张账单的编号是 in_bm_052 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这张账单属于测试还是真实业务？账户套餐和主地区是什么？ 先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了查看账单时间线，请提供大概发生时间和账单或订阅编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 允许进入 void；void 是终态，不应继续为该 Invoice 扣费。 处理方式：取消相关待执行扣费任务，并保留状态时间线。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0208-A1` 允许进入 void；void 是终态，不应继续为该 Invoice 扣费。
- `FP-BM-DG-0208-A2` 取消相关待执行扣费任务，并保留状态时间线。

禁止结论（说了就算错）：

- 不得认定：只有 draft Invoice 才能 void

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-014`、`KB-API-026`
- 操作：`query_payments.get_invoice_timeline`、`get_runtime_state.list_requests`
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-INVOICE-007`、`RULE-INVOICE-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_invoice_timeline`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：允许进入 void；void 是终态，不应继续为该 Invoice 扣费。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_invoice_timeline` | `sql` | `query_payments.get_invoice_timeline` | `as_of`=2026-08-01T12:00:00Z、`invoice_id`=in_bm_052 | `at_least_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_052、`as_of`=2026-08-01T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-01T11:50:00.000Z` 请求 req_bm_052_01 在 2026 年 08 月 01 日 11:50 UTC 以 POST 调用 /v1/invoices/in_bm_052/void，返回 HTTP 200，响应对象为 无，请求参数 invoice_id=in_bm_052

查到的实例事实：

- `get_invoice_timeline` 账单 in_bm_052 当前状态为 void，应付 2500、已付 0；没有扣款尝试。
- `list_requests` 请求 req_bm_052_01 在 2026 年 08 月 01 日 11:50 UTC 以 POST 调用 /v1/invoices/in_bm_052/void，返回 HTTP 200，响应对象为 无，请求参数 invoice_id=in_bm_052。

证据 ID：`doc:KB-BR-014#c006`、`doc:KB-API-026#c004`、`sql:invoice:in_bm_052`、`runtime:req:req_bm_052_01`

## FP-BM-DG-0212

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-053-starter_endpoint_limit`
- 快照时点 `as_of`：2026-08-02T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`starter_endpoint_limit`

### 开场白

> 客户那边反馈：我们给账户新增回调地址时突然提示数量已到上限。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认第三个 Endpoint 是否应创建。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Starter Account 这个账户已有两个 enabled Endpoint，又尝试创建 这个回调地址。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Starter，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 2 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_053，那次请求的编号是 req_bm_053_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先确认事件所属环境，以及账户当前套餐和主地区。 能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需查看回调实际尝试记录。大概何时发生，能提供事件或投递编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应；Starter 上限为 2，应返回 FP-4031。 处理方式：删除或禁用并不会自动改变上限语义；需要按产品操作减少配置或升级套餐。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0212-A1` 不应；Starter 上限为 2，应返回 FP-4031。
- `FP-BM-DG-0212-A2` 删除或禁用并不会自动改变上限语义；需要按产品操作减少配置或升级套餐。

禁止结论（说了就算错）：

- 不得认定：Endpoint 上限只影响投递，不影响创建

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_accounts_sql`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_accounts`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-029`、`KB-TS-010`
- 操作：`query_accounts.get_account`、`query_webhooks.list_endpoints`、`get_runtime_state.get_request`
- 规则：`RULE-ENV-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-REGION-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_webhooks.list_endpoints`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应；Starter 上限为 2，应返回 FP-4031。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_053、`as_of`=2026-08-02T12:00:00Z | `exactly_one` |
| `list_endpoints` | `sql` | `query_webhooks.list_endpoints` | `account_id`=acct_bm_053、`as_of`=2026-08-02T12:00:00Z | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-02T12:00:00Z、`request_id`=req_bm_053_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-02T11:50:00.000Z` 请求 req_bm_053_01 在 2026 年 08 月 02 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 403、错误码 FP-4031，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_053 当时套餐为 Starter、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `list_endpoints` 回调地址 we_bm_053_existing_1 状态 enabled，重试策略 default；回调地址 we_bm_053_existing_2 状态 enabled，重试策略 default。
- `get_request` 请求 req_bm_053_01 在 2026 年 08 月 02 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 403、错误码 FP-4031，响应对象为 无。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-029#c005`、`doc:KB-TS-010#c008`、`sql:account:acct_bm_053`、`sql:webhook_endpoint:we_bm_053_existing_1`、`sql:webhook_endpoint:we_bm_053_existing_2`、`runtime:req:req_bm_053_01`

## FP-BM-DG-0216

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-054-downgrade_restricts_newer_endpoints`
- 快照时点 `as_of`：2026-08-03T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`downgrade_restricts_newer_endpoints`

### 开场白

> 套餐降级后，部分回调地址还在，部分却不再接收新事件。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认降级生效后这个 Endpoint 应删除、disabled 还是 restricted。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户从 Growth 降至 Starter，原有五个 Endpoint，其中 这个回调地址是较晚创建的第三个。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 3 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_054，这个回调地址的编号是 we_bm_054 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个回调来自测试还是正式环境？账户套餐和主地区是什么？ 先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需查看回调实际尝试记录。大概何时发生，能提供事件或投递编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应变为 restricted；最早两个保持可用，历史投递保留。 处理方式：向商户展示 restricted 状态，并要求其调整配置或重新升级。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0216-A1` 应变为 restricted；最早两个保持可用，历史投递保留。
- `FP-BM-DG-0216-A2` 向商户展示 restricted 状态，并要求其调整配置或重新升级。

禁止结论（说了就算错）：

- 不得认定：降级会物理删除所有超额 Endpoint

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_accounts_sql`、`query_webhooks_sql`
- 工具：`search_business_rules`、`search_api_docs`、`query_accounts`、`query_webhooks`
- 文档：`KB-BR-004`、`KB-BR-015`、`KB-API-029`
- 操作：`query_accounts.get_plan_timeline`、`query_webhooks.list_endpoints`、`query_webhooks.get_endpoint`
- 规则：`RULE-ENV-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-PLAN-005`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_plan_timeline`、`query_webhooks.list_endpoints`、`query_webhooks.get_endpoint`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应变为 restricted；最早两个保持可用，历史投递保留。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_plan_timeline` | `sql` | `query_accounts.get_plan_timeline` | `account_id`=acct_bm_054、`as_of`=2026-08-03T12:00:00Z | `at_least_one` |
| `list_endpoints` | `sql` | `query_webhooks.list_endpoints` | `account_id`=acct_bm_054、`as_of`=2026-08-03T12:00:00Z | `at_least_one` |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-03T12:00:00Z、`endpoint_id`=we_bm_054 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-03T11:50:00.000Z` 2026 年 08 月 03 日 11:50 UTC 申请 Growth→Starter，2026 年 08 月 03 日 11:50 UTC 状态为 effective

查到的实例事实：

- `get_plan_timeline` 套餐轨迹：2026 年 08 月 03 日 11:50 UTC 申请 Growth→Starter，2026 年 08 月 03 日 11:50 UTC 状态为 effective。
- `list_endpoints` 回调地址 we_bm_054 状态 restricted，重试策略 default；回调地址 we_bm_054_existing_1 状态 enabled，重试策略 default；回调地址 we_bm_054_existing_2 状态 enabled，重试策略 default；回调地址 we_bm_054_existing_4 状态 restricted，重试策略 default；回调地址 we_bm_054_existing_5 状态 restricted，重试策略 default。
- `get_endpoint` 回调地址 we_bm_054 状态 restricted，重试策略 default。

证据 ID：`doc:KB-BR-004#c004`、`doc:KB-BR-015#c003`、`doc:KB-API-029#c005`、`sql:account_plan:pc_bm_054_01`、`sql:webhook_endpoint:we_bm_054`、`sql:webhook_endpoint:we_bm_054_existing_1`、`sql:webhook_endpoint:we_bm_054_existing_2`、`sql:webhook_endpoint:we_bm_054_existing_4`、`sql:webhook_endpoint:we_bm_054_existing_5`

## FP-BM-DG-0220

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-055-disabled_endpoint_no_delivery`
- 快照时点 `as_of`：2026-08-04T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`disabled_endpoint_no_delivery`

### 开场白

> 我们排查时发现：一个已停用的回调地址似乎还和事件有关，我们想确认会不会继续产生投递。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认缺少 Delivery 是否说明平台丢失了 Webhook。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个回调地址在 Event 那个事件发生前已 disabled，商户搜索不到 那次投递。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 4 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_055，这个回调地址的编号是 we_bm_055，那个事件的编号是 evt_bm_055，那次投递的编号是 del_bm_055 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先确认事件所属环境，以及账户当前套餐和主地区。 能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不说明；Endpoint 在事件发生时 disabled，按规则本就不应创建 Delivery。 处理方式：核对事件时间与 Endpoint 状态时间线，重新启用只影响后续事件。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0220-A1` 不说明；Endpoint 在事件发生时 disabled，按规则本就不应创建 Delivery。
- `FP-BM-DG-0220-A2` 核对事件时间与 Endpoint 状态时间线，重新启用只影响后续事件。

禁止结论（说了就算错）：

- 不得认定：任何已配置 Endpoint 都必须为每个 Event 产生 Delivery

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-029`、`KB-TS-023`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-013`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不说明；Endpoint 在事件发生时 disabled，按规则本就不应创建 Delivery。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-04T12:00:00Z、`endpoint_id`=we_bm_055 | `exactly_one` |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-04T12:00:00Z、`event_id`=evt_bm_055 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-04T12:00:00Z、`delivery_id`=del_bm_055 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-04T12:00:00Z、`delivery_id`=del_bm_055 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-04T11:20:09.000Z` 事件 evt_bm_055 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 04 日 11:20 UTC，关联投递 0 个。

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_055 状态 disabled，重试策略 default。
- `get_event` 事件 evt_bm_055 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 04 日 11:20 UTC，关联投递 0 个。
- `get_delivery` 在限定范围（as_of=2026-08-04T12:00:00Z、delivery_id=del_bm_055、account_id=acct_bm_055、environment=production）内没有查到 get_delivery 对应记录。
- `get_delivery_timeline` 在限定范围（as_of=2026-08-04T12:00:00Z、delivery_id=del_bm_055、account_id=acct_bm_055、environment=production）内没有查到 get_delivery_timeline 对应记录。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-029#c004`、`doc:KB-TS-023#c005`、`sql:webhook_endpoint:we_bm_055`、`sql:event:evt_bm_055`、`negative:sql:webhook_delivery:8ea8e9e40d3b4770caab`、`negative:runtime:delivery_attempt:8ea8e9e40d3b4770caab`

## FP-BM-DG-0224

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `dev`

- 场景：`SC-056-endpoint_not_subscribed`
- 快照时点 `as_of`：2026-08-05T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`endpoint_not_subscribed`

### 开场白

> 客服转来一个问题：支付已经成功，但其中一个回调地址始终收不到对应事件。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这是投递失败还是配置不匹配。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付成功并产生 那个事件，enabled 的 这个回调地址只订阅 payment.failed，因此没有 那次投递。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 5 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_056，那笔支付的编号是 pay_bm_056，那个事件的编号是 evt_bm_056，那次投递的编号是 del_bm_056 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个回调来自测试还是正式环境？账户套餐和主地区是什么？ 为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 是订阅配置不匹配；根本没有创建 Delivery，不是重试失败。 处理方式：订阅适用版本的成功事件名；修改只影响后续事件。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0224-A1` 是订阅配置不匹配；根本没有创建 Delivery，不是重试失败。
- `FP-BM-DG-0224-A2` 订阅适用版本的成功事件名；修改只影响后续事件。

禁止结论（说了就算错）：

- 不得认定：Endpoint enabled 就会接收所有 Event Type

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`support_cases`、`query_payments_sql`、`query_webhooks_sql`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`、`query_payments`、`query_webhooks`
- 文档：`KB-BR-015`、`KB-API-030`、`KB-TS-023`、`KB-CASE-015`
- 操作：`query_payments.get_payment`、`query_webhooks.list_endpoints`、`query_webhooks.get_event`、`query_webhooks.get_delivery`
- 规则：`RULE-ENV-004`、`RULE-PAY-007`、`RULE-PLAN-003`、`RULE-VERSION-005`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-013`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_webhooks.list_endpoints`、`query_webhooks.get_event`、`query_webhooks.get_delivery`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：是订阅配置不匹配；根本没有创建 Delivery，不是重试失败。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-05T12:00:00Z、`payment_id`=pay_bm_056 | `exactly_one` |
| `list_endpoints` | `sql` | `query_webhooks.list_endpoints` | `account_id`=acct_bm_056、`as_of`=2026-08-05T12:00:00Z | `at_least_one` |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-05T12:00:00Z、`event_id`=evt_bm_056 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-05T12:00:00Z、`delivery_id`=del_bm_056 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-05T11:20:04.000Z` 支付 pay_bm_056 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-05T11:20:09.000Z` 事件 evt_bm_056 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 05 日 11:20 UTC，关联投递 0 个。

查到的实例事实：

- `get_payment` 支付 pay_bm_056 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `list_endpoints` 回调地址 we_bm_056 状态 enabled，重试策略 default。
- `get_event` 事件 evt_bm_056 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 05 日 11:20 UTC，关联投递 0 个。
- `get_delivery` 在限定范围（as_of=2026-08-05T12:00:00Z、delivery_id=del_bm_056、account_id=acct_bm_056、environment=production）内没有查到 get_delivery 对应记录。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-030#c003`、`doc:KB-TS-023#c002`、`doc:KB-CASE-015#c001`、`sql:payment:pay_bm_056`、`sql:webhook_endpoint:we_bm_056`、`sql:event:evt_bm_056`、`negative:sql:webhook_delivery:6f0bf8b13e772eeb870d`

## FP-BM-DG-0228

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-057-payment_event_name_by_version`
- 快照时点 `as_of`：2026-08-06T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`payment_event_name_by_version`

### 开场白

> 线上同事发现：支付成功以后，新旧回调消费者收到的事件名称不一样。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认应生成哪种 Event，为什么 Endpoint 没收到。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付由 当前部署使用的接口版本 请求创建并成功，这个回调地址只订阅 payment.completed。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 6 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_057，那笔支付的编号是 pay_bm_057，这个回调地址的编号是 we_bm_057，那个事件的编号是 evt_bm_057，那次投递的编号是 del_bm_057 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个回调来自测试还是正式环境？账户套餐和主地区是什么？ 为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应生成 payment.succeeded；Endpoint 未订阅新版事件名，因此不创建 Delivery。 处理方式：迁移订阅到 payment.succeeded，必要时在过渡期同时订阅适用名称。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0228-A1` 应生成 payment.succeeded；Endpoint 未订阅新版事件名，因此不创建 Delivery。
- `FP-BM-DG-0228-A2` 迁移订阅到 payment.succeeded，必要时在过渡期同时订阅适用名称。

禁止结论（说了就算错）：

- 不得认定：Account 创建时间决定 Event 名称

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`release_notes`、`query_payments_sql`、`query_webhooks_sql`
- 工具：`search_business_rules`、`search_api_docs`、`search_release_notes`、`query_payments`、`query_webhooks`
- 文档：`KB-BR-015`、`KB-API-030`、`KB-REL-007`、`KB-REL-009`
- 操作：`query_payments.get_payment`、`query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`
- 规则：`RULE-ENV-004`、`RULE-PAY-007`、`RULE-PLAN-003`、`RULE-RATE-007`、`RULE-REFUND-001`、`RULE-VERSION-005`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_release_notes`、`search_release_notes`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应生成 payment.succeeded；Endpoint 未订阅新版事件名，因此不创建 Delivery。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-06T12:00:00Z、`payment_id`=pay_bm_057 | `exactly_one` |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-06T12:00:00Z、`endpoint_id`=we_bm_057 | `exactly_one` |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-06T12:00:00Z、`event_id`=evt_bm_057 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-06T12:00:00Z、`delivery_id`=del_bm_057 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-06T11:20:04.000Z` 支付 pay_bm_057 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-06T11:20:09.000Z` 事件 evt_bm_057 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 06 日 11:20 UTC，关联投递 0 个。

查到的实例事实：

- `get_payment` 支付 pay_bm_057 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_endpoint` 回调地址 we_bm_057 状态 enabled，重试策略 default。
- `get_event` 事件 evt_bm_057 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 06 日 11:20 UTC，关联投递 0 个。
- `get_delivery` 在限定范围（as_of=2026-08-06T12:00:00Z、delivery_id=del_bm_057、account_id=acct_bm_057、environment=production）内没有查到 get_delivery 对应记录。

证据 ID：`doc:KB-BR-015#c004`、`doc:KB-API-030#c004`、`doc:KB-REL-007#c004`、`doc:KB-REL-009#c001`、`sql:payment:pay_bm_057`、`sql:webhook_endpoint:we_bm_057`、`sql:event:evt_bm_057`、`negative:sql:webhook_delivery:cd164b4a546606610549`

## FP-BM-DG-0232

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-058-scheduled_event_uses_account_default`
- 快照时点 `as_of`：2026-08-07T12:00:00Z　接口版本：2026-04-01
- 标签：`webhooks`、`scheduled_event_uses_account_default`

### 开场白

> 客服转来一个问题：系统自动产生的事件版本和我们最近一次接口请求的版本对不上。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 3 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Event 应采用什么版本，Payment 成功事件名如何判断。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户默认版本为 当前部署使用的接口版本；Scheduler 生成 那张账单并产生 那个事件，没有外部请求 Header。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 7 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-04-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_058，那张账单的编号是 in_bm_058，那个事件的编号是 evt_bm_058 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先确认事件所属环境，以及账户当前套餐和主地区。 这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`before_knowledge`，取 `api_version`）能确认当时客户端使用的接口版本吗？
3. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应采用当时 Account 默认 2026-04-01；相关成功事件仍使用 payment.completed。 处理方式：按任务发生时的 Account 默认版本配置 Endpoint 订阅。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0232-A1` 应采用当时 Account 默认 2026-04-01；相关成功事件仍使用 payment.completed。
- `FP-BM-DG-0232-A2` 按任务发生时的 Account 默认版本配置 Endpoint 订阅。

禁止结论（说了就算错）：

- 不得认定：平台内部事件总使用最新版本

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`release_notes`、`query_accounts_sql`、`query_payments_sql`、`query_webhooks_sql`
- 工具：`search_business_rules`、`search_api_docs`、`search_release_notes`、`query_accounts`、`query_payments`、`query_webhooks`
- 文档：`KB-BR-015`、`KB-API-030`、`KB-REL-009`
- 操作：`query_accounts.get_account`、`query_payments.get_invoice_timeline`、`query_webhooks.get_event`
- 规则：`RULE-ENV-004`、`RULE-PAY-007`、`RULE-PLAN-003`、`RULE-VERSION-005`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_release_notes`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_payments.get_invoice_timeline`、`query_webhooks.get_event`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应采用当时 Account 默认 2026-04-01；相关成功事件仍使用 payment.completed。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_058、`as_of`=2026-08-07T12:00:00Z | `exactly_one` |
| `get_invoice_timeline` | `sql` | `query_payments.get_invoice_timeline` | `as_of`=2026-08-07T12:00:00Z、`invoice_id`=in_bm_058 | `at_least_one` |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-07T12:00:00Z、`event_id`=evt_bm_058 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-07T11:20:09.000Z` 事件 evt_bm_058 类型为 invoice.created，版本 2026-04-01，产生于 2026 年 08 月 07 日 11:20 UTC，关联投递 0 个。

查到的实例事实：

- `get_account` 账户 acct_bm_058 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-04-01。
- `get_invoice_timeline` 账单 in_bm_058 当前状态为 open，应付 2500、已付 0；没有扣款尝试。
- `get_event` 事件 evt_bm_058 类型为 invoice.created，版本 2026-04-01，产生于 2026 年 08 月 07 日 11:20 UTC，关联投递 0 个。

证据 ID：`doc:KB-BR-015#c004`、`doc:KB-API-030#c004`、`doc:KB-REL-009#c006`、`sql:account:acct_bm_058`、`sql:invoice:in_bm_058`、`sql:event:evt_bm_058`

## FP-BM-DG-0236

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-059-webhook_2xx_success`
- 快照时点 `as_of`：2026-08-08T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_2xx_success`

### 开场白

> 线上同事发现：回调服务返回成功后，我们偶尔仍看到重复事件，不确定平台是否认为投递失败。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这个重试计划是否正确。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次投递第一次 Attempt 收到 HTTP 204，系统仍安排下一次重试。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 8 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_059，那次投递的编号是 del_bm_059 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个回调来自测试还是正式环境？账户套餐和主地区是什么？ 先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不正确；204 属于 2xx，应将 Delivery 标记 delivered 并停止重试。 处理方式：修正响应分类并取消多余调度。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0236-A1` 不正确；204 属于 2xx，应将 Delivery 标记 delivered 并停止重试。
- `FP-BM-DG-0236-A2` 修正响应分类并取消多余调度。

禁止结论（说了就算错）：

- 不得认定：只有 HTTP 200 才算成功

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`
- 操作：`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不正确；204 属于 2xx，应将 Delivery 标记 delivered 并停止重试。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-08T12:00:00Z、`delivery_id`=del_bm_059 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-08T12:00:00Z、`delivery_id`=del_bm_059 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-08T11:50:00.000Z` 投递 del_bm_059 状态为 delivered，已尝试 1 次，终止原因是 无。
- `2026-08-08T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 08 日 11:50 UTC 返回 HTTP 204，结果状态 delivered

查到的实例事实：

- `get_delivery` 投递 del_bm_059 状态为 delivered，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 08 日 11:50 UTC 返回 HTTP 204，结果状态 delivered。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-032#c004`、`sql:webhook_delivery:del_bm_059`、`runtime:attempt:att_bm_059_01`

## FP-BM-DG-0240

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-060-webhook_redirect_retry`
- 快照时点 `as_of`：2026-08-09T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_redirect_retry`

### 开场白

> 线上同事发现：回调地址做了跳转以后，平台没有跟过去，反而不断重试。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认Delivery 应成功还是进入重试。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个回调地址对 那次投递返回 HTTP 302 和 Location，团队认为 FlowPay 会跟随跳转。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 9 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_060，这个回调地址的编号是 we_bm_060，那次投递的编号是 del_bm_060 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先确认事件所属环境，以及账户当前套餐和主地区。 这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应进入重试；FlowPay 不跟随 Webhook 重定向。 处理方式：让 Endpoint 直接在已配置 URL 返回 2xx。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0240-A1` 应进入重试；FlowPay 不跟随 Webhook 重定向。
- `FP-BM-DG-0240-A2` 让 Endpoint 直接在已配置 URL 返回 2xx。

禁止结论（说了就算错）：

- 不得认定：提供 Location 就等同于成功投递

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`、`KB-TS-023`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-013`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应进入重试；FlowPay 不跟随 Webhook 重定向。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-09T12:00:00Z、`endpoint_id`=we_bm_060 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-09T12:00:00Z、`delivery_id`=del_bm_060 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-09T12:00:00Z、`delivery_id`=del_bm_060 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-09T11:50:00.000Z` 投递 del_bm_060 状态为 retrying，已尝试 1 次，终止原因是 无。
- `2026-08-09T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 09 日 11:50 UTC 返回 HTTP 302，结果状态 retrying

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_060 状态 enabled，重试策略 default。
- `get_delivery` 投递 del_bm_060 状态为 retrying，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 09 日 11:50 UTC 返回 HTTP 302，结果状态 retrying。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-032#c003`、`doc:KB-TS-023#c007`、`sql:webhook_endpoint:we_bm_060`、`sql:webhook_delivery:del_bm_060`、`runtime:attempt:att_bm_060_01`

## FP-BM-DG-0244

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `dev`

- 场景：`SC-061-webhook_4xx_retry`
- 快照时点 `as_of`：2026-08-10T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_4xx_retry`

### 开场白

> 客服转来一个问题：回调服务明确返回客户端错误，平台却还是继续重试投递。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认是否应立即终止 Delivery。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次投递首次收到 HTTP 400，这个回调地址仍 enabled。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 10 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_061，这个回调地址的编号是 we_bm_061，那次投递的编号是 del_bm_061 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先确认事件所属环境，以及账户当前套餐和主地区。 能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应；HTTP 400 是可重试失败，应按重试策略继续。 处理方式：修复接收端并观察后续 Attempt；只有 410 触发立即禁用。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0244-A1` 不应；HTTP 400 是可重试失败，应按重试策略继续。
- `FP-BM-DG-0244-A2` 修复接收端并观察后续 Attempt；只有 410 触发立即禁用。

禁止结论（说了就算错）：

- 不得认定：所有 4xx 都永久禁用 Endpoint

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`、`KB-TS-023`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-013`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应；HTTP 400 是可重试失败，应按重试策略继续。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-10T12:00:00Z、`endpoint_id`=we_bm_061 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-10T12:00:00Z、`delivery_id`=del_bm_061 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-10T12:00:00Z、`delivery_id`=del_bm_061 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-10T11:50:00.000Z` 投递 del_bm_061 状态为 retrying，已尝试 1 次，终止原因是 无。
- `2026-08-10T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 10 日 11:50 UTC 返回 HTTP 400，结果状态 retrying

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_061 状态 enabled，重试策略 default。
- `get_delivery` 投递 del_bm_061 状态为 retrying，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 10 日 11:50 UTC 返回 HTTP 400，结果状态 retrying。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-032#c003`、`doc:KB-TS-023#c007`、`sql:webhook_endpoint:we_bm_061`、`sql:webhook_delivery:del_bm_061`、`runtime:attempt:att_bm_061_01`

## FP-BM-DG-0248

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-062-webhook_410_disables_endpoint`
- 快照时点 `as_of`：2026-08-11T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_410_disables_endpoint`

### 开场白

> 客服转来一个问题：回调服务返回资源已删除后，这个地址突然被系统停用了。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这些后续行为是否符合规则。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次投递第一次收到 HTTP 410，之后又为同一 Endpoint 调度重试并接收新 Event。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 11 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_062，这个回调地址的编号是 we_bm_062，那个事件的编号是 evt_bm_062，那次投递的编号是 del_bm_062 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先确认事件所属环境，以及账户当前套餐和主地区。 这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不符合；410 后 Endpoint 应立即 disabled，当前 Delivery 不再重试，后续 Event 不创建新 Delivery。 处理方式：修复 Endpoint 状态和调度，并由商户确认 URL 后重新启用。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0248-A1` 不符合；410 后 Endpoint 应立即 disabled，当前 Delivery 不再重试，后续 Event 不创建新 Delivery。
- `FP-BM-DG-0248-A2` 修复 Endpoint 状态和调度，并由商户确认 URL 后重新启用。

禁止结论（说了就算错）：

- 不得认定：410 与 400 一样走默认六次重试

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`、`KB-TS-023`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-013`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不符合；410 后 Endpoint 应立即 disabled，当前 Delivery 不再重试，后续 Event 不创建新 Delivery。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-11T12:00:00Z、`endpoint_id`=we_bm_062 | `exactly_one` |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-11T12:00:00Z、`event_id`=evt_bm_062 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-11T12:00:00Z、`delivery_id`=del_bm_062 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-11T12:00:00Z、`delivery_id`=del_bm_062 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-11T11:20:09.000Z` 事件 evt_bm_062 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 11 日 11:20 UTC，关联投递 1 个。
- `2026-08-11T11:50:00.000Z` 投递 del_bm_062 状态为 canceled，已尝试 1 次，终止原因是 无。
- `2026-08-11T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 11 日 11:50 UTC 返回 HTTP 410，结果状态 canceled

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_062 状态 disabled，重试策略 default。
- `get_event` 事件 evt_bm_062 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 11 日 11:20 UTC，关联投递 1 个。
- `get_delivery` 投递 del_bm_062 状态为 canceled，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 11 日 11:50 UTC 返回 HTTP 410，结果状态 canceled。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-032#c002`、`doc:KB-TS-023#c007`、`sql:webhook_endpoint:we_bm_062`、`sql:event:evt_bm_062`、`sql:webhook_delivery:del_bm_062`、`runtime:attempt:att_bm_062_01`

## FP-BM-DG-0252

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-063-webhook_default_retry_exhaustion`
- 快照时点 `as_of`：2026-08-12T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_default_retry_exhaustion`

### 开场白

> 客服转来一个问题：一个回调地址故障很久后，平台似乎已经停止继续投递。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认最终状态和 Attempt 数量应如何计算。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次投递首次失败且六个默认重试均返回 500。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 12 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_063，那次投递的编号是 del_bm_063 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先确认事件所属环境，以及账户当前套餐和主地区。 能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需查看回调实际尝试记录。大概何时发生，能提供事件或投递编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 最终应 exhausted；共有首次 Attempt 加六次重试，共七次 Attempt。 处理方式：停止继续投递并向商户展示完整失败时间线。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0252-A1` 最终应 exhausted；共有首次 Attempt 加六次重试，共七次 Attempt。
- `FP-BM-DG-0252-A2` 停止继续投递并向商户展示完整失败时间线。

禁止结论（说了就算错）：

- 不得认定：六次重试包含首次投递，所以总共只有六次 Attempt

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`
- 操作：`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：最终应 exhausted；共有首次 Attempt 加六次重试，共七次 Attempt。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-12T12:00:00Z、`delivery_id`=del_bm_063 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-12T12:00:00Z、`delivery_id`=del_bm_063 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-12T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 12 日 11:50 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-12T11:51:00.000Z` 第 2 次投递在 2026 年 08 月 12 日 11:51 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-12T11:55:00.000Z` 第 3 次投递在 2026 年 08 月 12 日 11:55 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-12T12:20:00.000Z` 第 4 次投递在 2026 年 08 月 12 日 12:20 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-12T13:50:00.000Z` 第 5 次投递在 2026 年 08 月 12 日 13:50 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-12T19:50:00.000Z` 第 6 次投递在 2026 年 08 月 12 日 19:50 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-13T11:50:00.000Z` 投递 del_bm_063 状态为 exhausted，已尝试 7 次，终止原因是 retry_exhausted。
- `2026-08-13T11:50:00.000Z` 第 7 次投递在 2026 年 08 月 13 日 11:50 UTC 返回 HTTP 500，结果状态 retrying

查到的实例事实：

- `get_delivery` 投递 del_bm_063 状态为 exhausted，已尝试 7 次，终止原因是 retry_exhausted。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 12 日 11:50 UTC 返回 HTTP 500，结果状态 retrying；第 2 次投递在 2026 年 08 月 12 日 11:51 UTC 返回 HTTP 500，结果状态 retrying；第 3 次投递在 2026 年 08 月 12 日 11:55 UTC 返回 HTTP 500，结果状态 retrying；第 4 次投递在 2026 年 08 月 12 日 12:20 UTC 返回 HTTP 500，结果状态 retrying；第 5 次投递在 2026 年 08 月 12 日 13:50 UTC 返回 HTTP 500，结果状态 retrying；第 6 次投递在 2026 年 08 月 12 日 19:50 UTC 返回 HTTP 500，结果状态 retrying；第 7 次投递在 2026 年 08 月 13 日 11:50 UTC 返回 HTTP 500，结果状态 retrying。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-032#c003`、`sql:webhook_delivery:del_bm_063`、`runtime:attempt:att_bm_063_01`、`runtime:attempt:att_bm_063_02`、`runtime:attempt:att_bm_063_03`、`runtime:attempt:att_bm_063_04`、`runtime:attempt:att_bm_063_05`、`runtime:attempt:att_bm_063_06`、`runtime:attempt:att_bm_063_07`

## FP-BM-DG-0256

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-064-scale_custom_retry`
- 快照时点 `as_of`：2026-08-13T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`scale_custom_retry`

### 开场白

> 我们排查时发现：我们给高级套餐配置了自己的回调重试节奏，但实际重试时间和预期不一致。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认两份配置是否有效。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Scale Account 这个账户先配置 9 次自定义重试，随后改为 8 次但总窗口为 80 小时。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Scale，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 13 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_064，这个回调地址的编号是 we_bm_064 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先确认事件所属环境，以及账户当前套餐和主地区。 能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 都无效：第一次超过 8 次上限，第二次的 80 小时超过 72 小时上限。 处理方式：将重试次数和总窗口同时控制在 Scale 的允许范围内。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0256-A1` 都无效：第一次超过 8 次上限，第二次的 80 小时超过 72 小时上限。
- `FP-BM-DG-0256-A2` 将重试次数和总窗口同时控制在 Scale 的允许范围内。

禁止结论（说了就算错）：

- 不得认定：满足次数上限就可以忽略套餐和总窗口

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_accounts_sql`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_accounts`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`、`KB-TS-010`
- 操作：`query_accounts.get_account`、`query_webhooks.get_endpoint`、`get_runtime_state.list_requests`
- 规则：`RULE-ENV-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-REGION-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`query_webhooks.get_endpoint`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：都无效：第一次超过 8 次上限，第二次的 80 小时超过 72 小时上限。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_064、`as_of`=2026-08-13T12:00:00Z | `exactly_one` |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-13T12:00:00Z、`endpoint_id`=we_bm_064 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_064、`as_of`=2026-08-13T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-13T11:49:59.000Z` 请求 req_bm_064_01 在 2026 年 08 月 13 日 11:49 UTC 以 PATCH 调用 /v1/webhook_endpoints/we_bm_064，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 retry_count=9、retry_window_hours=48
- `2026-08-13T11:50:00.000Z` 请求 req_26153730f5_000002 在 2026 年 08 月 13 日 11:50 UTC 以 PATCH 调用 /v1/webhook_endpoints/we_bm_064，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 retry_count=8、retry_window_hours=80

查到的实例事实：

- `get_account` 账户 acct_bm_064 当时套餐为 Scale、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_endpoint` 回调地址 we_bm_064 状态 enabled，重试策略 default。
- `list_requests` 请求 req_bm_064_01 在 2026 年 08 月 13 日 11:49 UTC 以 PATCH 调用 /v1/webhook_endpoints/we_bm_064，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 retry_count=9、retry_window_hours=48；请求 req_26153730f5_000002 在 2026 年 08 月 13 日 11:50 UTC 以 PATCH 调用 /v1/webhook_endpoints/we_bm_064，返回 HTTP 400、错误码 FP-4001，响应对象为 无，请求参数 retry_count=8、retry_window_hours=80。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-032#c003`、`doc:KB-TS-010#c007`、`sql:account:acct_bm_064`、`sql:webhook_endpoint:we_bm_064`、`runtime:req:req_bm_064_01`、`runtime:req:req_26153730f5_000002`

## FP-BM-DG-0260

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-065-webhook_at_least_once`
- 快照时点 `as_of`：2026-08-14T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_at_least_once`

### 开场白

> 线上同事发现：业务收到两次内容相同的回调，担心系统重复执行了付款逻辑。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认第二次是否代表发生了新的 Payment。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那个事件的首次 那次投递已被 Merchant 处理，但响应丢失导致 FlowPay 重试，Merchant 再次收到相同 Event ID。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 14 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_065，那个事件的编号是 evt_bm_065，那次投递的编号是 del_bm_065 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先确认事件所属环境，以及账户当前套餐和主地区。 能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不代表；这是同一 Event 的重复投递，应按 event_id 去重。 处理方式：接收端持久化已处理 event_id，并对重复请求安全返回 2xx。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0260-A1` 不代表；这是同一 Event 的重复投递，应按 event_id 去重。
- `FP-BM-DG-0260-A2` 接收端持久化已处理 event_id，并对重复请求安全返回 2xx。

禁止结论（说了就算错）：

- 不得认定：每个 Webhook 请求都代表一个新的业务事件

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-015`、`KB-API-032`
- 操作：`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不代表；这是同一 Event 的重复投递，应按 event_id 去重。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-14T12:00:00Z、`event_id`=evt_bm_065 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-14T12:00:00Z、`delivery_id`=del_bm_065 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-14T12:00:00Z、`delivery_id`=del_bm_065 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-14T11:20:09.000Z` 事件 evt_bm_065 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 14 日 11:20 UTC，关联投递 1 个。
- `2026-08-14T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 14 日 11:50 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-14T11:51:00.000Z` 投递 del_bm_065 状态为 delivered，已尝试 2 次，终止原因是 无。
- `2026-08-14T11:51:00.000Z` 第 2 次投递在 2026 年 08 月 14 日 11:51 UTC 返回 HTTP 200，结果状态 delivered

查到的实例事实：

- `get_event` 事件 evt_bm_065 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 14 日 11:20 UTC，关联投递 1 个。
- `get_delivery` 投递 del_bm_065 状态为 delivered，已尝试 2 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 14 日 11:50 UTC 返回 HTTP 500，结果状态 retrying；第 2 次投递在 2026 年 08 月 14 日 11:51 UTC 返回 HTTP 200，结果状态 delivered。

证据 ID：`doc:KB-BR-015#c008`、`doc:KB-API-032#c004`、`sql:event:evt_bm_065`、`sql:webhook_delivery:del_bm_065`、`runtime:attempt:att_bm_065_01`、`runtime:attempt:att_bm_065_02`

## FP-BM-DG-0264

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `dev`

- 场景：`SC-066-signature_header_by_version`
- 快照时点 `as_of`：2026-08-15T12:00:00Z　接口版本：2026-04-01
- 标签：`webhooks`、`signature_header_by_version`

### 开场白

> 我们排查时发现：升级回调版本后，验签程序突然找不到原来的签名请求头。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 3 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认FlowPay 是否未签名，还是接收端读取了错误 Header。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那个事件使用 当前部署使用的接口版本，这个回调地址的接收端仍只读取 X-FlowPay-Signature，因而报签名缺失。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 15 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-04-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_066，这个回调地址的编号是 we_bm_066，那个事件的编号是 evt_bm_066，那次投递的编号是 del_bm_066 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先确认事件所属环境，以及账户当前套餐和主地区。 这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`before_knowledge`，取 `api_version`）能确认当时客户端使用的接口版本吗？
3. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`api_version`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> FlowPay 使用了新版 FlowPay-Signature；接收端读取旧 Header 才是根因。 处理方式：按 Event API Version 读取对应 Header，并完成迁移。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0264-A1` FlowPay 使用了新版 FlowPay-Signature；接收端读取旧 Header 才是根因。
- `FP-BM-DG-0264-A2` 按 Event API Version 读取对应 Header，并完成迁移。

禁止结论（说了就算错）：

- 不得认定：所有 API Version 都同时发送两个签名 Header

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`release_notes`、`support_cases`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_release_notes`、`search_support_cases`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-016`、`KB-API-031`、`KB-REL-006`、`KB-CASE-008`
- 操作：`query_webhooks.get_event`、`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-WEBHOOK-013`、`RULE-WEBHOOK-014`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_release_notes`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_event`、`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：FlowPay 使用了新版 FlowPay-Signature；接收端读取旧 Header 才是根因。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-15T12:00:00Z、`event_id`=evt_bm_066 | `exactly_one` |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-15T12:00:00Z、`endpoint_id`=we_bm_066 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-15T12:00:00Z、`delivery_id`=del_bm_066 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-15T12:00:00Z、`delivery_id`=del_bm_066 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-15T11:20:09.000Z` 事件 evt_bm_066 类型为 payment.succeeded，版本 2026-04-01，产生于 2026 年 08 月 15 日 11:20 UTC，关联投递 1 个。
- `2026-08-15T11:50:00.000Z` 投递 del_bm_066 状态为 retrying，已尝试 1 次，终止原因是 无。
- `2026-08-15T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 15 日 11:50 UTC 返回 HTTP 400，结果状态 retrying，校验信息 client_error=header_missing、client_expected_header=X-FlowPay-Signature、sent_header=FlowPay-Signature

查到的实例事实：

- `get_event` 事件 evt_bm_066 类型为 payment.succeeded，版本 2026-04-01，产生于 2026 年 08 月 15 日 11:20 UTC，关联投递 1 个。
- `get_endpoint` 回调地址 we_bm_066 状态 enabled，重试策略 default。
- `get_delivery` 投递 del_bm_066 状态为 retrying，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 15 日 11:50 UTC 返回 HTTP 400，结果状态 retrying，校验信息 client_error=header_missing、client_expected_header=X-FlowPay-Signature、sent_header=FlowPay-Signature。

证据 ID：`doc:KB-BR-016#c003`、`doc:KB-API-031#c002`、`doc:KB-REL-006#c003`、`doc:KB-CASE-008#c001`、`sql:event:evt_bm_066`、`sql:webhook_endpoint:we_bm_066`、`sql:webhook_delivery:del_bm_066`、`runtime:attempt:att_bm_066_01`

## FP-BM-DG-0268

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-067-signature_timestamp_tolerance`
- 快照时点 `as_of`：2026-08-16T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`signature_timestamp_tolerance`

### 开场白

> 回调内容和密钥看起来都对，但验签仍提示时间不合法。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认是否应该接受这次请求。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次投递的签名摘要正确，但接收端验证时与 signature_timestamp 相差 8 分钟。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 16 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_067，这个回调地址的编号是 we_bm_067，那次投递的编号是 del_bm_067 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）先确认事件所属环境，以及账户当前套餐和主地区。 这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应该；8 分钟超过默认 5 分钟容差。 处理方式：校准服务器时钟，并在 5 分钟内完成验证。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0268-A1` 不应该；8 分钟超过默认 5 分钟容差。
- `FP-BM-DG-0268-A2` 校准服务器时钟，并在 5 分钟内完成验证。

禁止结论（说了就算错）：

- 不得认定：只要 HMAC 正确就可以忽略时间戳

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-016`、`KB-API-031`、`KB-TS-023`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-013`、`RULE-WEBHOOK-014`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应该；8 分钟超过默认 5 分钟容差。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-16T12:00:00Z、`endpoint_id`=we_bm_067 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-16T12:00:00Z、`delivery_id`=del_bm_067 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-16T12:00:00Z、`delivery_id`=del_bm_067 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-16T11:50:00.000Z` 投递 del_bm_067 状态为 retrying，已尝试 1 次，终止原因是 无。
- `2026-08-16T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 16 日 11:50 UTC 返回 HTTP 400，结果状态 retrying，校验信息 timestamp_skew_seconds=480、verification_time=2026-08-16T11:50:00.000Z

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_067 状态 enabled，重试策略 default。
- `get_delivery` 投递 del_bm_067 状态为 retrying，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 16 日 11:50 UTC 返回 HTTP 400，结果状态 retrying，校验信息 timestamp_skew_seconds=480、verification_time=2026-08-16T11:50:00.000Z。

证据 ID：`doc:KB-BR-016#c006`、`doc:KB-API-031#c003`、`doc:KB-TS-023#c007`、`sql:webhook_endpoint:we_bm_067`、`sql:webhook_delivery:del_bm_067`、`runtime:attempt:att_bm_067_01`

## FP-BM-DG-0272

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-068-signing_secret_rotation_window`
- 快照时点 `as_of`：2026-08-17T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`signing_secret_rotation_window`

### 开场白

> 客户那边反馈：我们正在轮换回调密钥，担心切换期间旧实例会突然验签失败。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认新投递能否继续只用旧 Secret 验证。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个回调地址在 10:00 轮换 Secret；10:05 的新 那次投递使用新版本，接收端仅配置旧 Secret。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 17 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_068，这个回调地址的编号是 we_bm_068，那次投递的编号是 del_bm_068 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个回调来自测试还是正式环境？账户套餐和主地区是什么？ 为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需查看回调实际尝试记录。大概何时发生，能提供事件或投递编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；新投递立即使用新 Secret。旧 Secret 的 24 小时窗口只用于兼容验证旧签名。 处理方式：接收端在过渡期同时接受新旧 Secret，并优先部署新 Secret。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0272-A1` 不能；新投递立即使用新 Secret。旧 Secret 的 24 小时窗口只用于兼容验证旧签名。
- `FP-BM-DG-0272-A2` 接收端在过渡期同时接受新旧 Secret，并优先部署新 Secret。

禁止结论（说了就算错）：

- 不得认定：24 小时内所有新投递仍由旧 Secret 签名

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-016`、`KB-API-031`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-WEBHOOK-013`、`RULE-WEBHOOK-014`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；新投递立即使用新 Secret。旧 Secret 的 24 小时窗口只用于兼容验证旧签名。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-17T12:00:00Z、`endpoint_id`=we_bm_068 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-17T12:00:00Z、`delivery_id`=del_bm_068 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-17T12:00:00Z、`delivery_id`=del_bm_068 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-17T11:50:00.000Z` 投递 del_bm_068 状态为 retrying，已尝试 1 次，终止原因是 无。
- `2026-08-17T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 17 日 11:50 UTC 返回 HTTP 401，结果状态 retrying

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_068 状态 enabled，重试策略 default。
- `get_delivery` 投递 del_bm_068 状态为 retrying，已尝试 1 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 17 日 11:50 UTC 返回 HTTP 401，结果状态 retrying。

证据 ID：`doc:KB-BR-016#c006`、`doc:KB-API-031#c005`、`sql:webhook_endpoint:we_bm_068`、`sql:webhook_delivery:del_bm_068`、`runtime:attempt:att_bm_068_01`

## FP-BM-DG-0276

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-069-webhook_retry_resigned`
- 快照时点 `as_of`：2026-08-18T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_retry_resigned`

### 开场白

> 客户那边反馈：同一个回调事件重试时签名发生了变化，接收方把它当成篡改。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认重试应使用旧 Secret 还是新 Secret。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次投递首次失败后，这个回调地址在下一次重试前轮换 Secret。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 18 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_069，这个回调地址的编号是 we_bm_069，那次投递的编号是 del_bm_069 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个回调来自测试还是正式环境？账户套餐和主地区是什么？ 先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还需查看回调实际尝试记录。大概何时发生，能提供事件或投递编号吗？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应使用重试时的当前新 Secret重新签名。 处理方式：接收端在轮换窗口同时接受新旧 Secret，并逐次按 Header 验证。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0276-A1` 应使用重试时的当前新 Secret重新签名。
- `FP-BM-DG-0276-A2` 接收端在轮换窗口同时接受新旧 Secret，并逐次按 Header 验证。

禁止结论（说了就算错）：

- 不得认定：同一 Delivery 的所有 Attempt 必须复用第一次签名

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`release_notes`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_release_notes`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-016`、`KB-API-031`、`KB-REL-006`
- 操作：`query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-WEBHOOK-013`、`RULE-WEBHOOK-014`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_release_notes`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_webhooks.get_endpoint`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应使用重试时的当前新 Secret重新签名。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-18T12:00:00Z、`endpoint_id`=we_bm_069 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-18T12:00:00Z、`delivery_id`=del_bm_069 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-18T12:00:00Z、`delivery_id`=del_bm_069 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-18T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 18 日 11:50 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-18T11:51:00.000Z` 投递 del_bm_069 状态为 delivered，已尝试 2 次，终止原因是 无。
- `2026-08-18T11:51:00.000Z` 第 2 次投递在 2026 年 08 月 18 日 11:51 UTC 返回 HTTP 200，结果状态 delivered

查到的实例事实：

- `get_endpoint` 回调地址 we_bm_069 状态 enabled，重试策略 default。
- `get_delivery` 投递 del_bm_069 状态为 delivered，已尝试 2 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 18 日 11:50 UTC 返回 HTTP 500，结果状态 retrying；第 2 次投递在 2026 年 08 月 18 日 11:51 UTC 返回 HTTP 200，结果状态 delivered。

证据 ID：`doc:KB-BR-016#c003`、`doc:KB-API-031#c005`、`doc:KB-REL-006#c005`、`sql:webhook_endpoint:we_bm_069`、`sql:webhook_delivery:del_bm_069`、`runtime:attempt:att_bm_069_01`、`runtime:attempt:att_bm_069_02`

## FP-BM-DG-0280

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-070-distinguish_500_and_503`
- 快照时点 `as_of`：2026-08-19T12:00:00Z　接口版本：2026-07-01
- 标签：`operations`、`distinguish_500_and_503`

### 开场白

> 我们排查时发现：线上请求有时返回内部错误，有时又显示服务暂不可用，我们不知道处理方式是否一样。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认两类错误是否应归为同一个 Merchant 配置问题。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户的一个 那次请求返回 FP-5001，随后同地区大量请求返回 FP-5031 并存在 这次服务异常。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 19 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_070，那次请求的编号是 req_bm_070_01，这次服务异常的编号是 inc_bm_070 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）受影响的是测试还是真实流量？账户套餐和主要地区是什么？ 先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）需要查看当时的运行记录。请提供大概时间和请求编号；如果有地区异常编号也可以一并提供。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不应；单次 FP-5001 与区域性 FP-5031 需要分别判断，后者由服务 Incident 支持。 处理方式：查询 Request ID、服务状态和影响范围；幂等请求按规则安全重试。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0280-A1` 不应；单次 FP-5001 与区域性 FP-5031 需要分别判断，后者由服务 Incident 支持。
- `FP-BM-DG-0280-A2` 查询 Request ID、服务状态和影响范围；幂等请求按规则安全重试。

禁止结论（说了就算错）：

- 不得认定：所有 5xx 都说明 Webhook Endpoint 配置错误

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`support_cases`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_support_cases`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-011`、`KB-API-008`、`KB-TS-017`、`KB-TS-018`、`KB-TS-024`、`KB-CASE-016`
- 操作：`query_accounts.get_account`、`get_runtime_state.get_request`、`get_runtime_state.list_requests`、`get_runtime_state.get_service_status`
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-IDEMP-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-005`、`RULE-RATE-007`、`RULE-REQ-001`、`RULE-VERSION-004`、`RULE-WEBHOOK-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`、`search_troubleshooting`、`search_troubleshooting`、`search_support_cases`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`get_runtime_state.get_request`、`get_runtime_state.list_requests`、`get_runtime_state.get_service_status`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不应；单次 FP-5001 与区域性 FP-5031 需要分别判断，后者由服务 Incident 支持。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_070、`as_of`=2026-08-19T12:00:00Z | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-19T12:00:00Z、`request_id`=req_bm_070_01 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_070、`as_of`=2026-08-19T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |
| `get_service_status` | `runtime` | `get_runtime_state.get_service_status` | `as_of`=2026-08-19T12:00:00Z、`incident_id`=inc_bm_070 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-19T11:47:00.000Z` 请求 req_bm_070_01 在 2026 年 08 月 19 日 11:47 UTC 以 POST 调用 /v1/payments，返回 HTTP 500、错误码 FP-5001，响应对象为 无
- `2026-08-19T11:47:00.000Z` 请求 req_bm_070_01 在 2026 年 08 月 19 日 11:47 UTC 以 POST 调用 /v1/payments，返回 HTTP 500、错误码 FP-5001，响应对象为 无
- `2026-08-19T11:50:00.000Z` 请求 req_603a57f99d_000002 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 503、错误码 FP-5031，响应对象为 无
- `2026-08-19T11:50:10.000Z` 请求 req_603a57f99d_000003 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 503、错误码 FP-5031，响应对象为 无
- `2026-08-19T11:50:20.000Z` 请求 req_603a57f99d_000004 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 503、错误码 FP-5031，响应对象为 无

查到的实例事实：

- `get_account` 账户 acct_bm_070 当时套餐为 Growth、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_request` 请求 req_bm_070_01 在 2026 年 08 月 19 日 11:47 UTC 以 POST 调用 /v1/payments，返回 HTTP 500、错误码 FP-5001，响应对象为 无。
- `list_requests` 请求 req_bm_070_01 在 2026 年 08 月 19 日 11:47 UTC 以 POST 调用 /v1/payments，返回 HTTP 500、错误码 FP-5001，响应对象为 无；请求 req_603a57f99d_000002 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 503、错误码 FP-5031，响应对象为 无；请求 req_603a57f99d_000003 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 503、错误码 FP-5031，响应对象为 无；请求 req_603a57f99d_000004 在 2026 年 08 月 19 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 503、错误码 FP-5031，响应对象为 无。
- `get_service_status` 服务 payments 在 NA 存在状态为 active 的服务事件，影响从 2026 年 08 月 19 日 11:20 UTC 开始。

证据 ID：`doc:KB-BR-011#c005`、`doc:KB-API-008#c003`、`doc:KB-TS-017#c007`、`doc:KB-TS-018#c007`、`doc:KB-TS-024#c007`、`doc:KB-CASE-016#c010`、`sql:account:acct_bm_070`、`runtime:req:req_bm_070_01`、`runtime:req:req_603a57f99d_000002`、`runtime:req:req_603a57f99d_000003`、`runtime:req:req_603a57f99d_000004`、`runtime:incident:inc_bm_070`

## FP-BM-DG-0284

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `dev`

- 场景：`SC-071-regional_service_incident`
- 快照时点 `as_of`：2026-08-20T12:00:00Z　接口版本：2026-07-01
- 标签：`operations`、`regional_service_incident`

### 开场白

> 我们排查时发现：只有某个地区的线上请求明显变慢并报错，其他地区基本正常。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认问题范围是单个 Account 还是区域服务。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | NA payments 服务在时间窗内有 这次服务异常；NA 多个 Account 返回 FP-5031，EU 同类请求正常。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 20 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_071，这次服务异常的编号是 inc_bm_071 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）受影响的是测试还是真实流量？账户套餐和主要地区是什么？ 为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）下一步要核对服务状态和请求轨迹。问题大概何时发生，请求号是什么？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 证据表明是 NA 区域 payments 服务降级，不是单个 Account 配置。 处理方式：按 Incident 时间线沟通影响，并在恢复后使用幂等重试。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0284-A1` 证据表明是 NA 区域 payments 服务降级，不是单个 Account 配置。
- `FP-BM-DG-0284-A2` 按 Incident 时间线沟通影响，并在恢复后使用幂等重试。

禁止结论（说了就算错）：

- 不得认定：某个 Account 最先报告就说明只有该账户受影响

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`troubleshooting`、`runtime`
- 工具：`search_business_rules`、`search_troubleshooting`、`get_runtime_state`
- 文档：`KB-BR-011`、`KB-TS-018`、`KB-TS-024`
- 操作：`get_runtime_state.list_requests`、`get_runtime_state.get_service_status`
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-IDEMP-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-005`、`RULE-RATE-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_troubleshooting`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `get_runtime_state.list_requests`、`get_runtime_state.get_service_status`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：证据表明是 NA 区域 payments 服务降级，不是单个 Account 配置。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_071、`as_of`=2026-08-20T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |
| `get_service_status` | `runtime` | `get_runtime_state.get_service_status` | `as_of`=2026-08-20T12:00:00Z、`incident_id`=inc_bm_071 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-20T11:50:00.000Z` 请求 req_bm_071_01 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 503、错误码 FP-5031，响应对象为 无

查到的实例事实：

- `list_requests` 请求 req_bm_071_01 在 2026 年 08 月 20 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 503、错误码 FP-5031，响应对象为 无。
- `get_service_status` 服务 payments 在 NA 存在状态为 active 的服务事件，影响从 2026 年 08 月 20 日 11:20 UTC 开始。

证据 ID：`doc:KB-BR-011#c005`、`doc:KB-TS-018#c003`、`doc:KB-TS-024#c003`、`runtime:req:req_bm_071_01`、`runtime:incident:inc_bm_071`

## FP-BM-DG-0288

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-072-request_id_before_auth`
- 快照时点 `as_of`：2026-08-21T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`request_id_before_auth`

### 开场白

> 我们排查时发现：请求在认证阶段就失败了，开发同学说因此没法继续排查。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认这次失败是否应有 Request ID。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那次请求使用格式错误的那把密钥，返回 FP-4011；客户端认为认证失败所以不可能查询请求日志。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 21 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_072，那次请求的编号是 req_bm_072_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）请求发往测试还是正式环境？相关账户的套餐和主地区是什么？ 先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）接下来需要查看当时的请求。请给一个大概时间范围，以及相关账户或请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 应有；Request ID 在认证前分配，可用于查询脱敏日志，但不等于资源 ID。 处理方式：记录响应中的 Request ID，并据此查询失败阶段。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0288-A1` 应有；Request ID 在认证前分配，可用于查询脱敏日志，但不等于资源 ID。
- `FP-BM-DG-0288-A2` 记录响应中的 Request ID，并据此查询失败阶段。

禁止结论（说了就算错）：

- 不得认定：只有成功认证后才生成 Request ID

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-006`、`KB-API-007`、`KB-API-008`、`KB-TS-004`、`KB-TS-019`
- 操作：`query_accounts.list_api_keys`、`get_runtime_state.get_request`、`get_runtime_state.list_requests`
- 规则：`RULE-AUTH-001`、`RULE-AUTH-002`、`RULE-AUTH-003`、`RULE-AUTH-004`、`RULE-AUTH-005`、`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-001`、`RULE-ENV-005`、`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-REQ-001`、`RULE-REQ-002`、`RULE-REQ-003`、`RULE-VERSION-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_api_docs`、`search_troubleshooting`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.list_api_keys`、`get_runtime_state.get_request`、`get_runtime_state.list_requests`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：应有；Request ID 在认证前分配，可用于查询脱敏日志，但不等于资源 ID。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `list_api_keys` | `sql` | `query_accounts.list_api_keys` | `account_id`=acct_bm_072、`as_of`=2026-08-21T12:00:00Z | `at_least_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-21T12:00:00Z、`request_id`=req_bm_072_01 | `exactly_one` |
| `list_requests` | `runtime` | `get_runtime_state.list_requests` | `account_id`=acct_bm_072、`as_of`=2026-08-21T12:00:00Z、`window`=scenario_observation_window | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-21T11:50:00.000Z` 请求 req_bm_072_01 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 401、错误码 FP-4011，响应对象为 无
- `2026-08-21T11:50:00.000Z` 请求 req_bm_072_01 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 401、错误码 FP-4011，响应对象为 无

查到的实例事实：

- `list_api_keys` 账户在该范围查到 1 把 API Key：active 1 条。
- `get_request` 请求 req_bm_072_01 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 401、错误码 FP-4011，响应对象为 无。
- `list_requests` 请求 req_bm_072_01 在 2026 年 08 月 21 日 11:50 UTC 以 POST 调用 /v1/scenario，返回 HTTP 401、错误码 FP-4011，响应对象为 无。

证据 ID：`doc:KB-BR-006#c002`、`doc:KB-API-007#c002`、`doc:KB-API-008#c003`、`doc:KB-TS-004#c007`、`doc:KB-TS-019#c001`、`sql:api_key:key_bm_072`、`runtime:req:req_bm_072_01`

## FP-BM-DG-0292

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-073-resource_not_visible_semantics`
- 快照时点 `as_of`：2026-08-22T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`resource_not_visible_semantics`

### 开场白

> 客户那边反馈：查询资源时统一提示不存在，但我们不确定是编号错了还是权限问题。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认能否据此断言 Payment 已被删除。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 这个账户的 Sandbox Key 查询一个 Production 那笔支付，得到 FP-4041。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在测试环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 22 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_073，那笔支付的编号是 pay_bm_073，那次请求的编号是 req_bm_073_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这次调用对应哪个环境？也请补充账户套餐和主地区。 能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）还要核对客户端调用记录。大概何时发生，能否提供请求编号？

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；环境或租户不可见与真实不存在共享该语义。 处理方式：先核对 Key、Account、Environment 和资源 ID，不要求平台泄漏所有权。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0292-A1` 不能；环境或租户不可见与真实不存在共享该语义。
- `FP-BM-DG-0292-A2` 先核对 Key、Account、Environment 和资源 ID，不要求平台泄漏所有权。

禁止结论（说了就算错）：

- 不得认定：FP-4041 会精确告诉调用方资源属于哪个环境

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_accounts_sql`、`query_payments_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_accounts`、`query_payments`、`get_runtime_state`
- 文档：`KB-BR-001`、`KB-API-014`、`KB-TS-012`
- 操作：`query_accounts.list_api_keys`、`query_payments.get_payment`、`get_runtime_state.get_request`
- 规则：`RULE-ENV-001`、`RULE-PAY-001`、`RULE-REQ-003`、`RULE-TENANT-001`、`RULE-TENANT-002`、`RULE-TENANT-003`、`RULE-TENANT-004`、`RULE-VERSION-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.list_api_keys`、`query_payments.get_payment`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；环境或租户不可见与真实不存在共享该语义。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `list_api_keys` | `sql` | `query_accounts.list_api_keys` | `account_id`=acct_bm_073、`as_of`=2026-08-22T12:00:00Z | `at_least_one` |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-22T12:00:00Z、`payment_id`=pay_bm_073 | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-22T12:00:00Z、`request_id`=req_bm_073_01 | `exactly_one` |

### 快照里的实况

时间线：

- `2026-08-22T11:50:00.000Z` 请求 req_bm_073_01 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 404、错误码 FP-4041，响应对象为 无

查到的实例事实：

- `list_api_keys` 账户在该范围查到 1 把 API Key：active 1 条。
- `get_payment` 在限定范围（as_of=2026-08-22T12:00:00Z、payment_id=pay_bm_073、account_id=acct_bm_073、environment=sandbox）内没有查到 get_payment 对应记录。
- `get_request` 请求 req_bm_073_01 在 2026 年 08 月 22 日 11:50 UTC 以 POST 调用 /v1/payments，返回 HTTP 404、错误码 FP-4041，响应对象为 无。

证据 ID：`doc:KB-BR-001#c003`、`doc:KB-API-014#c007`、`doc:KB-TS-012#c008`、`sql:api_key:key_bm_073`、`negative:sql:payment:452833d92c7b6a86a7b2`、`runtime:req:req_bm_073_01`

## FP-BM-DG-0296

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-074-runtime_retention_by_plan`
- 快照时点 `as_of`：2026-08-23T12:00:00Z　接口版本：2026-07-01
- 标签：`operations`、`runtime_retention_by_plan`

### 开场白

> 线上同事发现：我们想排查一段时间以前的请求，但控制台已经查不到记录了。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认能否根据仍然可见的业务对象还原这次请求的完整日志内容。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | Starter Account 这个账户查询 20 天前的请求 那次请求时返回 retention_exceeded，但相关业务对象现在仍然可以看到。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Starter，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 23 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_074，那次请求的编号是 req_bm_074_01 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）异常出现在哪个环境和地区？相关账户是什么套餐？ 能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了区分单次错误和区域异常，请补充时间范围、地区和可用的请求编号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> 不能；Starter 的请求记录查询范围只有 7 天，业务对象仍然可见不等于完整请求日志仍可查询。 处理方式：说明当前可查询的时间范围；如需更长历史，应提前采用符合产品规则的长期留存方案。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0296-A1` 不能；Starter 的请求记录查询范围只有 7 天，业务对象仍然可见不等于完整请求日志仍可查询。
- `FP-BM-DG-0296-A2` 说明当前可查询的时间范围；如需更长历史，应提前采用符合产品规则的长期留存方案。

禁止结论（说了就算错）：

- 不得认定：只要业务对象还在，就一定能还原完整历史请求日志

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`troubleshooting`、`query_accounts_sql`、`runtime`
- 工具：`search_business_rules`、`search_troubleshooting`、`query_accounts`、`get_runtime_state`
- 文档：`KB-BR-004`、`KB-TS-022`
- 操作：`query_accounts.get_account`、`get_runtime_state.get_request`
- 规则：`RULE-PLAN-001`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_accounts.get_account`、`get_runtime_state.get_request`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：不能；Starter 的请求记录查询范围只有 7 天，业务对象仍然可见不等于完整请求日志仍可查询。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_account` | `sql` | `query_accounts.get_account` | `account_id`=acct_bm_074、`as_of`=2026-08-23T12:00:00Z | `exactly_one` |
| `get_request` | `runtime` | `get_runtime_state.get_request` | `as_of`=2026-08-23T12:00:00Z、`request_id`=req_bm_074_01 | `exactly_one` |

### 快照里的实况

查到的实例事实：

- `get_account` 账户 acct_bm_074 当时套餐为 Starter、主地区为 NA，Production 状态为 active，默认接口版本为 2026-07-01。
- `get_request` 请求日志已超过当前套餐的保留范围；现存日志最早从 2026 年 08 月 16 日 12:00 UTC 开始，因此编号 req_bm_074_01 的日志正文不能被返回。

证据 ID：`doc:KB-BR-004#c005`、`doc:KB-TS-022#c002`、`sql:account:acct_bm_074`、`negative:runtime:api_request:29ae4ccb0ec8b0c646ad`

## FP-BM-DG-0300

**工具诊断**（`tool_use_diagnostic`） · 难度 5 · 多轮 · `test`

- 场景：`SC-075-payment_to_webhook_end_to_end`
- 快照时点 `as_of`：2026-08-24T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`payment_to_webhook_end_to_end`

### 开场白

> 我们排查时发现：客户已经付款成功，但业务系统一直没有收到对应的回调通知。基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。

### 对话脚本（最多追问 2 轮）

开场只说表面现象，其余条件要助手自己问。

模拟用户手里的事实——**问到哪一类才说哪一类**：

| 类别 | 助手问到这些词才披露 | 用户会说 |
| --- | --- | --- |
| `goal` | 想确认什么、希望解决什么、具体问题 | 我们主要想确认应如何给出最终业务结论和 Webhook 投递结论。 |
| `symptom_details` | 具体现象、报错、状态、操作步骤、发生了什么 | 那笔支付已 succeeded 并生成 那个事件；这个回调地址已订阅正确事件，那次投递首次 500、重试 204。商户却认为 Payment 失败。 |
| `account_context` | 环境、套餐、地区、账户情况 | 发生在正式环境；账户套餐是 Growth，主地区是 NA。 |
| `occurrence_time` | 什么时候、大概时间、时间范围 | 大概是 8 月 24 日中午前后，只能确定到这个时间范围。 |
| `api_version` | 接口版本、API 版本、版本请求头 | 部署配置里显示使用的接口版本是 2026-07-01。 |
| `identifiers` | 相关编号、请求编号、对象编号、ID | 这个账户的编号是 acct_bm_075，那笔支付的编号是 pay_bm_075，这个回调地址的编号是 we_bm_075，那个事件的编号是 evt_bm_075，那次投递的编号是 del_bm_075 |

预设的追问节奏：

1. （`before_knowledge`，取 `goal`、`symptom_details`、`account_context`）这个回调来自测试还是正式环境？账户套餐和主地区是什么？ 先补充一下实际表现：做了什么操作，随后看到了什么结果？
2. （`after_knowledge`，取 `occurrence_time`、`identifiers`）为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。

必须问全的类别：`goal`、`symptom_details`、`account_context`、`occurrence_time`、`identifiers`

### 判分标准

标准答案：

> Payment 已成功；Webhook 首次失败但重试 204 后 delivered。投递故障不能反推 Payment 失败。 处理方式：分别引用 Payment、Event、Endpoint 和 Delivery Timeline，按 event_id 做幂等处理。

必需结论（全部要被证据支持）：

- `FP-BM-DG-0300-A1` Payment 已成功；Webhook 首次失败但重试 204 后 delivered。投递故障不能反推 Payment 失败。
- `FP-BM-DG-0300-A2` 分别引用 Payment、Event、Endpoint 和 Delivery Timeline，按 event_id 做幂等处理。

禁止结论（说了就算错）：

- 不得认定：没在首次收到 Webhook 就说明 Payment 未成功

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`、`troubleshooting`、`query_payments_sql`、`query_webhooks_sql`、`runtime`
- 工具：`search_business_rules`、`search_api_docs`、`search_troubleshooting`、`query_payments`、`query_webhooks`、`get_runtime_state`
- 文档：`KB-BR-010`、`KB-BR-015`、`KB-API-013`、`KB-API-030`、`KB-API-032`、`KB-TS-023`
- 操作：`query_payments.get_payment`、`query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
- 规则：`RULE-ENV-004`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-PAY-007`、`RULE-PLAN-003`、`RULE-REGION-001`、`RULE-VERSION-005`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-013`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_business_rules`、`search_api_docs`、`search_api_docs`、`search_api_docs`、`search_troubleshooting`
2. 使用用户提供或前一步发现的编号查询对象、请求与运行轨迹　→ `query_payments.get_payment`、`query_webhooks.get_endpoint`、`query_webhooks.get_event`、`query_webhooks.get_delivery`、`get_runtime_state.get_delivery_timeline`
3. 先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案
   - 应得出：Payment 已成功；Webhook 首次失败但重试 204 后 delivered。投递故障不能反推 Payment 失败。

证据取值口径：

| 别名 | 来源 | 工具.操作 | 条件 | 条数 |
| --- | --- | --- | --- | --- |
| `get_payment` | `sql` | `query_payments.get_payment` | `as_of`=2026-08-24T12:00:00Z、`payment_id`=pay_bm_075 | `exactly_one` |
| `get_endpoint` | `sql` | `query_webhooks.get_endpoint` | `as_of`=2026-08-24T12:00:00Z、`endpoint_id`=we_bm_075 | `exactly_one` |
| `get_event` | `sql` | `query_webhooks.get_event` | `as_of`=2026-08-24T12:00:00Z、`event_id`=evt_bm_075 | `exactly_one` |
| `get_delivery` | `sql` | `query_webhooks.get_delivery` | `as_of`=2026-08-24T12:00:00Z、`delivery_id`=del_bm_075 | `exactly_one` |
| `get_delivery_timeline` | `runtime` | `get_runtime_state.get_delivery_timeline` | `as_of`=2026-08-24T12:00:00Z、`delivery_id`=del_bm_075 | `at_least_one` |

### 快照里的实况

时间线：

- `2026-08-24T11:20:04.000Z` 支付 pay_bm_075 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000
- `2026-08-24T11:20:09.000Z` 事件 evt_bm_075 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 24 日 11:20 UTC，关联投递 1 个。
- `2026-08-24T11:50:00.000Z` 第 1 次投递在 2026 年 08 月 24 日 11:50 UTC 返回 HTTP 500，结果状态 retrying
- `2026-08-24T11:51:00.000Z` 投递 del_bm_075 状态为 delivered，已尝试 2 次，终止原因是 无。
- `2026-08-24T11:51:00.000Z` 第 2 次投递在 2026 年 08 月 24 日 11:51 UTC 返回 HTTP 204，结果状态 delivered

查到的实例事实：

- `get_payment` 支付 pay_bm_075 状态 succeeded，金额 10000 USD，已占用退款额度 0、当前可退 10000。
- `get_endpoint` 回调地址 we_bm_075 状态 enabled，重试策略 default。
- `get_event` 事件 evt_bm_075 类型为 payment.succeeded，版本 2026-07-01，产生于 2026 年 08 月 24 日 11:20 UTC，关联投递 1 个。
- `get_delivery` 投递 del_bm_075 状态为 delivered，已尝试 2 次，终止原因是 无。
- `get_delivery_timeline` 投递轨迹：第 1 次投递在 2026 年 08 月 24 日 11:50 UTC 返回 HTTP 500，结果状态 retrying；第 2 次投递在 2026 年 08 月 24 日 11:51 UTC 返回 HTTP 204，结果状态 delivered。

证据 ID：`doc:KB-BR-010#c007`、`doc:KB-BR-015#c008`、`doc:KB-API-013#c004`、`doc:KB-API-030#c004`、`doc:KB-API-032#c002`、`doc:KB-TS-023#c002`、`sql:payment:pay_bm_075`、`sql:webhook_endpoint:we_bm_075`、`sql:event:evt_bm_075`、`sql:webhook_delivery:del_bm_075`、`runtime:attempt:att_bm_075_01`、`runtime:attempt:att_bm_075_02`
