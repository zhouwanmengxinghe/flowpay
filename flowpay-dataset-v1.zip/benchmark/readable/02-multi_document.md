# 跨文档　`multi_document`　50 道

## FP-BM-MD-0002

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `dev`

- 场景：`SC-001-cross_tenant_payment_visibility`
- 快照时点 `as_of`：2026-08-02T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`cross_tenant_payment_visibility`

### 题面

> 请帮忙确认一下。这个账户使用自己的 Production Key 查询另一个 Account 所属的那笔支付，请求得到 FP-4041。我们想知道FP-4041 是否能证明 Payment ID 不存在，以及应如何判断这次访问？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不能证明 ID 不存在；该访问越过租户边界，应拒绝且不得泄漏目标资源是否存在。 处理方式：核对调用 Key 的 Account、环境和 Payment 所属关系，不要尝试枚举其他租户资源。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0002-A1` 不能证明 ID 不存在；该访问越过租户边界，应拒绝且不得泄漏目标资源是否存在。
- `FP-BM-MD-0002-A2` 核对调用 Key 的 Account、环境和 Payment 所属关系，不要尝试枚举其他租户资源。

禁止结论（说了就算错）：

- 不得认定：把 FP-4041 直接解释为 Payment ID 拼写错误

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`、`troubleshooting`
- 工具：`search_api_docs`、`search_troubleshooting`
- 文档：`KB-API-014`、`KB-TS-012`
- 操作：—
- 规则：`RULE-ENV-001`、`RULE-PAY-001`、`RULE-REQ-003`、`RULE-TENANT-002`、`RULE-TENANT-003`、`RULE-TENANT-004`、`RULE-VERSION-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-API-014#c007`、`doc:KB-TS-012#c007`

## FP-BM-MD-0006

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-002-sandbox_key_on_production`
- 快照时点 `as_of`：2026-08-03T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`sandbox_key_on_production`

### 题面

> 请帮忙确认一下。这个账户的部署加载了 Sandbox Key，却尝试为 Production Customer 这位客户创建 Payment，那次请求返回 FP-4012。我们想知道根因是 Key 无效、Customer 不存在还是环境不匹配？同时应该采取什么处理方式？

### 判分标准

标准答案：

> Key 本身有效，但 Key 属于 Sandbox、Customer 属于 Production，因此是环境不匹配。 处理方式：替换为该 Account 的有效 Production Key；不要复制 Sandbox 资源作为修复。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0006-A1` Key 本身有效，但 Key 属于 Sandbox、Customer 属于 Production，因此是环境不匹配。
- `FP-BM-MD-0006-A2` 替换为该 Account 的有效 Production Key；不要复制 Sandbox 资源作为修复。

禁止结论（说了就算错）：

- 不得认定：只要 Key 有效就可以跨环境调用

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`support_cases`、`api_docs`
- 工具：`search_support_cases`、`search_api_docs`
- 文档：`KB-CASE-001`、`KB-API-001`
- 操作：—
- 规则：`RULE-AUTH-001`、`RULE-AUTH-002`、`RULE-ENV-001`、`RULE-ENV-002`、`RULE-ENV-005`、`RULE-REQ-001`、`RULE-TENANT-004`、`RULE-VERSION-001`、`RULE-VERSION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_support_cases`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-CASE-001#c007`、`doc:KB-API-001#c006`

## FP-BM-MD-0010

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-003-production_not_enabled`
- 快照时点 `as_of`：2026-08-04T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`production_not_enabled`

### 题面

> 目前能确认的是：Starter Account 这个账户尚未启用 Production，却请求创建那把密钥。接下来需要判断该 Key 创建是否应成功，套餐是否是拒绝原因？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 创建应被拒绝；原因是 Production 尚未启用，而不是 Starter 套餐不支持一次性支付。 处理方式：先完成 Production 启用，再创建新的 Production Key。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0010-A1` 创建应被拒绝；原因是 Production 尚未启用，而不是 Starter 套餐不支持一次性支付。
- `FP-BM-MD-0010-A2` 先完成 Production 启用，再创建新的 Production Key。

禁止结论（说了就算错）：

- 不得认定：Starter 套餐永远不能启用 Production

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`、`troubleshooting`
- 工具：`search_api_docs`、`search_troubleshooting`
- 文档：`KB-API-005`、`KB-TS-010`
- 操作：—
- 规则：`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-003`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-004`、`RULE-REGION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-API-005#c002`、`doc:KB-TS-010#c007`

## FP-BM-MD-0014

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-004-production_suspended`
- 快照时点 `as_of`：2026-08-05T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`production_suspended`

### 题面

> 请帮忙确认一下。这个账户仍持有 active 的那把密钥，Production 请求 那次请求全部返回 FP-4032，而 Sandbox 请求正常。我们想知道这是 Key 被撤销、套餐降级还是 Production 被暂停？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 证据符合 Production 被暂停：Live Key 仍存在，Production 返回 FP-4032，Sandbox 正常。 处理方式：查询 Production 状态并解除暂停；不要轮换 Key 或升级套餐来掩盖根因。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0014-A1` 证据符合 Production 被暂停：Live Key 仍存在，Production 返回 FP-4032，Sandbox 正常。
- `FP-BM-MD-0014-A2` 查询 Production 状态并解除暂停；不要轮换 Key 或升级套餐来掩盖根因。

禁止结论（说了就算错）：

- 不得认定：把所有 403 都当作套餐功能限制

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-011`、`KB-TS-020`
- 操作：—
- 规则：`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-003`、`RULE-ERROR-002`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-011#c007`、`doc:KB-TS-020#c006`

## FP-BM-MD-0018

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-005-region_currency_mismatch`
- 快照时点 `as_of`：2026-08-06T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`region_currency_mismatch`

### 题面

> 想咨询一个问题：EU Account 这个账户为 这位客户创建 USD Payment 那笔支付，那次请求返回 FP-4001。是否可以把 Account 临时改成 NA 来完成这笔 USD 支付？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不能；EU 不支持 USD，且主地区不可公开修改。应使用 EU 支持的 EUR/GBP 或另行设计合法账户。 处理方式：按 EU 支持币种重新提交，并保留新的幂等业务意图。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0018-A1` 不能；EU 不支持 USD，且主地区不可公开修改。应使用 EU 支持的 EUR/GBP 或另行设计合法账户。
- `FP-BM-MD-0018-A2` 按 EU 支持币种重新提交，并保留新的幂等业务意图。

禁止结论（说了就算错）：

- 不得认定：通过 API 临时修改主地区即可绕过币种约束

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`troubleshooting`
- 工具：`search_business_rules`、`search_troubleshooting`
- 文档：`KB-BR-003`、`KB-TS-001`
- 操作：—
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REGION-001`、`RULE-REGION-002`、`RULE-REGION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-BR-003#c006`、`doc:KB-TS-001#c007`

## FP-BM-MD-0022

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `dev`

- 场景：`SC-006-payment_amount_bounds`
- 快照时点 `as_of`：2026-08-07T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_amount_bounds`

### 题面

> 目前能确认的是：这个账户连续提交 amount=49 和 amount=100000001 的 Payment 请求，均未创建那笔支付。接下来需要判断两次请求为什么失败，重试原请求是否有意义？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 两次金额分别低于最小值和高于最大值，应返回 FP-4001；原样重试不会成功。 处理方式：修正整数金额后用符合新业务意图的 Idempotency Key 重新提交。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0022-A1` 两次金额分别低于最小值和高于最大值，应返回 FP-4001；原样重试不会成功。
- `FP-BM-MD-0022-A2` 修正整数金额后用符合新业务意图的 Idempotency Key 重新提交。

禁止结论（说了就算错）：

- 不得认定：金额越界属于临时平台错误

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`、`troubleshooting`
- 工具：`search_api_docs`、`search_troubleshooting`
- 文档：`KB-API-002`、`KB-TS-001`
- 操作：—
- 规则：`RULE-AUTH-001`、`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-REQ-001`、`RULE-VERSION-002`、`RULE-VERSION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-API-002#c001`、`doc:KB-TS-001#c007`

## FP-BM-MD-0026

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-007-starter_subscription_entitlement`
- 快照时点 `as_of`：2026-08-08T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`starter_subscription_entitlement`

### 题面

> 想咨询一个问题：Starter Account 这个账户的 subscriptions Flag 被配置为 true，但创建 这份订阅返回 FP-4031。Feature Flag 是否足以使创建成功？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不足；Starter 不具备订阅套餐权益，Flag 不能越过硬限制。 处理方式：先升级到 Growth 或 Scale，确认升级已生效后再启用并创建 Subscription。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0026-A1` 不足；Starter 不具备订阅套餐权益，Flag 不能越过硬限制。
- `FP-BM-MD-0026-A2` 先升级到 Growth 或 Scale，确认升级已生效后再启用并创建 Subscription。

禁止结论（说了就算错）：

- 不得认定：后台打开 Feature Flag 就能授予任何套餐能力

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`、`troubleshooting`
- 工具：`search_api_docs`、`search_troubleshooting`
- 文档：`KB-API-024`、`KB-TS-010`
- 操作：—
- 规则：`RULE-CUSTOMER-004`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-004`、`RULE-REGION-003`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-API-024#c002`、`doc:KB-TS-010#c002`

## FP-BM-MD-0030

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-008-plan_upgrade_immediate`
- 快照时点 `as_of`：2026-08-09T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`plan_upgrade_immediate`

### 题面

> 我们遇到了这种情况：这个账户在 10:00 从 Starter 升级为 Growth，10:01 创建 这份订阅。请问10:01 应按 Starter 还是 Growth 判断权限？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 应按 Growth；升级立即生效，满足其他条件时可创建 Subscription。 处理方式：查询套餐时间线并按请求发生时的有效套餐判断。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0030-A1` 应按 Growth；升级立即生效，满足其他条件时可创建 Subscription。
- `FP-BM-MD-0030-A2` 查询套餐时间线并按请求发生时的有效套餐判断。

禁止结论（说了就算错）：

- 不得认定：升级要等到下个计费周期才生效

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`
- 工具：`search_business_rules`、`search_api_docs`
- 文档：`KB-BR-004`、`KB-API-005`
- 操作：—
- 规则：`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-003`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-PLAN-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-BR-004#c003`、`doc:KB-API-005#c005`

## FP-BM-MD-0034

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-009-plan_downgrade_deferred`
- 快照时点 `as_of`：2026-08-10T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`plan_downgrade_deferred`

### 题面

> 客户反馈Scale Account 这个账户在周期中申请降为 Starter；申请后、周期结束前又创建了 这个回调地址。这种情况应该如何判断：新 Endpoint 应按 Scale 还是 Starter 上限判断？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 周期结束前仍按 Scale；降级尚未生效。周期结束后才应用 Starter 上限和 restricted 规则。 处理方式：核对 effective_at，并在周期结束后重新评估 Endpoint 状态。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0034-A1` 周期结束前仍按 Scale；降级尚未生效。周期结束后才应用 Starter 上限和 restricted 规则。
- `FP-BM-MD-0034-A2` 核对 effective_at，并在周期结束后重新评估 Endpoint 状态。

禁止结论（说了就算错）：

- 不得认定：提交降级申请会立刻套用 Starter 上限

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`
- 工具：`search_business_rules`、`search_api_docs`
- 文档：`KB-BR-004`、`KB-API-029`
- 操作：—
- 规则：`RULE-ENV-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-PLAN-005`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-BR-004#c005`、`doc:KB-API-029#c005`

## FP-BM-MD-0038

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-010-api_key_rotation_overlap`
- 快照时点 `as_of`：2026-08-11T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`api_key_rotation_overlap`

### 题面

> 我们遇到了这种情况：这个账户创建新 那把密钥后，旧 Key 进入 expiring；发布仍有部分实例使用旧 Key。请问是否必须立即撤销旧 Key，以及怎样避免发布中断？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不必立即撤销；可在最长 24 小时重叠窗口内完成切换，再主动撤销旧 Key。 处理方式：验证所有实例已使用新 Key后再撤销旧 Key。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0038-A1` 不必立即撤销；可在最长 24 小时重叠窗口内完成切换，再主动撤销旧 Key。
- `FP-BM-MD-0038-A2` 验证所有实例已使用新 Key后再撤销旧 Key。

禁止结论（说了就算错）：

- 不得认定：创建新 Key 会自动让旧 Key 立即失效

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`support_cases`、`api_docs`
- 工具：`search_support_cases`、`search_api_docs`
- 文档：`KB-CASE-002`、`KB-API-003`
- 操作：—
- 规则：`RULE-AUTH-001`、`RULE-AUTH-002`、`RULE-AUTH-003`、`RULE-AUTH-004`、`RULE-AUTH-005`、`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-001`、`RULE-ENV-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_support_cases`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-CASE-002#c001`、`doc:KB-API-003#c005`

## FP-BM-MD-0042

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `dev`

- 场景：`SC-011-revoked_key_is_terminal`
- 快照时点 `as_of`：2026-08-12T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`revoked_key_is_terminal`

### 题面

> 请帮忙确认一下。那把密钥被撤销后，这个账户尝试把它重新标记 active，并继续发送 那次请求。我们想知道旧 Key 能否恢复使用？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不能；revoked 是不可逆状态，请求应返回 FP-4011。 处理方式：创建新的 Secret Key并更新部署，保留撤销记录。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0042-A1` 不能；revoked 是不可逆状态，请求应返回 FP-4011。
- `FP-BM-MD-0042-A2` 创建新的 Secret Key并更新部署，保留撤销记录。

禁止结论（说了就算错）：

- 不得认定：重新启用 revoked Key 比创建新 Key更安全

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`、`troubleshooting`
- 工具：`search_api_docs`、`search_troubleshooting`
- 文档：`KB-API-003`、`KB-TS-004`
- 操作：—
- 规则：`RULE-AUTH-001`、`RULE-AUTH-002`、`RULE-AUTH-003`、`RULE-AUTH-004`、`RULE-AUTH-005`、`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-001`、`RULE-ENV-005`、`RULE-ERROR-002`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-API-003#c003`、`doc:KB-TS-004#c007`

## FP-BM-MD-0046

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-012-version_header_selection`
- 快照时点 `as_of`：2026-08-13T12:00:00Z　接口版本：2026-04-01
- 标签：`developer_platform`、`version_header_selection`

### 题面

> 目前能确认的是：这个账户默认版本为 新版接口，那次请求显式发送 FlowPay-Version: 旧版接口。接下来需要判断请求应使用默认版本还是失败？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 应返回 FP-4002；显式但不受支持的版本不会回退到 Account 默认版本。 处理方式：改为受支持版本或移除 Header 以使用 Account 默认版本。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0046-A1` 应返回 FP-4002；显式但不受支持的版本不会回退到 Account 默认版本。
- `FP-BM-MD-0046-A2` 改为受支持版本或移除 Header 以使用 Account 默认版本。

禁止结论（说了就算错）：

- 不得认定：错误版本 Header 会被静默忽略

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`、`release_notes`
- 工具：`search_troubleshooting`、`search_release_notes`
- 文档：`KB-TS-002`、`KB-REL-001`
- 操作：—
- 规则：`RULE-ERROR-001`、`RULE-IDEMP-001`、`RULE-PAY-001`、`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-003`、`RULE-VERSION-004`、`RULE-VERSION-006`、`RULE-WEBHOOK-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_release_notes`

### 快照里的实况

证据 ID：`doc:KB-TS-002#c004`、`doc:KB-REL-001#c006`

## FP-BM-MD-0050

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-013-source_deprecated_2026_04`
- 快照时点 `as_of`：2026-08-14T12:00:00Z　接口版本：2026-04-01
- 标签：`payments`、`source_deprecated_2026_04`

### 题面

> 客户反馈这个账户使用 API Version 当前部署使用的接口版本 和 source 创建那笔支付，响应含弃用提示。这种情况应该如何判断：这次请求应失败还是成功，迁移时应改什么？同时应该采取什么处理方式？

### 判分标准

标准答案：

> source 在该版本仍兼容，请求可成功；客户端应迁移到 payment_method。 处理方式：在升级到 2026-07-01 前完成 source 到 payment_method 的迁移。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0050-A1` source 在该版本仍兼容，请求可成功；客户端应迁移到 payment_method。
- `FP-BM-MD-0050-A2` 在升级到 2026-07-01 前完成 source 到 payment_method 的迁移。

禁止结论（说了就算错）：

- 不得认定：看到弃用提示就说明该参数已经被移除

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`release_notes`、`api_docs`
- 工具：`search_release_notes`、`search_api_docs`
- 文档：`KB-REL-005`、`KB-API-018`
- 操作：—
- 规则：`RULE-PAY-005`、`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-005`、`RULE-VERSION-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_release_notes`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-REL-005#c002`、`doc:KB-API-018#c002`

## FP-BM-MD-0054

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-014-source_removed_2026_07`
- 快照时点 `as_of`：2026-08-15T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`source_removed_2026_07`

### 题面

> 请帮忙确认一下。这个账户升级到 当前部署使用的接口版本 后仍用 source 创建那笔支付，那次请求返回 FP-4003。我们想知道是否可以重试相同请求解决问题？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不可以；参数已从该版本移除，原样重试仍失败且不会创建 Payment。 处理方式：改用 payment_method，并检查所有仍发送 source 的客户端。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0054-A1` 不可以；参数已从该版本移除，原样重试仍失败且不会创建 Payment。
- `FP-BM-MD-0054-A2` 改用 payment_method，并检查所有仍发送 source 的客户端。

禁止结论（说了就算错）：

- 不得认定：FP-4003 是偶发参数校验错误

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`、`troubleshooting`
- 工具：`search_api_docs`、`search_troubleshooting`
- 文档：`KB-API-018`、`KB-TS-003`
- 操作：—
- 规则：`RULE-PAY-005`、`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-005`、`RULE-VERSION-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-API-018#c002`、`doc:KB-TS-003#c007`

## FP-BM-MD-0058

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-015-requires_action_version_difference`
- 快照时点 `as_of`：2026-08-16T12:00:00Z　接口版本：2026-01-15
- 标签：`payments`、`requires_action_version_difference`

### 题面

> 目前能确认的是：同一客户操作场景分别由 旧版接口 与 新版接口 请求创建 Payment。接下来需要判断两个版本应分别看到什么状态和错误？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 旧版本看到 failed + FP-4023；新版本看到 requires_action，并可继续 confirm。 处理方式：按请求实际 API Version 处理状态，旧客户端不能套用新状态机。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0058-A1` 旧版本看到 failed + FP-4023；新版本看到 requires_action，并可继续 confirm。
- `FP-BM-MD-0058-A2` 按请求实际 API Version 处理状态，旧客户端不能套用新状态机。

禁止结论（说了就算错）：

- 不得认定：所有版本都会返回 requires_action

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`、`troubleshooting`
- 工具：`search_api_docs`、`search_troubleshooting`
- 文档：`KB-API-018`、`KB-TS-008`
- 操作：—
- 规则：`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-005`、`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-005`、`RULE-VERSION-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-API-018#c004`、`doc:KB-TS-008#c007`

## FP-BM-MD-0062

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `dev`

- 场景：`SC-016-idempotent_replay_same_params`
- 快照时点 `as_of`：2026-08-17T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`idempotent_replay_same_params`

### 题面

> 客户反馈这个账户在网络超时后用相同参数和相同 Idempotency Key 重试创建那笔支付。这种情况应该如何判断：是否会创建第二个 Payment？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不会；应返回第一次请求的 Payment 结果，两个 Request ID 指向同一 Payment。 处理方式：保留同一 Key 和完全相同参数，并按 Request ID 核对重放结果。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0062-A1` 不会；应返回第一次请求的 Payment 结果，两个 Request ID 指向同一 Payment。
- `FP-BM-MD-0062-A2` 保留同一 Key 和完全相同参数，并按 Request ID 核对重放结果。

禁止结论（说了就算错）：

- 不得认定：每次 HTTP 重试都会创建新 Payment

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`
- 工具：`search_business_rules`、`search_api_docs`
- 文档：`KB-BR-008`、`KB-API-033`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-002`、`RULE-IDEMP-003`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-IDEMP-006`、`RULE-REQ-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-BR-008#c006`、`doc:KB-API-033#c004`

## FP-BM-MD-0066

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-017-idempotency_conflict`
- 快照时点 `as_of`：2026-08-18T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`idempotency_conflict`

### 题面

> 客户反馈这个账户先用 amount=5000 创建那笔支付，随后用同一 Key 把 amount 改为 7000。这种情况应该如何判断：第二次请求应修改原 Payment 还是创建新 Payment？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 都不会；第二次应返回 FP-4091，第一次的 Payment 和金额保持不变。 处理方式：为新的 7000 金额请求使用新的 Idempotency Key。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0066-A1` 都不会；第二次应返回 FP-4091，第一次的 Payment 和金额保持不变。
- `FP-BM-MD-0066-A2` 为新的 7000 金额请求使用新的 Idempotency Key。

禁止结论（说了就算错）：

- 不得认定：同一 Key 可以用来表达修改后的业务意图

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`、`troubleshooting`
- 工具：`search_api_docs`、`search_troubleshooting`
- 文档：`KB-API-033`、`KB-TS-013`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-002`、`RULE-IDEMP-003`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-IDEMP-006`、`RULE-REQ-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-API-033#c002`、`doc:KB-TS-013#c007`

## FP-BM-MD-0070

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-018-idempotency_expired`
- 快照时点 `as_of`：2026-08-19T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`idempotency_expired`

### 题面

> 想咨询一个问题：这个账户在首次创建那笔支付的 25 小时后，以相同参数和同一 Key 再次发送请求。第二次请求是否仍应返回第一次 Payment？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不应；24 小时窗口已过，第二次是新请求并可创建新的 Payment。 处理方式：客户端不应在窗口外依赖旧 Key 去重，应保存业务侧订单关联。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0070-A1` 不应；24 小时窗口已过，第二次是新请求并可创建新的 Payment。
- `FP-BM-MD-0070-A2` 客户端不应在窗口外依赖旧 Key 去重，应保存业务侧订单关联。

禁止结论（说了就算错）：

- 不得认定：Idempotency Key 永久全局唯一

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`、`api_docs`
- 工具：`search_troubleshooting`、`search_api_docs`
- 文档：`KB-TS-013`、`KB-API-033`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-002`、`RULE-IDEMP-003`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-IDEMP-006`、`RULE-REQ-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-TS-013#c007`、`doc:KB-API-033#c003`

## FP-BM-MD-0074

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-019-sandbox_fixed_rate_limit`
- 快照时点 `as_of`：2026-08-20T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`sandbox_fixed_rate_limit`

### 题面

> 客户反馈Scale Account 这个账户在 Sandbox 一分钟发送 200 个请求并出现 FP-4291。这种情况应该如何判断：是否应按 Scale 的 5,000 req/min 判断？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不应；Sandbox 使用固定 120 req/min 和 180 burst，因此可能被限流。 处理方式：降低 Sandbox 流量并按退避 Header 重试；不要用升级套餐解决。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0074-A1` 不应；Sandbox 使用固定 120 req/min 和 180 burst，因此可能被限流。
- `FP-BM-MD-0074-A2` 降低 Sandbox 流量并按退避 Header 重试；不要用升级套餐解决。

禁止结论（说了就算错）：

- 不得认定：购买 Scale 会提高 Sandbox 限额

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`、`api_docs`
- 工具：`search_troubleshooting`、`search_api_docs`
- 文档：`KB-TS-016`、`KB-API-004`
- 操作：—
- 规则：`RULE-AUTH-008`、`RULE-ENV-001`、`RULE-ENV-002`、`RULE-ENV-004`、`RULE-ENV-005`、`RULE-PLAN-005`、`RULE-RATE-001`、`RULE-RATE-002`、`RULE-RATE-003`、`RULE-RATE-004`、`RULE-RATE-005`、`RULE-RATE-006`、`RULE-RATE-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-TS-016#c007`、`doc:KB-API-004#c005`

## FP-BM-MD-0078

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-020-growth_rate_burst`
- 快照时点 `as_of`：2026-08-21T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`growth_rate_burst`

### 题面

> 客户反馈Growth Account 这个账户在一分钟内产生 1,420 个请求，10 秒峰值未超过 1,500，部分请求返回 FP-4291。这种情况应该如何判断：这是否说明套餐被降级？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不说明；当时仍是 Growth，持续请求量超过 1,200 已足以触发限流。 处理方式：按 Usage 确认流量并实施指数退避；容量长期不足时再评估套餐。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0078-A1` 不说明；当时仍是 Growth，持续请求量超过 1,200 已足以触发限流。
- `FP-BM-MD-0078-A2` 按 Usage 确认流量并实施指数退避；容量长期不足时再评估套餐。

禁止结论（说了就算错）：

- 不得认定：429 是套餐状态发生变化的证据

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`、`troubleshooting`
- 工具：`search_api_docs`、`search_troubleshooting`
- 文档：`KB-API-034`、`KB-TS-022`
- 操作：—
- 规则：`RULE-PLAN-001`、`RULE-PLAN-005`、`RULE-RATE-001`、`RULE-RATE-002`、`RULE-RATE-003`、`RULE-RATE-004`、`RULE-RATE-005`、`RULE-RATE-006`、`RULE-RATE-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-API-034#c005`、`doc:KB-TS-022#c002`

## FP-BM-MD-0082

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `dev`

- 场景：`SC-021-rate_retry_storm`
- 快照时点 `as_of`：2026-08-22T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`rate_retry_storm`

### 题面

> 我们遇到了这种情况：这个账户首次接近 Growth 上限后，客户端对每个 429 立即并发重试 5 次，那次请求形成重试链。请问持续 429 的主要原因是套餐降级还是客户端重试放大？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 主要原因是立即 fan-out 重试放大请求量；套餐在事发时未变化。 处理方式：停止 fan-out，遵守 Reset/Retry-After 提示并使用指数退避。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0082-A1` 主要原因是立即 fan-out 重试放大请求量；套餐在事发时未变化。
- `FP-BM-MD-0082-A2` 停止 fan-out，遵守 Reset/Retry-After 提示并使用指数退避。

禁止结论（说了就算错）：

- 不得认定：只要增加重试次数就能更快恢复

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`、`support_cases`
- 工具：`search_troubleshooting`、`search_support_cases`
- 文档：`KB-TS-022`、`KB-CASE-006`
- 操作：—
- 规则：`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-005`、`RULE-RATE-001`、`RULE-RATE-002`、`RULE-RATE-003`、`RULE-RATE-004`、`RULE-RATE-005`、`RULE-RATE-006`、`RULE-RATE-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_support_cases`

### 快照里的实况

证据 ID：`doc:KB-TS-022#c006`、`doc:KB-CASE-006#c005`

## FP-BM-MD-0086

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-022-webhooks_excluded_from_rate_limit`
- 快照时点 `as_of`：2026-08-23T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhooks_excluded_from_rate_limit`

### 题面

> 我们遇到了这种情况：这个账户同一分钟有 900 次 API 请求和 700 次 Webhook Delivery Attempt，套餐为 Growth。请问Rate Limit 计数应是 900 还是 1,600？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 应是 900；Webhook Delivery Attempt 不计入 Merchant API Rate Limit。 处理方式：分别查询 API Usage 与 Delivery Timeline，不要把两个指标相加。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0086-A1` 应是 900；Webhook Delivery Attempt 不计入 Merchant API Rate Limit。
- `FP-BM-MD-0086-A2` 分别查询 API Usage 与 Delivery Timeline，不要把两个指标相加。

禁止结论（说了就算错）：

- 不得认定：所有 FlowPay 发出的 HTTP 流量都计入商户限流

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-032`、`KB-API-034`
- 操作：—
- 规则：`RULE-PLAN-005`、`RULE-RATE-001`、`RULE-RATE-002`、`RULE-RATE-003`、`RULE-RATE-004`、`RULE-RATE-005`、`RULE-RATE-006`、`RULE-RATE-007`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-032#c003`、`doc:KB-API-034#c003`

## FP-BM-MD-0090

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-023-customer_soft_delete_history`
- 快照时点 `as_of`：2026-08-24T12:00:00Z　接口版本：2026-07-01
- 标签：`customers`、`customer_soft_delete_history`

### 题面

> 我们遇到了这种情况：这位客户被删除后，历史 那笔支付仍能被 这个账户查询并显示原 Customer ID。请问这是否表示删除失败？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不是；软删除只阻止新的业务创建，不移除既有对象的关联。 处理方式：把 Customer 状态显示为 deleted，同时保留审计与历史对象关联。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0090-A1` 不是；软删除只阻止新的业务创建，不移除既有对象的关联。
- `FP-BM-MD-0090-A2` 把 Customer 状态显示为 deleted，同时保留审计与历史对象关联。

禁止结论（说了就算错）：

- 不得认定：删除 Customer 应级联删除所有历史交易

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-009`、`KB-API-011`
- 操作：—
- 规则：`RULE-CUSTOMER-001`、`RULE-CUSTOMER-002`、`RULE-CUSTOMER-003`、`RULE-CUSTOMER-004`、`RULE-CUSTOMER-005`、`RULE-TENANT-001`、`RULE-TENANT-003`、`RULE-TENANT-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-009#c004`、`doc:KB-API-011#c003`

## FP-BM-MD-0094

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-024-deleted_customer_new_payment`
- 快照时点 `as_of`：2026-08-25T12:00:00Z　接口版本：2026-07-01
- 标签：`customers`、`deleted_customer_new_payment`

### 题面

> 客户反馈这位客户已 deleted，这个账户随后尝试创建新 那笔支付，请求返回状态错误。这种情况应该如何判断：能否重新使用这个 Customer ID 创建 Payment？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不能；deleted Customer 不可恢复为 active，也不能用于新 Payment。 处理方式：创建新的 active Customer，并用新 Customer ID 表达后续业务。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0094-A1` 不能；deleted Customer 不可恢复为 active，也不能用于新 Payment。
- `FP-BM-MD-0094-A2` 创建新的 active Customer，并用新 Customer ID 表达后续业务。

禁止结论（说了就算错）：

- 不得认定：既然历史 Payment 可见，Customer 就仍可用于新交易

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`、`troubleshooting`
- 工具：`search_api_docs`、`search_troubleshooting`
- 文档：`KB-API-013`、`KB-TS-014`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-REFUND-001`、`RULE-REFUND-008`、`RULE-REGION-001`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-API-013#c006`、`doc:KB-TS-014#c007`

## FP-BM-MD-0098

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-025-duplicate_customer_email`
- 快照时点 `as_of`：2026-08-26T12:00:00Z　接口版本：2026-07-01
- 标签：`customers`、`duplicate_customer_email`

### 题面

> 目前能确认的是：这个账户中有两个 active Customer 使用相同 Email，其中只有 这位客户关联目标 Payment。接下来需要判断能否仅用 Email 确定应更新哪个 Customer？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不能；Email 可重复，必须先取得并使用明确的 Customer ID。 处理方式：按 Customer ID 查询、更新和关联，避免对 Email 做唯一性假设。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0098-A1` 不能；Email 可重复，必须先取得并使用明确的 Customer ID。
- `FP-BM-MD-0098-A2` 按 Customer ID 查询、更新和关联，避免对 Email 做唯一性假设。

禁止结论（说了就算错）：

- 不得认定：相同 Email 代表同一个 Customer

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-009`、`KB-API-010`
- 操作：—
- 规则：`RULE-CUSTOMER-001`、`RULE-CUSTOMER-002`、`RULE-CUSTOMER-003`、`RULE-CUSTOMER-004`、`RULE-CUSTOMER-005`、`RULE-REQ-001`、`RULE-TENANT-001`、`RULE-TENANT-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-009#c005`、`doc:KB-API-010#c004`

## FP-BM-MD-0102

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `dev`

- 场景：`SC-026-payment_success_terminal`
- 快照时点 `as_of`：2026-08-01T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_success_terminal`

### 题面

> 目前能确认的是：那笔支付已 succeeded，之后客户端尝试再次 confirm，并在列表与详情接口中查询它。接下来需要判断Payment 是否会重新进入 processing？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不会；succeeded 是终态，再次 confirm 不得逆转状态，列表与详情应显示同一业务状态。 处理方式：保留原 Payment，若有新的收费意图应创建新 Payment。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0102-A1` 不会；succeeded 是终态，再次 confirm 不得逆转状态，列表与详情应显示同一业务状态。
- `FP-BM-MD-0102-A2` 保留原 Payment，若有新的收费意图应创建新 Payment。

禁止结论（说了就算错）：

- 不得认定：再次 confirm 可以重新处理已成功 Payment

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-017`、`KB-API-015`
- 操作：—
- 规则：`RULE-PAY-001`、`RULE-PAY-003`、`RULE-PAY-005`、`RULE-TENANT-001`、`RULE-TENANT-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-017#c001`、`doc:KB-API-015#c006`

## FP-BM-MD-0106

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-027-confirm_requires_action`
- 快照时点 `as_of`：2026-08-02T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`confirm_requires_action`

### 题面

> 想咨询一个问题：当前部署使用的接口版本 Payment 那笔支付处于 requires_action，客户完成验证后发送 confirm。confirm 后允许发生什么状态变化？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 允许从 requires_action 进入 processing，再由处理结果进入 succeeded 或 failed。 处理方式：只对 requires_action 调用 confirm，并继续查询状态或处理 Webhook。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0106-A1` 允许从 requires_action 进入 processing，再由处理结果进入 succeeded 或 failed。
- `FP-BM-MD-0106-A2` 只对 requires_action 调用 confirm，并继续查询状态或处理 Webhook。

禁止结论（说了就算错）：

- 不得认定：confirm 会直接把任何 Payment 强制改成 succeeded

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`
- 工具：`search_business_rules`、`search_api_docs`
- 文档：`KB-BR-010`、`KB-API-015`
- 操作：—
- 规则：`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-PAY-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-BR-010#c004`、`doc:KB-API-015#c002`

## FP-BM-MD-0110

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-028-cancel_payment_state_guard`
- 快照时点 `as_of`：2026-08-03T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`cancel_payment_state_guard`

### 题面

> 请帮忙确认一下。这个账户尝试取消 processing 的那笔支付，那次请求返回 FP-4221。我们想知道是否应该把 Payment 改成 canceled？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不应该；processing 不允许主动取消，原状态保持不变。 处理方式：等待处理完成并根据最终状态采取后续操作。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0110-A1` 不应该；processing 不允许主动取消，原状态保持不变。
- `FP-BM-MD-0110-A2` 等待处理完成并根据最终状态采取后续操作。

禁止结论（说了就算错）：

- 不得认定：所有未成功 Payment 都可以取消

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`、`api_docs`
- 工具：`search_troubleshooting`、`search_api_docs`
- 文档：`KB-TS-014`、`KB-API-016`
- 操作：—
- 规则：`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-REFUND-001`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-TS-014#c007`、`doc:KB-API-016#c004`

## FP-BM-MD-0114

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-029-failed_payment_new_retry`
- 快照时点 `as_of`：2026-08-04T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`failed_payment_new_retry`

### 题面

> 客户反馈那笔支付因支付方式被拒绝进入 failed；商户对原 ID 再次 confirm，并在 Payment 列表查找后续尝试。这种情况应该如何判断：正确的重试模型是什么？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 原 Payment 保持 failed；新的收费尝试必须有新的 Payment ID。 处理方式：创建新的 Payment，并在商户业务层关联两次尝试。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0114-A1` 原 Payment 保持 failed；新的收费尝试必须有新的 Payment ID。
- `FP-BM-MD-0114-A2` 创建新的 Payment，并在商户业务层关联两次尝试。

禁止结论（说了就算错）：

- 不得认定：把 failed Payment 原地改回 processing 能保持订单连续性

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`、`support_cases`
- 工具：`search_troubleshooting`、`search_support_cases`
- 文档：`KB-TS-021`、`KB-CASE-009`
- 操作：—
- 规则：`RULE-ERROR-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_support_cases`

### 快照里的实况

证据 ID：`doc:KB-TS-021#c007`、`doc:KB-CASE-009#c005`

## FP-BM-MD-0118

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-030-payment_method_declined`
- 快照时点 `as_of`：2026-08-05T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_method_declined`

### 题面

> 请帮忙确认一下。那笔支付返回 FP-4021，Request 那次请求没有平台 Incident，客户认为稍后重试同一 Payment 即可。我们想知道根因类别和正确处置是什么？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 这是 Payment Method Declined；原 Payment 已 failed，应让客户更换支付方式并创建新 Payment。 处理方式：收集失败码，提示更换支付方式，不要无限重试原 Payment。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0118-A1` 这是 Payment Method Declined；原 Payment 已 failed，应让客户更换支付方式并创建新 Payment。
- `FP-BM-MD-0118-A2` 收集失败码，提示更换支付方式，不要无限重试原 Payment。

禁止结论（说了就算错）：

- 不得认定：FP-4021 表示 FlowPay 服务降级

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`、`api_docs`
- 工具：`search_troubleshooting`、`search_api_docs`
- 文档：`KB-TS-006`、`KB-API-013`
- 操作：—
- 规则：`RULE-ERROR-002`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-REGION-001`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-TS-006#c007`、`doc:KB-API-013#c006`

## FP-BM-MD-0122

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `dev`

- 场景：`SC-031-payment_insufficient_funds`
- 快照时点 `as_of`：2026-08-06T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_insufficient_funds`

### 题面

> 目前能确认的是：那笔支付返回 FP-4022；同一客户此前另一笔 Payment 曾返回 FP-4021。接下来需要判断这次能否沿用上次的拒绝根因？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不能；本次明确是 Insufficient Funds，应按 FP-4022 处理。 处理方式：向客户说明余额不足，新的支付尝试必须创建新 Payment。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0122-A1` 不能；本次明确是 Insufficient Funds，应按 FP-4022 处理。
- `FP-BM-MD-0122-A2` 向客户说明余额不足，新的支付尝试必须创建新 Payment。

禁止结论（说了就算错）：

- 不得认定：相同 HTTP 402 的所有错误根因都相同

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-007`、`KB-TS-021`
- 操作：—
- 规则：`RULE-ERROR-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-007#c007`、`doc:KB-TS-021#c007`

## FP-BM-MD-0126

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-032-payment_method_expired`
- 快照时点 `as_of`：2026-08-07T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_method_expired`

### 题面

> 客户反馈那笔支付使用已过期支付方式并返回 FP-4024，商户准备重放同一请求。这种情况应该如何判断：原样重放是否可能成功？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不会改变已过期支付方式，也不会复活 failed Payment；应更新支付方式并创建新 Payment。 处理方式：获取新的有效支付方式后发起新的收费尝试。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0126-A1` 不会改变已过期支付方式，也不会复活 failed Payment；应更新支付方式并创建新 Payment。
- `FP-BM-MD-0126-A2` 获取新的有效支付方式后发起新的收费尝试。

禁止结论（说了就算错）：

- 不得认定：FP-4024 可以通过 API 重试退避自动恢复

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-021`、`KB-TS-009`
- 操作：—
- 规则：`RULE-ERROR-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-021#c007`、`doc:KB-TS-009#c007`

## FP-BM-MD-0130

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-033-action_required_old_and_new`
- 快照时点 `as_of`：2026-08-08T12:00:00Z　接口版本：2026-01-15
- 标签：`payments`、`action_required_old_and_new`

### 题面

> 我们遇到了这种情况：这个账户的旧客户端与新客户端对同一类验证场景分别创建 Payment。请问为什么两个 Payment 的状态不同，是否是数据不一致？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不是数据不一致；差异由请求 API Version 决定，旧版 failed + FP-4023，新版 requires_action。 处理方式：客户端按各自版本实现处理，并按迁移指南升级。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0130-A1` 不是数据不一致；差异由请求 API Version 决定，旧版 failed + FP-4023，新版 requires_action。
- `FP-BM-MD-0130-A2` 客户端按各自版本实现处理，并按迁移指南升级。

禁止结论（说了就算错）：

- 不得认定：同一业务原因必须在所有版本中有完全相同状态字段

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`、`release_notes`
- 工具：`search_troubleshooting`、`search_release_notes`
- 文档：`KB-TS-008`、`KB-REL-003`
- 操作：—
- 规则：`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-005`、`RULE-VERSION-002`、`RULE-VERSION-005`、`RULE-VERSION-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_release_notes`

### 快照里的实况

证据 ID：`doc:KB-TS-008#c007`、`doc:KB-REL-003#c006`

## FP-BM-MD-0134

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-034-refund_processing_payment`
- 快照时点 `as_of`：2026-08-09T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`refund_processing_payment`

### 题面

> 客户反馈那笔支付仍为 processing，这个账户为它创建那笔退款，那次请求返回 FP-4221。这种情况应该如何判断：是否已创建 pending Refund，以及正确等待条件是什么？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 没有创建 Refund；必须等待 Payment succeeded 后再申请退款。 处理方式：查询 Payment 最终状态，仅在 succeeded 后发起 Refund。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0134-A1` 没有创建 Refund；必须等待 Payment succeeded 后再申请退款。
- `FP-BM-MD-0134-A2` 查询 Payment 最终状态，仅在 succeeded 后发起 Refund。

禁止结论（说了就算错）：

- 不得认定：processing 已代表扣款完成，可以先占用退款额度

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`support_cases`、`api_docs`
- 工具：`search_support_cases`、`search_api_docs`
- 文档：`KB-CASE-010`、`KB-API-019`
- 操作：—
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PAY-001`、`RULE-PAY-004`、`RULE-REFUND-001`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_support_cases`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-CASE-010#c002`、`doc:KB-API-019#c005`

## FP-BM-MD-0138

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-035-starter_full_refund_only`
- 快照时点 `as_of`：2026-08-10T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`starter_full_refund_only`

### 题面

> 目前能确认的是：Starter Account 这个账户对 succeeded 的那笔支付申请小于剩余金额的那笔退款，返回 FP-4031。接下来需要判断Payment 可退款为何请求仍失败？同时应该采取什么处理方式？

### 判分标准

标准答案：

> Payment 状态合格，但 Starter 不支持部分退款；必须一次退还全部剩余可退金额。 处理方式：按剩余可退金额发起一次全额 Refund，或先合法升级套餐。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0138-A1` Payment 状态合格，但 Starter 不支持部分退款；必须一次退还全部剩余可退金额。
- `FP-BM-MD-0138-A2` 按剩余可退金额发起一次全额 Refund，或先合法升级套餐。

禁止结论（说了就算错）：

- 不得认定：只要 Payment succeeded，任何套餐都支持部分退款

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-020`、`KB-API-021`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-020#c005`、`doc:KB-API-021#c002`

## FP-BM-MD-0142

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `dev`

- 场景：`SC-036-growth_multiple_partial_refunds`
- 快照时点 `as_of`：2026-08-11T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`growth_multiple_partial_refunds`

### 题面

> 请帮忙确认一下。Growth Account 这个账户对 10,000 的那笔支付先成功退款 2,000，再申请 3,000。我们想知道第二笔部分 Refund 是否允许，剩余可退金额是多少？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 允许；第二笔后已占用 5,000，剩余可退金额为 5,000。 处理方式：每次创建前查询当前 pending+succeeded 占用与可退余额。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0142-A1` 允许；第二笔后已占用 5,000，剩余可退金额为 5,000。
- `FP-BM-MD-0142-A2` 每次创建前查询当前 pending+succeeded 占用与可退余额。

禁止结论（说了就算错）：

- 不得认定：部分退款只能发生一次

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-022`、`KB-API-021`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-MONEY-004`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-TENANT-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-022#c003`、`doc:KB-API-021#c002`

## FP-BM-MD-0146

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-037-pending_refund_reserves_amount`
- 快照时点 `as_of`：2026-08-12T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`pending_refund_reserves_amount`

### 题面

> 我们遇到了这种情况：10,000 的那笔支付已有 6,000 pending 那笔退款，这个账户又申请 5,000。请问第二次请求能否通过？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不能；pending 已占用 6,000，只剩 4,000 可退。 处理方式：等待 pending 完成或失败后重新查询可退金额。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0146-A1` 不能；pending 已占用 6,000，只剩 4,000 可退。
- `FP-BM-MD-0146-A2` 等待 pending 完成或失败后重新查询可退金额。

禁止结论（说了就算错）：

- 不得认定：pending 尚未成功，所以不影响可退余额

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-019`、`KB-API-022`
- 操作：—
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-TENANT-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-019#c004`、`doc:KB-API-022#c006`

## FP-BM-MD-0150

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-038-failed_refund_releases_amount`
- 快照时点 `as_of`：2026-08-13T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`failed_refund_releases_amount`

### 题面

> 我们遇到了这种情况：那笔支付的 4,000 pending 那笔退款随后 failed；商户再次查询可退金额。请问这 4,000 是否仍被占用？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不再占用；failed Refund 释放额度，可退金额应相应增加。 处理方式：确认 Refund 终态后重新计算 succeeded+pending 占用。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0150-A1` 不再占用；failed Refund 释放额度，可退金额应相应增加。
- `FP-BM-MD-0150-A2` 确认 Refund 终态后重新计算 succeeded+pending 占用。

禁止结论（说了就算错）：

- 不得认定：Refund 一旦创建就永久占用额度

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-022`、`KB-API-019`
- 操作：—
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-TENANT-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-022#c001`、`doc:KB-API-019#c004`

## FP-BM-MD-0154

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-039-refund_window_expired`
- 快照时点 `as_of`：2026-08-14T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`refund_window_expired`

### 题面

> 请帮忙确认一下。那笔支付在 181 天前 succeeded，当前仍有全部金额未退；这个账户创建那笔退款返回 FP-4222。我们想知道有剩余金额是否足以使退款成功？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不足；退款窗口已经超过 180 天，即使余额完整也不具备资格。 处理方式：核对 succeeded_at 与请求时间，不要重试过期 Refund。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0154-A1` 不足；退款窗口已经超过 180 天，即使余额完整也不具备资格。
- `FP-BM-MD-0154-A2` 核对 succeeded_at 与请求时间，不要重试过期 Refund。

禁止结论（说了就算错）：

- 不得认定：可退余额大于零就代表永远可退款

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`、`support_cases`
- 工具：`search_troubleshooting`、`search_support_cases`
- 文档：`KB-TS-015`、`KB-CASE-012`
- 操作：—
- 规则：`RULE-REFUND-001`、`RULE-REFUND-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_support_cases`

### 快照里的实况

证据 ID：`doc:KB-TS-015#c007`、`doc:KB-CASE-012#c003`

## FP-BM-MD-0158

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-040-instant_refund_scale_na`
- 快照时点 `as_of`：2026-08-15T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`instant_refund_scale_na`

### 题面

> 客户反馈NA Scale Account 这个账户已开启 instant_refund，对 那笔支付申请 80,000 的那笔退款。这种情况应该如何判断：该请求是否具备 Instant Refund 资格？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 具备；套餐、地区、Flag、金额和 Payment 状态均满足时可使用 Instant Refund。 处理方式：在调用前同时验证地区、Flag、金额和可退余额。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0158-A1` 具备；套餐、地区、Flag、金额和 Payment 状态均满足时可使用 Instant Refund。
- `FP-BM-MD-0158-A2` 在调用前同时验证地区、Flag、金额和可退余额。

禁止结论（说了就算错）：

- 不得认定：Instant Refund 只由 Scale 套餐单一条件决定

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`
- 工具：`search_business_rules`、`search_api_docs`
- 文档：`KB-BR-012`、`KB-API-021`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-BR-012#c006`、`doc:KB-API-021#c005`

## FP-BM-MD-0162

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `dev`

- 场景：`SC-041-instant_refund_apac`
- 快照时点 `as_of`：2026-08-16T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`instant_refund_apac`

### 题面

> 想咨询一个问题：APAC Scale Account 这个账户开启 Flag 后，对 那笔支付请求 50,000 Instant Refund。请求是否应因 Scale 身份而成功？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不应；APAC 不在 Instant Refund 支持地区内。 处理方式：改用标准 Refund 流程，不要尝试修改 Account 主地区。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0162-A1` 不应；APAC 不在 Instant Refund 支持地区内。
- `FP-BM-MD-0162-A2` 改用标准 Refund 流程，不要尝试修改 Account 主地区。

禁止结论（说了就算错）：

- 不得认定：Scale 可以覆盖地区限制

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`
- 工具：`search_business_rules`、`search_api_docs`
- 文档：`KB-BR-012`、`KB-API-021`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-BR-012#c006`、`doc:KB-API-021#c005`

## FP-BM-MD-0166

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-042-instant_refund_flag_and_amount`
- 快照时点 `as_of`：2026-08-17T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`instant_refund_flag_and_amount`

### 题面

> 客户反馈EU Scale Account 这个账户的 Flag 起初关闭，随后开启但请求 120,000 的 Instant Refund。这种情况应该如何判断：两次尝试分别为什么不具备资格？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 第一次缺少 Flag；第二次金额超过 100,000。两次都不能使用 Instant Refund。 处理方式：开启 Flag后把金额控制在上限内，或改用标准 Refund。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0166-A1` 第一次缺少 Flag；第二次金额超过 100,000。两次都不能使用 Instant Refund。
- `FP-BM-MD-0166-A2` 开启 Flag后把金额控制在上限内，或改用标准 Refund。

禁止结论（说了就算错）：

- 不得认定：只要后续打开 Flag，之前和超额请求都会自动合法

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`、`business_rules`
- 工具：`search_api_docs`、`search_business_rules`
- 文档：`KB-API-021`、`KB-BR-012`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-API-021#c005`、`doc:KB-BR-012#c006`

## FP-BM-MD-0170

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-043-starter_subscription_blocked`
- 快照时点 `as_of`：2026-08-18T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`starter_subscription_blocked`

### 题面

> 我们遇到了这种情况：Starter Account 这个账户使用 active 这位客户创建 这份订阅，请求参数都合法。请问Customer active 是否足以使创建成功？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不足；套餐不支持 Subscription，应返回 FP-4031。 处理方式：升级到 Growth/Scale并确认 subscriptions Flag 后重新创建。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0170-A1` 不足；套餐不支持 Subscription，应返回 FP-4031。
- `FP-BM-MD-0170-A2` 升级到 Growth/Scale并确认 subscriptions Flag 后重新创建。

禁止结论（说了就算错）：

- 不得认定：参数合法就能绕过套餐权限

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`、`troubleshooting`
- 工具：`search_api_docs`、`search_troubleshooting`
- 文档：`KB-API-024`、`KB-TS-010`
- 操作：—
- 规则：`RULE-CUSTOMER-004`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-004`、`RULE-REGION-003`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-API-024#c003`、`doc:KB-TS-010#c002`

## FP-BM-MD-0174

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-044-subscription_trial_bounds`
- 快照时点 `as_of`：2026-08-19T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_trial_bounds`

### 题面

> 想咨询一个问题：这个账户先尝试以 trial_days=31 创建 这份订阅，之后又想给已 active 的 Subscription 补加试用期。两种操作是否允许？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 都不允许；31 天越界，且试用期不能在创建后追加。 处理方式：创建时使用 1～30 天范围；已创建资源需按现有周期处理。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0174-A1` 都不允许；31 天越界，且试用期不能在创建后追加。
- `FP-BM-MD-0174-A2` 创建时使用 1～30 天范围；已创建资源需按现有周期处理。

禁止结论（说了就算错）：

- 不得认定：试用期可在任意时间延长

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`、`api_docs`
- 工具：`search_troubleshooting`、`search_api_docs`
- 文档：`KB-TS-001`、`KB-API-024`
- 操作：—
- 规则：`RULE-CUSTOMER-004`、`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PLAN-001`、`RULE-PLAN-004`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-TS-001#c007`、`doc:KB-API-024#c004`

## FP-BM-MD-0178

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-045-subscription_cancel_period_end`
- 快照时点 `as_of`：2026-08-20T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_cancel_period_end`

### 题面

> 客户反馈这份订阅在周期中收到默认取消请求，当前时间尚未到 period_end。这种情况应该如何判断：它应立即 canceled 还是继续 active？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 应继续 active 到周期末，届时再进入 canceled。 处理方式：向用户展示 scheduled cancellation 与实际生效时间。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0178-A1` 应继续 active 到周期末，届时再进入 canceled。
- `FP-BM-MD-0178-A2` 向用户展示 scheduled cancellation 与实际生效时间。

禁止结论（说了就算错）：

- 不得认定：所有取消请求都立即终止服务

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`
- 工具：`search_business_rules`、`search_api_docs`
- 文档：`KB-BR-013`、`KB-API-025`
- 操作：—
- 规则：`RULE-CUSTOMER-003`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-BR-013#c007`、`doc:KB-API-025#c003`

## FP-BM-MD-0281

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `dev`

- 场景：`SC-071-regional_service_incident`
- 快照时点 `as_of`：2026-08-20T12:00:00Z　接口版本：2026-07-01
- 标签：`operations`、`regional_service_incident`

### 题面

> 想咨询一个问题：NA payments 服务在时间窗内有 这次服务异常；NA 多个 Account 返回 FP-5031，EU 同类请求正常。问题范围是单个 Account 还是区域服务？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 证据表明是 NA 区域 payments 服务降级，不是单个 Account 配置。 处理方式：按 Incident 时间线沟通影响，并在恢复后使用幂等重试。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0281-A1` 证据表明是 NA 区域 payments 服务降级，不是单个 Account 配置。
- `FP-BM-MD-0281-A2` 按 Incident 时间线沟通影响，并在恢复后使用幂等重试。

禁止结论（说了就算错）：

- 不得认定：某个 Account 最先报告就说明只有该账户受影响

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-024`、`KB-TS-018`
- 操作：—
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-IDEMP-004`、`RULE-RATE-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-024#c002`、`doc:KB-TS-018#c007`

## FP-BM-MD-0285

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-072-request_id_before_auth`
- 快照时点 `as_of`：2026-08-21T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`request_id_before_auth`

### 题面

> 想咨询一个问题：那次请求使用格式错误的那把密钥，返回 FP-4011；客户端认为认证失败所以不可能查询请求日志。这次失败是否应有 Request ID？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 应有；Request ID 在认证前分配，可用于查询脱敏日志，但不等于资源 ID。 处理方式：记录响应中的 Request ID，并据此查询失败阶段。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0285-A1` 应有；Request ID 在认证前分配，可用于查询脱敏日志，但不等于资源 ID。
- `FP-BM-MD-0285-A2` 记录响应中的 Request ID，并据此查询失败阶段。

禁止结论（说了就算错）：

- 不得认定：只有成功认证后才生成 Request ID

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-007`、`KB-API-008`
- 操作：—
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-REQ-001`、`RULE-REQ-002`、`RULE-REQ-003`、`RULE-VERSION-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-007#c002`、`doc:KB-API-008#c004`

## FP-BM-MD-0289

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-073-resource_not_visible_semantics`
- 快照时点 `as_of`：2026-08-22T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`resource_not_visible_semantics`

### 题面

> 请帮忙确认一下。这个账户的 Sandbox Key 查询一个 Production 那笔支付，得到 FP-4041。我们想知道能否据此断言 Payment 已被删除？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不能；环境或租户不可见与真实不存在共享该语义。 处理方式：先核对 Key、Account、Environment 和资源 ID，不要求平台泄漏所有权。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0289-A1` 不能；环境或租户不可见与真实不存在共享该语义。
- `FP-BM-MD-0289-A2` 先核对 Key、Account、Environment 和资源 ID，不要求平台泄漏所有权。

禁止结论（说了就算错）：

- 不得认定：FP-4041 会精确告诉调用方资源属于哪个环境

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`、`api_docs`
- 工具：`search_troubleshooting`、`search_api_docs`
- 文档：`KB-TS-012`、`KB-API-014`
- 操作：—
- 规则：`RULE-ENV-001`、`RULE-PAY-001`、`RULE-REQ-003`、`RULE-TENANT-002`、`RULE-TENANT-003`、`RULE-TENANT-004`、`RULE-VERSION-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-TS-012#c007`、`doc:KB-API-014#c007`

## FP-BM-MD-0293

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-074-runtime_retention_by_plan`
- 快照时点 `as_of`：2026-08-23T12:00:00Z　接口版本：2026-07-01
- 标签：`operations`、`runtime_retention_by_plan`

### 题面

> 目前能确认的是：Starter Account 这个账户查询 20 天前的请求 那次请求时返回 retention_exceeded，但相关业务对象现在仍然可以看到。接下来需要判断能否根据仍然可见的业务对象还原这次请求的完整日志内容？同时应该采取什么处理方式？

### 判分标准

标准答案：

> 不能；Starter 的请求记录查询范围只有 7 天，业务对象仍然可见不等于完整请求日志仍可查询。 处理方式：说明当前可查询的时间范围；如需更长历史，应提前采用符合产品规则的长期留存方案。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0293-A1` 不能；Starter 的请求记录查询范围只有 7 天，业务对象仍然可见不等于完整请求日志仍可查询。
- `FP-BM-MD-0293-A2` 说明当前可查询的时间范围；如需更长历史，应提前采用符合产品规则的长期留存方案。

禁止结论（说了就算错）：

- 不得认定：只要业务对象还在，就一定能还原完整历史请求日志

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`troubleshooting`
- 工具：`search_business_rules`、`search_troubleshooting`
- 文档：`KB-BR-004`、`KB-TS-022`
- 操作：—
- 规则：`RULE-PLAN-001`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-BR-004#c003`、`doc:KB-TS-022#c007`

## FP-BM-MD-0297

**跨文档**（`multi_document`） · 难度 2 · 单轮 · `test`

- 场景：`SC-075-payment_to_webhook_end_to_end`
- 快照时点 `as_of`：2026-08-24T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`payment_to_webhook_end_to_end`

### 题面

> 想咨询一个问题：那笔支付已 succeeded 并生成 那个事件；这个回调地址已订阅正确事件，那次投递首次 500、重试 204。商户却认为 Payment 失败。应如何给出最终业务结论和 Webhook 投递结论？同时应该采取什么处理方式？

### 判分标准

标准答案：

> Payment 已成功；Webhook 首次失败但重试 204 后 delivered。投递故障不能反推 Payment 失败。 处理方式：分别引用 Payment、Event、Endpoint 和 Delivery Timeline，按 event_id 做幂等处理。

必需结论（全部要被证据支持）：

- `FP-BM-MD-0297-A1` Payment 已成功；Webhook 首次失败但重试 204 后 delivered。投递故障不能反推 Payment 失败。
- `FP-BM-MD-0297-A2` 分别引用 Payment、Event、Endpoint 和 Delivery Timeline，按 event_id 做幂等处理。

禁止结论（说了就算错）：

- 不得认定：没在首次收到 Webhook 就说明 Payment 未成功

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`、`api_docs`
- 工具：`search_business_rules`、`search_api_docs`
- 文档：`KB-BR-015`、`KB-API-013`
- 操作：—
- 规则：`RULE-ENV-004`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-PLAN-003`、`RULE-REGION-001`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`、`search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-BR-015#c001`、`doc:KB-API-013#c006`
