# 单点检索　`simple_retrieval`　70 道

## FP-BM-SR-0001

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-001-cross_tenant_payment_visibility`
- 快照时点 `as_of`：2026-08-02T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`cross_tenant_payment_visibility`

### 题面

> 我们遇到了这种情况：这个账户使用自己的 Production Key 查询另一个 Account 所属的那笔支付，请求得到 FP-4041。请问FP-4041 是否能证明 Payment ID 不存在，以及应如何判断这次访问？

### 判分标准

标准答案：

> 业务对象只能由所属 Account 访问；跨账户访问统一返回资源不存在或不可见语义。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0001-A1` 业务对象只能由所属 Account 访问；跨账户访问统一返回资源不存在或不可见语义。

禁止结论（说了就算错）：

- 不得认定：把 FP-4041 直接解释为 Payment ID 拼写错误

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-001`
- 操作：—
- 规则：`RULE-TENANT-001`、`RULE-TENANT-002`、`RULE-TENANT-003`、`RULE-TENANT-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-001#c003`

## FP-BM-SR-0005

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-002-sandbox_key_on_production`
- 快照时点 `as_of`：2026-08-03T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`sandbox_key_on_production`

### 题面

> 我们遇到了这种情况：这个账户的部署加载了 Sandbox Key，却尝试为 Production Customer 这位客户创建 Payment，那次请求返回 FP-4012。请问根因是 Key 无效、Customer 不存在还是环境不匹配？

### 判分标准

标准答案：

> API Key 与资源环境必须一致，Sandbox Key 访问 Production 资源返回 FP-4012。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0005-A1` API Key 与资源环境必须一致，Sandbox Key 访问 Production 资源返回 FP-4012。

禁止结论（说了就算错）：

- 不得认定：只要 Key 有效就可以跨环境调用

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-001`
- 操作：—
- 规则：`RULE-AUTH-001`、`RULE-ENV-001`、`RULE-ENV-002`、`RULE-REQ-001`、`RULE-VERSION-001`、`RULE-VERSION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-001#c006`

## FP-BM-SR-0009

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-003-production_not_enabled`
- 快照时点 `as_of`：2026-08-04T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`production_not_enabled`

### 题面

> 客户反馈Starter Account 这个账户尚未启用 Production，却请求创建那把密钥。这种情况应该如何判断：该 Key 创建是否应成功，套餐是否是拒绝原因？

### 判分标准

标准答案：

> Account 创建后只有 Sandbox 权限；启用 Production 前不能创建 Production Key。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0009-A1` Account 创建后只有 Sandbox 权限；启用 Production 前不能创建 Production Key。

禁止结论（说了就算错）：

- 不得认定：Starter 套餐永远不能启用 Production

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-010`
- 操作：—
- 规则：`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-004`、`RULE-REGION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-010#c004`

## FP-BM-SR-0013

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-004-production_suspended`
- 快照时点 `as_of`：2026-08-05T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`production_suspended`

### 题面

> 我们遇到了这种情况：这个账户仍持有 active 的那把密钥，Production 请求 那次请求全部返回 FP-4032，而 Sandbox 请求正常。请问这是 Key 被撤销、套餐降级还是 Production 被暂停？

### 判分标准

标准答案：

> Production 暂停时现有 Live Key 保留，但 Production 请求返回 FP-4032；Sandbox 不受影响。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0013-A1` Production 暂停时现有 Live Key 保留，但 Production 请求返回 FP-4032；Sandbox 不受影响。

禁止结论（说了就算错）：

- 不得认定：把所有 403 都当作套餐功能限制

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-020`
- 操作：—
- 规则：`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-020#c007`

## FP-BM-SR-0017

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-005-region_currency_mismatch`
- 快照时点 `as_of`：2026-08-06T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`region_currency_mismatch`

### 题面

> 请帮忙确认一下。EU Account 这个账户为 这位客户创建 USD Payment 那笔支付，那次请求返回 FP-4001。我们想知道是否可以把 Account 临时改成 NA 来完成这笔 USD 支付？

### 判分标准

标准答案：

> Account 主地区决定支持币种，主地区创建后不能通过公开 API 修改。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0017-A1` Account 主地区决定支持币种，主地区创建后不能通过公开 API 修改。

禁止结论（说了就算错）：

- 不得认定：通过 API 临时修改主地区即可绕过币种约束

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-003`
- 操作：—
- 规则：`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REGION-001`、`RULE-REGION-002`、`RULE-REGION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-003#c006`

## FP-BM-SR-0021

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-006-payment_amount_bounds`
- 快照时点 `as_of`：2026-08-07T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_amount_bounds`

### 题面

> 客户反馈这个账户连续提交 amount=49 和 amount=100000001 的 Payment 请求，均未创建那笔支付。这种情况应该如何判断：两次请求为什么失败，重试原请求是否有意义？

### 判分标准

标准答案：

> Payment 金额必须是最小货币单位整数，范围为 50 到 100,000,000。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0021-A1` Payment 金额必须是最小货币单位整数，范围为 50 到 100,000,000。

禁止结论（说了就算错）：

- 不得认定：金额越界属于临时平台错误

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-013`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-REGION-001`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-013#c003`

## FP-BM-SR-0025

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-007-starter_subscription_entitlement`
- 快照时点 `as_of`：2026-08-08T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`starter_subscription_entitlement`

### 题面

> 请帮忙确认一下。Starter Account 这个账户的 subscriptions Flag 被配置为 true，但创建 这份订阅返回 FP-4031。我们想知道Feature Flag 是否足以使创建成功？

### 判分标准

标准答案：

> Subscription 只对 Growth 和 Scale 开放，Feature Flag 不能越过套餐硬限制。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0025-A1` Subscription 只对 Growth 和 Scale 开放，Feature Flag 不能越过套餐硬限制。

禁止结论（说了就算错）：

- 不得认定：后台打开 Feature Flag 就能授予任何套餐能力

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-004`
- 操作：—
- 规则：`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-PLAN-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-004#c003`

## FP-BM-SR-0029

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-008-plan_upgrade_immediate`
- 快照时点 `as_of`：2026-08-09T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`plan_upgrade_immediate`

### 题面

> 目前能确认的是：这个账户在 10:00 从 Starter 升级为 Growth，10:01 创建 这份订阅。接下来需要判断10:01 应按 Starter 还是 Growth 判断权限？

### 判分标准

标准答案：

> 套餐升级在申请时立即生效，后续请求按已生效的新套餐判断。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0029-A1` 套餐升级在申请时立即生效，后续请求按已生效的新套餐判断。

禁止结论（说了就算错）：

- 不得认定：升级要等到下个计费周期才生效

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-005`
- 操作：—
- 规则：`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`、`RULE-ENV-003`、`RULE-PLAN-002`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-005#c005`

## FP-BM-SR-0033

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-009-plan_downgrade_deferred`
- 快照时点 `as_of`：2026-08-10T12:00:00Z　接口版本：2026-07-01
- 标签：`accounts`、`plan_downgrade_deferred`

### 题面

> 想咨询一个问题：Scale Account 这个账户在周期中申请降为 Starter；申请后、周期结束前又创建了 这个回调地址。新 Endpoint 应按 Scale 还是 Starter 上限判断？

### 判分标准

标准答案：

> 套餐降级在当前计费周期结束时生效，申请时间不等于生效时间。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0033-A1` 套餐降级在当前计费周期结束时生效，申请时间不等于生效时间。

禁止结论（说了就算错）：

- 不得认定：提交降级申请会立刻套用 Starter 上限

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-004`
- 操作：—
- 规则：`RULE-PLAN-001`、`RULE-PLAN-002`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-PLAN-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-004#c005`

## FP-BM-SR-0037

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-010-api_key_rotation_overlap`
- 快照时点 `as_of`：2026-08-11T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`api_key_rotation_overlap`

### 题面

> 目前能确认的是：这个账户创建新 那把密钥后，旧 Key 进入 expiring；发布仍有部分实例使用旧 Key。接下来需要判断是否必须立即撤销旧 Key，以及怎样避免发布中断？

### 判分标准

标准答案：

> Key 轮换时旧 Key 最长可保持 24 小时 expiring，撤销前仍可用。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0037-A1` Key 轮换时旧 Key 最长可保持 24 小时 expiring，撤销前仍可用。

禁止结论（说了就算错）：

- 不得认定：创建新 Key 会自动让旧 Key 立即失效

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-006`
- 操作：—
- 规则：`RULE-AUTH-001`、`RULE-AUTH-002`、`RULE-AUTH-003`、`RULE-AUTH-004`、`RULE-AUTH-005`、`RULE-AUTH-006`、`RULE-AUTH-007`、`RULE-AUTH-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-006#c004`

## FP-BM-SR-0041

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-011-revoked_key_is_terminal`
- 快照时点 `as_of`：2026-08-12T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`revoked_key_is_terminal`

### 题面

> 我们遇到了这种情况：那把密钥被撤销后，这个账户尝试把它重新标记 active，并继续发送 那次请求。请问旧 Key 能否恢复使用？

### 判分标准

标准答案：

> API Key 撤销即时生效且不可恢复，后续请求返回 FP-4011。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0041-A1` API Key 撤销即时生效且不可恢复，后续请求返回 FP-4011。

禁止结论（说了就算错）：

- 不得认定：重新启用 revoked Key 比创建新 Key更安全

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-004`
- 操作：—
- 规则：`RULE-AUTH-001`、`RULE-AUTH-003`、`RULE-AUTH-004`、`RULE-ERROR-002`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-004#c007`

## FP-BM-SR-0045

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-012-version_header_selection`
- 快照时点 `as_of`：2026-08-13T12:00:00Z　接口版本：2026-04-01
- 标签：`developer_platform`、`version_header_selection`

### 题面

> 客户反馈这个账户默认版本为 新版接口，那次请求显式发送 FlowPay-Version: 旧版接口。这种情况应该如何判断：请求应使用默认版本还是失败？

### 判分标准

标准答案：

> 请求 Header 可覆盖 Account 默认版本；不支持的版本返回 FP-4002，不能自动回退。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0045-A1` 请求 Header 可覆盖 Account 默认版本；不支持的版本返回 FP-4002，不能自动回退。

禁止结论（说了就算错）：

- 不得认定：错误版本 Header 会被静默忽略

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-006`
- 操作：—
- 规则：`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-003`、`RULE-VERSION-004`、`RULE-VERSION-005`、`RULE-VERSION-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-006#c005`

## FP-BM-SR-0049

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-013-source_deprecated_2026_04`
- 快照时点 `as_of`：2026-08-14T12:00:00Z　接口版本：2026-04-01
- 标签：`payments`、`source_deprecated_2026_04`

### 题面

> 想咨询一个问题：这个账户使用 API Version 当前部署使用的接口版本 和 source 创建那笔支付，响应含弃用提示。这次请求应失败还是成功，迁移时应改什么？

### 判分标准

标准答案：

> 在 2026-04-01 中 source 仍可使用但会产生弃用提示，payment_method 是推荐参数。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0049-A1` 在 2026-04-01 中 source 仍可使用但会产生弃用提示，payment_method 是推荐参数。

禁止结论（说了就算错）：

- 不得认定：看到弃用提示就说明该参数已经被移除

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-007`
- 操作：—
- 规则：`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-003`、`RULE-VERSION-004`、`RULE-VERSION-005`、`RULE-VERSION-006`、`RULE-VERSION-007`、`RULE-VERSION-008`、`RULE-VERSION-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-007#c003`

## FP-BM-SR-0053

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-014-source_removed_2026_07`
- 快照时点 `as_of`：2026-08-15T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`source_removed_2026_07`

### 题面

> 我们遇到了这种情况：这个账户升级到 当前部署使用的接口版本 后仍用 source 创建那笔支付，那次请求返回 FP-4003。请问是否可以重试相同请求解决问题？

### 判分标准

标准答案：

> 从 2026-07-01 起 source 被移除，使用时返回 FP-4003，必须改用 payment_method。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0053-A1` 从 2026-07-01 起 source 被移除，使用时返回 FP-4003，必须改用 payment_method。

禁止结论（说了就算错）：

- 不得认定：FP-4003 是偶发参数校验错误

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-018`
- 操作：—
- 规则：`RULE-PAY-005`、`RULE-VERSION-001`、`RULE-VERSION-002`、`RULE-VERSION-005`、`RULE-VERSION-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-018#c002`

## FP-BM-SR-0057

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-015-requires_action_version_difference`
- 快照时点 `as_of`：2026-08-16T12:00:00Z　接口版本：2026-01-15
- 标签：`payments`、`requires_action_version_difference`

### 题面

> 客户反馈同一客户操作场景分别由 旧版接口 与 新版接口 请求创建 Payment。这种情况应该如何判断：两个版本应分别看到什么状态和错误？

### 判分标准

标准答案：

> requires_action 只在 2026-01-15 及以后版本出现；旧版本将同类场景表示为 failed + FP-4023。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0057-A1` requires_action 只在 2026-01-15 及以后版本出现；旧版本将同类场景表示为 failed + FP-4023。

禁止结论（说了就算错）：

- 不得认定：所有版本都会返回 requires_action

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`release_notes`
- 工具：`search_release_notes`
- 文档：`KB-REL-003`
- 操作：—
- 规则：`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-005`、`RULE-VERSION-002`、`RULE-VERSION-009`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_release_notes`

### 快照里的实况

证据 ID：`doc:KB-REL-003#c002`

## FP-BM-SR-0061

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-016-idempotent_replay_same_params`
- 快照时点 `as_of`：2026-08-17T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`idempotent_replay_same_params`

### 题面

> 想咨询一个问题：这个账户在网络超时后用相同参数和相同 Idempotency Key 重试创建那笔支付。是否会创建第二个 Payment？

### 判分标准

标准答案：

> 同一 Account、环境、Endpoint 内，同一 Idempotency Key 与完全相同参数在 24 小时内返回首次结果。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0061-A1` 同一 Account、环境、Endpoint 内，同一 Idempotency Key 与完全相同参数在 24 小时内返回首次结果。

禁止结论（说了就算错）：

- 不得认定：每次 HTTP 重试都会创建新 Payment

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-033`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-002`、`RULE-IDEMP-003`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-IDEMP-006`、`RULE-REQ-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-033#c004`

## FP-BM-SR-0065

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-017-idempotency_conflict`
- 快照时点 `as_of`：2026-08-18T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`idempotency_conflict`

### 题面

> 想咨询一个问题：这个账户先用 amount=5000 创建那笔支付，随后用同一 Key 把 amount 改为 7000。第二次请求应修改原 Payment 还是创建新 Payment？

### 判分标准

标准答案：

> 同一幂等作用域内，相同 Key 使用不同参数返回 FP-4091，不覆盖第一次结果。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0065-A1` 同一幂等作用域内，相同 Key 使用不同参数返回 FP-4091，不覆盖第一次结果。

禁止结论（说了就算错）：

- 不得认定：同一 Key 可以用来表达修改后的业务意图

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-008`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-002`、`RULE-IDEMP-003`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-IDEMP-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-008#c007`

## FP-BM-SR-0069

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-018-idempotency_expired`
- 快照时点 `as_of`：2026-08-19T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`idempotency_expired`

### 题面

> 请帮忙确认一下。这个账户在首次创建那笔支付的 25 小时后，以相同参数和同一 Key 再次发送请求。我们想知道第二次请求是否仍应返回第一次 Payment？

### 判分标准

标准答案：

> 幂等结果保留 24 小时；超过窗口后复用相同 Key 被视为新请求。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0069-A1` 幂等结果保留 24 小时；超过窗口后复用相同 Key 被视为新请求。

禁止结论（说了就算错）：

- 不得认定：Idempotency Key 永久全局唯一

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-013`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-IDEMP-002`、`RULE-IDEMP-003`、`RULE-IDEMP-004`、`RULE-IDEMP-005`、`RULE-IDEMP-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-013#c006`

## FP-BM-SR-0073

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-019-sandbox_fixed_rate_limit`
- 快照时点 `as_of`：2026-08-20T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`sandbox_fixed_rate_limit`

### 题面

> 想咨询一个问题：Scale Account 这个账户在 Sandbox 一分钟发送 200 个请求并出现 FP-4291。是否应按 Scale 的 5,000 req/min 判断？

### 判分标准

标准答案：

> Sandbox 固定为 120 req/min、180 burst，不受 Production 套餐影响。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0073-A1` Sandbox 固定为 120 req/min、180 burst，不受 Production 套餐影响。

禁止结论（说了就算错）：

- 不得认定：购买 Scale 会提高 Sandbox 限额

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-034`
- 操作：—
- 规则：`RULE-PLAN-005`、`RULE-RATE-001`、`RULE-RATE-002`、`RULE-RATE-003`、`RULE-RATE-004`、`RULE-RATE-005`、`RULE-RATE-006`、`RULE-RATE-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-034#c003`

## FP-BM-SR-0077

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-020-growth_rate_burst`
- 快照时点 `as_of`：2026-08-21T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`growth_rate_burst`

### 题面

> 想咨询一个问题：Growth Account 这个账户在一分钟内产生 1,420 个请求，10 秒峰值未超过 1,500，部分请求返回 FP-4291。这是否说明套餐被降级？

### 判分标准

标准答案：

> Production Rate Limit 使用请求发生时已生效套餐；Growth 持续 1,200 req/min、短时 burst 1,500。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0077-A1` Production Rate Limit 使用请求发生时已生效套餐；Growth 持续 1,200 req/min、短时 burst 1,500。

禁止结论（说了就算错）：

- 不得认定：429 是套餐状态发生变化的证据

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`support_cases`
- 工具：`search_support_cases`
- 文档：`KB-CASE-005`
- 操作：—
- 规则：`RULE-PLAN-005`、`RULE-RATE-001`、`RULE-RATE-003`、`RULE-RATE-004`、`RULE-RATE-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_support_cases`

### 快照里的实况

证据 ID：`doc:KB-CASE-005#c005`

## FP-BM-SR-0081

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-021-rate_retry_storm`
- 快照时点 `as_of`：2026-08-22T12:00:00Z　接口版本：2026-07-01
- 标签：`developer_platform`、`rate_retry_storm`

### 题面

> 目前能确认的是：这个账户首次接近 Growth 上限后，客户端对每个 429 立即并发重试 5 次，那次请求形成重试链。接下来需要判断持续 429 的主要原因是套餐降级还是客户端重试放大？

### 判分标准

标准答案：

> 429 应使用指数退避；立即并发重试会增加 Usage 并延长限流。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0081-A1` 429 应使用指数退避；立即并发重试会增加 Usage 并延长限流。

禁止结论（说了就算错）：

- 不得认定：只要增加重试次数就能更快恢复

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-005`
- 操作：—
- 规则：`RULE-PLAN-005`、`RULE-RATE-001`、`RULE-RATE-002`、`RULE-RATE-003`、`RULE-RATE-004`、`RULE-RATE-005`、`RULE-RATE-006`、`RULE-RATE-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-005#c005`

## FP-BM-SR-0085

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-022-webhooks_excluded_from_rate_limit`
- 快照时点 `as_of`：2026-08-23T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhooks_excluded_from_rate_limit`

### 题面

> 目前能确认的是：这个账户同一分钟有 900 次 API 请求和 700 次 Webhook Delivery Attempt，套餐为 Growth。接下来需要判断Rate Limit 计数应是 900 还是 1,600？

### 判分标准

标准答案：

> Webhook Delivery 不计入 Merchant API Rate Limit，限流边界是 Account + 环境的 API 请求。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0085-A1` Webhook Delivery 不计入 Merchant API Rate Limit，限流边界是 Account + 环境的 API 请求。

禁止结论（说了就算错）：

- 不得认定：所有 FlowPay 发出的 HTTP 流量都计入商户限流

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-005`
- 操作：—
- 规则：`RULE-PLAN-005`、`RULE-RATE-001`、`RULE-RATE-002`、`RULE-RATE-003`、`RULE-RATE-004`、`RULE-RATE-005`、`RULE-RATE-006`、`RULE-RATE-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-005#c001`

## FP-BM-SR-0089

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-023-customer_soft_delete_history`
- 快照时点 `as_of`：2026-08-24T12:00:00Z　接口版本：2026-07-01
- 标签：`customers`、`customer_soft_delete_history`

### 题面

> 目前能确认的是：这位客户被删除后，历史 那笔支付仍能被 这个账户查询并显示原 Customer ID。接下来需要判断这是否表示删除失败？

### 判分标准

标准答案：

> Customer 删除是软删除，已有 Payment、Refund、Subscription 和 Invoice 仍保留 Customer ID。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0089-A1` Customer 删除是软删除，已有 Payment、Refund、Subscription 和 Invoice 仍保留 Customer ID。

禁止结论（说了就算错）：

- 不得认定：删除 Customer 应级联删除所有历史交易

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-009`
- 操作：—
- 规则：`RULE-CUSTOMER-001`、`RULE-CUSTOMER-002`、`RULE-CUSTOMER-003`、`RULE-CUSTOMER-004`、`RULE-CUSTOMER-005`、`RULE-TENANT-001`、`RULE-TENANT-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-009#c004`

## FP-BM-SR-0093

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-024-deleted_customer_new_payment`
- 快照时点 `as_of`：2026-08-25T12:00:00Z　接口版本：2026-07-01
- 标签：`customers`、`deleted_customer_new_payment`

### 题面

> 想咨询一个问题：这位客户已 deleted，这个账户随后尝试创建新 那笔支付，请求返回状态错误。能否重新使用这个 Customer ID 创建 Payment？

### 判分标准

标准答案：

> deleted Customer 不能创建新的 Payment 或 Subscription，但历史对象保留。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0093-A1` deleted Customer 不能创建新的 Payment 或 Subscription，但历史对象保留。

禁止结论（说了就算错）：

- 不得认定：既然历史 Payment 可见，Customer 就仍可用于新交易

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-014`
- 操作：—
- 规则：`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-REFUND-001`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-014#c004`

## FP-BM-SR-0097

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-025-duplicate_customer_email`
- 快照时点 `as_of`：2026-08-26T12:00:00Z　接口版本：2026-07-01
- 标签：`customers`、`duplicate_customer_email`

### 题面

> 客户反馈这个账户中有两个 active Customer 使用相同 Email，其中只有 这位客户关联目标 Payment。这种情况应该如何判断：能否仅用 Email 确定应更新哪个 Customer？

### 判分标准

标准答案：

> Customer Email 不是唯一键，精确关联必须使用 Customer ID。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0097-A1` Customer Email 不是唯一键，精确关联必须使用 Customer ID。

禁止结论（说了就算错）：

- 不得认定：相同 Email 代表同一个 Customer

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-009`
- 操作：—
- 规则：`RULE-CUSTOMER-001`、`RULE-CUSTOMER-002`、`RULE-CUSTOMER-003`、`RULE-CUSTOMER-004`、`RULE-CUSTOMER-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-009#c004`

## FP-BM-SR-0101

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-026-payment_success_terminal`
- 快照时点 `as_of`：2026-08-01T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_success_terminal`

### 题面

> 客户反馈那笔支付已 succeeded，之后客户端尝试再次 confirm，并在列表与详情接口中查询它。这种情况应该如何判断：Payment 是否会重新进入 processing？

### 判分标准

标准答案：

> succeeded、failed、canceled 都是 Payment 终态，读取版本不会改变内部状态。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0101-A1` succeeded、failed、canceled 都是 Payment 终态，读取版本不会改变内部状态。

禁止结论（说了就算错）：

- 不得认定：再次 confirm 可以重新处理已成功 Payment

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-010`
- 操作：—
- 规则：`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-PAY-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-010#c003`

## FP-BM-SR-0105

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-027-confirm_requires_action`
- 快照时点 `as_of`：2026-08-02T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`confirm_requires_action`

### 题面

> 请帮忙确认一下。当前部署使用的接口版本 Payment 那笔支付处于 requires_action，客户完成验证后发送 confirm。我们想知道confirm 后允许发生什么状态变化？

### 判分标准

标准答案：

> 只有 requires_action Payment 可由 confirm 推进到 processing，随后才可能成功或失败。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0105-A1` 只有 requires_action Payment 可由 confirm 推进到 processing，随后才可能成功或失败。

禁止结论（说了就算错）：

- 不得认定：confirm 会直接把任何 Payment 强制改成 succeeded

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-010`
- 操作：—
- 规则：`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-PAY-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-010#c004`

## FP-BM-SR-0109

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-028-cancel_payment_state_guard`
- 快照时点 `as_of`：2026-08-03T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`cancel_payment_state_guard`

### 题面

> 我们遇到了这种情况：这个账户尝试取消 processing 的那笔支付，那次请求返回 FP-4221。请问是否应该把 Payment 改成 canceled？

### 判分标准

标准答案：

> 只有 requires_action 可被 Merchant 主动取消；processing 和终态不能用 cancel 改变。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0109-A1` 只有 requires_action 可被 Merchant 主动取消；processing 和终态不能用 cancel 改变。

禁止结论（说了就算错）：

- 不得认定：所有未成功 Payment 都可以取消

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-010`
- 操作：—
- 规则：`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`、`RULE-PAY-006`、`RULE-PAY-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-010#c003`

## FP-BM-SR-0113

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-029-failed_payment_new_retry`
- 快照时点 `as_of`：2026-08-04T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`failed_payment_new_retry`

### 题面

> 想咨询一个问题：那笔支付因支付方式被拒绝进入 failed；商户对原 ID 再次 confirm，并在 Payment 列表查找后续尝试。正确的重试模型是什么？

### 判分标准

标准答案：

> failed Payment 是终态，重试收费必须创建新 Payment，不能原地恢复。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0113-A1` failed Payment 是终态，重试收费必须创建新 Payment，不能原地恢复。

禁止结论（说了就算错）：

- 不得认定：把 failed Payment 原地改回 processing 能保持订单连续性

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-021`
- 操作：—
- 规则：`RULE-ERROR-002`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-003`、`RULE-PAY-004`、`RULE-PAY-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-021#c003`

## FP-BM-SR-0117

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-030-payment_method_declined`
- 快照时点 `as_of`：2026-08-05T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_method_declined`

### 题面

> 我们遇到了这种情况：那笔支付返回 FP-4021，Request 那次请求没有平台 Incident，客户认为稍后重试同一 Payment 即可。请问根因类别和正确处置是什么？

### 判分标准

标准答案：

> FP-4021 表示支付方式被拒绝；Payment 进入 failed，原样重试不会复活它。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0117-A1` FP-4021 表示支付方式被拒绝；Payment 进入 failed，原样重试不会复活它。

禁止结论（说了就算错）：

- 不得认定：FP-4021 表示 FlowPay 服务降级

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-006`
- 操作：—
- 规则：`RULE-ERROR-002`、`RULE-PAY-001`、`RULE-PAY-002`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-006#c001`

## FP-BM-SR-0121

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-031-payment_insufficient_funds`
- 快照时点 `as_of`：2026-08-06T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_insufficient_funds`

### 题面

> 客户反馈那笔支付返回 FP-4022；同一客户此前另一笔 Payment 曾返回 FP-4021。这种情况应该如何判断：这次能否沿用上次的拒绝根因？

### 判分标准

标准答案：

> FP-4022 表示资金不足，与一般拒绝和平台错误是不同失败类别。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0121-A1` FP-4022 表示资金不足，与一般拒绝和平台错误是不同失败类别。

禁止结论（说了就算错）：

- 不得认定：相同 HTTP 402 的所有错误根因都相同

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-011`
- 操作：—
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-011#c003`

## FP-BM-SR-0125

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-032-payment_method_expired`
- 快照时点 `as_of`：2026-08-07T12:00:00Z　接口版本：2026-07-01
- 标签：`payments`、`payment_method_expired`

### 题面

> 想咨询一个问题：那笔支付使用已过期支付方式并返回 FP-4024，商户准备重放同一请求。原样重放是否可能成功？

### 判分标准

标准答案：

> FP-4024 表示支付方式已过期，属于 Payment 失败而非参数或服务错误。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0125-A1` FP-4024 表示支付方式已过期，属于 Payment 失败而非参数或服务错误。

禁止结论（说了就算错）：

- 不得认定：FP-4024 可以通过 API 重试退避自动恢复

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-009`
- 操作：—
- 规则：`RULE-ERROR-002`、`RULE-PAY-001`、`RULE-PAY-002`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-009#c004`

## FP-BM-SR-0129

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-033-action_required_old_and_new`
- 快照时点 `as_of`：2026-08-08T12:00:00Z　接口版本：2026-01-15
- 标签：`payments`、`action_required_old_and_new`

### 题面

> 目前能确认的是：这个账户的旧客户端与新客户端对同一类验证场景分别创建 Payment。接下来需要判断为什么两个 Payment 的状态不同，是否是数据不一致？

### 判分标准

标准答案：

> 客户操作要求在旧版表现为 failed + FP-4023，在 2026-01-15 起表现为 requires_action。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0129-A1` 客户操作要求在旧版表现为 failed + FP-4023，在 2026-01-15 起表现为 requires_action。

禁止结论（说了就算错）：

- 不得认定：同一业务原因必须在所有版本中有完全相同状态字段

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-011`
- 操作：—
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-ERROR-004`、`RULE-PAY-001`、`RULE-PAY-002`、`RULE-PAY-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-011#c005`

## FP-BM-SR-0133

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-034-refund_processing_payment`
- 快照时点 `as_of`：2026-08-09T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`refund_processing_payment`

### 题面

> 想咨询一个问题：那笔支付仍为 processing，这个账户为它创建那笔退款，那次请求返回 FP-4221。是否已创建 pending Refund，以及正确等待条件是什么？

### 判分标准

标准答案：

> 只有 succeeded Payment 可创建 Refund；对 processing Payment 请求退款返回 FP-4221。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0133-A1` 只有 succeeded Payment 可创建 Refund；对 processing Payment 请求退款返回 FP-4221。

禁止结论（说了就算错）：

- 不得认定：processing 已代表扣款完成，可以先占用退款额度

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-019`
- 操作：—
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-019#c005`

## FP-BM-SR-0137

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-035-starter_full_refund_only`
- 快照时点 `as_of`：2026-08-10T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`starter_full_refund_only`

### 题面

> 客户反馈Starter Account 这个账户对 succeeded 的那笔支付申请小于剩余金额的那笔退款，返回 FP-4031。这种情况应该如何判断：Payment 可退款为何请求仍失败？

### 判分标准

标准答案：

> Starter 只支持对剩余可退金额进行一次全额退款，不支持部分退款。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0137-A1` Starter 只支持对剩余可退金额进行一次全额退款，不支持部分退款。

禁止结论（说了就算错）：

- 不得认定：只要 Payment succeeded，任何套餐都支持部分退款

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`support_cases`
- 工具：`search_support_cases`
- 文档：`KB-CASE-011`
- 操作：—
- 规则：`RULE-PLAN-001`、`RULE-PLAN-004`、`RULE-REFUND-002`、`RULE-REFUND-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_support_cases`

### 快照里的实况

证据 ID：`doc:KB-CASE-011#c005`

## FP-BM-SR-0141

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-036-growth_multiple_partial_refunds`
- 快照时点 `as_of`：2026-08-11T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`growth_multiple_partial_refunds`

### 题面

> 我们遇到了这种情况：Growth Account 这个账户对 10,000 的那笔支付先成功退款 2,000，再申请 3,000。请问第二笔部分 Refund 是否允许，剩余可退金额是多少？

### 判分标准

标准答案：

> Growth 和 Scale 支持多次部分退款，但 pending 与 succeeded 金额合计不能超过 Payment 金额。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0141-A1` Growth 和 Scale 支持多次部分退款，但 pending 与 succeeded 金额合计不能超过 Payment 金额。

禁止结论（说了就算错）：

- 不得认定：部分退款只能发生一次

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-022`
- 操作：—
- 规则：`RULE-MONEY-004`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-TENANT-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-022#c003`

## FP-BM-SR-0145

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-037-pending_refund_reserves_amount`
- 快照时点 `as_of`：2026-08-12T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`pending_refund_reserves_amount`

### 题面

> 目前能确认的是：10,000 的那笔支付已有 6,000 pending 那笔退款，这个账户又申请 5,000。接下来需要判断第二次请求能否通过？

### 判分标准

标准答案：

> pending Refund 暂时占用可退额度，计算时与 succeeded Refund 一同计入。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0145-A1` pending Refund 暂时占用可退额度，计算时与 succeeded Refund 一同计入。

禁止结论（说了就算错）：

- 不得认定：pending 尚未成功，所以不影响可退余额

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-012`
- 操作：—
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`、`RULE-REFUND-007`、`RULE-REFUND-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-012#c007`

## FP-BM-SR-0149

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-038-failed_refund_releases_amount`
- 快照时点 `as_of`：2026-08-13T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`failed_refund_releases_amount`

### 题面

> 目前能确认的是：那笔支付的 4,000 pending 那笔退款随后 failed；商户再次查询可退金额。接下来需要判断这 4,000 是否仍被占用？

### 判分标准

标准答案：

> pending Refund 进入 failed 或 canceled 后释放其占用的可退款额度。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0149-A1` pending Refund 进入 failed 或 canceled 后释放其占用的可退款额度。

禁止结论（说了就算错）：

- 不得认定：Refund 一旦创建就永久占用额度

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-019`
- 操作：—
- 规则：`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REFUND-001`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-019#c004`

## FP-BM-SR-0153

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-039-refund_window_expired`
- 快照时点 `as_of`：2026-08-14T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`refund_window_expired`

### 题面

> 我们遇到了这种情况：那笔支付在 181 天前 succeeded，当前仍有全部金额未退；这个账户创建那笔退款返回 FP-4222。请问有剩余金额是否足以使退款成功？

### 判分标准

标准答案：

> Payment 成功超过 180 天后不可退款，返回 FP-4222。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0153-A1` Payment 成功超过 180 天后不可退款，返回 FP-4222。

禁止结论（说了就算错）：

- 不得认定：可退余额大于零就代表永远可退款

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-015`
- 操作：—
- 规则：`RULE-REFUND-001`、`RULE-REFUND-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-015#c002`

## FP-BM-SR-0157

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-040-instant_refund_scale_na`
- 快照时点 `as_of`：2026-08-15T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`instant_refund_scale_na`

### 题面

> 想咨询一个问题：NA Scale Account 这个账户已开启 instant_refund，对 那笔支付申请 80,000 的那笔退款。该请求是否具备 Instant Refund 资格？

### 判分标准

标准答案：

> Instant Refund 需要 Scale、NA/EU、功能开关开启且金额不超过 100,000。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0157-A1` Instant Refund 需要 Scale、NA/EU、功能开关开启且金额不超过 100,000。

禁止结论（说了就算错）：

- 不得认定：Instant Refund 只由 Scale 套餐单一条件决定

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-021`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-021#c005`

## FP-BM-SR-0161

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-041-instant_refund_apac`
- 快照时点 `as_of`：2026-08-16T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`instant_refund_apac`

### 题面

> 请帮忙确认一下。APAC Scale Account 这个账户开启 Flag 后，对 那笔支付请求 50,000 Instant Refund。我们想知道请求是否应因 Scale 身份而成功？

### 判分标准

标准答案：

> Instant Refund 仅在 NA 和 EU 可用；APAC 即使是 Scale 且 Flag 开启也不符合地区条件。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0161-A1` Instant Refund 仅在 NA 和 EU 可用；APAC 即使是 Scale 且 Flag 开启也不符合地区条件。

禁止结论（说了就算错）：

- 不得认定：Scale 可以覆盖地区限制

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-003`
- 操作：—
- 规则：`RULE-MONEY-001`、`RULE-MONEY-002`、`RULE-MONEY-003`、`RULE-MONEY-004`、`RULE-REGION-001`、`RULE-REGION-002`、`RULE-REGION-003`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-003#c003`

## FP-BM-SR-0165

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-042-instant_refund_flag_and_amount`
- 快照时点 `as_of`：2026-08-17T12:00:00Z　接口版本：2026-07-01
- 标签：`refunds`、`instant_refund_flag_and_amount`

### 题面

> 想咨询一个问题：EU Scale Account 这个账户的 Flag 起初关闭，随后开启但请求 120,000 的 Instant Refund。两次尝试分别为什么不具备资格？

### 判分标准

标准答案：

> Instant Refund 的金额不得超过 100,000，且必须显式开启功能开关。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0165-A1` Instant Refund 的金额不得超过 100,000，且必须显式开启功能开关。

禁止结论（说了就算错）：

- 不得认定：只要后续打开 Flag，之前和超额请求都会自动合法

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-021`
- 操作：—
- 规则：`RULE-IDEMP-001`、`RULE-PLAN-004`、`RULE-REFUND-001`、`RULE-REFUND-002`、`RULE-REFUND-003`、`RULE-REFUND-004`、`RULE-REFUND-005`、`RULE-REFUND-007`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-021#c005`

## FP-BM-SR-0169

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-043-starter_subscription_blocked`
- 快照时点 `as_of`：2026-08-18T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`starter_subscription_blocked`

### 题面

> 目前能确认的是：Starter Account 这个账户使用 active 这位客户创建 这份订阅，请求参数都合法。接下来需要判断Customer active 是否足以使创建成功？

### 判分标准

标准答案：

> Subscription 只对 Growth 和 Scale 开放，Starter 返回 FP-4031。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0169-A1` Subscription 只对 Growth 和 Scale 开放，Starter 返回 FP-4031。

禁止结论（说了就算错）：

- 不得认定：参数合法就能绕过套餐权限

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-013`
- 操作：—
- 规则：`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-013#c003`

## FP-BM-SR-0173

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-044-subscription_trial_bounds`
- 快照时点 `as_of`：2026-08-19T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_trial_bounds`

### 题面

> 请帮忙确认一下。这个账户先尝试以 trial_days=31 创建 这份订阅，之后又想给已 active 的 Subscription 补加试用期。我们想知道两种操作是否允许？

### 判分标准

标准答案：

> 试用期只能在创建时设置，范围为 1 到 30 天。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0173-A1` 试用期只能在创建时设置，范围为 1 到 30 天。

禁止结论（说了就算错）：

- 不得认定：试用期可在任意时间延长

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-024`
- 操作：—
- 规则：`RULE-CUSTOMER-004`、`RULE-IDEMP-001`、`RULE-IDEMP-004`、`RULE-PLAN-001`、`RULE-PLAN-004`、`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-024#c004`

## FP-BM-SR-0177

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-045-subscription_cancel_period_end`
- 快照时点 `as_of`：2026-08-20T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_cancel_period_end`

### 题面

> 想咨询一个问题：这份订阅在周期中收到默认取消请求，当前时间尚未到 period_end。它应立即 canceled 还是继续 active？

### 判分标准

标准答案：

> 主动取消默认在当前周期末生效；在此之前 Subscription 继续 active。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0177-A1` 主动取消默认在当前周期末生效；在此之前 Subscription 继续 active。

禁止结论（说了就算错）：

- 不得认定：所有取消请求都立即终止服务

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-013`
- 操作：—
- 规则：`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-013#c007`

## FP-BM-SR-0181

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-046-subscription_cancel_immediately`
- 快照时点 `as_of`：2026-08-21T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_cancel_immediately`

### 题面

> 请帮忙确认一下。这个账户对 active 的 这份订阅发送 immediate=true 取消，随后尝试恢复。我们想知道取消与恢复请求应如何处理？

### 判分标准

标准答案：

> 只有显式请求立即取消时，Subscription 才立刻进入 canceled；canceled 是终态。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0181-A1` 只有显式请求立即取消时，Subscription 才立刻进入 canceled；canceled 是终态。

禁止结论（说了就算错）：

- 不得认定：canceled Subscription 可以切回 active

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-025`
- 操作：—
- 规则：`RULE-CUSTOMER-003`、`RULE-SUB-004`、`RULE-SUB-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-025#c003`

## FP-BM-SR-0185

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-047-subscription_immutable_identity`
- 快照时点 `as_of`：2026-08-22T12:00:00Z　接口版本：2026-07-01
- 标签：`subscriptions`、`subscription_immutable_identity`

### 题面

> 我们遇到了这种情况：这份订阅已绑定 这位客户和 USD，这个账户尝试改成另一个 Customer 与 CAD。请问能否直接更新这两个字段？

### 判分标准

标准答案：

> Subscription 创建后不能更换 Customer 或币种；变更需要取消原资源并新建。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0185-A1` Subscription 创建后不能更换 Customer 或币种；变更需要取消原资源并新建。

禁止结论（说了就算错）：

- 不得认定：active Subscription 的所有字段都可更新

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-023`
- 操作：—
- 规则：`RULE-SUB-001`、`RULE-SUB-002`、`RULE-SUB-003`、`RULE-SUB-004`、`RULE-SUB-005`、`RULE-SUB-006`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-023#c003`

## FP-BM-SR-0189

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-048-invoice_retry_day1_success`
- 快照时点 `as_of`：2026-08-23T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`invoice_retry_day1_success`

### 题面

> 请帮忙确认一下。那张账单首次 Payment 失败使 这份订阅past_due，第 1 天新 那笔支付成功。我们想知道Invoice 与 Subscription 最终应是什么状态？

### 判分标准

标准答案：

> Invoice 首次扣费失败后第 1、3、7 天重试；任一重试成功使 Invoice paid、Subscription 恢复 active。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0189-A1` Invoice 首次扣费失败后第 1、3、7 天重试；任一重试成功使 Invoice paid、Subscription 恢复 active。

禁止结论（说了就算错）：

- 不得认定：重试成功后仍要执行第 3、7 天重试

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-027`
- 操作：—
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-PAY-002`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-027#c004`

## FP-BM-SR-0193

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-049-invoice_retry_day3_success`
- 快照时点 `as_of`：2026-08-24T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`invoice_retry_day3_success`

### 题面

> 想咨询一个问题：那张账单首次与第 1 天 Payment 失败，第 3 天 Payment 成功。应该存在几笔 Payment，是否继续第 7 天重试？

### 判分标准

标准答案：

> Invoice 每次重试创建新 Payment；第 3 天成功后恢复 Subscription 并停止第 7 天任务。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0193-A1` Invoice 每次重试创建新 Payment；第 3 天成功后恢复 Subscription 并停止第 7 天任务。

禁止结论（说了就算错）：

- 不得认定：重试应复用第一笔 failed Payment ID

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-014`
- 操作：—
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-INVOICE-007`、`RULE-INVOICE-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-014#c004`

## FP-BM-SR-0197

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-050-invoice_retries_exhausted`
- 快照时点 `as_of`：2026-08-25T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`invoice_retries_exhausted`

### 题面

> 我们遇到了这种情况：那张账单的四次 Payment 全部 failed，这份订阅仍显示 past_due。请问这个状态是否符合规则？

### 判分标准

标准答案：

> 首次失败及第 1、3、7 天三次重试全部失败后，Invoice uncollectible、Subscription canceled。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0197-A1` 首次失败及第 1、3、7 天三次重试全部失败后，Invoice uncollectible、Subscription canceled。

禁止结论（说了就算错）：

- 不得认定：重试耗尽后 Subscription 会无限保持 past_due

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-027`
- 操作：—
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-PAY-002`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-027#c004`

## FP-BM-SR-0201

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-051-paid_invoice_cannot_void`
- 快照时点 `as_of`：2026-08-26T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`paid_invoice_cannot_void`

### 题面

> 想咨询一个问题：那张账单已 paid，这个账户为纠正账单说明而调用 void。Invoice 是否应变成 void？

### 判分标准

标准答案：

> paid Invoice 不允许执行 void，终态不能由 void 操作改变。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0201-A1` paid Invoice 不允许执行 void，终态不能由 void 操作改变。

禁止结论（说了就算错）：

- 不得认定：void 是可以覆盖任何 Invoice 状态的管理操作

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-014`
- 操作：—
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-004`、`RULE-INVOICE-005`、`RULE-INVOICE-006`、`RULE-INVOICE-007`、`RULE-INVOICE-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-014#c006`

## FP-BM-SR-0205

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-052-open_invoice_can_void`
- 快照时点 `as_of`：2026-08-01T12:00:00Z　接口版本：2026-07-01
- 标签：`invoices`、`open_invoice_can_void`

### 题面

> 请帮忙确认一下。那张账单已 open 但尚未支付，这个账户决定作废它。我们想知道void 是否允许，之后还能否继续扣费？

### 判分标准

标准答案：

> draft 或 open Invoice 可以进入 void；paid、uncollectible、void 不可由 void 操作改变。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0205-A1` draft 或 open Invoice 可以进入 void；paid、uncollectible、void 不可由 void 操作改变。

禁止结论（说了就算错）：

- 不得认定：只有 draft Invoice 才能 void

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-026`
- 操作：—
- 规则：`RULE-INVOICE-001`、`RULE-INVOICE-002`、`RULE-INVOICE-003`、`RULE-INVOICE-007`、`RULE-INVOICE-008`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-026#c004`

## FP-BM-SR-0209

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-053-starter_endpoint_limit`
- 快照时点 `as_of`：2026-08-02T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`starter_endpoint_limit`

### 题面

> 我们遇到了这种情况：Starter Account 这个账户已有两个 enabled Endpoint，又尝试创建 这个回调地址。请问第三个 Endpoint 是否应创建？

### 判分标准

标准答案：

> Starter 最多 2 个 Webhook Endpoint，超出套餐能力返回 FP-4031。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0209-A1` Starter 最多 2 个 Webhook Endpoint，超出套餐能力返回 FP-4031。

禁止结论（说了就算错）：

- 不得认定：Endpoint 上限只影响投递，不影响创建

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-029`
- 操作：—
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-029#c003`

## FP-BM-SR-0213

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-054-downgrade_restricts_newer_endpoints`
- 快照时点 `as_of`：2026-08-03T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`downgrade_restricts_newer_endpoints`

### 题面

> 想咨询一个问题：这个账户从 Growth 降至 Starter，原有五个 Endpoint，其中 这个回调地址是较晚创建的第三个。降级生效后这个 Endpoint 应删除、disabled 还是 restricted？

### 判分标准

标准答案：

> 套餐降级不删除超额 Endpoint；按创建时间保留最早的可用数量，其余变为 restricted。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0213-A1` 套餐降级不删除超额 Endpoint；按创建时间保留最早的可用数量，其余变为 restricted。

禁止结论（说了就算错）：

- 不得认定：降级会物理删除所有超额 Endpoint

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-029`
- 操作：—
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-PLAN-004`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-029#c005`

## FP-BM-SR-0217

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-055-disabled_endpoint_no_delivery`
- 快照时点 `as_of`：2026-08-04T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`disabled_endpoint_no_delivery`

### 题面

> 请帮忙确认一下。这个回调地址在 Event 那个事件发生前已 disabled，商户搜索不到 那次投递。我们想知道缺少 Delivery 是否说明平台丢失了 Webhook？

### 判分标准

标准答案：

> 只有 enabled Endpoint 接收新事件；disabled Endpoint 不产生 Delivery 记录。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0217-A1` 只有 enabled Endpoint 接收新事件；disabled Endpoint 不产生 Delivery 记录。

禁止结论（说了就算错）：

- 不得认定：任何已配置 Endpoint 都必须为每个 Event 产生 Delivery

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-015`
- 操作：—
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-015#c002`

## FP-BM-SR-0221

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-056-endpoint_not_subscribed`
- 快照时点 `as_of`：2026-08-05T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`endpoint_not_subscribed`

### 题面

> 目前能确认的是：那笔支付成功并产生 那个事件，enabled 的 这个回调地址只订阅 payment.failed，因此没有 那次投递。接下来需要判断这是投递失败还是配置不匹配？

### 判分标准

标准答案：

> Endpoint 必须显式订阅事件类型；未订阅时不创建 Delivery。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0221-A1` Endpoint 必须显式订阅事件类型；未订阅时不创建 Delivery。

禁止结论（说了就算错）：

- 不得认定：Endpoint enabled 就会接收所有 Event Type

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`support_cases`
- 工具：`search_support_cases`
- 文档：`KB-CASE-015`
- 操作：—
- 规则：`RULE-PAY-007`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_support_cases`

### 快照里的实况

证据 ID：`doc:KB-CASE-015#c004`

## FP-BM-SR-0225

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-057-payment_event_name_by_version`
- 快照时点 `as_of`：2026-08-06T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`payment_event_name_by_version`

### 题面

> 客户反馈那笔支付由 当前部署使用的接口版本 请求创建并成功，这个回调地址只订阅 payment.completed。这种情况应该如何判断：应生成哪种 Event，为什么 Endpoint 没收到？

### 判分标准

标准答案：

> 2026-07-01 起成功事件名为 payment.succeeded；此前版本使用 payment.completed。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0225-A1` 2026-07-01 起成功事件名为 payment.succeeded；此前版本使用 payment.completed。

禁止结论（说了就算错）：

- 不得认定：Account 创建时间决定 Event 名称

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-015`
- 操作：—
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-015#c002`

## FP-BM-SR-0229

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-058-scheduled_event_uses_account_default`
- 快照时点 `as_of`：2026-08-07T12:00:00Z　接口版本：2026-04-01
- 标签：`webhooks`、`scheduled_event_uses_account_default`

### 题面

> 目前能确认的是：这个账户默认版本为 当前部署使用的接口版本；Scheduler 生成 那张账单并产生 那个事件，没有外部请求 Header。接下来需要判断Event 应采用什么版本，Payment 成功事件名如何判断？

### 判分标准

标准答案：

> 由订阅周期任务等平台内部操作产生的 Event 使用 Account 当时默认 API Version。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0229-A1` 由订阅周期任务等平台内部操作产生的 Event 使用 Account 当时默认 API Version。

禁止结论（说了就算错）：

- 不得认定：平台内部事件总使用最新版本

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-015`
- 操作：—
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-015#c004`

## FP-BM-SR-0233

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-059-webhook_2xx_success`
- 快照时点 `as_of`：2026-08-08T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_2xx_success`

### 题面

> 客户反馈那次投递第一次 Attempt 收到 HTTP 204，系统仍安排下一次重试。这种情况应该如何判断：这个重试计划是否正确？

### 判分标准

标准答案：

> Webhook 响应 200～299 均视为成功，不再调度重试。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0233-A1` Webhook 响应 200～299 均视为成功，不再调度重试。

禁止结论（说了就算错）：

- 不得认定：只有 HTTP 200 才算成功

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-015`
- 操作：—
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-015#c006`

## FP-BM-SR-0237

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-060-webhook_redirect_retry`
- 快照时点 `as_of`：2026-08-09T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_redirect_retry`

### 题面

> 客户反馈这个回调地址对 那次投递返回 HTTP 302 和 Location，团队认为 FlowPay 会跟随跳转。这种情况应该如何判断：Delivery 应成功还是进入重试？

### 判分标准

标准答案：

> Webhook 3xx 不跟随重定向，视为失败并按策略重试。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0237-A1` Webhook 3xx 不跟随重定向，视为失败并按策略重试。

禁止结论（说了就算错）：

- 不得认定：提供 Location 就等同于成功投递

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-023`
- 操作：—
- 规则：`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-013`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-023#c007`

## FP-BM-SR-0241

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-061-webhook_4xx_retry`
- 快照时点 `as_of`：2026-08-10T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_4xx_retry`

### 题面

> 目前能确认的是：那次投递首次收到 HTTP 400，这个回调地址仍 enabled。接下来需要判断是否应立即终止 Delivery？

### 判分标准

标准答案：

> 除 410 外，Webhook 4xx 与 5xx 都进入重试。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0241-A1` 除 410 外，Webhook 4xx 与 5xx 都进入重试。

禁止结论（说了就算错）：

- 不得认定：所有 4xx 都永久禁用 Endpoint

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-015`
- 操作：—
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-015#c002`

## FP-BM-SR-0245

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-062-webhook_410_disables_endpoint`
- 快照时点 `as_of`：2026-08-11T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_410_disables_endpoint`

### 题面

> 目前能确认的是：那次投递第一次收到 HTTP 410，之后又为同一 Endpoint 调度重试并接收新 Event。接下来需要判断这些后续行为是否符合规则？

### 判分标准

标准答案：

> HTTP 410 是普通 4xx 的例外，会立即禁用 Endpoint，不继续重试。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0245-A1` HTTP 410 是普通 4xx 的例外，会立即禁用 Endpoint，不继续重试。

禁止结论（说了就算错）：

- 不得认定：410 与 400 一样走默认六次重试

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-032`
- 操作：—
- 规则：`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-032#c004`

## FP-BM-SR-0249

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-063-webhook_default_retry_exhaustion`
- 快照时点 `as_of`：2026-08-12T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_default_retry_exhaustion`

### 题面

> 目前能确认的是：那次投递首次失败且六个默认重试均返回 500。接下来需要判断最终状态和 Attempt 数量应如何计算？

### 判分标准

标准答案：

> 默认在 1m、5m、30m、2h、8h、24h 重试；完成六次重试仍失败后 Delivery exhausted。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0249-A1` 默认在 1m、5m、30m、2h、8h、24h 重试；完成六次重试仍失败后 Delivery exhausted。

禁止结论（说了就算错）：

- 不得认定：六次重试包含首次投递，所以总共只有六次 Attempt

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-015`
- 操作：—
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-015#c005`

## FP-BM-SR-0253

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-064-scale_custom_retry`
- 快照时点 `as_of`：2026-08-13T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`scale_custom_retry`

### 题面

> 请帮忙确认一下。Scale Account 这个账户先配置 9 次自定义重试，随后改为 8 次但总窗口为 80 小时。我们想知道两份配置是否有效？

### 判分标准

标准答案：

> 只有 Scale 可自定义 Webhook 重试，最多 8 次且总窗口不超过 72 小时。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0253-A1` 只有 Scale 可自定义 Webhook 重试，最多 8 次且总窗口不超过 72 小时。

禁止结论（说了就算错）：

- 不得认定：满足次数上限就可以忽略套餐和总窗口

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-015`
- 操作：—
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-015#c005`

## FP-BM-SR-0257

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-065-webhook_at_least_once`
- 快照时点 `as_of`：2026-08-14T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_at_least_once`

### 题面

> 客户反馈那个事件的首次 那次投递已被 Merchant 处理，但响应丢失导致 FlowPay 重试，Merchant 再次收到相同 Event ID。这种情况应该如何判断：第二次是否代表发生了新的 Payment？

### 判分标准

标准答案：

> Webhook 使用至少一次语义，同一 Event 可能多次投递；Merchant 必须按 event_id 去重。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0257-A1` Webhook 使用至少一次语义，同一 Event 可能多次投递；Merchant 必须按 event_id 去重。

禁止结论（说了就算错）：

- 不得认定：每个 Webhook 请求都代表一个新的业务事件

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-015`
- 操作：—
- 规则：`RULE-ENV-004`、`RULE-PLAN-003`、`RULE-WEBHOOK-001`、`RULE-WEBHOOK-002`、`RULE-WEBHOOK-003`、`RULE-WEBHOOK-004`、`RULE-WEBHOOK-005`、`RULE-WEBHOOK-006`、`RULE-WEBHOOK-007`、`RULE-WEBHOOK-008`、`RULE-WEBHOOK-009`、`RULE-WEBHOOK-010`、`RULE-WEBHOOK-011`、`RULE-WEBHOOK-012`、`RULE-WEBHOOK-017`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-015#c006`

## FP-BM-SR-0261

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `dev`

- 场景：`SC-066-signature_header_by_version`
- 快照时点 `as_of`：2026-08-15T12:00:00Z　接口版本：2026-04-01
- 标签：`webhooks`、`signature_header_by_version`

### 题面

> 请帮忙确认一下。那个事件使用 当前部署使用的接口版本，这个回调地址的接收端仍只读取 X-FlowPay-Signature，因而报签名缺失。我们想知道FlowPay 是否未签名，还是接收端读取了错误 Header？

### 判分标准

标准答案：

> 2026-04-01 起签名 Header 为 FlowPay-Signature；旧版使用 X-FlowPay-Signature。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0261-A1` 2026-04-01 起签名 Header 为 FlowPay-Signature；旧版使用 X-FlowPay-Signature。

禁止结论（说了就算错）：

- 不得认定：所有 API Version 都同时发送两个签名 Header

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-031`
- 操作：—
- 规则：`RULE-WEBHOOK-013`、`RULE-WEBHOOK-014`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-031#c006`

## FP-BM-SR-0265

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-067-signature_timestamp_tolerance`
- 快照时点 `as_of`：2026-08-16T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`signature_timestamp_tolerance`

### 题面

> 想咨询一个问题：那次投递的签名摘要正确，但接收端验证时与 signature_timestamp 相差 8 分钟。是否应该接受这次请求？

### 判分标准

标准答案：

> Webhook 签名时间戳默认容差为 5 分钟，超出时即使摘要匹配也应拒绝。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0265-A1` Webhook 签名时间戳默认容差为 5 分钟，超出时即使摘要匹配也应拒绝。

禁止结论（说了就算错）：

- 不得认定：只要 HMAC 正确就可以忽略时间戳

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`business_rules`
- 工具：`search_business_rules`
- 文档：`KB-BR-016`
- 操作：—
- 规则：`RULE-WEBHOOK-013`、`RULE-WEBHOOK-014`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_business_rules`

### 快照里的实况

证据 ID：`doc:KB-BR-016#c004`

## FP-BM-SR-0269

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-068-signing_secret_rotation_window`
- 快照时点 `as_of`：2026-08-17T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`signing_secret_rotation_window`

### 题面

> 我们遇到了这种情况：这个回调地址在 10:00 轮换 Secret；10:05 的新 那次投递使用新版本，接收端仅配置旧 Secret。请问新投递能否继续只用旧 Secret 验证？

### 判分标准

标准答案：

> Secret 轮换后新投递立即使用新 Secret，旧 Secret 继续有效 24 小时。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0269-A1` Secret 轮换后新投递立即使用新 Secret，旧 Secret 继续有效 24 小时。

禁止结论（说了就算错）：

- 不得认定：24 小时内所有新投递仍由旧 Secret 签名

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`api_docs`
- 工具：`search_api_docs`
- 文档：`KB-API-031`
- 操作：—
- 规则：`RULE-WEBHOOK-013`、`RULE-WEBHOOK-014`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_api_docs`

### 快照里的实况

证据 ID：`doc:KB-API-031#c005`

## FP-BM-SR-0273

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-069-webhook_retry_resigned`
- 快照时点 `as_of`：2026-08-18T12:00:00Z　接口版本：2026-07-01
- 标签：`webhooks`、`webhook_retry_resigned`

### 题面

> 我们遇到了这种情况：那次投递首次失败后，这个回调地址在下一次重试前轮换 Secret。请问重试应使用旧 Secret 还是新 Secret？

### 判分标准

标准答案：

> Webhook 重试在发生时使用 Endpoint 当前 Secret 重新签名，不复用首次 Attempt 的签名。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0273-A1` Webhook 重试在发生时使用 Endpoint 当前 Secret 重新签名，不复用首次 Attempt 的签名。

禁止结论（说了就算错）：

- 不得认定：同一 Delivery 的所有 Attempt 必须复用第一次签名

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`release_notes`
- 工具：`search_release_notes`
- 文档：`KB-REL-006`
- 操作：—
- 规则：`RULE-WEBHOOK-013`、`RULE-WEBHOOK-014`、`RULE-WEBHOOK-015`、`RULE-WEBHOOK-016`、`RULE-WEBHOOK-017`、`RULE-WEBHOOK-018`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_release_notes`

### 快照里的实况

证据 ID：`doc:KB-REL-006#c005`

## FP-BM-SR-0277

**单点检索**（`simple_retrieval`） · 难度 1 · 单轮 · `test`

- 场景：`SC-070-distinguish_500_and_503`
- 快照时点 `as_of`：2026-08-19T12:00:00Z　接口版本：2026-07-01
- 标签：`operations`、`distinguish_500_and_503`

### 题面

> 请帮忙确认一下。这个账户的一个 那次请求返回 FP-5001，随后同地区大量请求返回 FP-5031 并存在 这次服务异常。我们想知道两类错误是否应归为同一个 Merchant 配置问题？

### 判分标准

标准答案：

> FP-5001 是单次内部处理错误，FP-5031 表示服务暂时降级；二者不能直接归因于商户配置。

必需结论（全部要被证据支持）：

- `FP-BM-SR-0277-A1` FP-5001 是单次内部处理错误，FP-5031 表示服务暂时降级；二者不能直接归因于商户配置。

禁止结论（说了就算错）：

- 不得认定：所有 5xx 都说明 Webhook Endpoint 配置错误

结束条件：所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。

### 该走到哪

- 数据源：`troubleshooting`
- 工具：`search_troubleshooting`
- 文档：`KB-TS-018`
- 操作：—
- 规则：`RULE-ERROR-001`、`RULE-ERROR-002`、`RULE-ERROR-003`、`RULE-IDEMP-004`
- 禁用捷径：`support_case_as_current_fact`、`current_state_used_for_historical_question`、`raw_sql_or_hidden_audit_access`

预期步骤：

1. 获取适用的正式规则与版本证据　→ `search_troubleshooting`

### 快照里的实况

证据 ID：`doc:KB-TS-018#c002`
