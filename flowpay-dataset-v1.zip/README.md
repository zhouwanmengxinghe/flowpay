# FlowPay 数据工程

课程用到的全部数据都出自这里：100 篇业务知识文档、300 道冻结 Benchmark，以及一个无第三方依赖的确定性场景编译器与模拟器。

这个目录**只负责造数据**。Agentic RAG 的实现、评测与教程在仓库上层的 `backend/`、`scripts/benchmark/` 和 `docs/tutorials/`。

## 哪些是冻结产物，哪些要自己生成

已经入库、不需要重建：

| 路径 | 内容 |
| --- | --- |
| `data/knowledge/` | 100 篇文档，五类 |
| `data/index/` | 确定性切块结果 |
| `data/releases/flowpay_dataset_v1/` | V1 冻结发布清单 |
| `benchmark/design/` | 300 题蓝图与设计清单 |
| `benchmark/compiled/` | 编译后的原子命令 |
| `benchmark/resolved/` | 每题的证据解析结果 |

**不入库、需要在本机生成一次**的只有 `data/generated/`（约 152 MB 的业务快照与运行日志）。s3、s4 两级课程离开它跑不起来。

## 生成业务快照

```bash
cd dataset
PYTHONPATH=src python3 -m flowpay_simulator.cli simulate
```

默认输出到 `data/generated/canonical/`。目录已存在时命令拒绝覆盖，要替换得显式传 `--force`。

产物：

- `flowpay.sqlite`：业务事实表与 Audit 表
- `runtime/*.jsonl`：API 请求、用量、投递尝试、平台事故
- `audit/event_journal.jsonl`：完整事件日志，不提供给 Agent
- `audit/invariant_report.json`：状态机、金额、引用、ID 与敏感信息校验
- `manifest.json`：全部文件的数量与 SHA-256

想先快速验证链路通不通，用小规模背景数据：

```bash
PYTHONPATH=src python3 -m flowpay_simulator.cli simulate \
  --background smoke --output /tmp/flowpay-smoke
```

相同 `--seed` 得到相同快照，`manifest.json` 的哈希可逐位比对。

## 单独编译场景

`simulate` 内部会先编译，一般不需要单独跑。要检查设计工件有没有被改动时：

```bash
PYTHONPATH=src python3 -m flowpay_simulator.cli compile
```

编译器先校验 `benchmark/design/design_manifest.json` 里的 SHA-256，再解析 75 个场景族、实体预留表和 300 条蓝图。任何设计文件被静默修改都会拒绝编译。

## 测试

```bash
cd dataset
PYTHONPATH=src python3 -m unittest discover -s tests
```

覆盖编译器的确定性、75 个场景族的完整性、SQLite 投影，以及相同 seed 下的快照哈希一致性。

## 设计依据

数据为什么长这样，见 `docs/`：

- `00_foundation/FlowPay_业务规则总表.md`：平台规则的唯一真相来源，文档和数据都按它生成
- `00_foundation/FlowPay_知识语料生成与约束规范.md`：100 篇文档的写作约束
- `00_foundation/FlowPay_项目目录与文件说明.md`：各目录用途
- `01_system/FlowPay_确定性模拟系统设计.md`：模拟器怎么保证可重放
- `01_system/FlowPay_数据生成场景编译与回放规范.md`：场景编译的规则
- `02_benchmark/FlowPay_300题Benchmark设计规范.md`：题目分型与证据契约

数据库表结构见仓库上层的 [DATABASE_SCHEMA.md](../docs/DATABASE_SCHEMA.md)。
