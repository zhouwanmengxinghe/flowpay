#!/usr/bin/env python3
# 生成以问题为中心的评测设计与覆盖资料，不生成运行数据库记录。
"""Build the frozen, question-first FlowPay benchmark design artifacts.

This script does not generate SQL rows or runtime data.  It turns a curated
catalog of 75 scenario families into the four design artifacts that must be
frozen before the simulator is implemented or run.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
KNOWLEDGE_DIR = ROOT / "data" / "knowledge"
RULES_PATH = ROOT / "docs" / "00_foundation" / "FlowPay_业务规则总表.md"
OUT_DIR = ROOT / "benchmark" / "design"

QUESTION_TYPE_QUOTA = {
    "dev": {
        "simple_retrieval": 14,
        "multi_document": 10,
        "multi_hop": 12,
        "multi_source": 14,
        "temporal_versioned": 5,
        "tool_use_diagnostic": 5,
    },
    "test": {
        "simple_retrieval": 56,
        "multi_document": 40,
        "multi_hop": 48,
        "multi_source": 56,
        "temporal_versioned": 20,
        "tool_use_diagnostic": 20,
    },
}

TYPE_CODE = {
    "simple_retrieval": "SR",
    "multi_document": "MD",
    "multi_hop": "MH",
    "multi_source": "MS",
    "temporal_versioned": "TV",
    "tool_use_diagnostic": "DG",
}

DOC_TOOL = {
    "KB-BR": "search_business_rules",
    "KB-API": "search_api_docs",
    "KB-TS": "search_troubleshooting",
    "KB-REL": "search_release_notes",
    "KB-CASE": "search_support_cases",
}

DOC_SOURCE = {
    "KB-BR": "business_rules",
    "KB-API": "api_docs",
    "KB-TS": "troubleshooting",
    "KB-REL": "release_notes",
    "KB-CASE": "support_cases",
}

ALL_LOGICAL_TOOLS = {
    "search_business_rules",
    "search_api_docs",
    "search_troubleshooting",
    "search_release_notes",
    "search_support_cases",
    "query_accounts",
    "query_payments",
    "query_webhooks",
    "get_runtime_state",
}

QUESTION_ROUTE_LEAKAGE_PHRASES = {
    "Published",
    "Business Rules",
    "API / Product Docs",
    "操作/排障文档",
    "Runtime",
    "Tool",
    "SQLite",
    "SQL",
    "Agent",
    "运行证据显示",
    "请沿",
    " → ",
    "Required Document",
    "search_",
    "query_",
    "get_runtime_state",
    "冻结时刻",
}

ENTITY_PREFIX = {
    "account": "acct",
    "key": "key",
    "customer": "cus",
    "payment": "pay",
    "refund": "re",
    "subscription": "sub",
    "invoice": "in",
    "endpoint": "we",
    "event": "evt",
    "delivery": "del",
    "request": "req",
    "incident": "inc",
}

# The first user turn is deliberately symptom-only.  These are written as
# things a merchant operator or developer could realistically say before the
# assistant has asked for environment, time, version, error details or IDs.
REALISTIC_OPENINGS = {
    "cross_tenant_payment_visibility": "后台里明明能看到一笔支付，但我们从服务里查询时一直提示找不到。",
    "sandbox_key_on_production": "测试时一直正常，可一上线创建支付就变成认证失败了。",
    "production_not_enabled": "我们刚开好账户，准备接正式环境，但创建正式密钥时被拒绝了。",
    "production_suspended": "正式环境的请求突然全都被拒绝了，可测试环境还是正常的。",
    "region_currency_mismatch": "有个欧洲客户下单时支付创建失败，我们怀疑是币种设置的问题。",
    "payment_amount_bounds": "有两笔金额很特殊的支付怎么都建不出来，普通金额却没问题。",
    "starter_subscription_entitlement": "我们已经把订阅功能开关打开了，但创建订阅仍然提示没有权限。",
    "plan_upgrade_immediate": "我们刚升级套餐，紧接着使用新功能时，不确定系统有没有按新套餐处理。",
    "plan_downgrade_deferred": "我们提交了降级，之后又新增了一个回调地址，不确定它会不会受新套餐限制。",
    "api_key_rotation_overlap": "我们正在更换线上密钥，担心新旧实例切换期间会中断请求。",
    "revoked_key_is_terminal": "有把线上密钥误操作停用了，现在旧部署全部认证失败。",
    "version_header_selection": "有一批请求突然报版本不支持，但账户里的默认版本看起来没问题。",
    "source_deprecated_2026_04": "支付还能创建成功，不过响应里一直提示一个参数快不能用了。",
    "source_removed_2026_07": "升级接口版本以后，原来能用的支付参数突然全部报错。",
    "requires_action_version_difference": "同一种需要客户确认的支付，在两套客户端里表现成了完全不同的状态。",
    "idempotent_replay_same_params": "一次创建支付超时后我们重试了，现在担心系统生成了两笔支付。",
    "idempotency_conflict": "我们重试创建支付时改了金额，结果既没更新也没新建。",
    "idempotency_expired": "隔了一天多重试同一笔业务后，系统里好像多出了一笔支付。",
    "sandbox_fixed_rate_limit": "压测测试环境时很快就被限流了，降低并发后还是容易触发。",
    "growth_rate_burst": "线上流量短时间冲高后开始大量限流，但平时的请求量并不大。",
    "rate_retry_storm": "服务被限流后，客户端越重试错误越多，流量反而一直降不下来。",
    "webhooks_excluded_from_rate_limit": "业务接口被限流的同时，回调还在持续收到，我们不确定这是否正常。",
    "customer_soft_delete_history": "客户被删除后后台仍能查到以前的支付，我们担心删除没有生效。",
    "deleted_customer_new_payment": "一个已经删除的客户仍被业务系统拿来创建新支付，结果一直失败。",
    "duplicate_customer_email": "同一个邮箱似乎对应了两个客户，我们不知道支付该关联哪一个。",
    "payment_success_terminal": "一笔已经成功的支付后来又收到状态更新，我们担心它被改回处理中。",
    "confirm_requires_action": "客户已经完成验证，但那笔待确认支付仍没有继续成功。",
    "cancel_payment_state_guard": "我们想取消一笔支付，接口却说当前状态不允许取消。",
    "failed_payment_new_retry": "一笔失败支付修好原因后，我们反复重试原对象还是没有变化。",
    "payment_method_declined": "客户付款时被拒绝了，但我们看不出是平台故障还是支付方式的问题。",
    "payment_insufficient_funds": "客户说卡能正常使用，可这笔支付一直提示资金方面的问题。",
    "payment_method_expired": "一批老客户最近付款失败，似乎都和保存过的支付方式有关。",
    "action_required_old_and_new": "同一类客户验证问题，在新旧客户端里一个显示失败，一个显示待操作。",
    "refund_processing_payment": "支付还在处理中，客服就发起了退款，系统没有接受。",
    "starter_full_refund_only": "客服想给客户退一部分金额，但退款接口一直拒绝。",
    "growth_multiple_partial_refunds": "同一笔支付已经退过一部分，现在第二次部分退款出现了额度问题。",
    "pending_refund_reserves_amount": "一笔退款还没处理完，客服又发起退款时发现可退金额变少了。",
    "failed_refund_releases_amount": "之前的退款失败了，但客服不确定那部分金额还能不能重新退。",
    "refund_window_expired": "客服在给一笔很久以前的支付退款时被拒绝了。",
    "instant_refund_scale_na": "我们给北美客户做快速退款，但结果没有按预期立刻完成。",
    "instant_refund_apac": "亚太地区的一笔退款勾选了快速到账，却一直无法提交。",
    "instant_refund_flag_and_amount": "快速退款偶尔能用、偶尔被拒绝，我们怀疑和账户配置或金额有关。",
    "starter_subscription_blocked": "普通支付没问题，但一创建订阅就提示当前账户不能使用。",
    "subscription_trial_bounds": "创建带试用期的订阅时，某些天数可以，某些天数直接报参数错误。",
    "subscription_cancel_period_end": "客户选择到期取消订阅，但我们担心系统会立即停掉服务。",
    "subscription_cancel_immediately": "客服执行立即取消后，客户仍在问这一期是否还会继续计费。",
    "subscription_immutable_identity": "业务想把现有订阅转给另一个客户，同时顺便换结算币种。",
    "invoice_retry_day1_success": "订阅扣款第一次失败后很快恢复了，我们想确认账单是否还会继续重试。",
    "invoice_retry_day3_success": "订阅账单连续失败了几次，后来客户补足余额，不确定系统接下来怎么处理。",
    "invoice_retries_exhausted": "一张订阅账单多次扣款失败后就不再尝试了，订阅状态也变了。",
    "paid_invoice_cannot_void": "客服想作废一张账单，但系统提示它当前不能作废。",
    "open_invoice_can_void": "客户不再需要一张尚未支付的账单，客服想确认能否直接作废。",
    "starter_endpoint_limit": "我们给账户新增回调地址时突然提示数量已到上限。",
    "downgrade_restricts_newer_endpoints": "套餐降级后，部分回调地址还在，部分却不再接收新事件。",
    "disabled_endpoint_no_delivery": "一个已停用的回调地址似乎还和事件有关，我们想确认会不会继续产生投递。",
    "endpoint_not_subscribed": "支付已经成功，但其中一个回调地址始终收不到对应事件。",
    "payment_event_name_by_version": "支付成功以后，新旧回调消费者收到的事件名称不一样。",
    "scheduled_event_uses_account_default": "系统自动产生的事件版本和我们最近一次接口请求的版本对不上。",
    "webhook_2xx_success": "回调服务返回成功后，我们偶尔仍看到重复事件，不确定平台是否认为投递失败。",
    "webhook_redirect_retry": "回调地址做了跳转以后，平台没有跟过去，反而不断重试。",
    "webhook_4xx_retry": "回调服务明确返回客户端错误，平台却还是继续重试投递。",
    "webhook_410_disables_endpoint": "回调服务返回资源已删除后，这个地址突然被系统停用了。",
    "webhook_default_retry_exhaustion": "一个回调地址故障很久后，平台似乎已经停止继续投递。",
    "scale_custom_retry": "我们给高级套餐配置了自己的回调重试节奏，但实际重试时间和预期不一致。",
    "webhook_at_least_once": "业务收到两次内容相同的回调，担心系统重复执行了付款逻辑。",
    "signature_header_by_version": "升级回调版本后，验签程序突然找不到原来的签名请求头。",
    "signature_timestamp_tolerance": "回调内容和密钥看起来都对，但验签仍提示时间不合法。",
    "signing_secret_rotation_window": "我们正在轮换回调密钥，担心切换期间旧实例会突然验签失败。",
    "webhook_retry_resigned": "同一个回调事件重试时签名发生了变化，接收方把它当成篡改。",
    "distinguish_500_and_503": "线上请求有时返回内部错误，有时又显示服务暂不可用，我们不知道处理方式是否一样。",
    "regional_service_incident": "只有某个地区的线上请求明显变慢并报错，其他地区基本正常。",
    "request_id_before_auth": "请求在认证阶段就失败了，开发同学说因此没法继续排查。",
    "resource_not_visible_semantics": "查询资源时统一提示不存在，但我们不确定是编号错了还是权限问题。",
    "runtime_retention_by_plan": "我们想排查一段时间以前的请求，但控制台已经查不到记录了。",
    "payment_to_webhook_end_to_end": "客户已经付款成功，但业务系统一直没有收到对应的回调通知。",
}

ENTITY_DISPLAY = {
    "account": "这个账户", "key": "那把密钥", "customer": "这位客户",
    "payment": "那笔支付", "refund": "那笔退款", "subscription": "这份订阅",
    "invoice": "那张账单", "endpoint": "这个回调地址", "event": "那个事件",
    "delivery": "那次投递", "request": "那次请求", "incident": "这次服务异常",
}


def parse_scalar(value: str):
    value = value.strip()
    if value == "null":
        return None
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        if not inner:
            return []
        return [part.strip().strip('"\'') for part in inner.split(",")]
    return value.strip('"\'')


def load_documents() -> dict[str, dict]:
    documents: dict[str, dict] = {}
    for path in sorted(KNOWLEDGE_DIR.rglob("*.md")):
        text = path.read_text(encoding="utf-8")
        if not text.startswith("---\n"):
            raise ValueError(f"missing front matter: {path}")
        front = text.split("---", 2)[1]
        meta: dict[str, object] = {}
        for line in front.splitlines():
            if ":" not in line:
                continue
            key, value = line.split(":", 1)
            meta[key.strip()] = parse_scalar(value)
        doc_id = str(meta["doc_id"])
        meta["path"] = str(path.relative_to(ROOT))
        documents[doc_id] = meta
    return documents


def load_rules() -> set[str]:
    text = RULES_PATH.read_text(encoding="utf-8")
    return set(re.findall(r"RULE-[A-Z]+-[0-9]{3}", text))


FAMILIES: list[dict] = []


def F(
    slug: str,
    title: str,
    area: str,
    policy: str,
    context: str,
    decision: str,
    expected: str,
    negative: str,
    action: str,
    docs: list[str],
    data_ops: list[str],
    entities: list[str],
    command: str,
    *,
    plan: str = "Growth",
    region: str = "NA",
    environment: str = "production",
    api_version: str = "2026-07-01",
    runtime_signal: str = "对应请求与对象状态",
    required_rule_ids: list[str] | None = None,
) -> None:
    FAMILIES.append(
        {
            "slug": slug,
            "title": title,
            "area": area,
            "policy": policy,
            "context": context,
            "decision": decision,
            "expected": expected,
            "negative": negative,
            "action": action,
            "docs": docs,
            "data_ops": data_ops,
            "entities": entities,
            "command": command,
            "plan": plan,
            "region": region,
            "environment": environment,
            "api_version": api_version,
            "runtime_signal": runtime_signal,
            "required_rule_ids": required_rule_ids,
        }
    )


# The curated catalog is appended below.  Each family expresses one causal
# business story and four independently scored questions.

F(
    "cross_tenant_payment_visibility", "跨账户 Payment 可见性", "accounts",
    "业务对象只能由所属 Account 访问；跨账户访问统一返回资源不存在或不可见语义。",
    "{account} 使用自己的 Production Key 查询另一个 Account 所属的 {payment}，请求得到 FP-4041。",
    "FP-4041 是否能证明 Payment ID 不存在，以及应如何判断这次访问",
    "不能证明 ID 不存在；该访问越过租户边界，应拒绝且不得泄漏目标资源是否存在。",
    "把 FP-4041 直接解释为 Payment ID 拼写错误",
    "核对调用 Key 的 Account、环境和 Payment 所属关系，不要尝试枚举其他租户资源。",
    ["KB-BR-001", "KB-API-014", "KB-TS-012"],
    ["query_accounts.get_account", "query_payments.get_payment", "get_runtime_state.get_request"],
    ["account", "key", "payment", "request"], "retrieve_cross_tenant_payment",
    runtime_signal="FP-4041 请求日志与资源所属账户不一致",
)

F(
    "sandbox_key_on_production", "Sandbox Key 调用 Production", "developer_platform",
    "API Key 与资源环境必须一致，Sandbox Key 访问 Production 资源返回 FP-4012。",
    "{account} 的部署加载了 Sandbox Key，却尝试为 Production Customer {customer} 创建 Payment，{request} 返回 FP-4012。",
    "根因是 Key 无效、Customer 不存在还是环境不匹配",
    "Key 本身有效，但 Key 属于 Sandbox、Customer 属于 Production，因此是环境不匹配。",
    "只要 Key 有效就可以跨环境调用",
    "替换为该 Account 的有效 Production Key；不要复制 Sandbox 资源作为修复。",
    ["KB-BR-002", "KB-API-001", "KB-API-003", "KB-TS-005", "KB-CASE-001"],
    ["query_accounts.list_api_keys", "query_payments.get_customer", "get_runtime_state.get_request"],
    ["account", "key", "customer", "request"], "create_payment_with_wrong_environment_key",
    runtime_signal="认证成功但 Key 与目标资源环境不同",
)

F(
    "production_not_enabled", "未启用 Production 时创建 Live Key", "accounts",
    "Account 创建后只有 Sandbox 权限；启用 Production 前不能创建 Production Key。",
    "Starter Account {account} 尚未启用 Production，却请求创建 {key}。",
    "该 Key 创建是否应成功，套餐是否是拒绝原因",
    "创建应被拒绝；原因是 Production 尚未启用，而不是 Starter 套餐不支持一次性支付。",
    "Starter 套餐永远不能启用 Production",
    "先完成 Production 启用，再创建新的 Production Key。",
    ["KB-BR-002", "KB-API-005", "KB-TS-010"],
    ["query_accounts.get_account", "query_accounts.list_api_keys"],
    ["account", "key", "request"], "create_production_key_before_enablement", plan="Starter",
)

F(
    "production_suspended", "Production 暂停与套餐误判", "accounts",
    "Production 暂停时现有 Live Key 保留，但 Production 请求返回 FP-4032；Sandbox 不受影响。",
    "{account} 仍持有 active 的 {key}，Production 请求 {request} 全部返回 FP-4032，而 Sandbox 请求正常。",
    "这是 Key 被撤销、套餐降级还是 Production 被暂停",
    "证据符合 Production 被暂停：Live Key 仍存在，Production 返回 FP-4032，Sandbox 正常。",
    "把所有 403 都当作套餐功能限制",
    "查询 Production 状态并解除暂停；不要轮换 Key 或升级套餐来掩盖根因。",
    ["KB-BR-002", "KB-API-005", "KB-TS-011", "KB-TS-020", "KB-CASE-003"],
    ["query_accounts.get_account", "query_accounts.list_api_keys", "get_runtime_state.list_requests"],
    ["account", "key", "request"], "suspend_production_and_send_requests",
    runtime_signal="Production 请求 FP-4032、Sandbox 请求成功",
)

F(
    "region_currency_mismatch", "地区与币种不匹配", "payments",
    "Account 主地区决定支持币种，主地区创建后不能通过公开 API 修改。",
    "EU Account {account} 为 {customer} 创建 USD Payment {payment}，{request} 返回 FP-4001。",
    "是否可以把 Account 临时改成 NA 来完成这笔 USD 支付",
    "不能；EU 不支持 USD，且主地区不可公开修改。应使用 EU 支持的 EUR/GBP 或另行设计合法账户。",
    "通过 API 临时修改主地区即可绕过币种约束",
    "按 EU 支持币种重新提交，并保留新的幂等业务意图。",
    ["KB-BR-003", "KB-TS-001"],
    ["query_accounts.get_account", "query_payments.get_customer", "get_runtime_state.get_request"],
    ["account", "customer", "payment", "request"], "create_payment_with_unsupported_currency",
    region="EU", runtime_signal="FP-4001 的 error.param 指向 currency",
)

F(
    "payment_amount_bounds", "Payment 金额边界", "payments",
    "Payment 金额必须是最小货币单位整数，范围为 50 到 100,000,000。",
    "{account} 连续提交 amount=49 和 amount=100000001 的 Payment 请求，均未创建 {payment}。",
    "两次请求为什么失败，重试原请求是否有意义",
    "两次金额分别低于最小值和高于最大值，应返回 FP-4001；原样重试不会成功。",
    "金额越界属于临时平台错误",
    "修正整数金额后用符合新业务意图的 Idempotency Key 重新提交。",
    ["KB-BR-003", "KB-API-013", "KB-API-002", "KB-TS-001"],
    ["query_payments.get_payment", "get_runtime_state.list_requests"],
    ["account", "customer", "payment", "request"], "submit_payment_amount_boundaries",
    runtime_signal="两个 FP-4001 请求且均无 Payment 响应对象",
)

F(
    "starter_subscription_entitlement", "Starter 订阅权限", "subscriptions",
    "Subscription 只对 Growth 和 Scale 开放，Feature Flag 不能越过套餐硬限制。",
    "Starter Account {account} 的 subscriptions Flag 被配置为 true，但创建 {subscription} 返回 FP-4031。",
    "Feature Flag 是否足以使创建成功",
    "不足；Starter 不具备订阅套餐权益，Flag 不能越过硬限制。",
    "后台打开 Feature Flag 就能授予任何套餐能力",
    "先升级到 Growth 或 Scale，确认升级已生效后再启用并创建 Subscription。",
    ["KB-BR-004", "KB-API-024", "KB-TS-010"],
    ["query_accounts.get_account", "query_accounts.get_feature_flags", "query_payments.get_subscription", "get_runtime_state.get_request"],
    ["account", "customer", "subscription", "request"], "create_subscription_on_starter", plan="Starter",
    runtime_signal="FP-4031 且 Flag 配置值与套餐有效权限不一致",
)

F(
    "plan_upgrade_immediate", "套餐升级立即生效", "accounts",
    "套餐升级在申请时立即生效，后续请求按已生效的新套餐判断。",
    "{account} 在 10:00 从 Starter 升级为 Growth，10:01 创建 {subscription}。",
    "10:01 应按 Starter 还是 Growth 判断权限",
    "应按 Growth；升级立即生效，满足其他条件时可创建 Subscription。",
    "升级要等到下个计费周期才生效",
    "查询套餐时间线并按请求发生时的有效套餐判断。",
    ["KB-BR-004", "KB-API-005"],
    ["query_accounts.get_plan_timeline", "query_accounts.get_feature_flags", "query_payments.get_subscription"],
    ["account", "customer", "subscription", "request"], "upgrade_plan_then_create_subscription", plan="Starter",
)

F(
    "plan_downgrade_deferred", "套餐降级延后生效", "accounts",
    "套餐降级在当前计费周期结束时生效，申请时间不等于生效时间。",
    "Scale Account {account} 在周期中申请降为 Starter；申请后、周期结束前又创建了 {endpoint}。",
    "新 Endpoint 应按 Scale 还是 Starter 上限判断",
    "周期结束前仍按 Scale；降级尚未生效。周期结束后才应用 Starter 上限和 restricted 规则。",
    "提交降级申请会立刻套用 Starter 上限",
    "核对 effective_at，并在周期结束后重新评估 Endpoint 状态。",
    ["KB-BR-004", "KB-API-029"],
    ["query_accounts.get_plan_timeline", "query_webhooks.list_endpoints"],
    ["account", "endpoint", "request"], "request_plan_downgrade_then_create_endpoint", plan="Scale",
)

F(
    "api_key_rotation_overlap", "API Key 轮换兼容窗口", "developer_platform",
    "Key 轮换时旧 Key 最长可保持 24 小时 expiring，撤销前仍可用。",
    "{account} 创建新 {key} 后，旧 Key 进入 expiring；发布仍有部分实例使用旧 Key。",
    "是否必须立即撤销旧 Key，以及怎样避免发布中断",
    "不必立即撤销；可在最长 24 小时重叠窗口内完成切换，再主动撤销旧 Key。",
    "创建新 Key 会自动让旧 Key 立即失效",
    "验证所有实例已使用新 Key后再撤销旧 Key。",
    ["KB-BR-006", "KB-API-003", "KB-CASE-002"],
    ["query_accounts.list_api_keys", "get_runtime_state.list_requests"],
    ["account", "key", "request"], "rotate_api_key_with_overlap",
    runtime_signal="新旧 Key 在 expiring 窗口内均有成功请求",
)

F(
    "revoked_key_is_terminal", "已撤销 Key 不可恢复", "developer_platform",
    "API Key 撤销即时生效且不可恢复，后续请求返回 FP-4011。",
    "{key} 被撤销后，{account} 尝试把它重新标记 active，并继续发送 {request}。",
    "旧 Key 能否恢复使用",
    "不能；revoked 是不可逆状态，请求应返回 FP-4011。",
    "重新启用 revoked Key 比创建新 Key更安全",
    "创建新的 Secret Key并更新部署，保留撤销记录。",
    ["KB-BR-006", "KB-API-003", "KB-TS-004", "KB-TS-019"],
    ["query_accounts.list_api_keys", "get_runtime_state.get_request"],
    ["account", "key", "request"], "revoke_key_then_reuse",
    runtime_signal="Key 状态 revoked 且请求 FP-4011",
)

F(
    "version_header_selection", "API Version Header 选择", "developer_platform",
    "请求 Header 可覆盖 Account 默认版本；不支持的版本返回 FP-4002，不能自动回退。",
    "{account} 默认版本为 2026-04-01，{request} 显式发送 FlowPay-Version: 2024-01-01。",
    "请求应使用默认版本还是失败",
    "应返回 FP-4002；显式但不受支持的版本不会回退到 Account 默认版本。",
    "错误版本 Header 会被静默忽略",
    "改为受支持版本或移除 Header 以使用 Account 默认版本。",
    ["KB-BR-007", "KB-API-006", "KB-TS-002", "KB-REL-001", "KB-REL-010"],
    ["query_accounts.get_account", "get_runtime_state.get_request"],
    ["account", "request"], "send_unsupported_version_header", api_version="2026-04-01",
    runtime_signal="请求记录保留显式版本 2024-01-01 和 FP-4002",
)

F(
    "source_deprecated_2026_04", "source 参数弃用期", "payments",
    "在 2026-04-01 中 source 仍可使用但会产生弃用提示，payment_method 是推荐参数。",
    "{account} 使用 API Version 2026-04-01 和 source 创建 {payment}，响应含弃用提示。",
    "这次请求应失败还是成功，迁移时应改什么",
    "source 在该版本仍兼容，请求可成功；客户端应迁移到 payment_method。",
    "看到弃用提示就说明该参数已经被移除",
    "在升级到 2026-07-01 前完成 source 到 payment_method 的迁移。",
    ["KB-BR-007", "KB-API-018", "KB-REL-004", "KB-REL-005"],
    ["query_accounts.get_account", "query_payments.get_payment", "get_runtime_state.get_request"],
    ["account", "customer", "payment", "request"], "create_payment_with_deprecated_source", api_version="2026-04-01",
    runtime_signal="Payment 创建成功且响应包含 source 弃用提示",
)

F(
    "source_removed_2026_07", "source 参数正式移除", "payments",
    "从 2026-07-01 起 source 被移除，使用时返回 FP-4003，必须改用 payment_method。",
    "{account} 升级到 2026-07-01 后仍用 source 创建 {payment}，{request} 返回 FP-4003。",
    "是否可以重试相同请求解决问题",
    "不可以；参数已从该版本移除，原样重试仍失败且不会创建 Payment。",
    "FP-4003 是偶发参数校验错误",
    "改用 payment_method，并检查所有仍发送 source 的客户端。",
    ["KB-BR-007", "KB-API-018", "KB-TS-003", "KB-REL-007", "KB-REL-008", "KB-CASE-007"],
    ["query_accounts.get_account", "query_payments.get_payment", "get_runtime_state.get_request"],
    ["account", "customer", "payment", "request"], "create_payment_with_removed_source",
    runtime_signal="FP-4003 且没有创建 Payment",
)

F(
    "requires_action_version_difference", "requires_action 版本差异", "payments",
    "requires_action 只在 2026-01-15 及以后版本出现；旧版本将同类场景表示为 failed + FP-4023。",
    "同一客户操作场景分别由 2025-10-01 与 2026-01-15 请求创建 Payment。",
    "两个版本应分别看到什么状态和错误",
    "旧版本看到 failed + FP-4023；新版本看到 requires_action，并可继续 confirm。",
    "所有版本都会返回 requires_action",
    "按请求实际 API Version 处理状态，旧客户端不能套用新状态机。",
    ["KB-BR-010", "KB-API-018", "KB-TS-008", "KB-REL-002", "KB-REL-003"],
    ["query_payments.get_payment", "query_payments.list_payments", "get_runtime_state.list_requests"],
    ["account", "customer", "payment", "request"], "compare_action_required_versions", api_version="2026-01-15",
    runtime_signal="两个版本请求产生不同的状态表示",
)

F(
    "idempotent_replay_same_params", "同参数幂等重放", "developer_platform",
    "同一 Account、环境、Endpoint 内，同一 Idempotency Key 与完全相同参数在 24 小时内返回首次结果。",
    "{account} 在网络超时后用相同参数和相同 Idempotency Key 重试创建 {payment}。",
    "是否会创建第二个 Payment",
    "不会；应返回第一次请求的 Payment 结果，两个 Request ID 指向同一 Payment。",
    "每次 HTTP 重试都会创建新 Payment",
    "保留同一 Key 和完全相同参数，并按 Request ID 核对重放结果。",
    ["KB-BR-008", "KB-API-033"],
    ["query_payments.get_payment", "query_payments.list_payments", "get_runtime_state.list_requests"],
    ["account", "customer", "payment", "request"], "replay_idempotent_payment_request",
    runtime_signal="两个请求返回同一个 Payment ID",
)

F(
    "idempotency_conflict", "幂等键参数冲突", "developer_platform",
    "同一幂等作用域内，相同 Key 使用不同参数返回 FP-4091，不覆盖第一次结果。",
    "{account} 先用 amount=5000 创建 {payment}，随后用同一 Key 把 amount 改为 7000。",
    "第二次请求应修改原 Payment 还是创建新 Payment",
    "都不会；第二次应返回 FP-4091，第一次的 Payment 和金额保持不变。",
    "同一 Key 可以用来表达修改后的业务意图",
    "为新的 7000 金额请求使用新的 Idempotency Key。",
    ["KB-BR-008", "KB-API-033", "KB-TS-013", "KB-CASE-004"],
    ["query_payments.get_payment", "query_payments.list_payments", "get_runtime_state.list_requests"],
    ["account", "customer", "payment", "request"], "reuse_idempotency_key_with_changed_amount",
    runtime_signal="首次请求成功，第二次 FP-4091 且引用冲突请求",
)

F(
    "idempotency_expired", "幂等结果超过 24 小时", "developer_platform",
    "幂等结果保留 24 小时；超过窗口后复用相同 Key 被视为新请求。",
    "{account} 在首次创建 {payment} 的 25 小时后，以相同参数和同一 Key 再次发送请求。",
    "第二次请求是否仍应返回第一次 Payment",
    "不应；24 小时窗口已过，第二次是新请求并可创建新的 Payment。",
    "Idempotency Key 永久全局唯一",
    "客户端不应在窗口外依赖旧 Key 去重，应保存业务侧订单关联。",
    ["KB-BR-008", "KB-API-033", "KB-TS-013"],
    ["query_payments.list_payments", "get_runtime_state.list_requests"],
    ["account", "customer", "payment", "request"], "reuse_idempotency_key_after_expiry",
    runtime_signal="两个相隔 25 小时的请求产生不同 Payment ID",
)

F(
    "sandbox_fixed_rate_limit", "Sandbox 固定限流", "developer_platform",
    "Sandbox 固定为 120 req/min、180 burst，不受 Production 套餐影响。",
    "Scale Account {account} 在 Sandbox 一分钟发送 200 个请求并出现 FP-4291。",
    "是否应按 Scale 的 5,000 req/min 判断",
    "不应；Sandbox 使用固定 120 req/min 和 180 burst，因此可能被限流。",
    "购买 Scale 会提高 Sandbox 限额",
    "降低 Sandbox 流量并按退避 Header 重试；不要用升级套餐解决。",
    ["KB-BR-005", "KB-API-004", "KB-API-034", "KB-TS-016"],
    ["query_accounts.get_account", "get_runtime_state.get_usage", "get_runtime_state.list_requests"],
    ["account", "request"], "send_sandbox_rate_burst", plan="Scale", environment="sandbox",
    runtime_signal="Sandbox 分钟桶超过 120 且出现 FP-4291",
)

F(
    "growth_rate_burst", "Growth 流量峰值限流", "developer_platform",
    "Production Rate Limit 使用请求发生时已生效套餐；Growth 持续 1,200 req/min、短时 burst 1,500。",
    "Growth Account {account} 在一分钟内产生 1,420 个请求，10 秒峰值未超过 1,500，部分请求返回 FP-4291。",
    "这是否说明套餐被降级",
    "不说明；当时仍是 Growth，持续请求量超过 1,200 已足以触发限流。",
    "429 是套餐状态发生变化的证据",
    "按 Usage 确认流量并实施指数退避；容量长期不足时再评估套餐。",
    ["KB-BR-005", "KB-API-034", "KB-TS-022", "KB-CASE-005"],
    ["query_accounts.get_account", "query_accounts.get_plan_timeline", "get_runtime_state.get_usage", "get_runtime_state.list_requests"],
    ["account", "request"], "send_growth_sustained_rate_burst",
    runtime_signal="Growth 分钟桶 1,420 且套餐时间线无降级",
)

F(
    "rate_retry_storm", "429 客户端重试风暴", "developer_platform",
    "429 应使用指数退避；立即并发重试会增加 Usage 并延长限流。",
    "{account} 首次接近 Growth 上限后，客户端对每个 429 立即并发重试 5 次，{request} 形成重试链。",
    "持续 429 的主要原因是套餐降级还是客户端重试放大",
    "主要原因是立即 fan-out 重试放大请求量；套餐在事发时未变化。",
    "只要增加重试次数就能更快恢复",
    "停止 fan-out，遵守 Reset/Retry-After 提示并使用指数退避。",
    ["KB-BR-005", "KB-API-034", "KB-TS-022", "KB-CASE-006"],
    ["query_accounts.get_plan_timeline", "get_runtime_state.get_usage", "get_runtime_state.list_requests"],
    ["account", "request"], "trigger_immediate_retry_storm",
    runtime_signal="retry_parent_request_id 构成 5 倍放大链",
)

F(
    "webhooks_excluded_from_rate_limit", "Webhook 投递不计 Merchant 限流", "webhooks",
    "Webhook Delivery 不计入 Merchant API Rate Limit，限流边界是 Account + 环境的 API 请求。",
    "{account} 同一分钟有 900 次 API 请求和 700 次 Webhook Delivery Attempt，套餐为 Growth。",
    "Rate Limit 计数应是 900 还是 1,600",
    "应是 900；Webhook Delivery Attempt 不计入 Merchant API Rate Limit。",
    "所有 FlowPay 发出的 HTTP 流量都计入商户限流",
    "分别查询 API Usage 与 Delivery Timeline，不要把两个指标相加。",
    ["KB-BR-005", "KB-API-034", "KB-API-032"],
    ["query_webhooks.get_delivery", "get_runtime_state.get_usage", "get_runtime_state.get_delivery_timeline"],
    ["account", "endpoint", "event", "delivery", "request"], "emit_webhooks_alongside_api_usage",
    runtime_signal="API Usage 为 900，另有独立的 700 次 Delivery Attempt",
)

F(
    "customer_soft_delete_history", "Customer 软删除保留历史", "customers",
    "Customer 删除是软删除，已有 Payment、Refund、Subscription 和 Invoice 仍保留 Customer ID。",
    "{customer} 被删除后，历史 {payment} 仍能被 {account} 查询并显示原 Customer ID。",
    "这是否表示删除失败",
    "不是；软删除只阻止新的业务创建，不移除既有对象的关联。",
    "删除 Customer 应级联删除所有历史交易",
    "把 Customer 状态显示为 deleted，同时保留审计与历史对象关联。",
    ["KB-BR-009", "KB-API-009", "KB-API-011"],
    ["query_payments.get_customer", "query_payments.list_customers", "query_payments.get_payment"],
    ["account", "customer", "payment"], "soft_delete_customer_with_history",
)

F(
    "deleted_customer_new_payment", "Deleted Customer 禁止新建 Payment", "customers",
    "deleted Customer 不能创建新的 Payment 或 Subscription，但历史对象保留。",
    "{customer} 已 deleted，{account} 随后尝试创建新 {payment}，请求返回状态错误。",
    "能否重新使用这个 Customer ID 创建 Payment",
    "不能；deleted Customer 不可恢复为 active，也不能用于新 Payment。",
    "既然历史 Payment 可见，Customer 就仍可用于新交易",
    "创建新的 active Customer，并用新 Customer ID 表达后续业务。",
    ["KB-BR-009", "KB-API-011", "KB-API-013", "KB-TS-014"],
    ["query_payments.get_customer", "query_payments.get_payment", "get_runtime_state.get_request"],
    ["account", "customer", "payment", "request"], "create_payment_for_deleted_customer",
    runtime_signal="Customer deleted，创建请求失败且未生成新 Payment",
)

F(
    "duplicate_customer_email", "Customer Email 非唯一", "customers",
    "Customer Email 不是唯一键，精确关联必须使用 Customer ID。",
    "{account} 中有两个 active Customer 使用相同 Email，其中只有 {customer} 关联目标 Payment。",
    "能否仅用 Email 确定应更新哪个 Customer",
    "不能；Email 可重复，必须先取得并使用明确的 Customer ID。",
    "相同 Email 代表同一个 Customer",
    "按 Customer ID 查询、更新和关联，避免对 Email 做唯一性假设。",
    ["KB-BR-009", "KB-API-009", "KB-API-010"],
    ["query_payments.get_customer", "query_payments.list_customers", "query_payments.list_payments"],
    ["account", "customer", "payment"], "create_customers_with_duplicate_email",
)

F(
    "payment_success_terminal", "Payment 成功终态", "payments",
    "succeeded、failed、canceled 都是 Payment 终态，读取版本不会改变内部状态。",
    "{payment} 已 succeeded，之后客户端尝试再次 confirm，并在列表与详情接口中查询它。",
    "Payment 是否会重新进入 processing",
    "不会；succeeded 是终态，再次 confirm 不得逆转状态，列表与详情应显示同一业务状态。",
    "再次 confirm 可以重新处理已成功 Payment",
    "保留原 Payment，若有新的收费意图应创建新 Payment。",
    ["KB-BR-010", "KB-API-015", "KB-API-012", "KB-API-014", "KB-API-017"],
    ["query_payments.get_payment", "query_payments.list_payments", "get_runtime_state.get_request"],
    ["account", "customer", "payment", "request"], "confirm_succeeded_payment",
    runtime_signal="Payment 始终 succeeded，再次 confirm 返回状态错误",
)

F(
    "confirm_requires_action", "确认 requires_action Payment", "payments",
    "只有 requires_action Payment 可由 confirm 推进到 processing，随后才可能成功或失败。",
    "2026-07-01 Payment {payment} 处于 requires_action，客户完成验证后发送 confirm。",
    "confirm 后允许发生什么状态变化",
    "允许从 requires_action 进入 processing，再由处理结果进入 succeeded 或 failed。",
    "confirm 会直接把任何 Payment 强制改成 succeeded",
    "只对 requires_action 调用 confirm，并继续查询状态或处理 Webhook。",
    ["KB-BR-010", "KB-API-015"],
    ["query_payments.get_payment", "get_runtime_state.get_request"],
    ["account", "customer", "payment", "request"], "confirm_action_required_payment",
    runtime_signal="Payment 由 requires_action 进入 processing 后成功",
)

F(
    "cancel_payment_state_guard", "Payment 取消状态约束", "payments",
    "只有 requires_action 可被 Merchant 主动取消；processing 和终态不能用 cancel 改变。",
    "{account} 尝试取消 processing 的 {payment}，{request} 返回 FP-4221。",
    "是否应该把 Payment 改成 canceled",
    "不应该；processing 不允许主动取消，原状态保持不变。",
    "所有未成功 Payment 都可以取消",
    "等待处理完成并根据最终状态采取后续操作。",
    ["KB-BR-010", "KB-API-016", "KB-TS-014"],
    ["query_payments.get_payment", "get_runtime_state.get_request"],
    ["account", "payment", "request"], "cancel_processing_payment",
    runtime_signal="FP-4221 且 Payment 仍为 processing",
)

F(
    "failed_payment_new_retry", "Failed Payment 必须新建重试", "payments",
    "failed Payment 是终态，重试收费必须创建新 Payment，不能原地恢复。",
    "{payment} 因支付方式被拒绝进入 failed；商户对原 ID 再次 confirm，并在 Payment 列表查找后续尝试。",
    "正确的重试模型是什么",
    "原 Payment 保持 failed；新的收费尝试必须有新的 Payment ID。",
    "把 failed Payment 原地改回 processing 能保持订单连续性",
    "创建新的 Payment，并在商户业务层关联两次尝试。",
    ["KB-BR-010", "KB-API-012", "KB-API-017", "KB-TS-021", "KB-CASE-009"],
    ["query_payments.get_payment", "query_payments.list_payments", "get_runtime_state.list_requests"],
    ["account", "customer", "payment", "request"], "retry_failed_payment_in_place",
    runtime_signal="原 Payment failed，新的合法重试使用另一 Payment ID",
)

F(
    "payment_method_declined", "支付方式被拒绝", "payments",
    "FP-4021 表示支付方式被拒绝；Payment 进入 failed，原样重试不会复活它。",
    "{payment} 返回 FP-4021，Request {request} 没有平台 Incident，客户认为稍后重试同一 Payment 即可。",
    "根因类别和正确处置是什么",
    "这是 Payment Method Declined；原 Payment 已 failed，应让客户更换支付方式并创建新 Payment。",
    "FP-4021 表示 FlowPay 服务降级",
    "收集失败码，提示更换支付方式，不要无限重试原 Payment。",
    ["KB-BR-011", "KB-API-013", "KB-TS-006"],
    ["query_payments.get_payment", "query_payments.list_payments", "get_runtime_state.get_request", "get_runtime_state.get_service_status"],
    ["account", "customer", "payment", "request"], "decline_payment_method",
    runtime_signal="FP-4021 且服务状态正常",
)

F(
    "payment_insufficient_funds", "余额不足失败", "payments",
    "FP-4022 表示资金不足，与一般拒绝和平台错误是不同失败类别。",
    "{payment} 返回 FP-4022；同一客户此前另一笔 Payment 曾返回 FP-4021。",
    "这次能否沿用上次的拒绝根因",
    "不能；本次明确是 Insufficient Funds，应按 FP-4022 处理。",
    "相同 HTTP 402 的所有错误根因都相同",
    "向客户说明余额不足，新的支付尝试必须创建新 Payment。",
    ["KB-BR-011", "KB-TS-007", "KB-TS-021"],
    ["query_payments.get_payment", "query_payments.list_payments", "get_runtime_state.get_request"],
    ["account", "customer", "payment", "request"], "fail_payment_for_insufficient_funds",
    runtime_signal="错误码为 FP-4022，而非相邻 Payment 的 FP-4021",
)

F(
    "payment_method_expired", "支付方式已过期", "payments",
    "FP-4024 表示支付方式已过期，属于 Payment 失败而非参数或服务错误。",
    "{payment} 使用已过期支付方式并返回 FP-4024，商户准备重放同一请求。",
    "原样重放是否可能成功",
    "不会改变已过期支付方式，也不会复活 failed Payment；应更新支付方式并创建新 Payment。",
    "FP-4024 可以通过 API 重试退避自动恢复",
    "获取新的有效支付方式后发起新的收费尝试。",
    ["KB-BR-011", "KB-TS-009", "KB-TS-021"],
    ["query_payments.get_payment", "query_payments.list_payments", "get_runtime_state.get_request"],
    ["account", "customer", "payment", "request"], "use_expired_payment_method",
    runtime_signal="FP-4024 且 Payment 终态 failed",
)

F(
    "action_required_old_and_new", "客户操作要求的新旧表示", "payments",
    "客户操作要求在旧版表现为 failed + FP-4023，在 2026-01-15 起表现为 requires_action。",
    "{account} 的旧客户端与新客户端对同一类验证场景分别创建 Payment。",
    "为什么两个 Payment 的状态不同，是否是数据不一致",
    "不是数据不一致；差异由请求 API Version 决定，旧版 failed + FP-4023，新版 requires_action。",
    "同一业务原因必须在所有版本中有完全相同状态字段",
    "客户端按各自版本实现处理，并按迁移指南升级。",
    ["KB-BR-011", "KB-API-018", "KB-TS-008", "KB-REL-003"],
    ["query_accounts.get_account", "query_payments.list_payments", "get_runtime_state.list_requests"],
    ["account", "customer", "payment", "request"], "compare_action_required_clients", api_version="2026-01-15",
    runtime_signal="两次请求版本不同、业务原因相同、状态表示不同",
)

F(
    "refund_processing_payment", "Processing Payment 不可退款", "refunds",
    "只有 succeeded Payment 可创建 Refund；对 processing Payment 请求退款返回 FP-4221。",
    "{payment} 仍为 processing，{account} 为它创建 {refund}，{request} 返回 FP-4221。",
    "是否已创建 pending Refund，以及正确等待条件是什么",
    "没有创建 Refund；必须等待 Payment succeeded 后再申请退款。",
    "processing 已代表扣款完成，可以先占用退款额度",
    "查询 Payment 最终状态，仅在 succeeded 后发起 Refund。",
    ["KB-BR-012", "KB-API-019", "KB-TS-014", "KB-CASE-010"],
    ["query_payments.get_payment", "query_payments.get_refund", "get_runtime_state.get_request"],
    ["account", "payment", "refund", "request"], "refund_processing_payment",
    runtime_signal="FP-4221 且不存在 Refund 对象",
)

F(
    "starter_full_refund_only", "Starter 只能一次全额退款", "refunds",
    "Starter 只支持对剩余可退金额进行一次全额退款，不支持部分退款。",
    "Starter Account {account} 对 succeeded 的 {payment} 申请小于剩余金额的 {refund}，返回 FP-4031。",
    "Payment 可退款为何请求仍失败",
    "Payment 状态合格，但 Starter 不支持部分退款；必须一次退还全部剩余可退金额。",
    "只要 Payment succeeded，任何套餐都支持部分退款",
    "按剩余可退金额发起一次全额 Refund，或先合法升级套餐。",
    ["KB-BR-012", "KB-API-020", "KB-API-021", "KB-TS-010", "KB-CASE-011"],
    ["query_accounts.get_account", "query_payments.get_payment", "query_payments.get_refund", "get_runtime_state.get_request"],
    ["account", "payment", "refund", "request"], "create_partial_refund_on_starter", plan="Starter",
    runtime_signal="Payment succeeded、有余额，但请求 FP-4031",
)

F(
    "growth_multiple_partial_refunds", "Growth 多次部分退款", "refunds",
    "Growth 和 Scale 支持多次部分退款，但 pending 与 succeeded 金额合计不能超过 Payment 金额。",
    "Growth Account {account} 对 10,000 的 {payment} 先成功退款 2,000，再申请 3,000。",
    "第二笔部分 Refund 是否允许，剩余可退金额是多少",
    "允许；第二笔后已占用 5,000，剩余可退金额为 5,000。",
    "部分退款只能发生一次",
    "每次创建前查询当前 pending+succeeded 占用与可退余额。",
    ["KB-BR-012", "KB-API-021", "KB-API-022"],
    ["query_accounts.get_account", "query_payments.get_payment", "query_payments.get_refund"],
    ["account", "payment", "refund"], "create_multiple_partial_refunds",
)

F(
    "pending_refund_reserves_amount", "Pending Refund 占用额度", "refunds",
    "pending Refund 暂时占用可退额度，计算时与 succeeded Refund 一同计入。",
    "10,000 的 {payment} 已有 6,000 pending {refund}，{account} 又申请 5,000。",
    "第二次请求能否通过",
    "不能；pending 已占用 6,000，只剩 4,000 可退。",
    "pending 尚未成功，所以不影响可退余额",
    "等待 pending 完成或失败后重新查询可退金额。",
    ["KB-BR-012", "KB-API-019", "KB-API-022"],
    ["query_payments.get_payment", "query_payments.get_refund"],
    ["account", "payment", "refund", "request"], "overbook_refund_while_pending",
    runtime_signal="第二次退款请求超过剩余 4,000",
)

F(
    "failed_refund_releases_amount", "Failed Refund 释放额度", "refunds",
    "pending Refund 进入 failed 或 canceled 后释放其占用的可退款额度。",
    "{payment} 的 4,000 pending {refund} 随后 failed；商户再次查询可退金额。",
    "这 4,000 是否仍被占用",
    "不再占用；failed Refund 释放额度，可退金额应相应增加。",
    "Refund 一旦创建就永久占用额度",
    "确认 Refund 终态后重新计算 succeeded+pending 占用。",
    ["KB-BR-012", "KB-API-019", "KB-API-022"],
    ["query_payments.get_payment", "query_payments.get_refund"],
    ["account", "payment", "refund"], "fail_pending_refund_and_release_amount",
)

F(
    "refund_window_expired", "退款超过 180 天", "refunds",
    "Payment 成功超过 180 天后不可退款，返回 FP-4222。",
    "{payment} 在 181 天前 succeeded，当前仍有全部金额未退；{account} 创建 {refund} 返回 FP-4222。",
    "有剩余金额是否足以使退款成功",
    "不足；退款窗口已经超过 180 天，即使余额完整也不具备资格。",
    "可退余额大于零就代表永远可退款",
    "核对 succeeded_at 与请求时间，不要重试过期 Refund。",
    ["KB-BR-012", "KB-API-020", "KB-TS-015", "KB-CASE-012"],
    ["query_payments.get_payment", "query_payments.get_refund", "get_runtime_state.get_request"],
    ["account", "payment", "refund", "request"], "refund_payment_after_181_days",
    runtime_signal="FP-4222，成功时间距请求 181 天",
)

F(
    "instant_refund_scale_na", "Scale NA Instant Refund", "refunds",
    "Instant Refund 需要 Scale、NA/EU、功能开关开启且金额不超过 100,000。",
    "NA Scale Account {account} 已开启 instant_refund，对 {payment} 申请 80,000 的 {refund}。",
    "该请求是否具备 Instant Refund 资格",
    "具备；套餐、地区、Flag、金额和 Payment 状态均满足时可使用 Instant Refund。",
    "Instant Refund 只由 Scale 套餐单一条件决定",
    "在调用前同时验证地区、Flag、金额和可退余额。",
    ["KB-BR-012", "KB-API-021"],
    ["query_accounts.get_account", "query_accounts.get_feature_flags", "query_payments.get_payment", "query_payments.get_refund"],
    ["account", "payment", "refund"], "create_eligible_instant_refund", plan="Scale", region="NA",
)

F(
    "instant_refund_apac", "APAC 不支持 Instant Refund", "refunds",
    "Instant Refund 仅在 NA 和 EU 可用；APAC 即使是 Scale 且 Flag 开启也不符合地区条件。",
    "APAC Scale Account {account} 开启 Flag 后，对 {payment} 请求 50,000 Instant Refund。",
    "请求是否应因 Scale 身份而成功",
    "不应；APAC 不在 Instant Refund 支持地区内。",
    "Scale 可以覆盖地区限制",
    "改用标准 Refund 流程，不要尝试修改 Account 主地区。",
    ["KB-BR-003", "KB-BR-012", "KB-API-021", "KB-TS-010"],
    ["query_accounts.get_account", "query_accounts.get_feature_flags", "query_payments.get_payment", "query_payments.get_refund"],
    ["account", "payment", "refund", "request"], "create_instant_refund_in_apac", plan="Scale", region="APAC",
    runtime_signal="FP-4031 且地区为 APAC",
)

F(
    "instant_refund_flag_and_amount", "Instant Refund Flag 与金额上限", "refunds",
    "Instant Refund 的金额不得超过 100,000，且必须显式开启功能开关。",
    "EU Scale Account {account} 的 Flag 起初关闭，随后开启但请求 120,000 的 Instant Refund。",
    "两次尝试分别为什么不具备资格",
    "第一次缺少 Flag；第二次金额超过 100,000。两次都不能使用 Instant Refund。",
    "只要后续打开 Flag，之前和超额请求都会自动合法",
    "开启 Flag后把金额控制在上限内，或改用标准 Refund。",
    ["KB-BR-004", "KB-BR-012", "KB-API-021"],
    ["query_accounts.get_account", "query_accounts.get_feature_flags", "query_payments.get_payment", "query_payments.get_refund", "get_runtime_state.list_requests"],
    ["account", "payment", "refund", "request"], "exercise_instant_refund_conditions", plan="Scale", region="EU",
    runtime_signal="第一次缺少 Flag，第二次金额 120,000",
)

F(
    "starter_subscription_blocked", "Starter 创建 Subscription", "subscriptions",
    "Subscription 只对 Growth 和 Scale 开放，Starter 返回 FP-4031。",
    "Starter Account {account} 使用 active {customer} 创建 {subscription}，请求参数都合法。",
    "Customer active 是否足以使创建成功",
    "不足；套餐不支持 Subscription，应返回 FP-4031。",
    "参数合法就能绕过套餐权限",
    "升级到 Growth/Scale并确认 subscriptions Flag 后重新创建。",
    ["KB-BR-013", "KB-API-024", "KB-TS-010"],
    ["query_accounts.get_account", "query_accounts.get_feature_flags", "query_payments.get_customer", "query_payments.get_subscription", "get_runtime_state.get_request"],
    ["account", "customer", "subscription", "request"], "create_subscription_on_starter_plan", plan="Starter",
    runtime_signal="FP-4031，Customer 与参数均合法",
)

F(
    "subscription_trial_bounds", "Subscription 试用期边界", "subscriptions",
    "试用期只能在创建时设置，范围为 1 到 30 天。",
    "{account} 先尝试以 trial_days=31 创建 {subscription}，之后又想给已 active 的 Subscription 补加试用期。",
    "两种操作是否允许",
    "都不允许；31 天越界，且试用期不能在创建后追加。",
    "试用期可在任意时间延长",
    "创建时使用 1～30 天范围；已创建资源需按现有周期处理。",
    ["KB-BR-013", "KB-API-024", "KB-TS-001"],
    ["query_payments.get_subscription", "get_runtime_state.list_requests"],
    ["account", "customer", "subscription", "request"], "exercise_subscription_trial_bounds",
    runtime_signal="31 天请求 FP-4001，后置修改被拒绝",
)

F(
    "subscription_cancel_period_end", "Subscription 周期末取消", "subscriptions",
    "主动取消默认在当前周期末生效；在此之前 Subscription 继续 active。",
    "{subscription} 在周期中收到默认取消请求，当前时间尚未到 period_end。",
    "它应立即 canceled 还是继续 active",
    "应继续 active 到周期末，届时再进入 canceled。",
    "所有取消请求都立即终止服务",
    "向用户展示 scheduled cancellation 与实际生效时间。",
    ["KB-BR-013", "KB-API-025"],
    ["query_payments.get_subscription"],
    ["account", "customer", "subscription", "request"], "cancel_subscription_at_period_end",
)

F(
    "subscription_cancel_immediately", "Subscription 立即取消", "subscriptions",
    "只有显式请求立即取消时，Subscription 才立刻进入 canceled；canceled 是终态。",
    "{account} 对 active 的 {subscription} 发送 immediate=true 取消，随后尝试恢复。",
    "取消与恢复请求应如何处理",
    "Subscription 立即 canceled，且不能恢复；需要继续订阅必须创建新 Subscription。",
    "canceled Subscription 可以切回 active",
    "创建新的 Subscription，不要修改终态资源。",
    ["KB-BR-013", "KB-API-025"],
    ["query_payments.get_subscription", "get_runtime_state.list_requests"],
    ["account", "customer", "subscription", "request"], "cancel_subscription_immediately_then_restore",
    runtime_signal="取消后状态 canceled，恢复请求失败",
)

F(
    "subscription_immutable_identity", "Subscription Customer 与币种不可变", "subscriptions",
    "Subscription 创建后不能更换 Customer 或币种；变更需要取消原资源并新建。",
    "{subscription} 已绑定 {customer} 和 USD，{account} 尝试改成另一个 Customer 与 CAD。",
    "能否直接更新这两个字段",
    "不能；Customer 与币种是不可变身份字段。",
    "active Subscription 的所有字段都可更新",
    "按取消规则处理原 Subscription，并为新 Customer/币种创建新资源。",
    ["KB-BR-013", "KB-API-023", "KB-API-024"],
    ["query_payments.get_customer", "query_payments.get_subscription", "get_runtime_state.get_request"],
    ["account", "customer", "subscription", "request"], "change_subscription_customer_and_currency",
    runtime_signal="更新请求被拒绝，原 Customer 与币种未变",
)

F(
    "invoice_retry_day1_success", "Invoice 第 1 天重试成功", "invoices",
    "Invoice 首次扣费失败后第 1、3、7 天重试；任一重试成功使 Invoice paid、Subscription 恢复 active。",
    "{invoice} 首次 Payment 失败使 {subscription} past_due，第 1 天新 {payment} 成功。",
    "Invoice 与 Subscription 最终应是什么状态",
    "Invoice 应为 paid，Subscription 应恢复 active；首次 failed Payment 保持终态。",
    "重试成功后仍要执行第 3、7 天重试",
    "停止后续重试，并保留两次 Payment 的时间线。",
    ["KB-BR-014", "KB-API-026", "KB-API-027", "KB-API-028", "KB-CASE-013"],
    ["query_payments.get_payment", "query_payments.get_subscription", "query_payments.get_invoice_timeline"],
    ["account", "customer", "subscription", "invoice", "payment"], "invoice_retry_succeeds_on_day1",
)

F(
    "invoice_retry_day3_success", "Invoice 第 3 天重试成功", "invoices",
    "Invoice 每次重试创建新 Payment；第 3 天成功后恢复 Subscription 并停止第 7 天任务。",
    "{invoice} 首次与第 1 天 Payment 失败，第 3 天 Payment 成功。",
    "应该存在几笔 Payment，是否继续第 7 天重试",
    "应有三笔不同 Payment；第 3 天成功后不再执行第 7 天重试。",
    "重试应复用第一笔 failed Payment ID",
    "保留三笔关联记录并取消剩余调度。",
    ["KB-BR-014", "KB-API-027", "KB-API-028"],
    ["query_payments.get_payment", "query_payments.get_subscription", "query_payments.get_invoice_timeline"],
    ["account", "subscription", "invoice", "payment"], "invoice_retry_succeeds_on_day3",
)

F(
    "invoice_retries_exhausted", "Invoice 重试耗尽", "invoices",
    "首次失败及第 1、3、7 天三次重试全部失败后，Invoice uncollectible、Subscription canceled。",
    "{invoice} 的四次 Payment 全部 failed，{subscription} 仍显示 past_due。",
    "这个状态是否符合规则",
    "不符合；重试耗尽后 Invoice 应为 uncollectible，Subscription 应为 canceled。",
    "重试耗尽后 Subscription 会无限保持 past_due",
    "执行终态投影并停止继续扣费。",
    ["KB-BR-014", "KB-API-027", "KB-API-028", "KB-CASE-014"],
    ["query_payments.get_payment", "query_payments.get_subscription", "query_payments.get_invoice_timeline"],
    ["account", "subscription", "invoice", "payment"], "exhaust_invoice_retries",
    runtime_signal="四次 failed Payment 且调度已到第 7 天",
)

F(
    "paid_invoice_cannot_void", "Paid Invoice 不可作废", "invoices",
    "paid Invoice 不允许执行 void，终态不能由 void 操作改变。",
    "{invoice} 已 paid，{account} 为纠正账单说明而调用 void。",
    "Invoice 是否应变成 void",
    "不应；paid Invoice 不可 void，状态保持 paid。",
    "void 是可以覆盖任何 Invoice 状态的管理操作",
    "保留 paid 账单，使用业务允许的后续流程处理说明。",
    ["KB-BR-014", "KB-API-026"],
    ["query_payments.get_invoice_timeline", "get_runtime_state.get_request"],
    ["account", "subscription", "invoice", "request"], "void_paid_invoice",
    runtime_signal="void 请求失败，Invoice 仍 paid",
)

F(
    "open_invoice_can_void", "Open Invoice 可以作废", "invoices",
    "draft 或 open Invoice 可以进入 void；paid、uncollectible、void 不可由 void 操作改变。",
    "{invoice} 已 open 但尚未支付，{account} 决定作废它。",
    "void 是否允许，之后还能否继续扣费",
    "允许进入 void；void 是终态，不应继续为该 Invoice 扣费。",
    "只有 draft Invoice 才能 void",
    "取消相关待执行扣费任务，并保留状态时间线。",
    ["KB-BR-014", "KB-API-026"],
    ["query_payments.get_invoice_timeline", "get_runtime_state.list_requests"],
    ["account", "subscription", "invoice", "request"], "void_open_invoice",
    runtime_signal="Invoice 从 open 进入 void，后续无扣费请求",
)

F(
    "starter_endpoint_limit", "Starter Webhook Endpoint 上限", "webhooks",
    "Starter 最多 2 个 Webhook Endpoint，超出套餐能力返回 FP-4031。",
    "Starter Account {account} 已有两个 enabled Endpoint，又尝试创建 {endpoint}。",
    "第三个 Endpoint 是否应创建",
    "不应；Starter 上限为 2，应返回 FP-4031。",
    "Endpoint 上限只影响投递，不影响创建",
    "删除或禁用并不会自动改变上限语义；需要按产品操作减少配置或升级套餐。",
    ["KB-BR-015", "KB-API-029", "KB-TS-010"],
    ["query_accounts.get_account", "query_webhooks.list_endpoints", "get_runtime_state.get_request"],
    ["account", "endpoint", "request"], "create_third_endpoint_on_starter", plan="Starter",
    runtime_signal="已有两个 Endpoint，第三次创建 FP-4031",
)

F(
    "downgrade_restricts_newer_endpoints", "降级后 Endpoint restricted", "webhooks",
    "套餐降级不删除超额 Endpoint；按创建时间保留最早的可用数量，其余变为 restricted。",
    "{account} 从 Growth 降至 Starter，原有五个 Endpoint，其中 {endpoint} 是较晚创建的第三个。",
    "降级生效后这个 Endpoint 应删除、disabled 还是 restricted",
    "应变为 restricted；最早两个保持可用，历史投递保留。",
    "降级会物理删除所有超额 Endpoint",
    "向商户展示 restricted 状态，并要求其调整配置或重新升级。",
    ["KB-BR-004", "KB-BR-015", "KB-API-029"],
    ["query_accounts.get_plan_timeline", "query_webhooks.list_endpoints", "query_webhooks.get_endpoint"],
    ["account", "endpoint", "delivery"], "apply_endpoint_restrictions_after_downgrade",
)

F(
    "disabled_endpoint_no_delivery", "Disabled Endpoint 不生成新投递", "webhooks",
    "只有 enabled Endpoint 接收新事件；disabled Endpoint 不产生 Delivery 记录。",
    "{endpoint} 在 Event {event} 发生前已 disabled，商户搜索不到 {delivery}。",
    "缺少 Delivery 是否说明平台丢失了 Webhook",
    "不说明；Endpoint 在事件发生时 disabled，按规则本就不应创建 Delivery。",
    "任何已配置 Endpoint 都必须为每个 Event 产生 Delivery",
    "核对事件时间与 Endpoint 状态时间线，重新启用只影响后续事件。",
    ["KB-BR-015", "KB-API-029", "KB-TS-023"],
    ["query_webhooks.get_endpoint", "query_webhooks.get_event", "query_webhooks.get_delivery", "get_runtime_state.get_delivery_timeline"],
    ["account", "endpoint", "event", "delivery"], "emit_event_to_disabled_endpoint",
    runtime_signal="Event 存在但没有对应 Delivery Attempt",
)

F(
    "endpoint_not_subscribed", "Endpoint 未订阅事件", "webhooks",
    "Endpoint 必须显式订阅事件类型；未订阅时不创建 Delivery。",
    "{payment} 成功并产生 {event}，enabled 的 {endpoint} 只订阅 payment.failed，因此没有 {delivery}。",
    "这是投递失败还是配置不匹配",
    "是订阅配置不匹配；根本没有创建 Delivery，不是重试失败。",
    "Endpoint enabled 就会接收所有 Event Type",
    "订阅适用版本的成功事件名；修改只影响后续事件。",
    ["KB-BR-015", "KB-API-030", "KB-TS-023", "KB-CASE-015"],
    ["query_payments.get_payment", "query_webhooks.list_endpoints", "query_webhooks.get_event", "query_webhooks.get_delivery"],
    ["account", "payment", "endpoint", "event", "delivery"], "emit_unsubscribed_payment_event",
    runtime_signal="Event 存在、Endpoint enabled，但订阅集合不含该 Event Type",
)

F(
    "payment_event_name_by_version", "Payment 成功事件名随版本变化", "webhooks",
    "2026-07-01 起成功事件名为 payment.succeeded；此前版本使用 payment.completed。",
    "{payment} 由 2026-07-01 请求创建并成功，{endpoint} 只订阅 payment.completed。",
    "应生成哪种 Event，为什么 Endpoint 没收到",
    "应生成 payment.succeeded；Endpoint 未订阅新版事件名，因此不创建 Delivery。",
    "Account 创建时间决定 Event 名称",
    "迁移订阅到 payment.succeeded，必要时在过渡期同时订阅适用名称。",
    ["KB-BR-015", "KB-API-030", "KB-REL-007", "KB-REL-009"],
    ["query_payments.get_payment", "query_webhooks.get_endpoint", "query_webhooks.get_event", "query_webhooks.get_delivery"],
    ["account", "payment", "endpoint", "event", "delivery"], "emit_versioned_payment_success_event",
)

F(
    "scheduled_event_uses_account_default", "平台定时事件使用 Account 默认版本", "webhooks",
    "由订阅周期任务等平台内部操作产生的 Event 使用 Account 当时默认 API Version。",
    "{account} 默认版本为 2026-04-01；Scheduler 生成 {invoice} 并产生 {event}，没有外部请求 Header。",
    "Event 应采用什么版本，Payment 成功事件名如何判断",
    "应采用当时 Account 默认 2026-04-01；相关成功事件仍使用 payment.completed。",
    "平台内部事件总使用最新版本",
    "按任务发生时的 Account 默认版本配置 Endpoint 订阅。",
    ["KB-BR-015", "KB-API-030", "KB-REL-009"],
    ["query_accounts.get_account", "query_payments.get_invoice_timeline", "query_webhooks.get_event"],
    ["account", "subscription", "invoice", "event", "endpoint"], "generate_scheduled_invoice_event", api_version="2026-04-01",
)

F(
    "webhook_2xx_success", "Webhook 2xx 投递成功", "webhooks",
    "Webhook 响应 200～299 均视为成功，不再调度重试。",
    "{delivery} 第一次 Attempt 收到 HTTP 204，系统仍安排下一次重试。",
    "这个重试计划是否正确",
    "不正确；204 属于 2xx，应将 Delivery 标记 delivered 并停止重试。",
    "只有 HTTP 200 才算成功",
    "修正响应分类并取消多余调度。",
    ["KB-BR-015", "KB-API-032"],
    ["query_webhooks.get_delivery", "get_runtime_state.get_delivery_timeline"],
    ["account", "endpoint", "event", "delivery"], "deliver_webhook_with_204",
    runtime_signal="首个 Attempt HTTP 204",
)

F(
    "webhook_redirect_retry", "Webhook 3xx 不跟随重定向", "webhooks",
    "Webhook 3xx 不跟随重定向，视为失败并按策略重试。",
    "{endpoint} 对 {delivery} 返回 HTTP 302 和 Location，团队认为 FlowPay 会跟随跳转。",
    "Delivery 应成功还是进入重试",
    "应进入重试；FlowPay 不跟随 Webhook 重定向。",
    "提供 Location 就等同于成功投递",
    "让 Endpoint 直接在已配置 URL 返回 2xx。",
    ["KB-BR-015", "KB-API-032", "KB-TS-023"],
    ["query_webhooks.get_endpoint", "query_webhooks.get_delivery", "get_runtime_state.get_delivery_timeline"],
    ["account", "endpoint", "event", "delivery"], "deliver_webhook_with_redirect",
    runtime_signal="HTTP 302 后存在 next_retry_at",
)

F(
    "webhook_4xx_retry", "Webhook 普通 4xx 进入重试", "webhooks",
    "除 410 外，Webhook 4xx 与 5xx 都进入重试。",
    "{delivery} 首次收到 HTTP 400，{endpoint} 仍 enabled。",
    "是否应立即终止 Delivery",
    "不应；HTTP 400 是可重试失败，应按重试策略继续。",
    "所有 4xx 都永久禁用 Endpoint",
    "修复接收端并观察后续 Attempt；只有 410 触发立即禁用。",
    ["KB-BR-015", "KB-API-032", "KB-TS-023"],
    ["query_webhooks.get_endpoint", "query_webhooks.get_delivery", "get_runtime_state.get_delivery_timeline"],
    ["account", "endpoint", "event", "delivery"], "deliver_webhook_with_400",
    runtime_signal="HTTP 400 后 Endpoint enabled 且有重试计划",
)

F(
    "webhook_410_disables_endpoint", "Webhook 410 立即禁用 Endpoint", "webhooks",
    "HTTP 410 是普通 4xx 的例外，会立即禁用 Endpoint，不继续重试。",
    "{delivery} 第一次收到 HTTP 410，之后又为同一 Endpoint 调度重试并接收新 Event。",
    "这些后续行为是否符合规则",
    "不符合；410 后 Endpoint 应立即 disabled，当前 Delivery 不再重试，后续 Event 不创建新 Delivery。",
    "410 与 400 一样走默认六次重试",
    "修复 Endpoint 状态和调度，并由商户确认 URL 后重新启用。",
    ["KB-BR-015", "KB-API-032", "KB-TS-023"],
    ["query_webhooks.get_endpoint", "query_webhooks.get_event", "query_webhooks.get_delivery", "get_runtime_state.get_delivery_timeline"],
    ["account", "endpoint", "event", "delivery"], "deliver_webhook_with_410",
    runtime_signal="首次 Attempt 410，Endpoint 应在同一时刻 disabled",
)

F(
    "webhook_default_retry_exhaustion", "Webhook 默认重试耗尽", "webhooks",
    "默认在 1m、5m、30m、2h、8h、24h 重试；完成六次重试仍失败后 Delivery exhausted。",
    "{delivery} 首次失败且六个默认重试均返回 500。",
    "最终状态和 Attempt 数量应如何计算",
    "最终应 exhausted；共有首次 Attempt 加六次重试，共七次 Attempt。",
    "六次重试包含首次投递，所以总共只有六次 Attempt",
    "停止继续投递并向商户展示完整失败时间线。",
    ["KB-BR-015", "KB-API-032"],
    ["query_webhooks.get_delivery", "get_runtime_state.get_delivery_timeline"],
    ["account", "endpoint", "event", "delivery"], "exhaust_default_webhook_retries",
    runtime_signal="首次加六次重试全部 HTTP 500",
)

F(
    "scale_custom_retry", "Scale 自定义 Webhook 重试", "webhooks",
    "只有 Scale 可自定义 Webhook 重试，最多 8 次且总窗口不超过 72 小时。",
    "Scale Account {account} 先配置 9 次自定义重试，随后改为 8 次但总窗口为 80 小时。",
    "两份配置是否有效",
    "都无效：第一次超过 8 次上限，第二次的 80 小时超过 72 小时上限。",
    "满足次数上限就可以忽略套餐和总窗口",
    "将重试次数和总窗口同时控制在 Scale 的允许范围内。",
    ["KB-BR-015", "KB-API-032", "KB-TS-010"],
    ["query_accounts.get_account", "query_webhooks.get_endpoint", "get_runtime_state.list_requests"],
    ["account", "endpoint", "request"], "configure_invalid_custom_retry", plan="Scale",
    runtime_signal="一个 9 次配置拒绝与一个 80 小时配置拒绝",
)

F(
    "webhook_at_least_once", "Webhook 至少一次与去重", "webhooks",
    "Webhook 使用至少一次语义，同一 Event 可能多次投递；Merchant 必须按 event_id 去重。",
    "{event} 的首次 {delivery} 已被 Merchant 处理，但响应丢失导致 FlowPay 重试，Merchant 再次收到相同 Event ID。",
    "第二次是否代表发生了新的 Payment",
    "不代表；这是同一 Event 的重复投递，应按 event_id 去重。",
    "每个 Webhook 请求都代表一个新的业务事件",
    "接收端持久化已处理 event_id，并对重复请求安全返回 2xx。",
    ["KB-BR-015", "KB-API-032"],
    ["query_webhooks.get_event", "query_webhooks.get_delivery", "get_runtime_state.get_delivery_timeline"],
    ["account", "payment", "endpoint", "event", "delivery"], "redeliver_same_webhook_event",
    runtime_signal="两个 Attempt 携带相同 Event ID",
)

F(
    "signature_header_by_version", "Webhook 签名 Header 版本差异", "webhooks",
    "2026-04-01 起签名 Header 为 FlowPay-Signature；旧版使用 X-FlowPay-Signature。",
    "{event} 使用 2026-04-01，{endpoint} 的接收端仍只读取 X-FlowPay-Signature，因而报签名缺失。",
    "FlowPay 是否未签名，还是接收端读取了错误 Header",
    "FlowPay 使用了新版 FlowPay-Signature；接收端读取旧 Header 才是根因。",
    "所有 API Version 都同时发送两个签名 Header",
    "按 Event API Version 读取对应 Header，并完成迁移。",
    ["KB-BR-016", "KB-API-031", "KB-REL-006", "KB-CASE-008"],
    ["query_webhooks.get_event", "query_webhooks.get_endpoint", "query_webhooks.get_delivery", "get_runtime_state.get_delivery_timeline"],
    ["account", "endpoint", "event", "delivery"], "verify_signature_with_old_header", api_version="2026-04-01",
    runtime_signal="Attempt 使用 secret version 正确，但客户端报告 Header missing",
)

F(
    "signature_timestamp_tolerance", "Webhook 签名时间戳容差", "webhooks",
    "Webhook 签名时间戳默认容差为 5 分钟，超出时即使摘要匹配也应拒绝。",
    "{delivery} 的签名摘要正确，但接收端验证时与 signature_timestamp 相差 8 分钟。",
    "是否应该接受这次请求",
    "不应该；8 分钟超过默认 5 分钟容差。",
    "只要 HMAC 正确就可以忽略时间戳",
    "校准服务器时钟，并在 5 分钟内完成验证。",
    ["KB-BR-016", "KB-API-031", "KB-TS-023"],
    ["query_webhooks.get_endpoint", "query_webhooks.get_delivery", "get_runtime_state.get_delivery_timeline"],
    ["account", "endpoint", "event", "delivery"], "verify_stale_webhook_signature",
    runtime_signal="签名时间戳与验证时间相差 8 分钟",
)

F(
    "signing_secret_rotation_window", "Signing Secret 轮换窗口", "webhooks",
    "Secret 轮换后新投递立即使用新 Secret，旧 Secret 继续有效 24 小时。",
    "{endpoint} 在 10:00 轮换 Secret；10:05 的新 {delivery} 使用新版本，接收端仅配置旧 Secret。",
    "新投递能否继续只用旧 Secret 验证",
    "不能；新投递立即使用新 Secret。旧 Secret 的 24 小时窗口只用于兼容验证旧签名。",
    "24 小时内所有新投递仍由旧 Secret 签名",
    "接收端在过渡期同时接受新旧 Secret，并优先部署新 Secret。",
    ["KB-BR-016", "KB-API-031"],
    ["query_webhooks.get_endpoint", "query_webhooks.get_delivery", "get_runtime_state.get_delivery_timeline"],
    ["account", "endpoint", "event", "delivery"], "rotate_signing_secret_then_deliver",
    runtime_signal="轮换后新 Attempt 的 secret_version 为新版本",
)

F(
    "webhook_retry_resigned", "Webhook 重试使用当前 Secret 重签", "webhooks",
    "Webhook 重试在发生时使用 Endpoint 当前 Secret 重新签名，不复用首次 Attempt 的签名。",
    "{delivery} 首次失败后，{endpoint} 在下一次重试前轮换 Secret。",
    "重试应使用旧 Secret 还是新 Secret",
    "应使用重试时的当前新 Secret重新签名。",
    "同一 Delivery 的所有 Attempt 必须复用第一次签名",
    "接收端在轮换窗口同时接受新旧 Secret，并逐次按 Header 验证。",
    ["KB-BR-016", "KB-API-031", "KB-REL-006"],
    ["query_webhooks.get_endpoint", "query_webhooks.get_delivery", "get_runtime_state.get_delivery_timeline"],
    ["account", "endpoint", "event", "delivery"], "retry_webhook_after_secret_rotation",
    runtime_signal="Attempt 1 与 Attempt 2 使用不同 secret_version",
)

F(
    "distinguish_500_and_503", "区分 FP-5001 与 FP-5031", "operations",
    "FP-5001 是单次内部处理错误，FP-5031 表示服务暂时降级；二者不能直接归因于商户配置。",
    "{account} 的一个 {request} 返回 FP-5001，随后同地区大量请求返回 FP-5031 并存在 {incident}。",
    "两类错误是否应归为同一个 Merchant 配置问题",
    "不应；单次 FP-5001 与区域性 FP-5031 需要分别判断，后者由服务 Incident 支持。",
    "所有 5xx 都说明 Webhook Endpoint 配置错误",
    "查询 Request ID、服务状态和影响范围；幂等请求按规则安全重试。",
    ["KB-BR-011", "KB-API-008", "KB-TS-017", "KB-TS-018", "KB-TS-024", "KB-CASE-016"],
    ["query_accounts.get_account", "get_runtime_state.get_request", "get_runtime_state.list_requests", "get_runtime_state.get_service_status"],
    ["account", "request", "incident"], "emit_internal_error_then_regional_incident",
    runtime_signal="单个 FP-5001 后出现有 Incident 支撑的区域 FP-5031",
)

F(
    "regional_service_incident", "区域性服务降级", "operations",
    "服务 Incident 按 service、region 和时间判断，不应仅凭单个账户或配置推断。",
    "NA payments 服务在时间窗内有 {incident}；NA 多个 Account 返回 FP-5031，EU 同类请求正常。",
    "问题范围是单个 Account 还是区域服务",
    "证据表明是 NA 区域 payments 服务降级，不是单个 Account 配置。",
    "某个 Account 最先报告就说明只有该账户受影响",
    "按 Incident 时间线沟通影响，并在恢复后使用幂等重试。",
    ["KB-BR-011", "KB-TS-018", "KB-TS-024"],
    ["get_runtime_state.list_requests", "get_runtime_state.get_service_status"],
    ["account", "request", "incident"], "run_regional_payments_incident",
    runtime_signal="NA 多账户 FP-5031、EU 正常、Incident active",
)

F(
    "request_id_before_auth", "认证失败仍有 Request ID", "developer_platform",
    "每个到达网关的请求都先获得 Request ID，认证前失败也不例外。",
    "{request} 使用格式错误的 {key}，返回 FP-4011；客户端认为认证失败所以不可能查询请求日志。",
    "这次失败是否应有 Request ID",
    "应有；Request ID 在认证前分配，可用于查询脱敏日志，但不等于资源 ID。",
    "只有成功认证后才生成 Request ID",
    "记录响应中的 Request ID，并据此查询失败阶段。",
    ["KB-BR-006", "KB-API-007", "KB-API-008", "KB-TS-004", "KB-TS-019"],
    ["query_accounts.list_api_keys", "get_runtime_state.get_request", "get_runtime_state.list_requests"],
    ["account", "key", "request"], "send_request_with_malformed_key",
    runtime_signal="认证前失败日志仍包含唯一 Request ID",
)

F(
    "resource_not_visible_semantics", "资源不存在或不可见", "developer_platform",
    "FP-4041 统一覆盖 ID 不存在、跨 Account 或跨环境不可见，避免资源枚举。",
    "{account} 的 Sandbox Key 查询一个 Production {payment}，得到 FP-4041。",
    "能否据此断言 Payment 已被删除",
    "不能；环境或租户不可见与真实不存在共享该语义。",
    "FP-4041 会精确告诉调用方资源属于哪个环境",
    "先核对 Key、Account、Environment 和资源 ID，不要求平台泄漏所有权。",
    ["KB-BR-001", "KB-API-014", "KB-TS-012"],
    ["query_accounts.list_api_keys", "query_payments.get_payment", "get_runtime_state.get_request"],
    ["account", "key", "payment", "request"], "retrieve_resource_from_wrong_environment", environment="sandbox",
    runtime_signal="FP-4041 且工具不泄漏 Production 资源详情",
)

F(
    "runtime_retention_by_plan", "历史请求记录查询范围", "operations",
    "Starter、Growth、Scale 的请求记录查询范围分别为 7、30、90 天；超出范围时返回 retention_exceeded。",
    "Starter Account {account} 查询 20 天前的请求 {request} 时返回 retention_exceeded，但相关业务对象现在仍然可以看到。",
    "能否根据仍然可见的业务对象还原这次请求的完整日志内容",
    "不能；Starter 的请求记录查询范围只有 7 天，业务对象仍然可见不等于完整请求日志仍可查询。",
    "只要业务对象还在，就一定能还原完整历史请求日志",
    "说明当前可查询的时间范围；如需更长历史，应提前采用符合产品规则的长期留存方案。",
    ["KB-BR-004", "KB-TS-022"],
    ["query_accounts.get_account", "get_runtime_state.get_request"],
    ["account", "request"], "query_runtime_outside_retention", plan="Starter",
    runtime_signal="Tool available_from 晚于请求时间并返回 retention_exceeded",
    required_rule_ids=["RULE-PLAN-001"],
)

F(
    "payment_to_webhook_end_to_end", "Payment 到 Webhook 的端到端诊断", "webhooks",
    "Payment 成功、Event 生成、Endpoint 订阅、Delivery Attempt 和签名验证是相互独立但可追溯的环节。",
    "{payment} 已 succeeded 并生成 {event}；{endpoint} 已订阅正确事件，{delivery} 首次 500、重试 204。商户却认为 Payment 失败。",
    "应如何给出最终业务结论和 Webhook 投递结论",
    "Payment 已成功；Webhook 首次失败但重试 204 后 delivered。投递故障不能反推 Payment 失败。",
    "没在首次收到 Webhook 就说明 Payment 未成功",
    "分别引用 Payment、Event、Endpoint 和 Delivery Timeline，按 event_id 做幂等处理。",
    ["KB-BR-010", "KB-BR-015", "KB-API-013", "KB-API-030", "KB-API-032", "KB-TS-023"],
    ["query_payments.get_payment", "query_webhooks.get_endpoint", "query_webhooks.get_event", "query_webhooks.get_delivery", "get_runtime_state.get_delivery_timeline"],
    ["account", "customer", "payment", "endpoint", "event", "delivery", "request"], "complete_payment_with_webhook_retry",
    runtime_signal="Payment succeeded、Event 存在、Attempt 1=500、Attempt 2=204",
)


DEV_FAMILY_NUMBERS = set(range(1, 76, 5))


def question_types(split: str, position: int) -> list[str]:
    """Return four types while satisfying the exact split quotas."""
    if split == "dev":
        return [
            "simple_retrieval" if position < 14 else "multi_document",
            "multi_document" if position < 9 else "multi_hop",
            "multi_hop" if position < 6 else "multi_source",
            "multi_source" if position < 5 else (
                "temporal_versioned" if position < 10 else "tool_use_diagnostic"
            ),
        ]
    return [
        "simple_retrieval" if position < 56 else "multi_document",
        "multi_document" if position < 36 else "multi_hop",
        "multi_hop" if position < 24 else "multi_source",
        "multi_source" if position < 20 else (
            "temporal_versioned" if position < 40 else "tool_use_diagnostic"
        ),
    ]


def family_entity_ids(number: int, entity_types: list[str]) -> dict[str, str]:
    ids: dict[str, str] = {}
    for entity_type in entity_types:
        suffix = f"bm_{number:03d}"
        if entity_type == "request":
            suffix += "_01"
        ids[entity_type] = f"{ENTITY_PREFIX[entity_type]}_{suffix}"
    return ids


def doc_prefix(doc_id: str) -> str:
    return "-".join(doc_id.split("-")[:2])


def select_documents(family: dict, family_number: int, slot: int, qtype: str) -> list[str]:
    docs = family["docs"]
    if qtype in {"multi_hop", "multi_source", "temporal_versioned", "tool_use_diagnostic"}:
        if slot == 3:
            return list(docs)
        return list(docs[: min(2, len(docs))])
    if qtype == "simple_retrieval":
        return [docs[(family_number - 1) % len(docs)]]
    if len(docs) >= 3:
        start = 1 + ((family_number + slot) % (len(docs) - 1))
        selected = [docs[start], docs[1 + (start % (len(docs) - 1))]]
        return list(dict.fromkeys(selected))
    if slot == 3:
        return list(docs)
    return list(docs[:2])


def selector_for_operation(operation_ref: str, ids: dict[str, str], as_of: str) -> dict:
    tool, operation = operation_ref.split(".", 1)
    entity_for_operation = {
        "get_account": "account",
        "get_plan_timeline": "account_plan",
        "list_api_keys": "api_key",
        "get_feature_flags": "feature_flag",
        "get_customer": "customer",
        "list_customers": "customer",
        "get_payment": "payment",
        "list_payments": "payment",
        "get_refund": "refund",
        "get_subscription": "subscription",
        "get_invoice_timeline": "invoice",
        "get_endpoint": "webhook_endpoint",
        "list_endpoints": "webhook_endpoint",
        "get_event": "event",
        "get_delivery": "webhook_delivery",
        "get_request": "api_request",
        "list_requests": "api_request",
        "get_usage": "usage_bucket",
        "get_delivery_timeline": "delivery_attempt",
        "get_service_status": "service_incident",
    }
    id_key_for_operation = {
        "get_account": "account", "get_plan_timeline": "account", "list_api_keys": "account",
        "get_feature_flags": "account", "get_customer": "customer", "list_customers": "account", "get_payment": "payment",
        "list_payments": "account", "get_refund": "refund", "get_subscription": "subscription",
        "get_invoice_timeline": "invoice", "get_endpoint": "endpoint", "list_endpoints": "account",
        "get_event": "event", "get_delivery": "delivery", "get_request": "request",
        "list_requests": "account", "get_usage": "account", "get_delivery_timeline": "delivery",
        "get_service_status": "incident",
    }
    id_key = id_key_for_operation[operation]
    where: dict[str, str] = {"as_of": as_of}
    if id_key in ids:
        where[f"{id_key}_id"] = ids[id_key]
    elif "account" in ids:
        where["account_id"] = ids["account"]
    if operation in {"list_requests", "get_usage"}:
        where["window"] = "scenario_observation_window"
    source = "runtime" if tool == "get_runtime_state" else "sql"
    cardinality = "at_least_one" if operation.startswith("list_") or operation in {
        "get_usage", "get_delivery_timeline", "get_plan_timeline", "get_invoice_timeline"
    } else "exactly_one"
    return {
        "alias": operation,
        "source": source,
        "tool": tool,
        "operation": operation,
        "entity": entity_for_operation[operation],
        "where": where,
        "cardinality": cardinality,
    }


def build_question_text(
    family: dict, slot: int, qtype: str, context: str, as_of: str, ids: dict[str, str],
    required_docs: list[str]
) -> str:
    opening = REALISTIC_OPENINGS[family["slug"]]
    display_context = natural_display_context(family)
    if qtype in {"simple_retrieval", "multi_document"}:
        tail = (
            f"{family['decision']}？"
            if qtype == "simple_retrieval" else
            f"{family['decision']}？同时应该采取什么处理方式？"
        )
        variants = (
            f"想咨询一个问题：{display_context}{tail}",
            f"我们遇到了这种情况：{display_context}请问{tail}",
            f"客户反馈{display_context}这种情况应该如何判断：{tail}",
            f"请帮忙确认一下。{display_context}我们想知道{tail}",
            f"目前能确认的是：{display_context}接下来需要判断{tail}",
        )
        offset = 0 if qtype == "simple_retrieval" else 2
        return variants[(sum(ord(char) for char in family["slug"]) + offset) % len(variants)]
    suffixes = {
        "multi_hop": "我们现在只掌握这些表面现象，不确定应该从哪一步开始核对。",
        "multi_source": "业务侧看到的结果和接口表现对不上，想确认实际发生了什么。",
        "temporal_versioned": "这不是刚刚发生的问题，我们不确定当时的配置和现在是否一样。",
        "tool_use_diagnostic": "基础配置已经看过了，但还判断不出是客户端、账户还是平台问题。",
    }
    prefixes = ("", "客户那边反馈：", "线上同事发现：", "我们排查时发现：", "客服转来一个问题：")
    variant = sum(ord(char) for char in family["slug"] + qtype) % len(prefixes)
    return f"{prefixes[variant]}{opening}{suffixes[qtype]}"


def natural_display_context(family: dict) -> str:
    text = family["context"].format(**{
        entity: ENTITY_DISPLAY[entity] for entity in family["entities"]
    })
    for label in ENTITY_DISPLAY.values():
        text = text.replace(label + " ", label)
    text = text.replace("的 那", "的那").replace("创建 那", "创建那")
    versions = sorted(set(re.findall(r"\d{4}-\d{2}-\d{2}", text)))
    if len(versions) == 1:
        text = text.replace(versions[0], "当前部署使用的接口版本")
    elif versions:
        labels = ["旧版接口", "新版接口"]
        for index, version in enumerate(versions):
            text = text.replace(version, labels[min(index, len(labels) - 1)])
    return text


def human_time(as_of: str) -> str:
    value = datetime.fromisoformat(as_of.replace("Z", "+00:00"))
    return f"大概是 {value.month} 月 {value.day} 日中午前后"


def build_conversation(
    family: dict, slot: int, qtype: str, question: str, as_of: str,
    ids: dict[str, str], dynamic: bool,
) -> dict:
    display_context = natural_display_context(family)
    id_text = "，".join(
        f"{ENTITY_DISPLAY[entity]}的编号是 {value}" for entity, value in ids.items()
    )
    facts = [
        {
            "fact_id": "goal",
            "category": "goal",
            "user_value": f"我们主要想确认{family['decision']}。",
            "disclose_when_asked_about": ["想确认什么", "希望解决什么", "具体问题"],
        },
        {
            "fact_id": "symptom_details",
            "category": "symptom_details",
            "user_value": display_context,
            "disclose_when_asked_about": ["具体现象", "报错", "状态", "操作步骤", "发生了什么"],
        },
        {
            "fact_id": "account_context",
            "category": "account_context",
            "user_value": (
                f"发生在{'正式环境' if family['environment'] == 'production' else '测试环境'}；"
                f"账户套餐是 {family['plan']}，主地区是 {family['region']}。"
            ),
            "canonical_value": {
                "environment": family["environment"], "plan": family["plan"],
                "region": family["region"],
            },
            "disclose_when_asked_about": ["环境", "套餐", "地区", "账户情况"],
        },
        {
            "fact_id": "occurrence_time",
            "category": "occurrence_time",
            "user_value": f"{human_time(as_of)}，只能确定到这个时间范围。",
            "canonical_value": as_of,
            "disclose_when_asked_about": ["什么时候", "大概时间", "时间范围"],
        },
        {
            "fact_id": "api_version",
            "category": "api_version",
            "user_value": f"部署配置里显示使用的接口版本是 {family['api_version']}。",
            "canonical_value": family["api_version"],
            "disclose_when_asked_about": ["接口版本", "API 版本", "版本请求头"],
        },
        {
            "fact_id": "identifiers",
            "category": "identifiers",
            "user_value": id_text,
            "canonical_value": {f"{entity}_id": value for entity, value in ids.items()},
            "disclose_when_asked_about": ["相关编号", "请求编号", "对象编号", "ID"],
        },
    ]
    single_turn = qtype in {"simple_retrieval", "multi_document"}
    required: list[str] = []
    clarification_plan: list[dict] = []
    if not single_turn:
        required = ["goal", "symptom_details", "account_context"]
        problem_questions = (
            "能把具体操作、页面状态或错误提示再描述一下吗？你最想确认的是哪一点？",
            "先补充一下实际表现：做了什么操作，随后看到了什么结果？",
            "这个问题具体影响了哪项业务？当时最直接的错误或异常表现是什么？",
            "为了先判断属于哪个环节，请说一下操作过程、当前状态和你希望解决的问题。",
        )
        account_questions = {
            "accounts": ("这是测试环境还是正式环境？账户当前是什么套餐、哪个主地区？", "先确认账户背景：使用什么套餐，主地区在哪里，问题出现在哪个环境？"),
            "developer_platform": ("请求发往测试还是正式环境？相关账户的套餐和主地区是什么？", "这次调用对应哪个环境？也请补充账户套餐和主地区。"),
            "payments": ("这笔业务发生在测试还是正式环境？账户套餐和主地区能确认吗？", "先确认支付所属环境，以及账户当前套餐和主地区。"),
            "refunds": ("退款发生在哪个环境？账户套餐和所属地区分别是什么？", "这笔退款属于测试还是真实交易？相关账户是什么套餐和地区？"),
            "subscriptions": ("订阅来自哪个环境和地区？账户当前使用什么套餐？", "请补充订阅所属环境、账户套餐和主地区。"),
            "invoices": ("这张账单属于测试还是真实业务？账户套餐和主地区是什么？", "账单来自哪个环境？对应账户的套餐和地区能确认吗？"),
            "webhooks": ("这个回调来自测试还是正式环境？账户套餐和主地区是什么？", "先确认事件所属环境，以及账户当前套餐和主地区。"),
            "operations": ("受影响的是测试还是真实流量？账户套餐和主要地区是什么？", "异常出现在哪个环境和地区？相关账户是什么套餐？"),
            "customers": ("客户对象属于哪个环境？账户套餐和主地区是什么？", "先确认客户所属环境，以及账户套餐和主地区。"),
        }
        record_questions = {
            "accounts": ("结合目前的规则，还需要核对实际账户记录。问题大概何时发生，控制台里的账户或请求编号是什么？", "下一步要确认账户当时的状态。请提供大概时间，以及能找到的账户或请求编号。", "为了排除账户配置变化，需要一个时间范围和相关账户编号。"),
            "developer_platform": ("接下来需要查看当时的请求。请给一个大概时间范围，以及相关账户或请求编号。", "还要核对客户端调用记录。大概何时发生，能否提供请求编号？", "为了确认请求实际使用的配置，请补充发生时间和控制台中的请求号。"),
            "payments": ("为了核对实际支付记录，请提供大概发生时间，以及能找到的支付或请求编号。", "下一步需要查看这笔支付的状态变化。大概是什么时候，支付编号是什么？", "还需要把规则和实际交易对应起来。请给时间范围及支付或请求号。"),
            "refunds": ("还需要确认实际退款链路。大概是什么时候，退款或原支付的编号能提供吗？", "接下来要核对可退金额和退款状态。请提供时间范围及退款编号。", "为了查看退款前后的金额变化，请给出大概日期和原支付或退款号。"),
            "subscriptions": ("需要继续核对订阅记录。请提供大概时间，以及订阅、账单或请求编号。", "下一步要查看订阅当时的状态。大概何时发生，能提供订阅编号吗？", "为了核对订阅与账单关系，请补充时间范围和相关对象编号。"),
            "invoices": ("为了查看账单时间线，请提供大概发生时间和账单或订阅编号。", "还需要核对实际扣款记录。请提供日期范围和账单编号。", "下一步要查看账单状态变化，大概是什么时候，相关账单或订阅号是什么？"),
            "webhooks": ("下一步要核对事件投递。请提供大概时间，以及事件、投递或回调地址编号。", "还需查看回调实际尝试记录。大概何时发生，能提供事件或投递编号吗？", "为了把事件和接收结果对应起来，请给出时间范围及回调地址或事件号。"),
            "operations": ("需要查看当时的运行记录。请提供大概时间和请求编号；如果有地区异常编号也可以一并提供。", "下一步要核对服务状态和请求轨迹。问题大概何时发生，请求号是什么？", "为了区分单次错误和区域异常，请补充时间范围、地区和可用的请求编号。"),
            "customers": ("需要核对客户及关联对象。请提供大概时间和客户或请求编号。", "接下来要查看客户当时的状态。大概何时发生，客户编号能提供吗？", "为了确认客户与交易的关联，请补充时间范围和相关客户编号。"),
        }
        seed = sum(ord(char) for char in family["slug"])
        if qtype == "multi_source":
            clarification_plan.append({
                "stage": "before_knowledge",
                "categories": ["goal", "symptom_details", "account_context"],
                "assistant_question": (
                    problem_questions[seed % len(problem_questions)] + " "
                    + account_questions[family["area"]][seed % 2]
                ),
            })
        elif qtype == "tool_use_diagnostic":
            clarification_plan.append({
                "stage": "before_knowledge",
                "categories": ["goal", "symptom_details", "account_context"],
                "assistant_question": (
                    account_questions[family["area"]][seed % 2] + " "
                    + problem_questions[(seed + 1) % len(problem_questions)]
                ),
            })
        else:
            clarification_plan.extend([
                {
                    "stage": "before_knowledge", "categories": ["goal", "symptom_details"],
                    "assistant_question": problem_questions[seed % len(problem_questions)],
                },
                {
                    "stage": "before_knowledge", "categories": ["account_context"],
                    "assistant_question": account_questions[family["area"]][seed % 2],
                },
            ])
        needs_version = qtype == "temporal_versioned" or family["api_version"] != "2026-07-01"
        if needs_version:
            required.append("api_version")
            version_questions = (
                "这次调用使用的是哪个接口版本？如果没有显式设置，也请说明账户默认版本。",
                "部署里配置的 API 版本或版本请求头是什么？",
                "能确认当时客户端使用的接口版本吗？",
            )
            clarification_plan.append({
                "stage": "before_knowledge", "categories": ["api_version"],
                "assistant_question": version_questions[seed % len(version_questions)],
            })
        if dynamic:
            required.extend(["occurrence_time", "identifiers"])
            clarification_plan.append({
                "stage": "after_knowledge", "categories": ["occurrence_time", "identifiers"],
                "assistant_question": record_questions[family["area"]][seed % 3],
            })
    return {
        "schema_version": "1.0",
        "mode": "single_turn_complete" if single_turn else "progressive_disclosure",
        "initial_user_message": question,
        "disclosure_policy": (
            "no_follow_up_required"
            if single_turn else
            "only_answer_information_categories_the_assistant_explicitly_requests"
        ),
        "required_clarification_categories": list(dict.fromkeys(required)),
        "max_clarification_turns": len(clarification_plan),
        "clarification_plan": clarification_plan,
        "available_user_facts": facts,
    }


def build_answer(family: dict, slot: int, qtype: str) -> str:
    if qtype == "simple_retrieval":
        return family["policy"]
    if qtype == "multi_document":
        return f"{family['expected']} 处理方式：{family['action']}"
    if qtype == "multi_hop":
        return (
            f"{family['expected']} 推理时必须先确认对象归属和状态，再套用当时有效规则，"
            f"最后核对执行结果。处理方式：{family['action']}"
        )
    return f"{family['expected']} 处理方式：{family['action']}"


def build_artifacts() -> tuple[list[dict], list[dict], dict]:
    documents = load_documents()
    canonical_rules = load_rules()
    if len(FAMILIES) != 75:
        raise AssertionError(f"expected 75 families, got {len(FAMILIES)}")
    if len(documents) != 100:
        raise AssertionError(f"expected 100 documents, got {len(documents)}")
    if len(canonical_rules) != 110:
        raise AssertionError(f"expected 110 canonical rules, got {len(canonical_rules)}")

    split_positions = {"dev": 0, "test": 0}
    questions: list[dict] = []
    scenarios: list[dict] = []
    reservations: list[dict] = []
    question_number = 0

    for family_number, family in enumerate(FAMILIES, start=1):
        split = "dev" if family_number in DEV_FAMILY_NUMBERS else "test"
        split_position = split_positions[split]
        split_positions[split] += 1
        types = question_types(split, split_position)
        family_id = f"SF-{family_number:03d}-{family['slug']}"
        scenario_id = f"SC-{family_number:03d}-{family['slug']}"
        ids = family_entity_ids(family_number, family["entities"])
        as_of_dt = datetime(2026, 8, 1, 12, tzinfo=timezone.utc) + timedelta(days=family_number % 26)
        as_of = as_of_dt.isoformat().replace("+00:00", "Z")
        context = family["context"].format(**ids)

        family_question_ids: list[str] = []
        for slot, qtype in enumerate(types):
            question_number += 1
            question_id = f"FP-BM-{TYPE_CODE[qtype]}-{question_number:04d}"
            family_question_ids.append(question_id)
            required_docs = select_documents(family, family_number, slot, qtype)
            for doc_id in required_docs:
                if doc_id not in documents:
                    raise AssertionError(f"unknown document {doc_id} in {family_id}")

            dynamic = qtype in {
                "multi_hop", "multi_source", "temporal_versioned", "tool_use_diagnostic"
            }
            data_ops = list(family["data_ops"]) if dynamic else []
            doc_tools = [DOC_TOOL[doc_prefix(doc_id)] for doc_id in required_docs]
            required_tools = list(dict.fromkeys(doc_tools + [op.split(".", 1)[0] for op in data_ops]))
            required_sources = list(dict.fromkeys(
                [DOC_SOURCE[doc_prefix(doc_id)] for doc_id in required_docs]
                + ["runtime" if op.startswith("get_runtime_state.") else f"{op.split('.', 1)[0]}_sql" for op in data_ops]
            ))
            rule_ids = sorted(
                family["required_rule_ids"]
                if family["required_rule_ids"] is not None
                else {
                    rule_id
                    for doc_id in required_docs
                    for rule_id in documents[doc_id].get("rule_ids", [])
                    if rule_id
                }
            )
            selectors = [selector_for_operation(op, ids, as_of) for op in data_ops]
            expected_hops = [
                {"step": 1, "purpose": "获取适用的正式规则与版本证据", "tools": doc_tools},
            ]
            if data_ops:
                expected_hops.append(
                    {"step": 2, "purpose": "使用用户提供或前一步发现的编号查询对象、请求与运行轨迹", "operations": data_ops}
                )
                expected_hops.append(
                    {"step": 3, "purpose": "先向用户还原实际过程，再将动态事实代入规则并给出实例化处置方案", "expected": family["expected"]}
                )

            answer = build_answer(family, slot, qtype)
            initial_question = build_question_text(
                family, slot, qtype, context, as_of, ids, required_docs
            )
            selector_values = {
                value
                for selector in selectors
                for key, value in selector["where"].items()
                if key.endswith("_id")
            }
            conversation_ids = (
                {
                    entity: value for entity, value in ids.items()
                    if entity == "account" or value in selector_values
                }
                if dynamic else ids
            )
            conversation = build_conversation(
                family, slot, qtype, initial_question, as_of, conversation_ids, dynamic
            )
            question = {
                "schema_version": "1.1",
                "question_id": question_id,
                "split": split,
                "scenario_family_id": family_id,
                "scenario_id": scenario_id,
                "question_type": qtype,
                "secondary_tags": [family["area"], family["slug"]],
                "difficulty": {
                    "simple_retrieval": 1, "multi_document": 2, "multi_hop": 3,
                    "multi_source": 4, "temporal_versioned": 4, "tool_use_diagnostic": 5,
                }[qtype],
                # Kept for older consumers; it is now strictly the first user
                # turn, not a fully specified one-shot benchmark prompt.
                "question": initial_question,
                "conversation": conversation,
                "as_of": as_of,
                "api_version_context": family["api_version"],
                "ground_truth": {
                    "canonical_answer": answer,
                    # Simple retrieval has one factual assertion. “Explain the
                    # applicable conditions” is an answer-quality constraint, not a
                    # second business fact that must appear verbatim in evidence.
                    "required_assertions": [
                        {"assertion_id": f"{question_id}-A1", "text": family["expected"] if qtype != "simple_retrieval" else family["policy"]},
                    ] + ([] if qtype == "simple_retrieval" else [
                        {"assertion_id": f"{question_id}-A2", "text": family["action"]},
                    ]),
                    "acceptable_variants": [],
                    "negative_assertions": [f"不得认定：{family['negative']}"],
                },
                "instance_diagnosis_contract": {
                    "required": dynamic,
                    "must_use_user_identifiers": dynamic,
                    "must_describe_selector_observations": dynamic,
                    "must_reconstruct_timeline_when_available": dynamic,
                    "must_derive_solution_from_observed_state": dynamic,
                    "static_rule_only_answer_is_accepted": not dynamic,
                    "resolution_phase": "after_deterministic_data_generation" if dynamic else "not_applicable",
                },
                "required_documents": required_docs,
                "required_rule_ids": rule_ids,
                "required_sources": required_sources,
                "required_tools": required_tools,
                "required_operations": data_ops,
                "optional_tools": [],
                "forbidden_shortcuts": [
                    "support_case_as_current_fact",
                    "current_state_used_for_historical_question",
                    "raw_sql_or_hidden_audit_access",
                ],
                "expected_hops": expected_hops,
                "evidence_selectors": selectors,
                "selector_fact_policy": (
                    "All selector parameters must come from facts disclosed during the conversation; "
                    "the runner must never inject hidden as_of, API version or entity IDs into the first turn."
                ),
                "planned_evidence_ids": [f"doc:{doc_id}" for doc_id in required_docs],
                "resolved_evidence_ids": [],
                "stop_condition": "所有 Required Assertions 均有 Agent 可见证据支持，Negative Assertions 均被排除，且不存在未解释冲突。",
                "freeze_status": "frozen_before_data_generation",
            }
            questions.append(question)

        reservations.append(
            {
                "scenario_family_id": family_id,
                "scenario_id": scenario_id,
                "split": split,
                "namespace": "benchmark_reserved",
                "ids": {f"{key}_id": value for key, value in ids.items()},
            }
        )
        command_at = (as_of_dt - timedelta(minutes=10)).isoformat().replace("+00:00", "Z")
        scenarios.append(
            {
                "schema_version": "1.0",
                "scenario_family_id": family_id,
                "scenario_id": scenario_id,
                "split": split,
                "title": family["title"],
                "product_area": family["area"],
                "question_ids": family_question_ids,
                "observation_time": as_of,
                "api_version": family["api_version"],
                "entity_reservation_ref": family_id,
                "setup": {
                    "account": {
                        "account_id": ids.get("account"),
                        "plan": family["plan"],
                        "region": family["region"],
                        "environment": family["environment"],
                        "default_api_version": family["api_version"],
                    },
                    "reserved_entities": ids,
                    "precondition": context,
                },
                "commands": [
                    {
                        "at": command_at,
                        "command": family["command"],
                        "params": {
                            "account_id": ids.get("account"),
                            "environment": family["environment"],
                            "api_version": family["api_version"],
                            "reserved_entities": ids,
                            "scenario_mode": family["slug"],
                        },
                    }
                ],
                "expects": {
                    "policy": family["policy"],
                    "outcome": family["expected"],
                    "must_not_conclude": family["negative"],
                    "runtime_signal": family["runtime_signal"],
                },
                "required_documents": family["docs"],
                "required_operations": family["data_ops"],
            }
        )

    reservation_file = {
        "schema_version": "1.0",
        "namespace_policy": {
            "benchmark_prefix": "*_bm_NNN",
            "background_prefix": "*_bg_NNN",
            "collision_policy": "fail_build",
            "immutability": "IDs are frozen before simulation and may not be reassigned",
        },
        "reservations": reservations,
    }
    validate(questions, scenarios, reservation_file, documents, canonical_rules)
    return questions, scenarios, reservation_file


def validate(
    questions: list[dict], scenarios: list[dict], reservation_file: dict,
    documents: dict[str, dict], canonical_rules: set[str]
) -> None:
    assert len(questions) == 300
    assert len(scenarios) == 75
    assert len({q["question_id"] for q in questions}) == 300
    assert Counter(q["split"] for q in questions) == Counter({"dev": 60, "test": 240})
    assert Counter(s["split"] for s in scenarios) == Counter({"dev": 15, "test": 60})
    for split, quotas in QUESTION_TYPE_QUOTA.items():
        actual = Counter(q["question_type"] for q in questions if q["split"] == split)
        assert actual == Counter(quotas), (split, actual, quotas)
    family_counts = Counter(q["scenario_family_id"] for q in questions)
    assert set(family_counts.values()) == {4}
    family_splits = defaultdict(set)
    for q in questions:
        family_splits[q["scenario_family_id"]].add(q["split"])
    assert all(len(splits) == 1 for splits in family_splits.values())

    for question in questions:
        route_leaks = sorted(
            phrase for phrase in QUESTION_ROUTE_LEAKAGE_PHRASES
            if phrase.lower() in question["question"].lower()
        )
        assert not route_leaks, (question["question_id"], route_leaks)
        assert question["question"] == question["conversation"]["initial_user_message"]
        assert not re.search(r"\d{4}-\d{2}-\d{2}T", question["question"]), question["question_id"]
        assert not re.search(
            r"(?:acct|key|cus|pay|re|sub|in|we|evt|del|req|inc)_bm_\d+",
            question["question"], flags=re.IGNORECASE,
        ), question["question_id"]
        assert not re.search(r"API\s*(?:Version|版本)\s*\d{4}-\d{2}-\d{2}", question["question"], re.I)
        if question["question_type"] in {"simple_retrieval", "multi_document"}:
            assert question["conversation"]["mode"] == "single_turn_complete"
            assert question["conversation"]["required_clarification_categories"] == []
            assert question["conversation"]["clarification_plan"] == []
        else:
            assert question["conversation"]["mode"] == "progressive_disclosure"
            assert len(question["conversation"]["required_clarification_categories"]) >= 3
            assert question["conversation"]["clarification_plan"]

    assert Counter(q["conversation"]["mode"] for q in questions) == Counter({
        "single_turn_complete": 120,
        "progressive_disclosure": 180,
    })
    assert Counter(q["instance_diagnosis_contract"]["required"] for q in questions) == Counter({
        False: 120,
        True: 180,
    })
    assert all(
        bool(q["required_operations"]) == q["instance_diagnosis_contract"]["required"]
        for q in questions
    )

    covered_docs = {doc for q in questions for doc in q["required_documents"]}
    missing_docs = set(documents) - covered_docs
    assert not missing_docs, f"documents without required evidence: {sorted(missing_docs)}"
    covered_rules = {rule for q in questions for rule in q["required_rule_ids"]}
    missing_rules = canonical_rules - covered_rules
    assert not missing_rules, f"rules without benchmark coverage: {sorted(missing_rules)}"
    covered_tools = {tool for q in questions for tool in q["required_tools"]}
    assert covered_tools == ALL_LOGICAL_TOOLS, (covered_tools, ALL_LOGICAL_TOOLS)

    operation_counts = Counter(op for q in questions for op in q["required_operations"])
    undercovered = {op: count for op, count in operation_counts.items() if count < 3}
    assert not undercovered, f"typed operations with fewer than 3 questions: {undercovered}"

    reserved_ids = [
        value
        for reservation in reservation_file["reservations"]
        for value in reservation["ids"].values()
    ]
    assert len(reserved_ids) == len(set(reserved_ids)), "reserved ID collision"
    assert all(q["freeze_status"] == "frozen_before_data_generation" for q in questions)
    assert sum(bool(q["ground_truth"]["negative_assertions"]) for q in questions) >= 90


def yaml_quote(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def render_scenarios_yaml(scenarios: list[dict]) -> str:
    lines = [
        'schema_version: "1.0"',
        'design_status: "frozen_before_data_generation"',
        'description: "75 个 Scenario Family；编译器必须把声明式 setup 与 commands 转为统一模拟器命令。"',
        "scenario_families:",
    ]
    for s in scenarios:
        lines.extend([
            f"  - scenario_family_id: {yaml_quote(s['scenario_family_id'])}",
            f"    scenario_id: {yaml_quote(s['scenario_id'])}",
            f"    split: {s['split']}",
            f"    title: {yaml_quote(s['title'])}",
            f"    product_area: {s['product_area']}",
            f"    question_ids: {yaml_quote(s['question_ids'])}",
            f"    observation_time: {yaml_quote(s['observation_time'])}",
            f"    api_version: {yaml_quote(s['api_version'])}",
            f"    entity_reservation_ref: {yaml_quote(s['entity_reservation_ref'])}",
            "    setup:",
            f"      account: {yaml_quote(s['setup']['account'])}",
            f"      reserved_entities: {yaml_quote(s['setup']['reserved_entities'])}",
            f"      precondition: {yaml_quote(s['setup']['precondition'])}",
            "    commands:",
        ])
        for command in s["commands"]:
            lines.extend([
                f"      - at: {yaml_quote(command['at'])}",
                f"        command: {command['command']}",
                f"        params: {yaml_quote(command['params'])}",
            ])
        lines.extend([
            "    expects:",
            f"      policy: {yaml_quote(s['expects']['policy'])}",
            f"      outcome: {yaml_quote(s['expects']['outcome'])}",
            f"      must_not_conclude: {yaml_quote(s['expects']['must_not_conclude'])}",
            f"      runtime_signal: {yaml_quote(s['expects']['runtime_signal'])}",
            f"    required_documents: {yaml_quote(s['required_documents'])}",
            f"    required_operations: {yaml_quote(s['required_operations'])}",
        ])
    return "\n".join(lines) + "\n"


def render_coverage_matrix(
    questions: list[dict], documents: dict[str, dict], canonical_rules: set[str]
) -> str:
    doc_questions = defaultdict(list)
    rule_questions = defaultdict(list)
    tool_questions = defaultdict(list)
    operation_questions = defaultdict(list)
    for q in questions:
        for item in q["required_documents"]:
            doc_questions[item].append(q["question_id"])
        for item in q["required_rule_ids"]:
            rule_questions[item].append(q["question_id"])
        for item in q["required_tools"]:
            tool_questions[item].append(q["question_id"])
        for item in q["required_operations"]:
            operation_questions[item].append(q["question_id"])

    lines = [
        "# FlowPay 300 题覆盖矩阵",
        "",
        "> 由 `scripts/build_benchmark_design.py` 从冻结的 75 个 Scenario Family 生成。  ",
        "> 本文件是设计覆盖检查，不进入业务向量库。",
        "",
        "## 1. 验证摘要",
        "",
        f"- Questions：{len(questions)}（Dev 60 / Test 240）。",
        "- Scenario Families：75（Dev 15 / Test 60；每个 Family 4 题）。",
        f"- Published Documents：{len(doc_questions)}/{len(documents)} 均为至少一道题的 Required Evidence。",
        f"- Canonical Rules：{len(rule_questions)}/{len(canonical_rules)} 均有 Required Assertion 覆盖。",
        f"- Logical Tools：{len(tool_questions)}/9 均有 Required Tool 覆盖。",
        "- 所有题均在数据生成前冻结，并包含 Negative Assertion。",
        "",
        "## 2. 题型配额",
        "",
        "| Split | Simple | Multi-doc | Multi-hop | Multi-source | Temporal | Diagnostic | Total |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for split in ("dev", "test"):
        c = Counter(q["question_type"] for q in questions if q["split"] == split)
        lines.append(
            f"| {split} | {c['simple_retrieval']} | {c['multi_document']} | {c['multi_hop']} | "
            f"{c['multi_source']} | {c['temporal_versioned']} | {c['tool_use_diagnostic']} | {sum(c.values())} |"
        )
    lines.extend([
        "",
        "## 3. 逻辑工具与 Operation 覆盖",
        "",
        "| Tool / Operation | Questions | 示例题 |",
        "| --- | ---: | --- |",
    ])
    for tool in sorted(tool_questions):
        values = tool_questions[tool]
        lines.append(f"| `{tool}` | {len(values)} | {', '.join(values[:3])} |")
    for op in sorted(operation_questions):
        values = operation_questions[op]
        lines.append(f"| `{op}` | {len(values)} | {', '.join(values[:3])} |")

    lines.extend([
        "",
        "## 4. 100 份 Published 文档覆盖",
        "",
        "| Doc ID | Title | Required by | 示例题 |",
        "| --- | --- | ---: | --- |",
    ])
    for doc_id in sorted(documents):
        values = doc_questions[doc_id]
        lines.append(
            f"| {doc_id} | {documents[doc_id].get('title', '')} | {len(values)} | {', '.join(values[:3])} |"
        )

    lines.extend([
        "",
        "## 5. 110 条 Canonical Rules 覆盖",
        "",
        "| Rule ID | Questions | 示例题 |",
        "| --- | ---: | --- |",
    ])
    for rule_id in sorted(canonical_rules):
        values = rule_questions[rule_id]
        lines.append(f"| {rule_id} | {len(values)} | {', '.join(values[:3])} |")

    lines.extend([
        "",
        "## 6. 逐题矩阵",
        "",
        "| Question | Split | Family | Type | Docs | Rules | Tools / Operations |",
        "| --- | --- | --- | --- | --- | --- | --- |",
    ])
    for q in questions:
        operations = q["required_operations"] or q["required_tools"]
        lines.append(
            f"| {q['question_id']} | {q['split']} | {q['scenario_family_id'].split('-', 2)[1]} | "
            f"{q['question_type']} | {', '.join(q['required_documents'])} | "
            f"{', '.join(q['required_rule_ids'])} | {', '.join(operations)} |"
        )
    return "\n".join(lines) + "\n"


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    questions, scenarios, reservations = build_artifacts()
    documents = load_documents()
    canonical_rules = load_rules()
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    blueprints_text = "".join(
        json.dumps(question, ensure_ascii=False, separators=(",", ":")) + "\n"
        for question in questions
    )
    scenarios_text = render_scenarios_yaml(scenarios)
    reservations_text = json.dumps(reservations, ensure_ascii=False, indent=2) + "\n"
    coverage_text = render_coverage_matrix(questions, documents, canonical_rules)

    outputs = {
        "benchmark_blueprints.jsonl": blueprints_text,
        "scenario_specs.yaml": scenarios_text,
        "entity_reservations.json": reservations_text,
        "coverage_matrix.md": coverage_text,
    }
    for name, content in outputs.items():
        (OUT_DIR / name).write_text(content, encoding="utf-8")

    knowledge_inputs = [
        {
            "doc_id": doc_id,
            "path": documents[doc_id]["path"],
            "sha256": sha256_file(ROOT / str(documents[doc_id]["path"])),
        }
        for doc_id in sorted(documents)
    ]
    manifest = {
        "schema_version": "1.0",
        "design_status": "frozen_before_data_generation",
        "question_count": len(questions),
        "scenario_family_count": len(scenarios),
        "dev_questions": sum(q["split"] == "dev" for q in questions),
        "test_questions": sum(q["split"] == "test" for q in questions),
        "published_document_count": len(documents),
        "canonical_rule_count": len(canonical_rules),
        "inputs": {
            "canonical_rules": {
                "path": str(RULES_PATH.relative_to(ROOT)),
                "sha256": sha256_file(RULES_PATH),
            },
            "knowledge_manifest_sha256": sha256_text(
                json.dumps(knowledge_inputs, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            ),
            "knowledge_documents": knowledge_inputs,
            "generator": {
                "path": str(Path(__file__).resolve().relative_to(ROOT)),
                "sha256": sha256_file(Path(__file__).resolve()),
            },
        },
        "files": {name: {"sha256": sha256_text(content), "bytes": len(content.encode('utf-8'))} for name, content in outputs.items()},
    }
    (OUT_DIR / "design_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
