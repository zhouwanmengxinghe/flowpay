# 生成带随机种子控制的背景业务数据，为目标场景提供干扰记录。
from __future__ import annotations

import hashlib
import random
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Callable

from .engine import SimulationEngine


def _rng(seed: int, namespace: str) -> random.Random:
    digest = hashlib.sha256(f"{seed}:{namespace}".encode()).digest()
    return random.Random(int.from_bytes(digest[:8], "big"))


@dataclass(frozen=True, slots=True)
class BackgroundScale:
    accounts: int
    keys_per_account: int
    endpoints_per_account: int
    customers_per_account: int
    payments_per_account: int
    refunds_per_account: int
    subscriptions_per_account: int
    invoices_per_subscription: int
    noise_requests_per_account: int


CANONICAL_SCALE = BackgroundScale(
    accounts=45,
    keys_per_account=6,
    endpoints_per_account=5,
    customers_per_account=67,
    payments_per_account=400,
    refunds_per_account=40,
    subscriptions_per_account=22,
    invoices_per_subscription=4,
    noise_requests_per_account=720,
)

SMOKE_SCALE = BackgroundScale(
    accounts=3,
    keys_per_account=2,
    endpoints_per_account=2,
    customers_per_account=4,
    payments_per_account=8,
    refunds_per_account=1,
    subscriptions_per_account=1,
    invoices_per_subscription=2,
    noise_requests_per_account=12,
)


class BackgroundGenerator:
    def __init__(self, engine: SimulationEngine, scale: BackgroundScale = CANONICAL_SCALE):
        self.engine = engine
        self.scale = scale
        self.start = datetime(2025, 9, 1, tzinfo=timezone.utc)
        self.end = datetime(2026, 7, 30, 23, 59, tzinfo=timezone.utc)
        self._actions: list[tuple[datetime, int, str, dict[str, Any]]] = []

    def _add(self, at: datetime, priority: int, kind: str, params: dict[str, Any]) -> None:
        if at <= self.end:
            self._actions.append((at, priority, kind, params))

    def plan(self) -> None:
        plans = ("Starter", "Growth", "Scale")
        regions = ("NA", "EU", "APAC")
        currencies = {"NA": "USD", "EU": "EUR", "APAC": "SGD"}
        versions = ("2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01")
        payments_rng = _rng(self.engine.seed, "background/payments")
        requests_rng = _rng(self.engine.seed, "background/requests")

        for incident_index in range(1, 24):
            incident_at = self.start + timedelta(days=incident_index * 13, hours=incident_index % 17)
            self._add(incident_at, 5, "incident", {
                "incident_id": f"inc_bg_{incident_index:03d}",
                "service": ("payments", "webhooks", "api")[incident_index % 3],
                "region": regions[incident_index % 3],
                "status": "resolved",
            })

        for account_index in range(1, self.scale.accounts + 1):
            account_id = f"acct_bg_{account_index:03d}"
            plan = plans[(account_index - 1) % len(plans)]
            region = regions[(account_index - 1) % len(regions)]
            version = versions[(account_index - 1) % len(versions)]
            environment = "production"
            account = {
                "account_id": account_id, "plan": plan, "region": region,
                "environment": environment, "default_api_version": version,
                "scenario_mode": "background",
            }
            base = self.start + timedelta(seconds=account_index)
            self._add(base, 1, "account", account)
            for key_index in range(1, self.scale.keys_per_account + 1):
                self._add(base + timedelta(seconds=key_index), 2, "key", {
                    "key_id": f"key_bg_{account_index:03d}_{key_index:02d}",
                    "account_id": account_id, "environment": environment, "status": "active",
                })
            endpoint_count = 2 if plan == "Starter" else (5 if plan == "Growth" else min(8, self.scale.endpoints_per_account + 3))
            for endpoint_index in range(1, endpoint_count + 1):
                self._add(base + timedelta(minutes=1, seconds=endpoint_index), 3, "endpoint", {
                    "endpoint_id": f"we_bg_{account_index:03d}_{endpoint_index:02d}",
                    "account_id": account_id, "environment": environment,
                    "status": "enabled", "api_version": version,
                })
            if plan in {"Growth", "Scale"}:
                self._add(base + timedelta(minutes=2), 4, "feature_flag", {
                    "account_id": account_id, "environment": environment,
                    "feature_name": "subscriptions", "enabled": True,
                })

            customer_ids = []
            for customer_index in range(1, self.scale.customers_per_account + 1):
                customer_id = f"cus_bg_{account_index:03d}_{customer_index:03d}"
                customer_ids.append(customer_id)
                at = self.start + timedelta(days=(customer_index - 1) % 30, minutes=account_index, seconds=customer_index)
                self._add(at, 10, "customer", {
                    "customer_id": customer_id, "account_id": account_id,
                    "environment": environment, "status": "active",
                })

            succeeded_payments = []
            for payment_index in range(1, self.scale.payments_per_account + 1):
                payment_id = f"pay_bg_{account_index:03d}_{payment_index:04d}"
                customer_id = customer_ids[(payment_index - 1) % len(customer_ids)]
                at = self.start + timedelta(
                    days=(payment_index * 17 + account_index * 3) % 300,
                    seconds=(payment_index * 137 + account_index * 19) % 86400,
                )
                roll = payments_rng.random()
                status = "succeeded" if roll < 0.90 else ("failed" if roll < 0.98 else "processing")
                amount = 50 + payments_rng.randrange(50, 500_000)
                self._add(at, 20, "payment", {
                    "payment_id": payment_id, "account_id": account_id, "environment": environment,
                    "customer_id": customer_id, "status": status, "api_version": version,
                    "amount": amount, "currency": currencies[region],
                })
                self._add(at + timedelta(milliseconds=1), 21, "request", {
                    "ids": {"account": account_id, "request": f"req_bg_pay_{account_index:03d}_{payment_index:04d}"},
                    "mode": f"background_payment_{account_index:03d}_{payment_index:04d}", "account": account,
                    "status": 200 if status != "failed" else 402,
                    "error": None if status != "failed" else "FP-4021", "route": "/v1/payments",
                    "object_id": payment_id,
                })
                if status == "succeeded":
                    succeeded_payments.append((payment_id, amount, at))
                    event_id = f"evt_bg_{account_index:03d}_{payment_index:04d}"
                    delivery_id = f"del_bg_{account_index:03d}_{payment_index:04d}"
                    endpoint_index = ((payment_index - 1) % endpoint_count) + 1
                    endpoint_id = f"we_bg_{account_index:03d}_{endpoint_index:02d}"
                    self._add(at + timedelta(milliseconds=2), 22, "event", {
                        "event_id": event_id, "account_id": account_id, "environment": environment,
                        "object_id": payment_id, "api_version": version,
                        "event_type": "payment.succeeded" if version == "2026-07-01" else "payment.completed",
                    })
                    self._add(at + timedelta(milliseconds=3), 23, "delivery", {
                        "delivery_id": delivery_id, "event_id": event_id, "endpoint_id": endpoint_id, "status": "pending",
                    })
                    response_status = 204 if payments_rng.random() < 0.94 else 500
                    self._add(at + timedelta(milliseconds=4), 24, "delivery_attempt", {
                        "delivery_id": delivery_id, "http_status": response_status, "response_kind": "http",
                    })

            refund_count = 1 if plan == "Starter" else (60 if self.scale == CANONICAL_SCALE else self.scale.refunds_per_account)
            for refund_index, (payment_id, amount, payment_at) in enumerate(
                succeeded_payments[: refund_count], start=1
            ):
                refund_id = f"re_bg_{account_index:03d}_{refund_index:03d}"
                at = payment_at + timedelta(days=7, seconds=refund_index)
                self._add(at, 30, "refund", {
                    "refund_id": refund_id, "payment_id": payment_id, "account_id": account_id,
                    "environment": environment, "amount": amount if plan == "Starter" else max(1, amount // 4),
                    "currency": currencies[region], "status": "succeeded",
                })

            subscription_count = 0 if plan == "Starter" else (
                self.scale.subscriptions_per_account + 10 if self.scale == CANONICAL_SCALE else self.scale.subscriptions_per_account
            )
            for sub_index in range(1, subscription_count + 1):
                subscription_id = f"sub_bg_{account_index:03d}_{sub_index:03d}"
                customer_id = customer_ids[(sub_index * 3) % len(customer_ids)]
                sub_at = self.start + timedelta(days=(sub_index * 5) % 28, minutes=account_index)
                self._add(sub_at, 40, "subscription", {
                    "subscription_id": subscription_id, "account_id": account_id, "environment": environment,
                    "customer_id": customer_id, "status": "active", "amount": 2500 + sub_index,
                    "currency": currencies[region],
                })
                for invoice_index in range(1, self.scale.invoices_per_subscription + 1):
                    invoice_id = f"in_bg_{account_index:03d}_{sub_index:03d}_{invoice_index:02d}"
                    invoice_at = sub_at + timedelta(days=30 * invoice_index)
                    self._add(invoice_at, 41, "invoice", {
                        "invoice_id": invoice_id, "subscription_id": subscription_id,
                        "account_id": account_id, "environment": environment, "status": "paid",
                        "amount_due": 2500 + sub_index, "currency": currencies[region],
                    })

            for request_index in range(1, self.scale.noise_requests_per_account + 1):
                at = self.start + timedelta(
                    days=(request_index * 11 + account_index) % 330,
                    seconds=requests_rng.randrange(0, 86400),
                )
                roll = requests_rng.random()
                status, error = (200, None) if roll < 0.97 else ((429, "FP-4291") if roll < 0.985 else (500, "FP-5001"))
                self._add(at, 50, "request", {
                    "ids": {"account": account_id, "request": f"req_bg_noise_{account_index:03d}_{request_index:04d}"},
                    "mode": f"background_noise_{account_index:03d}_{request_index:04d}", "account": account,
                    "status": status, "error": error, "route": "/v1/customers", "object_id": None,
                })

        self._actions.sort(key=lambda item: (item[0], item[1], item[2], json_key(item[3])))

    def run(self) -> None:
        if not self._actions:
            self.plan()
        engine = self.engine
        engine.current_scenario_id = None
        engine.current_background_batch_id = "bg_canonical_20260827"
        for at, _, kind, p in self._actions:
            if at < engine.now:
                raise ValueError("background action order moved clock backwards")
            engine.now = at
            if kind == "account":
                engine._handle_create_account(p)
                engine._handle_enable_production({"account_id": p["account_id"]})
            elif kind == "key":
                engine._handle_create_api_key(p)
            elif kind == "endpoint":
                engine._handle_create_endpoint_fixture(p)
            elif kind == "customer":
                engine._handle_create_customer(p)
            elif kind == "feature_flag":
                engine._set_flag(p["account_id"], p["environment"], p["feature_name"], p["enabled"])
            elif kind == "incident":
                engine._handle_create_incident_fixture(p)
                row = engine.state.service_incidents[-1]
                row["resolved_at"] = (at + timedelta(minutes=45)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
                row["timeline"].append({"at": row["resolved_at"], "status": "resolved"})
            elif kind == "payment":
                engine._handle_create_payment_fixture(p)
            elif kind == "refund":
                engine._handle_create_refund_fixture(p)
                if p["status"] == "succeeded":
                    row = engine.state.refunds[p["refund_id"]]
                    row["completed_at"] = row["created_at"]
            elif kind == "subscription":
                engine._handle_create_subscription_fixture(p)
            elif kind == "invoice":
                engine._handle_create_invoice_fixture(p)
                row = engine.state.invoices[p["invoice_id"]]
                if p["status"] == "paid":
                    row["amount_paid"] = row["amount_due"]
                    row["paid_at"] = row["finalized_at"]
            elif kind == "event":
                engine._handle_create_event_fixture(p)
            elif kind == "delivery":
                engine._handle_create_delivery_fixture(p)
            elif kind == "delivery_attempt":
                engine.record_delivery_attempt(p["delivery_id"], http_status=p["http_status"], response_kind=p["response_kind"])
            elif kind == "request":
                engine.record_request(
                    ids=p["ids"], mode=p["mode"], account=p["account"], http_status=p["status"],
                    error_code=p["error"], route=p["route"],
                    response_object_type="payment" if p["object_id"] else None,
                    response_object_id=p["object_id"],
                )
            else:
                raise ValueError(f"unsupported background action: {kind}")
        engine.current_background_batch_id = None


def json_key(value: dict[str, Any]) -> str:
    return "|".join(f"{key}={value[key]}" for key in sorted(value) if key not in {"account"})
