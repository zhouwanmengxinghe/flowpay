# 驱动模拟世界的命令与事件处理，维护业务实体之间的状态关系。
from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

from .models import CompiledCommand, DomainEvent


def _dt(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _iso(value: datetime) -> str:
    return value.isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _derived(base: str | None, suffix: str) -> str:
    return f"{base}_{suffix}" if base else f"derived_{suffix}"


@dataclass(slots=True)
class WorldState:
    accounts: dict[str, dict[str, Any]] = field(default_factory=dict)
    plan_changes: dict[str, dict[str, Any]] = field(default_factory=dict)
    api_keys: dict[str, dict[str, Any]] = field(default_factory=dict)
    feature_flags: dict[str, dict[str, Any]] = field(default_factory=dict)
    customers: dict[str, dict[str, Any]] = field(default_factory=dict)
    payments: dict[str, dict[str, Any]] = field(default_factory=dict)
    refunds: dict[str, dict[str, Any]] = field(default_factory=dict)
    subscriptions: dict[str, dict[str, Any]] = field(default_factory=dict)
    invoices: dict[str, dict[str, Any]] = field(default_factory=dict)
    invoice_attempts: dict[str, dict[str, Any]] = field(default_factory=dict)
    endpoints: dict[str, dict[str, Any]] = field(default_factory=dict)
    webhook_subscriptions: dict[str, dict[str, Any]] = field(default_factory=dict)
    business_events: dict[str, dict[str, Any]] = field(default_factory=dict)
    deliveries: dict[str, dict[str, Any]] = field(default_factory=dict)
    api_requests: list[dict[str, Any]] = field(default_factory=list)
    delivery_attempts: list[dict[str, Any]] = field(default_factory=list)
    service_incidents: list[dict[str, Any]] = field(default_factory=list)
    events: list[DomainEvent] = field(default_factory=list)
    scenario_executions: dict[str, dict[str, Any]] = field(default_factory=dict)


ERROR_BY_MODE = {
    "retrieve_cross_tenant_payment": (404, "FP-4041"),
    "create_payment_with_wrong_environment_key": (401, "FP-4012"),
    "create_production_key_before_enablement": (403, "FP-4031"),
    "suspend_production_and_send_requests": (403, "FP-4032"),
    "create_payment_with_unsupported_currency": (400, "FP-4001"),
    "submit_payment_amount_boundaries": (400, "FP-4001"),
    "create_subscription_on_starter": (403, "FP-4031"),
    "revoke_key_then_reuse": (401, "FP-4011"),
    "send_unsupported_version_header": (400, "FP-4002"),
    "create_payment_with_removed_source": (400, "FP-4003"),
    "reuse_idempotency_key_with_changed_amount": (409, "FP-4091"),
    "create_payment_for_deleted_customer": (422, "FP-4221"),
    "confirm_succeeded_payment": (422, "FP-4221"),
    "cancel_processing_payment": (422, "FP-4221"),
    "decline_payment_method": (402, "FP-4021"),
    "fail_payment_for_insufficient_funds": (402, "FP-4022"),
    "use_expired_payment_method": (402, "FP-4024"),
    "refund_processing_payment": (422, "FP-4221"),
    "overbook_refund_while_pending": (400, "FP-4001"),
    "create_partial_refund_on_starter": (403, "FP-4031"),
    "refund_payment_after_181_days": (422, "FP-4222"),
    "create_instant_refund_in_apac": (403, "FP-4031"),
    "create_subscription_on_starter_plan": (403, "FP-4031"),
    "create_third_endpoint_on_starter": (403, "FP-4031"),
    "configure_invalid_custom_retry": (403, "FP-4031"),
    "void_paid_invoice": (422, "FP-4221"),
    "send_request_with_malformed_key": (401, "FP-4011"),
    "retrieve_resource_from_wrong_environment": (404, "FP-4041"),
}


class SimulationEngine:
    """Executes compiled commands with a fixed logical clock."""

    def __init__(self, *, run_id: str, seed: int = 20260827):
        self.run_id = run_id
        self.seed = seed
        self.state = WorldState()
        self.now = datetime(2025, 9, 1, tzinfo=timezone.utc)
        self._event_sequence = 0
        self._request_counters: defaultdict[str, int] = defaultdict(int)
        self._attempt_counters: defaultdict[str, int] = defaultdict(int)
        self.current_scenario_id: str | None = None
        self.current_background_batch_id: str | None = None

    # 导出当前世界状态，供后续存储投影和不变量校验使用。
    def snapshot(self) -> WorldState:
        return deepcopy(self.state)

    # 集中生成领域事件，使状态演化具有对应的事件记录。
    def emit(
        self, event_type: str, aggregate_type: str, aggregate_id: str,
        payload: dict[str, Any], *, request_id: str | None = None,
        rule_ids: tuple[str, ...] = (), background_batch_id: str | None = None,
    ) -> None:
        self._event_sequence += 1
        self.state.events.append(DomainEvent(
            event_sequence=self._event_sequence,
            simulation_time=_iso(self.now),
            scenario_id=self.current_scenario_id,
            background_batch_id=background_batch_id or self.current_background_batch_id,
            aggregate_type=aggregate_type,
            aggregate_id=aggregate_id,
            event_type=event_type,
            payload=payload,
            caused_by_request_id=request_id,
            rule_ids=rule_ids,
        ))

    def run(self, commands: tuple[CompiledCommand, ...]) -> WorldState:
        for command in commands:
            at = _dt(command.at)
            if at < self.now:
                raise ValueError(f"clock moved backwards at {command.scenario_id}")
            self.now = at
            self.current_scenario_id = command.scenario_id
            self.state.scenario_executions.setdefault(command.scenario_id, {
                "scenario_id": command.scenario_id,
                "scenario_family_id": command.scenario_family_id,
                "split": command.split,
                "started_at": _iso(self.now),
                "completed_at": None,
                "status": "running",
                "command_count": 0,
            })["command_count"] += 1
            handler = getattr(self, f"_handle_{command.kind}", None)
            if handler is None:
                raise ValueError(f"unsupported command kind: {command.kind}")
            handler(command.params)
            if command.kind == "execute_scenario":
                execution = self.state.scenario_executions[command.scenario_id]
                execution["completed_at"] = _iso(self.now)
                execution["status"] = "completed"
        self.current_scenario_id = None
        return self.state

    def _handle_create_account(self, p: dict[str, Any]) -> None:
        account_id = p["account_id"]
        if not account_id:
            raise ValueError("scenario account_id is required")
        row = {
            "run_id": self.run_id, "account_id": account_id,
            "name": f"Benchmark Merchant {account_id}", "primary_region": p.get("region", "NA"),
            "default_api_version": p.get("default_api_version", "2026-07-01"),
            "production_status": "not_enabled", "current_plan": p.get("plan", "Growth"),
            "billing_cycle_anchor": _iso(self.now), "created_at": _iso(self.now), "updated_at": _iso(self.now),
        }
        self.state.accounts[account_id] = row
        self.emit("account.created", "account", account_id, row, rule_ids=("RULE-ENV-002",))

    def _handle_enable_production(self, p: dict[str, Any]) -> None:
        account = self.state.accounts[p["account_id"]]
        account["production_status"] = "active"
        account["updated_at"] = _iso(self.now)
        self.emit("account.production_enabled", "account", account["account_id"], {}, rule_ids=("RULE-ENV-003",))

    def _handle_create_api_key(self, p: dict[str, Any]) -> None:
        key_id = p["key_id"]
        environment = p["environment"]
        prefix = "sk_test_" if environment == "sandbox" else "sk_live_"
        row = {
            "run_id": self.run_id, "key_id": key_id, "account_id": p["account_id"],
            "environment": environment, "key_type": "secret", "key_prefix": prefix,
            "key_fingerprint": hashlib.sha256(key_id.encode()).hexdigest()[:24],
            "scopes_json": "[\"full\"]", "status": p.get("status", "active"),
            "created_at": _iso(self.now), "expires_at": None, "revoked_at": None,
            "replaced_by_key_id": None,
        }
        self.state.api_keys[key_id] = row
        self.emit("api_key.created", "api_key", key_id, {"environment": environment}, rule_ids=("RULE-AUTH-002",))

    def _handle_create_customer(self, p: dict[str, Any]) -> None:
        row = {
            "run_id": self.run_id, "customer_id": p["customer_id"], "account_id": p["account_id"],
            "environment": p["environment"], "email": p.get("email") or f"{p['customer_id']}@example.test",
            "name": f"Customer {p['customer_id']}", "metadata_json": "{}", "status": p.get("status", "active"),
            "created_at": _iso(self.now), "updated_at": _iso(self.now), "deleted_at": None,
        }
        self.state.customers[row["customer_id"]] = row
        self.emit("customer.created", "customer", row["customer_id"], {}, rule_ids=("RULE-CUSTOMER-001",))

    def _handle_set_feature_flag(self, p: dict[str, Any]) -> None:
        self._set_flag(p["account_id"], p["environment"], p["feature_name"], bool(p["enabled"]))

    def _handle_create_payment_fixture(self, p: dict[str, Any]) -> None:
        status = p["status"]
        row = {
            "run_id": self.run_id, "payment_id": p["payment_id"], "account_id": p["account_id"],
            "environment": p["environment"], "customer_id": p.get("customer_id"),
            "amount": p["amount"], "currency": p["currency"], "status": status,
            "api_version": p["api_version"], "payment_method_profile_id": "pm_profile_scenario",
            "failure_code": "FP-4021" if status == "failed" else None,
            "failure_category": "declined" if status == "failed" else None, "idempotency_key_hash": None,
            "created_by_request_id": None, "created_at": _iso(self.now), "updated_at": _iso(self.now),
            "succeeded_at": _iso(self.now) if status == "succeeded" else None,
            "terminal_at": _iso(self.now) if status in {"succeeded", "failed", "canceled"} else None,
        }
        self.state.payments[row["payment_id"]] = row
        self.emit("payment.created", "payment", row["payment_id"], {"status": status}, rule_ids=("RULE-PAY-001",))

    def _handle_create_refund_fixture(self, p: dict[str, Any]) -> None:
        row = {
            "run_id": self.run_id, "refund_id": p["refund_id"], "payment_id": p.get("payment_id"),
            "account_id": p["account_id"], "environment": p["environment"],
            "amount": p["amount"], "currency": p["currency"], "status": p["status"], "mode": "standard",
            "failure_code": None, "created_by_request_id": None,
            "created_at": _iso(self.now), "updated_at": _iso(self.now), "completed_at": None,
        }
        self.state.refunds[row["refund_id"]] = row
        self.emit("refund.created", "refund", row["refund_id"], {"status": row["status"]}, rule_ids=("RULE-REFUND-004",))

    def _handle_create_subscription_fixture(self, p: dict[str, Any]) -> None:
        row = {
            "run_id": self.run_id, "subscription_id": p["subscription_id"], "account_id": p["account_id"],
            "environment": p["environment"], "customer_id": p.get("customer_id"), "status": p["status"],
            "amount": p["amount"], "currency": p["currency"], "interval": "month",
            "trial_end_at": None, "cancel_at_period_end": 0, "current_period_start": _iso(self.now),
            "current_period_end": _iso(self.now + timedelta(days=30)),
            "created_at": _iso(self.now), "updated_at": _iso(self.now), "canceled_at": None,
        }
        self.state.subscriptions[row["subscription_id"]] = row
        self.emit("subscription.created", "subscription", row["subscription_id"], {"status": row["status"]}, rule_ids=("RULE-SUB-002",))

    def _handle_create_invoice_fixture(self, p: dict[str, Any]) -> None:
        row = {
            "run_id": self.run_id, "invoice_id": p["invoice_id"], "subscription_id": p.get("subscription_id"),
            "account_id": p["account_id"], "environment": p["environment"], "status": p["status"],
            "amount_due": p["amount_due"], "amount_paid": 0, "currency": p["currency"],
            "period_start": _iso(self.now - timedelta(days=30)), "period_end": _iso(self.now),
            "finalized_at": _iso(self.now), "paid_at": None,
        }
        self.state.invoices[row["invoice_id"]] = row
        self.emit("invoice.created", "invoice", row["invoice_id"], {"status": row["status"]}, rule_ids=("RULE-INVOICE-001",))

    def _handle_create_endpoint_fixture(self, p: dict[str, Any]) -> None:
        row = {
            "run_id": self.run_id, "endpoint_id": p["endpoint_id"], "account_id": p["account_id"],
            "environment": p["environment"], "url_host": "hooks.example.test", "url_path_hash": hashlib.sha256(p["endpoint_id"].encode()).hexdigest()[:16],
            "status": p["status"], "api_version": p["api_version"], "secret_version": 1,
            "secret_fingerprint": hashlib.sha256((p["endpoint_id"] + ":secret:1").encode()).hexdigest()[:24],
            "retry_policy_id": "default", "created_at": _iso(self.now), "updated_at": _iso(self.now), "disabled_at": None,
        }
        self.state.endpoints[row["endpoint_id"]] = row
        self.emit("webhook_endpoint.created", "webhook_endpoint", row["endpoint_id"], {}, rule_ids=("RULE-WEBHOOK-001",))

    def _handle_create_event_fixture(self, p: dict[str, Any]) -> None:
        row = {
            "run_id": self.run_id, "event_id": p["event_id"], "account_id": p["account_id"],
            "environment": p["environment"], "event_type": p["event_type"], "api_version": p["api_version"],
            "object_type": "payment" if str(p.get("object_id", "")).startswith("pay_") else "invoice",
            "object_id": p.get("object_id"), "occurred_at": _iso(self.now),
            "payload_hash": hashlib.sha256(json.dumps(p, sort_keys=True).encode()).hexdigest(), "caused_by_request_id": None,
        }
        self.state.business_events[row["event_id"]] = row
        self.emit("business_event.created", "event", row["event_id"], {"event_type": row["event_type"]}, rule_ids=("RULE-WEBHOOK-017",))

    def _handle_create_delivery_fixture(self, p: dict[str, Any]) -> None:
        row = {
            "run_id": self.run_id, "delivery_id": p["delivery_id"], "event_id": p.get("event_id"),
            "endpoint_id": p.get("endpoint_id"), "status": p["status"], "attempt_count": 0,
            "first_attempt_at": None, "last_attempt_at": None, "next_attempt_at": None,
            "delivered_at": None, "terminal_reason": None,
        }
        self.state.deliveries[row["delivery_id"]] = row
        self.emit("webhook_delivery.created", "webhook_delivery", row["delivery_id"], {}, rule_ids=("RULE-WEBHOOK-005",))

    def _handle_create_incident_fixture(self, p: dict[str, Any]) -> None:
        row = {
            "schema_version": "1.0", "run_id": self.run_id,
            "evidence_id": f"runtime:incident:{p['incident_id']}", "incident_id": p["incident_id"],
            "service": p["service"], "region": p["region"], "status": p["status"],
            "started_at": _iso(self.now), "identified_at": _iso(self.now + timedelta(minutes=2)),
            "resolved_at": None, "impact": "elevated_errors", "affected_error_codes": ["FP-5031"],
            "timeline": [{"at": _iso(self.now), "status": p["status"]}],
        }
        self.state.service_incidents.append(row)
        self.emit("service_incident.started", "service_incident", p["incident_id"], {"region": p["region"]}, rule_ids=("RULE-ERROR-003",))

    def _request_id(self, ids: dict[str, str], mode: str) -> str:
        if ids.get("request") and self._request_counters[mode] == 0:
            request_id = ids["request"]
        else:
            mode_tag = hashlib.sha256(mode.encode()).hexdigest()[:10]
            request_id = f"req_{mode_tag}_{self._request_counters[mode] + 1:06d}"
        self._request_counters[mode] += 1
        return request_id

    def record_request(
        self, *, ids: dict[str, str], mode: str, account: dict[str, Any],
        http_status: int = 200, error_code: str | None = None,
        route: str = "/v1/scenario", method: str = "POST", retry_parent: str | None = None,
        response_object_type: str | None = None, response_object_id: str | None = None,
        at: datetime | None = None, api_version: str | None = None,
        request_details: dict[str, Any] | None = None,
    ) -> str:
        request_id = self._request_id(ids, mode)
        started = at or self.now
        latency = 25 + (int(hashlib.sha256(request_id.encode()).hexdigest()[:4], 16) % 175)
        row = {
            "schema_version": "1.0", "run_id": self.run_id,
            "evidence_id": f"runtime:req:{request_id}", "request_id": request_id,
            "account_id": ids.get("account"), "environment": account.get("environment", "production"),
            "api_version": api_version or account.get("default_api_version", "2026-07-01"),
            "method": method, "route": route,
            "started_at": _iso(started), "completed_at": _iso(started + timedelta(milliseconds=latency)),
            "latency_ms": latency, "http_status": http_status, "error_code": error_code,
            "service": "payments" if "payment" in route else "api", "region": account.get("region", "NA"),
            "idempotency_key_hash": None, "retry_parent_request_id": retry_parent,
            "response_object_type": response_object_type, "response_object_id": response_object_id,
            "request_details": request_details or {},
            "scenario_id": self.current_scenario_id,
        }
        self.state.api_requests.append(row)
        self.emit("api_request.completed", "api_request", request_id, {
            "http_status": http_status, "error_code": error_code, "route": route,
        }, request_id=request_id, rule_ids=("RULE-REQ-001",))
        return request_id

    # 支付状态变化通过统一入口处理，以维持相关事件和实体的一致性。
    def transition_payment(self, payment_id: str, status: str, *, failure_code: str | None = None) -> None:
        payment = self.state.payments[payment_id]
        old = payment["status"]
        allowed = {
            "requires_action": {"processing", "canceled"},
            "processing": {"succeeded", "failed"},
        }
        if old in {"succeeded", "failed", "canceled"} or status not in allowed.get(old, set()):
            raise ValueError(f"invalid payment transition {old} -> {status}")
        payment["status"] = status
        payment["updated_at"] = _iso(self.now)
        payment["failure_code"] = failure_code
        payment["failure_category"] = failure_code
        if status == "succeeded":
            payment["succeeded_at"] = _iso(self.now)
        if status in {"succeeded", "failed", "canceled"}:
            payment["terminal_at"] = _iso(self.now)
        self.emit("payment.status_changed", "payment", payment_id, {"from": old, "to": status}, rule_ids=("RULE-PAY-001",))

    def record_delivery_attempt(
        self, delivery_id: str, *, http_status: int | None, response_kind: str,
        secret_version: int = 1, at: datetime | None = None,
        signature_timestamp: datetime | None = None,
        verification_details: dict[str, Any] | None = None,
    ) -> None:
        delivery = self.state.deliveries[delivery_id]
        endpoint = self.state.endpoints.get(delivery["endpoint_id"], {})
        self._attempt_counters[delivery_id] += 1
        number = self._attempt_counters[delivery_id]
        attempted = at or self.now
        attempt_id = f"att_{delivery_id.removeprefix('del_')}_{number:02d}"
        success = http_status is not None and 200 <= http_status <= 299
        is_gone = http_status == 410
        resulting = "delivered" if success else ("canceled" if is_gone else "retrying")
        row = {
            "schema_version": "1.0", "run_id": self.run_id,
            "evidence_id": f"runtime:attempt:{attempt_id}", "attempt_id": attempt_id,
            "delivery_id": delivery_id, "event_id": delivery["event_id"], "endpoint_id": delivery["endpoint_id"],
            "attempt_number": number, "attempted_at": _iso(attempted), "latency_ms": 40 + number * 7,
            "response_kind": response_kind, "http_status": http_status,
            "error_code": None if success else "delivery_failed", "secret_version": secret_version,
            "signature_timestamp": _iso(signature_timestamp or attempted), "next_retry_at": None,
            "verification_details": verification_details or {},
            "resulting_delivery_status": resulting, "scenario_id": self.current_scenario_id,
        }
        delivery["attempt_count"] = number
        delivery["first_attempt_at"] = delivery["first_attempt_at"] or _iso(attempted)
        delivery["last_attempt_at"] = _iso(attempted)
        delivery["status"] = resulting
        if success:
            delivery["delivered_at"] = _iso(attempted)
        elif is_gone and endpoint:
            endpoint["status"] = "disabled"
            endpoint["disabled_at"] = _iso(attempted)
            endpoint["updated_at"] = _iso(attempted)
        else:
            next_retry = attempted + timedelta(minutes=1)
            delivery["next_attempt_at"] = _iso(next_retry)
            row["next_retry_at"] = _iso(next_retry)
        self.state.delivery_attempts.append(row)
        self.emit("webhook_delivery.attempted", "webhook_delivery", delivery_id, {
            "attempt_number": number, "http_status": http_status, "result": resulting,
        }, rule_ids=("RULE-WEBHOOK-006", "RULE-WEBHOOK-008"))

    def _handle_execute_scenario(self, p: dict[str, Any]) -> None:
        mode = p["mode"]
        ids = p["ids"]
        account = p["account"]
        status, error = ERROR_BY_MODE.get(mode, (200, None))
        route = "/v1/payments" if ids.get("payment") else "/v1/scenario"
        request_details: dict[str, Any] = {}
        if mode in {
            "refund_processing_payment", "create_partial_refund_on_starter",
            "overbook_refund_while_pending", "refund_payment_after_181_days",
            "create_eligible_instant_refund", "create_instant_refund_in_apac",
        }:
            route = "/v1/refunds"
            request_details = {
                "payment_id": ids.get("payment"), "refund_id": ids.get("refund"),
                "mode": "instant" if "instant_refund" in mode else "standard",
            }
        elif mode in {"confirm_succeeded_payment", "confirm_action_required_payment"}:
            route = f"/v1/payments/{ids.get('payment')}/confirm"
            request_details = {"payment_id": ids.get("payment")}
        elif mode == "create_payment_for_deleted_customer":
            route = "/v1/payments"
            request_details = {"customer_id": ids.get("customer")}
        elif mode in {"void_paid_invoice", "void_open_invoice"}:
            route = f"/v1/invoices/{ids.get('invoice')}/void"
            request_details = {"invoice_id": ids.get("invoice")}

        if mode == "retrieve_cross_tenant_payment" and ids.get("payment"):
            # Preserve that the resource exists while making it invisible to the caller's tenant scope.
            self.state.payments[ids["payment"]]["account_id"] = "acct_external_tenant"
        elif mode == "suspend_production_and_send_requests":
            self.state.accounts[ids["account"]]["production_status"] = "suspended"
        elif mode == "upgrade_plan_then_create_subscription":
            self._plan_change(ids["account"], "Starter", "Growth", immediate=True)
        elif mode == "request_plan_downgrade_then_create_endpoint":
            self._plan_change(ids["account"], "Scale", "Starter", immediate=False)
        elif mode == "rotate_api_key_with_overlap":
            old = self.state.api_keys[ids["key"]]
            old["status"] = "expiring"
            old["expires_at"] = _iso(self.now + timedelta(hours=24))
            new_id = _derived(ids["key"], "new")
            self._handle_create_api_key({**old, "key_id": new_id, "status": "active"})
            old["replaced_by_key_id"] = new_id
        elif mode == "revoke_key_then_reuse":
            key = self.state.api_keys[ids["key"]]
            key["status"] = "revoked"
            key["revoked_at"] = _iso(self.now)
        elif mode in {"soft_delete_customer_with_history", "create_payment_for_deleted_customer"}:
            customer = self.state.customers[ids["customer"]]
            customer["status"] = "deleted"
            customer["deleted_at"] = _iso(self.now)
            customer["updated_at"] = _iso(self.now)
        elif mode == "confirm_action_required_payment":
            self.transition_payment(ids["payment"], "processing")
            self.transition_payment(ids["payment"], "succeeded")
        elif mode == "retry_failed_payment_in_place":
            original = self.state.payments[ids["payment"]]
            new_id = _derived(ids["payment"], "retry")
            self._handle_create_payment_fixture({
                **original, "payment_id": new_id, "status": "processing",
            })
            self.transition_payment(new_id, "succeeded")
        elif mode == "compare_action_required_versions" or mode == "compare_action_required_clients":
            payment = self.state.payments[ids["payment"]]
            payment["status"] = "requires_action"
            other = _derived(ids["payment"], "old")
            self._handle_create_payment_fixture({**payment, "payment_id": other, "status": "failed"})
            self.state.payments[other]["failure_code"] = "FP-4023"
        elif mode == "fail_pending_refund_and_release_amount" and ids.get("refund"):
            refund = self.state.refunds[ids["refund"]]
            refund["status"] = "failed"
            refund["completed_at"] = _iso(self.now)
            payment = self.state.payments[ids["payment"]]
            payment["refund_reserved"] = 0
            payment["refundable_amount"] = payment["amount"]
            payment["updated_at"] = _iso(self.now)
        elif mode == "overbook_refund_while_pending" and ids.get("refund"):
            refund = self.state.refunds[ids["refund"]]
            refund["amount"] = 6000
            refund["status"] = "pending"
            refund["updated_at"] = _iso(self.now)
            payment = self.state.payments[ids["payment"]]
            payment["refund_reserved"] = 6000
            payment["refundable_amount"] = payment["amount"] - 6000
            payment["updated_at"] = _iso(self.now)
        elif mode == "create_multiple_partial_refunds" and ids.get("refund"):
            second = self.state.refunds[ids["refund"]]
            second["amount"] = 3000
            second["status"] = "pending"
            second["updated_at"] = _iso(self.now)
            first_id = _derived(ids["refund"], "first")
            self._handle_create_refund_fixture({
                **second, "refund_id": first_id, "amount": 2000, "status": "succeeded",
            })
            self.state.refunds[first_id]["completed_at"] = _iso(self.now - timedelta(minutes=1))
        elif mode == "create_eligible_instant_refund" and ids.get("refund"):
            refund = self.state.refunds[ids["refund"]]
            refund["mode"] = "instant"
            refund["status"] = "succeeded"
            refund["completed_at"] = _iso(self.now)
            self._set_flag(ids["account"], account["environment"], "instant_refund", True)
        elif mode in {"create_instant_refund_in_apac", "exercise_instant_refund_conditions"}:
            self._set_flag(ids["account"], account["environment"], "instant_refund", True)
        elif mode == "cancel_subscription_at_period_end":
            self.state.subscriptions[ids["subscription"]]["cancel_at_period_end"] = 1
        elif mode == "cancel_subscription_immediately_then_restore":
            sub = self.state.subscriptions[ids["subscription"]]
            sub["status"] = "canceled"
            sub["canceled_at"] = _iso(self.now)
        elif mode.startswith("invoice_retry_") or mode == "exhaust_invoice_retries":
            self._run_invoice_scenario(mode, ids)
        elif mode == "void_open_invoice":
            self.state.invoices[ids["invoice"]]["status"] = "void"
        elif mode == "void_paid_invoice":
            self.state.invoices[ids["invoice"]]["status"] = "paid"
            self.state.invoices[ids["invoice"]]["amount_paid"] = self.state.invoices[ids["invoice"]]["amount_due"]
            self.state.invoices[ids["invoice"]]["paid_at"] = _iso(self.now - timedelta(minutes=1))
        elif mode == "apply_endpoint_restrictions_after_downgrade":
            keep_ids = {
                f"we_{ids['account'].removeprefix('acct_')}_existing_1",
                f"we_{ids['account'].removeprefix('acct_')}_existing_2",
            }
            for endpoint in self.state.endpoints.values():
                if endpoint["account_id"] == ids["account"] and endpoint["endpoint_id"] not in keep_ids:
                    endpoint["status"] = "restricted"
                    endpoint["updated_at"] = _iso(self.now)
            self._plan_change(ids["account"], "Growth", "Starter", immediate=True)
        elif mode == "emit_event_to_disabled_endpoint":
            self.state.endpoints[ids["endpoint"]]["status"] = "disabled"
            self.state.deliveries.pop(ids.get("delivery"), None)
        elif mode in {"emit_unsubscribed_payment_event", "emit_versioned_payment_success_event"}:
            self.state.deliveries.pop(ids.get("delivery"), None)
            event_type = "payment.succeeded" if mode == "emit_versioned_payment_success_event" else "payment.succeeded"
            if ids.get("event") in self.state.business_events:
                self.state.business_events[ids["event"]]["event_type"] = event_type
        elif mode == "generate_scheduled_invoice_event" and ids.get("event"):
            self.state.business_events[ids["event"]]["api_version"] = "2026-04-01"
            self.state.business_events[ids["event"]]["event_type"] = "invoice.created"

        if mode in {"send_sandbox_rate_burst", "send_growth_sustained_rate_burst", "trigger_immediate_retry_storm"}:
            self._run_rate_scenario(mode, ids, account)
            return

        if mode == "emit_webhooks_alongside_api_usage":
            self._run_webhook_excluded_rate(ids, account)
            return

        if mode in {
            "replay_idempotent_payment_request", "reuse_idempotency_key_with_changed_amount",
            "reuse_idempotency_key_after_expiry",
        }:
            self._run_idempotency_scenario(mode, ids, account)
            return

        if mode == "submit_payment_amount_boundaries":
            self.record_request(ids=ids, mode=mode, account=account, http_status=400, error_code="FP-4001", route="/v1/payments", at=self.now - timedelta(seconds=1))
            self.record_request(ids=ids, mode=mode, account=account, http_status=400, error_code="FP-4001", route="/v1/payments")
            return

        if mode in {"compare_action_required_versions", "compare_action_required_clients"}:
            old_id = _derived(ids.get("payment"), "old")
            self.record_request(
                ids=ids, mode=mode, account=account, http_status=402, error_code="FP-4023",
                route="/v1/payments", api_version="2026-04-01",
                response_object_type="payment", response_object_id=old_id,
                at=self.now - timedelta(seconds=1),
                request_details={"representation": "legacy_failed", "payment_id": old_id},
            )
            next_ids = dict(ids)
            next_ids.pop("request", None)
            self.record_request(
                ids=next_ids, mode=mode, account=account, http_status=200,
                route="/v1/payments", api_version="2026-07-01",
                response_object_type="payment", response_object_id=ids.get("payment"),
                request_details={"representation": "requires_action", "payment_id": ids.get("payment")},
            )
            return

        if mode == "soft_delete_customer_with_history":
            self.record_request(
                ids=ids, mode=mode, account=account, http_status=200,
                method="DELETE", route=f"/v1/customers/{ids['customer']}",
                response_object_type="customer", response_object_id=ids["customer"],
            )
            return

        if mode == "retry_failed_payment_in_place":
            retry_id = _derived(ids.get("payment"), "retry")
            self.record_request(
                ids=ids, mode=mode, account=account, http_status=200, route="/v1/payments",
                response_object_type="payment", response_object_id=retry_id,
                request_details={"retry_of_payment_id": ids.get("payment")},
            )
            return

        if mode == "exercise_instant_refund_conditions":
            self.state.payments[ids["payment"]]["amount"] = 200000
            first = self.record_request(
                ids=ids, mode=mode, account=account, http_status=403, error_code="FP-4031",
                route="/v1/refunds", request_details={"mode": "instant", "amount": 50000, "instant_refund_flag": False},
                at=self.now - timedelta(seconds=1),
            )
            next_ids = dict(ids)
            next_ids.pop("request", None)
            self.record_request(
                ids=next_ids, mode=mode, account=account, http_status=403, error_code="FP-4031",
                route="/v1/refunds", retry_parent=first,
                request_details={"mode": "instant", "amount": 120000, "instant_refund_flag": True},
            )
            return

        if mode == "exercise_subscription_trial_bounds":
            first = self.record_request(
                ids=ids, mode=mode, account=account, http_status=400, error_code="FP-4001",
                route="/v1/subscriptions", request_details={"trial_days": 31},
                at=self.now - timedelta(seconds=1),
            )
            next_ids = dict(ids)
            next_ids.pop("request", None)
            self.record_request(
                ids=next_ids, mode=mode, account=account, http_status=400, error_code="FP-4001",
                method="PATCH", route=f"/v1/subscriptions/{ids['subscription']}", retry_parent=first,
                request_details={"trial_days": 14, "operation": "append_trial_after_creation"},
            )
            return

        if mode == "cancel_subscription_immediately_then_restore":
            first = self.record_request(
                ids=ids, mode=mode, account=account, http_status=200,
                route=f"/v1/subscriptions/{ids['subscription']}/cancel",
                response_object_type="subscription", response_object_id=ids["subscription"],
                request_details={"immediate": True}, at=self.now - timedelta(seconds=1),
            )
            next_ids = dict(ids)
            next_ids.pop("request", None)
            self.record_request(
                ids=next_ids, mode=mode, account=account, http_status=422, error_code="FP-4221",
                method="PATCH", route=f"/v1/subscriptions/{ids['subscription']}", retry_parent=first,
                request_details={"status": "active", "operation": "restore_canceled_subscription"},
            )
            return

        if mode == "change_subscription_customer_and_currency":
            self.record_request(
                ids=ids, mode=mode, account=account, http_status=400, error_code="FP-4001",
                method="PATCH", route=f"/v1/subscriptions/{ids['subscription']}",
                request_details={"customer_id": _derived(ids.get("customer"), "other"), "currency": "CAD"},
            )
            return

        if mode == "configure_invalid_custom_retry":
            first = self.record_request(
                ids=ids, mode=mode, account=account, http_status=400, error_code="FP-4001",
                method="PATCH", route=f"/v1/webhook_endpoints/{ids['endpoint']}",
                request_details={"retry_count": 9, "retry_window_hours": 48},
                at=self.now - timedelta(seconds=1),
            )
            next_ids = dict(ids)
            next_ids.pop("request", None)
            self.record_request(
                ids=next_ids, mode=mode, account=account, http_status=400, error_code="FP-4001",
                method="PATCH", route=f"/v1/webhook_endpoints/{ids['endpoint']}", retry_parent=first,
                request_details={"retry_count": 8, "retry_window_hours": 80},
            )
            return

        if mode == "emit_internal_error_then_regional_incident":
            self.record_request(
                ids=ids, mode=mode, account=account, http_status=500, error_code="FP-5001",
                route="/v1/payments", at=self.now - timedelta(minutes=3),
            )
            for offset in (0, 10, 20):
                next_ids = dict(ids)
                next_ids.pop("request", None)
                self.record_request(
                    ids=next_ids, mode=mode, account=account, http_status=503, error_code="FP-5031",
                    route="/v1/payments", at=self.now + timedelta(seconds=offset),
                )
            return

        if mode == "query_runtime_outside_retention":
            self.record_request(
                ids=ids, mode=mode, account=account, http_status=200,
                route="/v1/payments", at=self.now - timedelta(days=20),
                request_details={"historical_request": True},
            )
            return

        if mode in {
            "deliver_webhook_with_204", "deliver_webhook_with_redirect", "deliver_webhook_with_400",
            "deliver_webhook_with_410", "exhaust_default_webhook_retries", "redeliver_same_webhook_event",
            "verify_signature_with_old_header", "verify_stale_webhook_signature",
            "rotate_signing_secret_then_deliver", "retry_webhook_after_secret_rotation",
            "complete_payment_with_webhook_retry",
        }:
            self._run_webhook_scenario(mode, ids)

        if mode == "run_regional_payments_incident" or mode == "emit_internal_error_then_regional_incident":
            status, error = (503, "FP-5031")

        request_id = self.record_request(
            ids=ids, mode=mode, account=account, http_status=status, error_code=error, route=route,
            response_object_type="payment" if ids.get("payment") and status < 400 else None,
            response_object_id=ids.get("payment") if status < 400 else None,
            request_details=request_details,
        )
        if ids.get("payment") in self.state.payments:
            payment = self.state.payments[ids["payment"]]
            payment["created_by_request_id"] = payment["created_by_request_id"] or request_id
            if error in {"FP-4021", "FP-4022", "FP-4024"}:
                payment["status"] = "failed"
                payment["failure_code"] = error
                payment["failure_category"] = error
                payment["terminal_at"] = _iso(self.now)

    def _plan_change(self, account_id: str, old: str, new: str, *, immediate: bool) -> None:
        change_id = f"pc_{account_id.removeprefix('acct_')}_{len(self.state.plan_changes) + 1:02d}"
        effective = self.now if immediate else self.now + timedelta(days=15)
        self.state.plan_changes[change_id] = {
            "run_id": self.run_id, "plan_change_id": change_id, "account_id": account_id,
            "from_plan": old, "to_plan": new, "requested_at": _iso(self.now),
            "effective_at": _iso(effective), "status": "effective" if immediate else "scheduled",
        }
        if immediate:
            self.state.accounts[account_id]["current_plan"] = new
        self.emit("account.plan_change_requested", "account", account_id, {"to_plan": new, "effective_at": _iso(effective)}, rule_ids=("RULE-PLAN-002",))

    def _set_flag(self, account_id: str, environment: str, name: str, enabled: bool) -> None:
        key = f"{account_id}:{environment}:{name}"
        self.state.feature_flags[key] = {
            "run_id": self.run_id, "account_id": account_id, "environment": environment,
            "feature_name": name, "enabled": int(enabled), "effective_at": _iso(self.now), "updated_at": _iso(self.now),
        }
        self.emit("feature_flag.updated", "account", account_id, {"feature": name, "enabled": enabled}, rule_ids=("RULE-PLAN-001",))

    def _run_rate_scenario(self, mode: str, ids: dict[str, str], account: dict[str, Any]) -> None:
        counts = {"send_sandbox_rate_burst": 200, "send_growth_sustained_rate_burst": 1420, "trigger_immediate_retry_storm": 1600}[mode]
        threshold = 120 if mode == "send_sandbox_rate_burst" else 1200
        root: str | None = None
        for index in range(counts):
            limited = index >= threshold
            parent = root if mode == "trigger_immediate_retry_storm" and index > 60 else None
            request_id = self.record_request(
                ids=ids, mode=mode, account=account, http_status=429 if limited else 200,
                error_code="FP-4291" if limited else None, route="/v1/payments", retry_parent=parent,
                at=self.now + timedelta(milliseconds=index * 30),
            )
            root = root or request_id

    def _run_idempotency_scenario(self, mode: str, ids: dict[str, str], account: dict[str, Any]) -> None:
        payment_id = ids.get("payment")
        if mode == "reuse_idempotency_key_with_changed_amount" and payment_id in self.state.payments:
            self.state.payments[payment_id]["amount"] = 5000
        first_at = self.now - timedelta(hours=25) if mode == "reuse_idempotency_key_after_expiry" else self.now - timedelta(seconds=2)
        first = self.record_request(
            ids=ids, mode=mode, account=account, http_status=200, route="/v1/payments",
            response_object_type="payment", response_object_id=payment_id, at=first_at,
            request_details={
                "amount": 5000 if mode == "reuse_idempotency_key_with_changed_amount"
                else self.state.payments.get(payment_id, {}).get("amount")
            },
        )
        if mode == "reuse_idempotency_key_with_changed_amount":
            self.record_request(
                ids=ids, mode=mode, account=account, http_status=409, error_code="FP-4091",
                route="/v1/payments", retry_parent=first, at=self.now,
                request_details={"amount": 7000},
            )
        elif mode == "reuse_idempotency_key_after_expiry":
            second_payment = _derived(payment_id, "after_24h")
            if payment_id in self.state.payments:
                original = self.state.payments[payment_id]
                self._handle_create_payment_fixture({**original, "payment_id": second_payment, "status": "processing"})
            self.record_request(
                ids=ids, mode=mode, account=account, http_status=200, route="/v1/payments",
                response_object_type="payment", response_object_id=second_payment, at=self.now,
            )
        else:
            self.record_request(
                ids=ids, mode=mode, account=account, http_status=200, route="/v1/payments",
                retry_parent=first, response_object_type="payment", response_object_id=payment_id, at=self.now,
            )

    def _run_webhook_excluded_rate(self, ids: dict[str, str], account: dict[str, Any]) -> None:
        for index in range(900):
            request_ids = dict(ids)
            if index:
                request_ids.pop("request", None)
            self.record_request(
                ids=request_ids, mode="webhook_excluded_api_usage", account=account,
                http_status=200, route="/v1/customers", at=self.now + timedelta(milliseconds=index * 60),
            )
        endpoint_id = ids["endpoint"]
        for index in range(700):
            if index == 0:
                event_id = ids["event"]
                delivery_id = ids["delivery"]
            else:
                event_id = f"evt_{ids['account'].removeprefix('acct_')}_rate_{index:04d}"
                delivery_id = f"del_{ids['account'].removeprefix('acct_')}_rate_{index:04d}"
                self._handle_create_event_fixture({
                    "event_id": event_id, "account_id": ids["account"],
                    "environment": account["environment"], "object_id": None,
                    "api_version": account["default_api_version"], "event_type": "payment.succeeded",
                })
                self._handle_create_delivery_fixture({
                    "delivery_id": delivery_id, "event_id": event_id, "endpoint_id": endpoint_id, "status": "pending",
                })
            self.record_delivery_attempt(
                delivery_id, http_status=204, response_kind="http",
                at=self.now + timedelta(milliseconds=index * 70),
            )

    def _run_invoice_scenario(self, mode: str, ids: dict[str, str]) -> None:
        invoice = self.state.invoices[ids["invoice"]]
        sub = self.state.subscriptions[ids["subscription"]]
        success_attempt = {"invoice_retry_succeeds_on_day1": 1, "invoice_retry_succeeds_on_day3": 2}.get(mode)
        max_attempt = 3 if success_attempt is None else success_attempt
        sub["status"] = "past_due"
        for number in range(max_attempt + 1):
            pay_id = ids.get("payment") if number == 0 and ids.get("payment") else f"pay_{ids['invoice'].removeprefix('in_')}_attempt_{number}"
            if pay_id not in self.state.payments:
                self._handle_create_payment_fixture({
                    "payment_id": pay_id, "account_id": invoice["account_id"], "environment": invoice["environment"],
                    "customer_id": sub.get("customer_id"), "status": "processing", "api_version": "2026-07-01",
                    "amount": invoice["amount_due"], "currency": invoice["currency"],
                })
            outcome = "succeeded" if success_attempt == number else "failed"
            payment = self.state.payments[pay_id]
            if payment["status"] == "processing":
                self.transition_payment(pay_id, outcome, failure_code="FP-4021" if outcome == "failed" else None)
            attempt_id = f"{ids['invoice']}:{number}"
            self.state.invoice_attempts[attempt_id] = {
                "run_id": self.run_id, "invoice_id": ids["invoice"], "attempt_number": number,
                "payment_id": pay_id, "scheduled_at": _iso(self.now + timedelta(days=(0, 1, 3, 7)[number])),
                "executed_at": _iso(self.now + timedelta(days=(0, 1, 3, 7)[number])), "outcome": outcome,
            }
        if success_attempt is not None:
            invoice["status"] = "paid"
            invoice["amount_paid"] = invoice["amount_due"]
            invoice["paid_at"] = _iso(self.now + timedelta(days=(1, 3)[success_attempt - 1]))
            sub["status"] = "active"
        else:
            invoice["status"] = "uncollectible"
            sub["status"] = "canceled"
            sub["canceled_at"] = _iso(self.now + timedelta(days=7))

    def _run_webhook_scenario(self, mode: str, ids: dict[str, str]) -> None:
        delivery_id = ids.get("delivery")
        if not delivery_id or delivery_id not in self.state.deliveries:
            return
        if mode == "deliver_webhook_with_204":
            self.record_delivery_attempt(delivery_id, http_status=204, response_kind="http")
        elif mode == "deliver_webhook_with_redirect":
            self.record_delivery_attempt(delivery_id, http_status=302, response_kind="http")
        elif mode == "deliver_webhook_with_400":
            self.record_delivery_attempt(delivery_id, http_status=400, response_kind="http")
        elif mode == "deliver_webhook_with_410":
            self.record_delivery_attempt(delivery_id, http_status=410, response_kind="http")
        elif mode == "exhaust_default_webhook_retries":
            offsets = (0, 1, 5, 30, 120, 480, 1440)
            for minutes in offsets:
                self.record_delivery_attempt(delivery_id, http_status=500, response_kind="http", at=self.now + timedelta(minutes=minutes))
            delivery = self.state.deliveries[delivery_id]
            delivery["status"] = "exhausted"
            delivery["terminal_reason"] = "retry_exhausted"
        elif mode == "redeliver_same_webhook_event":
            self.record_delivery_attempt(delivery_id, http_status=500, response_kind="timeout")
            self.record_delivery_attempt(delivery_id, http_status=200, response_kind="http", at=self.now + timedelta(minutes=1))
        elif mode == "rotate_signing_secret_then_deliver":
            endpoint = self.state.endpoints[ids["endpoint"]]
            endpoint["secret_version"] = 2
            self.record_delivery_attempt(delivery_id, http_status=401, response_kind="http", secret_version=2)
        elif mode == "retry_webhook_after_secret_rotation":
            self.record_delivery_attempt(delivery_id, http_status=500, response_kind="http", secret_version=1)
            endpoint = self.state.endpoints[ids["endpoint"]]
            endpoint["secret_version"] = 2
            self.record_delivery_attempt(delivery_id, http_status=200, response_kind="http", secret_version=2, at=self.now + timedelta(minutes=1))
        elif mode == "complete_payment_with_webhook_retry":
            self.record_delivery_attempt(delivery_id, http_status=500, response_kind="http")
            self.record_delivery_attempt(delivery_id, http_status=204, response_kind="http", at=self.now + timedelta(minutes=1))
        elif mode == "verify_signature_with_old_header":
            self.record_delivery_attempt(
                delivery_id, http_status=400, response_kind="signature_error",
                verification_details={
                    "sent_header": "FlowPay-Signature",
                    "client_expected_header": "X-FlowPay-Signature",
                    "client_error": "header_missing",
                },
            )
        elif mode == "verify_stale_webhook_signature":
            self.record_delivery_attempt(
                delivery_id, http_status=400, response_kind="signature_error",
                signature_timestamp=self.now - timedelta(minutes=8),
                verification_details={"verification_time": _iso(self.now), "timestamp_skew_seconds": 480},
            )
        else:
            self.record_delivery_attempt(delivery_id, http_status=400, response_kind="signature_error")
