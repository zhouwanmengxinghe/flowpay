# FlowPay 确定性业务数据模拟器；与教学后端保持独立包结构。
"""FlowPay deterministic benchmark simulator."""

__version__ = "0.1.0"

