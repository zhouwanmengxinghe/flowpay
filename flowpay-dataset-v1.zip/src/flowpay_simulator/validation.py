# 检查模拟世界的业务不变量，发现跨实体状态不一致时报告违规。
from __future__ import annotations

from collections import Counter
import re
from typing import Any

from .engine import WorldState


class InvariantViolation(ValueError):
    pass


def validate_state(state: WorldState, *, expected_scenarios: int = 75) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []

    def check(name: str, condition: bool, detail: str) -> None:
        checks.append({"name": name, "passed": bool(condition), "detail": detail})

    request_ids = [row["request_id"] for row in state.api_requests]
    attempt_ids = [row["attempt_id"] for row in state.delivery_attempts]
    check("scenario_count", len(state.scenario_executions) == expected_scenarios, f"actual={len(state.scenario_executions)}")
    check(
        "scenarios_completed",
        all(row["status"] == "completed" for row in state.scenario_executions.values()),
        "all scenario executions must be completed",
    )
    check("request_ids_unique", len(request_ids) == len(set(request_ids)), f"count={len(request_ids)}")
    check("attempt_ids_unique", len(attempt_ids) == len(set(attempt_ids)), f"count={len(attempt_ids)}")
    check("event_sequence_contiguous", [e.event_sequence for e in state.events] == list(range(1, len(state.events) + 1)), f"events={len(state.events)}")

    tenant_mismatches = []
    for payment in state.payments.values():
        customer_id = payment.get("customer_id")
        if customer_id and customer_id in state.customers:
            customer = state.customers[customer_id]
            if (payment["account_id"], payment["environment"]) != (customer["account_id"], customer["environment"]):
                tenant_mismatches.append(payment["payment_id"])
    check("payment_customer_tenant_environment", not tenant_mismatches, f"mismatches={tenant_mismatches[:5]}")

    refund_overages = []
    reserved = Counter()
    for refund in state.refunds.values():
        if refund["status"] in {"pending", "succeeded"} and refund.get("payment_id"):
            reserved[refund["payment_id"]] += refund["amount"]
    for payment_id, amount in reserved.items():
        payment = state.payments.get(payment_id)
        if payment and amount > payment["amount"]:
            refund_overages.append({"payment_id": payment_id, "reserved": amount, "amount": payment["amount"]})
    check("refund_amount_not_exceeded", not refund_overages, f"overages={refund_overages[:5]}")

    bad_terminal = []
    for payment in state.payments.values():
        if payment["status"] in {"succeeded", "failed", "canceled"} and not payment.get("terminal_at"):
            bad_terminal.append(payment["payment_id"])
    check("payment_terminal_timestamp", not bad_terminal, f"missing={bad_terminal[:5]}")

    starter_subscriptions = [
        row["subscription_id"] for row in state.subscriptions.values()
        if state.accounts.get(row["account_id"], {}).get("current_plan") == "Starter"
    ]
    check("starter_has_no_subscriptions", not starter_subscriptions, f"violations={starter_subscriptions[:5]}")

    endpoint_limits = {"Starter": 2, "Growth": 5, "Scale": 15}
    enabled_endpoints = Counter(
        row["account_id"] for row in state.endpoints.values() if row["status"] == "enabled"
    )
    endpoint_overages = [
        {"account_id": account_id, "count": count, "limit": endpoint_limits[state.accounts[account_id]["current_plan"]]}
        for account_id, count in enabled_endpoints.items()
        if count > endpoint_limits[state.accounts[account_id]["current_plan"]]
    ]
    check("webhook_endpoint_plan_limits", not endpoint_overages, f"overages={endpoint_overages[:5]}")

    invalid_live_keys = [
        row["key_id"] for row in state.api_keys.values()
        if row["environment"] == "production"
        and state.accounts.get(row["account_id"], {}).get("production_status") == "not_enabled"
    ]
    check("production_key_requires_enablement", not invalid_live_keys, f"violations={invalid_live_keys[:5]}")

    orphan_deliveries = [
        row["delivery_id"] for row in state.deliveries.values()
        if row.get("event_id") not in state.business_events or row.get("endpoint_id") not in state.endpoints
    ]
    check("delivery_references", not orphan_deliveries, f"orphans={orphan_deliveries[:5]}")

    attempts_by_delivery = Counter(row["delivery_id"] for row in state.delivery_attempts)
    mismatch_attempt_counts = [
        delivery_id for delivery_id, delivery in state.deliveries.items()
        if delivery["attempt_count"] != attempts_by_delivery[delivery_id]
    ]
    check("delivery_attempt_counts", not mismatch_attempt_counts, f"mismatches={mismatch_attempt_counts[:5]}")

    secrets = []
    secret_pattern = re.compile(r"\bsk_(?:live|test)_[A-Za-z0-9]{8,}\b")
    for row in state.api_requests:
        serialized = str(row)
        if secret_pattern.search(serialized):
            secrets.append(row["request_id"])
    check("no_secrets_in_runtime", not secrets, f"violations={secrets[:5]}")

    failures = [item for item in checks if not item["passed"]]
    report = {
        "schema_version": "1.0",
        "status": "passed" if not failures else "failed",
        "checks": checks,
        "summary": {"total": len(checks), "passed": len(checks) - len(failures), "failed": len(failures)},
    }
    if failures:
        raise InvariantViolation("; ".join(f"{item['name']}: {item['detail']}" for item in failures))
    return report
