# 把模拟状态投影为数据库和日志快照，并聚合用量指标。
from __future__ import annotations

import hashlib
import json
import sqlite3
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Iterable

from .engine import WorldState


SCHEMA = """
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = OFF;
PRAGMA synchronous = OFF;
PRAGMA page_size = 4096;

CREATE TABLE simulation_runs (
  run_id TEXT PRIMARY KEY,
  simulator_version TEXT NOT NULL,
  canonical_seed INTEGER NOT NULL,
  history_start_at TEXT NOT NULL,
  freeze_at TEXT NOT NULL,
  design_manifest_sha256 TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('building','validated','failed'))
);
CREATE TABLE scenario_executions (
  run_id TEXT NOT NULL,
  scenario_id TEXT NOT NULL,
  scenario_family_id TEXT NOT NULL,
  split TEXT NOT NULL CHECK(split IN ('dev','test')),
  started_at TEXT NOT NULL,
  completed_at TEXT,
  status TEXT NOT NULL,
  command_count INTEGER NOT NULL,
  PRIMARY KEY(run_id, scenario_id)
);
CREATE TABLE event_journal (
  run_id TEXT NOT NULL,
  event_sequence INTEGER NOT NULL,
  simulation_time TEXT NOT NULL,
  scenario_id TEXT,
  background_batch_id TEXT,
  aggregate_type TEXT NOT NULL,
  aggregate_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  caused_by_request_id TEXT,
  rule_ids_json TEXT NOT NULL,
  PRIMARY KEY(run_id, event_sequence)
);
CREATE TABLE accounts (
  run_id TEXT NOT NULL, account_id TEXT PRIMARY KEY, name TEXT NOT NULL,
  primary_region TEXT NOT NULL CHECK(primary_region IN ('NA','EU','APAC')),
  default_api_version TEXT NOT NULL,
  production_status TEXT NOT NULL CHECK(production_status IN ('not_enabled','active','suspended')),
  current_plan TEXT NOT NULL CHECK(current_plan IN ('Starter','Growth','Scale')),
  billing_cycle_anchor TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE plan_changes (
  run_id TEXT NOT NULL, plan_change_id TEXT PRIMARY KEY, account_id TEXT NOT NULL,
  from_plan TEXT NOT NULL, to_plan TEXT NOT NULL, requested_at TEXT NOT NULL,
  effective_at TEXT NOT NULL, status TEXT NOT NULL
);
CREATE TABLE api_keys (
  run_id TEXT NOT NULL, key_id TEXT PRIMARY KEY, account_id TEXT NOT NULL,
  environment TEXT NOT NULL CHECK(environment IN ('sandbox','production')),
  key_type TEXT NOT NULL, key_prefix TEXT NOT NULL, key_fingerprint TEXT NOT NULL,
  scopes_json TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('active','expiring','revoked')),
  created_at TEXT NOT NULL, expires_at TEXT, revoked_at TEXT, replaced_by_key_id TEXT
);
CREATE TABLE feature_flags (
  run_id TEXT NOT NULL, account_id TEXT NOT NULL, environment TEXT NOT NULL,
  feature_name TEXT NOT NULL, enabled INTEGER NOT NULL CHECK(enabled IN (0,1)),
  effective_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  PRIMARY KEY(account_id, environment, feature_name)
);
CREATE TABLE customers (
  run_id TEXT NOT NULL, customer_id TEXT PRIMARY KEY, account_id TEXT NOT NULL,
  environment TEXT NOT NULL, email TEXT, name TEXT, metadata_json TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('active','deleted')),
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, deleted_at TEXT
);
CREATE TABLE payments (
  run_id TEXT NOT NULL, payment_id TEXT PRIMARY KEY, account_id TEXT NOT NULL,
  environment TEXT NOT NULL, customer_id TEXT, amount INTEGER NOT NULL CHECK(amount > 0),
  currency TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('requires_action','processing','succeeded','failed','canceled')),
  api_version TEXT NOT NULL, payment_method_profile_id TEXT,
  failure_code TEXT, failure_category TEXT, idempotency_key_hash TEXT,
  created_by_request_id TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  succeeded_at TEXT, terminal_at TEXT
);
CREATE TABLE refunds (
  run_id TEXT NOT NULL, refund_id TEXT PRIMARY KEY, payment_id TEXT,
  account_id TEXT NOT NULL, environment TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount > 0),
  currency TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('pending','succeeded','failed','canceled')),
  mode TEXT NOT NULL CHECK(mode IN ('standard','instant')), failure_code TEXT,
  created_by_request_id TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, completed_at TEXT
);
CREATE TABLE subscriptions (
  run_id TEXT NOT NULL, subscription_id TEXT PRIMARY KEY, account_id TEXT NOT NULL,
  environment TEXT NOT NULL, customer_id TEXT,
  status TEXT NOT NULL CHECK(status IN ('trialing','active','past_due','canceled')),
  amount INTEGER NOT NULL, currency TEXT NOT NULL, interval TEXT NOT NULL,
  trial_end_at TEXT, cancel_at_period_end INTEGER NOT NULL CHECK(cancel_at_period_end IN (0,1)),
  current_period_start TEXT NOT NULL, current_period_end TEXT NOT NULL,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, canceled_at TEXT
);
CREATE TABLE invoices (
  run_id TEXT NOT NULL, invoice_id TEXT PRIMARY KEY, subscription_id TEXT,
  account_id TEXT NOT NULL, environment TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('draft','open','paid','uncollectible','void')),
  amount_due INTEGER NOT NULL, amount_paid INTEGER NOT NULL, currency TEXT NOT NULL,
  period_start TEXT NOT NULL, period_end TEXT NOT NULL, finalized_at TEXT, paid_at TEXT
);
CREATE TABLE invoice_payment_attempts (
  run_id TEXT NOT NULL, invoice_id TEXT NOT NULL, attempt_number INTEGER NOT NULL,
  payment_id TEXT NOT NULL, scheduled_at TEXT NOT NULL, executed_at TEXT NOT NULL, outcome TEXT NOT NULL,
  PRIMARY KEY(invoice_id, attempt_number)
);
CREATE TABLE webhook_endpoints (
  run_id TEXT NOT NULL, endpoint_id TEXT PRIMARY KEY, account_id TEXT NOT NULL,
  environment TEXT NOT NULL, url_host TEXT NOT NULL, url_path_hash TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('enabled','disabled','restricted')),
  api_version TEXT NOT NULL, secret_version INTEGER NOT NULL, secret_fingerprint TEXT NOT NULL,
  retry_policy_id TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, disabled_at TEXT
);
CREATE TABLE webhook_subscriptions (
  run_id TEXT NOT NULL, endpoint_id TEXT NOT NULL, event_type TEXT NOT NULL, created_at TEXT NOT NULL,
  PRIMARY KEY(endpoint_id, event_type)
);
CREATE TABLE events (
  run_id TEXT NOT NULL, event_id TEXT PRIMARY KEY, account_id TEXT NOT NULL,
  environment TEXT NOT NULL, event_type TEXT NOT NULL, api_version TEXT NOT NULL,
  object_type TEXT, object_id TEXT, occurred_at TEXT NOT NULL, payload_hash TEXT NOT NULL,
  caused_by_request_id TEXT
);
CREATE TABLE webhook_deliveries (
  run_id TEXT NOT NULL, delivery_id TEXT PRIMARY KEY, event_id TEXT, endpoint_id TEXT,
  status TEXT NOT NULL CHECK(status IN ('pending','delivered','retrying','exhausted','canceled')),
  attempt_count INTEGER NOT NULL, first_attempt_at TEXT, last_attempt_at TEXT,
  next_attempt_at TEXT, delivered_at TEXT, terminal_reason TEXT
);

CREATE INDEX idx_payments_account_time ON payments(account_id, environment, created_at);
CREATE INDEX idx_refunds_payment_time ON refunds(payment_id, created_at);
CREATE INDEX idx_invoices_subscription ON invoices(subscription_id, period_start);
CREATE INDEX idx_deliveries_endpoint_time ON webhook_deliveries(endpoint_id, last_attempt_at);

CREATE VIEW v_payment_detail AS
SELECT p.*,
  COALESCE((SELECT SUM(r.amount) FROM refunds r WHERE r.payment_id=p.payment_id AND r.status IN ('pending','succeeded')),0) AS refund_reserved,
  p.amount - COALESCE((SELECT SUM(r.amount) FROM refunds r WHERE r.payment_id=p.payment_id AND r.status IN ('pending','succeeded')),0) AS refundable_amount
FROM payments p;
CREATE VIEW v_invoice_timeline AS
SELECT i.invoice_id, i.subscription_id, i.status AS invoice_status, s.status AS subscription_status,
       a.attempt_number, a.payment_id, a.scheduled_at, a.executed_at, a.outcome
FROM invoices i LEFT JOIN subscriptions s ON s.subscription_id=i.subscription_id
LEFT JOIN invoice_payment_attempts a ON a.invoice_id=i.invoice_id;
"""


TABLE_COLUMNS = {
    "accounts": ["run_id","account_id","name","primary_region","default_api_version","production_status","current_plan","billing_cycle_anchor","created_at","updated_at"],
    "plan_changes": ["run_id","plan_change_id","account_id","from_plan","to_plan","requested_at","effective_at","status"],
    "api_keys": ["run_id","key_id","account_id","environment","key_type","key_prefix","key_fingerprint","scopes_json","status","created_at","expires_at","revoked_at","replaced_by_key_id"],
    "feature_flags": ["run_id","account_id","environment","feature_name","enabled","effective_at","updated_at"],
    "customers": ["run_id","customer_id","account_id","environment","email","name","metadata_json","status","created_at","updated_at","deleted_at"],
    "payments": ["run_id","payment_id","account_id","environment","customer_id","amount","currency","status","api_version","payment_method_profile_id","failure_code","failure_category","idempotency_key_hash","created_by_request_id","created_at","updated_at","succeeded_at","terminal_at"],
    "refunds": ["run_id","refund_id","payment_id","account_id","environment","amount","currency","status","mode","failure_code","created_by_request_id","created_at","updated_at","completed_at"],
    "subscriptions": ["run_id","subscription_id","account_id","environment","customer_id","status","amount","currency","interval","trial_end_at","cancel_at_period_end","current_period_start","current_period_end","created_at","updated_at","canceled_at"],
    "invoices": ["run_id","invoice_id","subscription_id","account_id","environment","status","amount_due","amount_paid","currency","period_start","period_end","finalized_at","paid_at"],
    "invoice_payment_attempts": ["run_id","invoice_id","attempt_number","payment_id","scheduled_at","executed_at","outcome"],
    "webhook_endpoints": ["run_id","endpoint_id","account_id","environment","url_host","url_path_hash","status","api_version","secret_version","secret_fingerprint","retry_policy_id","created_at","updated_at","disabled_at"],
    "webhook_subscriptions": ["run_id","endpoint_id","event_type","created_at"],
    "events": ["run_id","event_id","account_id","environment","event_type","api_version","object_type","object_id","occurred_at","payload_hash","caused_by_request_id"],
    "webhook_deliveries": ["run_id","delivery_id","event_id","endpoint_id","status","attempt_count","first_attempt_at","last_attempt_at","next_attempt_at","delivered_at","terminal_reason"],
}


def _insert_rows(conn: sqlite3.Connection, table: str, rows: Iterable[dict[str, Any]], sort_key: str) -> None:
    columns = TABLE_COLUMNS[table]
    placeholders = ",".join("?" for _ in columns)
    sql = f"INSERT INTO {table} ({','.join(columns)}) VALUES ({placeholders})"
    values = []
    for row in sorted(rows, key=lambda item: str(item.get(sort_key, ""))):
        values.append(tuple(row.get(column) for column in columns))
    if values:
        conn.executemany(sql, values)


# 从请求记录汇总用量，避免把存储投影本身当成新的业务请求。
def aggregate_usage(
    requests: list[dict[str, Any]], run_id: str, accounts: dict[str, dict[str, Any]]
) -> list[dict[str, Any]]:
    buckets: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for request in requests:
        minute = request["started_at"][:16] + ":00.000Z"
        buckets[(request["account_id"], request["environment"], minute)].append(request)
    rows = []
    for (account_id, environment, minute), items in sorted(buckets.items()):
        status_counts = [item["http_status"] for item in items]
        rows.append({
            "schema_version": "1.0", "run_id": run_id,
            "evidence_id": f"runtime:usage:{account_id}:{environment}:{minute}",
            "account_id": account_id, "environment": environment,
            "bucket_start": minute, "bucket_width_seconds": 60,
            "request_count": len(items), "success_count": sum(status < 400 for status in status_counts),
            "error_count": sum(status >= 400 for status in status_counts),
            "rate_limited_count": sum(status == 429 for status in status_counts),
            "burst_peak_10s": _burst_peak(items),
            "plan_effective_at_bucket": accounts.get(account_id, {}).get("current_plan"),
        })
    return rows


def _burst_peak(items: list[dict[str, Any]]) -> int:
    per_second = defaultdict(int)
    for item in items:
        per_second[item["started_at"][:19]] += 1
    seconds = sorted(per_second)
    if not seconds:
        return 0
    parsed = [(datetime.fromisoformat(second), count) for second, count in per_second.items()]
    peak = 0
    for start, _ in parsed:
        total = sum(count for moment, count in parsed if start <= moment < start + timedelta(seconds=10))
        peak = max(peak, total)
    return peak


def _write_jsonl(path: Path, rows: Iterable[dict[str, Any]], key: str) -> None:
    text = "".join(
        json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
        for row in sorted(rows, key=lambda item: str(item.get(key, "")))
    )
    path.write_text(text, encoding="utf-8")


# 将同一份世界状态写成多个查询来源，保持结构化数据和日志业务自洽。
def project_snapshot(
    state: WorldState, output_dir: Path, *, run_id: str, seed: int,
    design_manifest_sha256: str, freeze_at: str = "2026-08-27T12:00:00.000Z",
    validation_report: dict[str, Any] | None = None,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=False)
    runtime_dir = output_dir / "runtime"
    audit_dir = output_dir / "audit"
    runtime_dir.mkdir()
    audit_dir.mkdir()
    db_path = output_dir / "flowpay.sqlite"
    conn = sqlite3.connect(db_path)
    try:
        conn.executescript(SCHEMA)
        conn.execute(
            "INSERT INTO simulation_runs VALUES (?,?,?,?,?,?,?)",
            (run_id, "0.1.0", seed, "2025-09-01T00:00:00.000Z", freeze_at, design_manifest_sha256, "validated"),
        )
        for row in sorted(state.scenario_executions.values(), key=lambda x: x["scenario_id"]):
            conn.execute(
                "INSERT INTO scenario_executions VALUES (?,?,?,?,?,?,?,?)",
                (run_id, row["scenario_id"], row["scenario_family_id"], row["split"], row["started_at"], row["completed_at"], row["status"], row["command_count"]),
            )
        for event in state.events:
            conn.execute(
                "INSERT INTO event_journal VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (run_id, event.event_sequence, event.simulation_time, event.scenario_id, event.background_batch_id,
                 event.aggregate_type, event.aggregate_id, event.event_type,
                 json.dumps(event.payload, ensure_ascii=False, sort_keys=True), event.caused_by_request_id,
                 json.dumps(list(event.rule_ids), ensure_ascii=False)),
            )
        _insert_rows(conn, "accounts", state.accounts.values(), "account_id")
        _insert_rows(conn, "plan_changes", state.plan_changes.values(), "plan_change_id")
        _insert_rows(conn, "api_keys", state.api_keys.values(), "key_id")
        _insert_rows(conn, "feature_flags", state.feature_flags.values(), "feature_name")
        _insert_rows(conn, "customers", state.customers.values(), "customer_id")
        _insert_rows(conn, "payments", state.payments.values(), "payment_id")
        _insert_rows(conn, "refunds", state.refunds.values(), "refund_id")
        _insert_rows(conn, "subscriptions", state.subscriptions.values(), "subscription_id")
        _insert_rows(conn, "invoices", state.invoices.values(), "invoice_id")
        _insert_rows(conn, "invoice_payment_attempts", state.invoice_attempts.values(), "invoice_id")
        _insert_rows(conn, "webhook_endpoints", state.endpoints.values(), "endpoint_id")
        _insert_rows(conn, "webhook_subscriptions", state.webhook_subscriptions.values(), "endpoint_id")
        _insert_rows(conn, "events", state.business_events.values(), "event_id")
        _insert_rows(conn, "webhook_deliveries", state.deliveries.values(), "delivery_id")
        conn.commit()
        conn.execute("VACUUM")
    finally:
        conn.close()

    usage = aggregate_usage(state.api_requests, run_id, state.accounts)
    _write_jsonl(runtime_dir / "api_requests.jsonl", state.api_requests, "request_id")
    _write_jsonl(runtime_dir / "usage_buckets.jsonl", usage, "evidence_id")
    _write_jsonl(runtime_dir / "webhook_delivery_attempts.jsonl", state.delivery_attempts, "attempt_id")
    _write_jsonl(runtime_dir / "service_incidents.jsonl", state.service_incidents, "incident_id")
    _write_jsonl(audit_dir / "event_journal.jsonl", [event.to_dict() for event in state.events], "event_sequence")
    (audit_dir / "invariant_report.json").write_text(
        json.dumps(validation_report or {"status": "not_run"}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    files = [db_path, *sorted(runtime_dir.iterdir()), *sorted(audit_dir.iterdir())]
    manifest = {
        "schema_version": "1.0", "run_id": run_id, "simulator_version": "0.1.0",
        "canonical_seed": seed, "freeze_at": freeze_at,
        "design_manifest_sha256": design_manifest_sha256,
        "counts": {
            "accounts": len(state.accounts), "customers": len(state.customers),
            "payments": len(state.payments), "refunds": len(state.refunds),
            "subscriptions": len(state.subscriptions), "invoices": len(state.invoices),
            "endpoints": len(state.endpoints), "events": len(state.business_events),
            "deliveries": len(state.deliveries), "api_requests": len(state.api_requests),
            "usage_buckets": len(usage), "delivery_attempts": len(state.delivery_attempts),
            "service_incidents": len(state.service_incidents), "event_journal": len(state.events),
        },
        "files": {
            str(path.relative_to(output_dir)): {
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size,
            }
            for path in files
        },
    }
    (output_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest
