# 解析项目限定格式的场景 YAML；不是通用 YAML 解析器。
"""Strict parser for the generated FlowPay scenario YAML schema.

The project intentionally has no PyYAML dependency.  The authoring generator
writes complex values as inline JSON, while this parser handles the small fixed
YAML envelope and rejects unknown indentation or malformed records.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ScenarioYamlError(ValueError):
    pass


def _value(raw: str) -> Any:
    raw = raw.strip()
    if not raw:
        return None
    if raw in {"true", "false", "null"} or raw[0] in "[\"{" or raw[0].isdigit() or raw[0] == "-":
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            pass
    return raw


def load_scenario_specs(path: Path) -> dict[str, Any]:
    lines = path.read_text(encoding="utf-8").splitlines()
    result: dict[str, Any] = {"scenario_families": []}
    current: dict[str, Any] | None = None
    section: str | None = None
    current_command: dict[str, Any] | None = None

    for lineno, line in enumerate(lines, start=1):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        indent = len(line) - len(line.lstrip(" "))
        stripped = line.strip()

        if indent == 0:
            if stripped == "scenario_families:":
                continue
            if ":" not in stripped:
                raise ScenarioYamlError(f"line {lineno}: expected top-level mapping")
            key, raw = stripped.split(":", 1)
            result[key] = _value(raw)
            continue

        if indent == 2 and stripped.startswith("- scenario_family_id:"):
            current = {"scenario_family_id": _value(stripped.split(":", 1)[1])}
            result["scenario_families"].append(current)
            section = None
            current_command = None
            continue

        if current is None:
            raise ScenarioYamlError(f"line {lineno}: content outside scenario family")

        if indent == 4:
            if stripped.endswith(":"):
                section = stripped[:-1]
                if section == "commands":
                    current[section] = []
                else:
                    current[section] = {}
                current_command = None
            else:
                key, raw = stripped.split(":", 1)
                current[key] = _value(raw)
                section = None
            continue

        if indent == 6 and section in {"setup", "expects"}:
            key, raw = stripped.split(":", 1)
            current[section][key] = _value(raw)
            continue

        if indent == 6 and section == "commands" and stripped.startswith("- at:"):
            current_command = {"at": _value(stripped.split(":", 1)[1])}
            current["commands"].append(current_command)
            continue

        if indent == 8 and section == "commands" and current_command is not None:
            key, raw = stripped.split(":", 1)
            current_command[key] = _value(raw)
            continue

        raise ScenarioYamlError(f"line {lineno}: unsupported indentation or field: {line!r}")

    families = result["scenario_families"]
    if len(families) != 75:
        raise ScenarioYamlError(f"expected 75 scenario families, got {len(families)}")
    required = {
        "scenario_family_id", "scenario_id", "split", "question_ids", "observation_time",
        "setup", "commands", "expects", "required_documents", "required_operations",
    }
    for family in families:
        missing = required - set(family)
        if missing:
            raise ScenarioYamlError(f"{family.get('scenario_id')}: missing {sorted(missing)}")
        if len(family["question_ids"]) != 4:
            raise ScenarioYamlError(f"{family['scenario_id']}: expected four questions")
    return result

