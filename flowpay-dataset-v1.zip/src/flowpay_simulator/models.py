# 定义编译命令、计划和领域事件的数据结构，供编译器与引擎共享。
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class CompiledCommand:
    at: str
    priority: int
    sequence: int
    scenario_id: str
    scenario_family_id: str
    split: str
    kind: str
    params: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class CompiledPlan:
    schema_version: str
    design_manifest_sha256: str
    commands: tuple[CompiledCommand, ...]
    scenario_count: int
    question_count: int


@dataclass(frozen=True, slots=True)
class DomainEvent:
    event_sequence: int
    simulation_time: str
    scenario_id: str | None
    background_batch_id: str | None
    aggregate_type: str
    aggregate_id: str
    event_type: str
    payload: dict[str, Any]
    caused_by_request_id: str | None = None
    rule_ids: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["rule_ids"] = list(self.rule_ids)
        return value

