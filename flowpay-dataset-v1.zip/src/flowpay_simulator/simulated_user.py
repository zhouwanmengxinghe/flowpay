# 根据预设上下文确定性地回复追问，使不同运行能够比较。
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


CATEGORY_KEYWORDS = {
    "goal": ("想确认", "想解决", "诉求", "希望", "具体问题"),
    "symptom_details": ("现象", "报错", "错误", "状态", "步骤", "发生了什么", "表现"),
    "account_context": ("环境", "正式", "测试", "沙箱", "套餐", "地区", "账户"),
    "occurrence_time": ("时间", "什么时候", "多久", "哪天", "时间范围"),
    "api_version": ("版本", "version", "请求头"),
    "identifiers": ("编号", "id", "请求号", "支付号", "退款号", "账单号", "事件号"),
}


@dataclass(slots=True)
class DeterministicSimulatedUser:
    """A benchmark user who reveals only facts explicitly requested by the assistant."""

    conversation: dict[str, Any]
    disclosed_fact_ids: set[str] = field(default_factory=set)

    def answer(self, assistant_question: str) -> tuple[str, list[dict[str, Any]]]:
        lower = assistant_question.lower()
        requested = {
            category
            for category, keywords in CATEGORY_KEYWORDS.items()
            if any(keyword.lower() in lower for keyword in keywords)
        }
        facts = [
            fact for fact in self.conversation.get("available_user_facts", [])
            if fact.get("category") in requested and fact.get("fact_id") not in self.disclosed_fact_ids
        ]
        if not facts:
            return "这些信息我现在还没整理出来。你可以告诉我具体需要哪一类信息吗？", []
        for fact in facts:
            self.disclosed_fact_ids.add(str(fact["fact_id"]))
        return " ".join(str(fact["user_value"]) for fact in facts), facts

    @property
    def disclosed_categories(self) -> list[str]:
        return [
            str(fact["category"])
            for fact in self.conversation.get("available_user_facts", [])
            if fact.get("fact_id") in self.disclosed_fact_ids
        ]

