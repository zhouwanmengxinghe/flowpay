# 将场景规格编译为模拟计划，并校验输入及生成内容的标识。
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .models import CompiledPlan
from .recipes import expand_family
from .scenario_yaml import load_scenario_specs


class CompileError(ValueError):
    pass


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class ScenarioCompiler:
    def __init__(self, project_root: Path):
        self.root = project_root.resolve()
        self.design_dir = self.root / "benchmark" / "design"

    # 编译前校验输入清单，防止场景引用与当前资料版本不一致。
    def _verify_manifest(self) -> str:
        manifest_path = self.design_dir / "design_manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for name, expected in manifest["files"].items():
            actual = _sha256(self.design_dir / name)
            if actual != expected["sha256"]:
                raise CompileError(f"design artifact hash mismatch: {name}")
        return _sha256(manifest_path)

    # 将声明式场景转换为可执行计划，业务状态变化交由模拟引擎执行。
    def compile(self) -> CompiledPlan:
        manifest_sha = self._verify_manifest()
        specs = load_scenario_specs(self.design_dir / "scenario_specs.yaml")
        reservations = json.loads((self.design_dir / "entity_reservations.json").read_text(encoding="utf-8"))
        blueprints = [
            json.loads(line)
            for line in (self.design_dir / "benchmark_blueprints.jsonl").read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        reserved_by_family = {
            row["scenario_family_id"]: row for row in reservations["reservations"]
        }
        question_ids = {q["question_id"] for q in blueprints}
        commands = []
        for family in specs["scenario_families"]:
            reservation = reserved_by_family.get(family["scenario_family_id"])
            if reservation is None:
                raise CompileError(f"missing reservation: {family['scenario_family_id']}")
            expected_ids = {key.removesuffix("_id"): value for key, value in reservation["ids"].items()}
            if expected_ids != family["setup"]["reserved_entities"]:
                raise CompileError(f"reservation mismatch: {family['scenario_family_id']}")
            unknown_questions = set(family["question_ids"]) - question_ids
            if unknown_questions:
                raise CompileError(f"unknown question IDs: {sorted(unknown_questions)}")
            commands.extend(expand_family(family))

        commands.sort(key=lambda c: (c.at, c.priority, c.scenario_id, c.sequence))
        return CompiledPlan(
            schema_version="1.0",
            design_manifest_sha256=manifest_sha,
            commands=tuple(commands),
            scenario_count=len(specs["scenario_families"]),
            question_count=len(blueprints),
        )

    def write(self, output_dir: Path) -> CompiledPlan:
        plan = self.compile()
        output_dir.mkdir(parents=True, exist_ok=True)
        commands_text = "".join(
            json.dumps(command.to_dict(), ensure_ascii=False, separators=(",", ":")) + "\n"
            for command in plan.commands
        )
        (output_dir / "compiled_commands.jsonl").write_text(commands_text, encoding="utf-8")
        manifest = {
            "schema_version": plan.schema_version,
            "design_manifest_sha256": plan.design_manifest_sha256,
            "scenario_count": plan.scenario_count,
            "question_count": plan.question_count,
            "command_count": len(plan.commands),
            "compiled_commands_sha256": hashlib.sha256(commands_text.encode("utf-8")).hexdigest(),
        }
        (output_dir / "compile_manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        return plan
