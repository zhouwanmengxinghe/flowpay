# 数据项目命令入口：把冻结的场景设计编译成原子命令，再回放成业务快照。
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from .background import BackgroundGenerator, CANONICAL_SCALE, SMOKE_SCALE
from .compiler import ScenarioCompiler
from .engine import SimulationEngine
from .storage import project_snapshot
from .validation import validate_state


def project_root(value: str | None) -> Path:
    return Path(value).resolve() if value else Path.cwd().resolve()


def cmd_compile(args: argparse.Namespace) -> None:
    root = project_root(args.project_root)
    output = Path(args.output).resolve() if args.output else root / "benchmark" / "compiled"
    plan = ScenarioCompiler(root).write(output)
    print(json.dumps({
        "status": "compiled", "scenario_count": plan.scenario_count,
        "question_count": plan.question_count, "command_count": len(plan.commands),
        "output": str(output),
    }, ensure_ascii=False, indent=2))


def cmd_simulate(args: argparse.Namespace) -> None:
    root = project_root(args.project_root)
    output = Path(args.output).resolve() if args.output else root / "data" / "generated" / "canonical"
    if output.exists():
        if not args.force:
            raise SystemExit(f"output already exists: {output}; pass --force to replace it")
        shutil.rmtree(output)

    compiler = ScenarioCompiler(root)
    plan = compiler.write(root / "benchmark" / "compiled")
    engine = SimulationEngine(run_id=args.run_id, seed=args.seed)
    if args.background != "none":
        scale = CANONICAL_SCALE if args.background == "canonical" else SMOKE_SCALE
        BackgroundGenerator(engine, scale).run()
    state = engine.run(plan.commands)
    report = validate_state(state, expected_scenarios=plan.scenario_count)
    manifest = project_snapshot(
        state, output, run_id=args.run_id, seed=args.seed,
        design_manifest_sha256=plan.design_manifest_sha256,
        validation_report=report,
    )
    print(json.dumps({
        "status": "validated", "output": str(output), "counts": manifest["counts"],
        "invariants": report["summary"],
    }, ensure_ascii=False, indent=2))


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(prog="flowpay-sim")
    result.add_argument("--project-root", help="FlowPay project root; defaults to current directory")
    sub = result.add_subparsers(dest="command", required=True)

    compile_parser = sub.add_parser("compile", help="compile frozen scenario specs into atomic commands")
    compile_parser.add_argument("--output")
    compile_parser.set_defaults(func=cmd_compile)

    simulate_parser = sub.add_parser("simulate", help="run the deterministic simulator and project a snapshot")
    simulate_parser.add_argument("--output")
    simulate_parser.add_argument("--run-id", default="run_canonical_20260827")
    simulate_parser.add_argument("--seed", type=int, default=20260827)
    simulate_parser.add_argument("--background", choices=("canonical", "smoke", "none"), default="canonical")
    simulate_parser.add_argument("--force", action="store_true")
    simulate_parser.set_defaults(func=cmd_simulate)
    return result


def main() -> None:
    args = parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
