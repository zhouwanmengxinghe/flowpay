# 把场景族展开为具体命令，集中组织模拟输入的时间与实体关系。
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from .models import CompiledCommand


PRIORITY = {
    "create_account": 10,
    "enable_production": 11,
    "create_api_key": 12,
    "set_feature_flag": 13,
    "create_customer": 20,
    "create_payment_fixture": 30,
    "create_refund_fixture": 31,
    "create_subscription_fixture": 32,
    "create_invoice_fixture": 33,
    "create_endpoint_fixture": 40,
    "create_event_fixture": 41,
    "create_delivery_fixture": 42,
    "create_incident_fixture": 43,
    "execute_scenario": 80,
}


PAYMENT_INITIAL = {
    "confirm_action_required_payment": "requires_action",
    "cancel_processing_payment": "processing",
    "refund_processing_payment": "processing",
    "decline_payment_method": "failed",
    "fail_payment_for_insufficient_funds": "failed",
    "use_expired_payment_method": "failed",
    "retry_failed_payment_in_place": "failed",
}

PAYMENT_SUCCEEDED_FIXTURE = {
    "confirm_succeeded_payment", "create_partial_refund_on_starter", "create_multiple_partial_refunds",
    "overbook_refund_while_pending", "fail_pending_refund_and_release_amount",
    "refund_payment_after_181_days", "create_eligible_instant_refund", "create_instant_refund_in_apac",
    "exercise_instant_refund_conditions", "emit_unsubscribed_payment_event",
    "emit_versioned_payment_success_event", "redeliver_same_webhook_event",
    "complete_payment_with_webhook_retry",
}

SKIP_PAYMENT_FIXTURE = {
    "create_payment_with_unsupported_currency", "submit_payment_amount_boundaries",
    "create_payment_with_removed_source", "create_payment_for_deleted_customer",
}
SKIP_REFUND_FIXTURE = {
    "refund_processing_payment", "create_partial_refund_on_starter", "refund_payment_after_181_days",
    "create_instant_refund_in_apac", "exercise_instant_refund_conditions",
}
SKIP_SUBSCRIPTION_FIXTURE = {"create_subscription_on_starter", "create_subscription_on_starter_plan"}


def _dt(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _iso(value: datetime) -> str:
    return value.isoformat().replace("+00:00", "Z")


def _command(
    *, at: datetime, sequence: int, family: dict[str, Any], kind: str, params: dict[str, Any]
) -> CompiledCommand:
    return CompiledCommand(
        at=_iso(at),
        priority=PRIORITY[kind],
        sequence=sequence,
        scenario_id=family["scenario_id"],
        scenario_family_id=family["scenario_family_id"],
        split=family["split"],
        kind=kind,
        params=params,
    )


def expand_family(family: dict[str, Any]) -> list[CompiledCommand]:
    high_level = family["commands"][0]
    main_at = _dt(high_level["at"])
    mode = high_level["command"]
    ids = dict(family["setup"]["reserved_entities"])
    account = dict(family["setup"]["account"])
    setup_at = main_at - timedelta(minutes=30)
    commands: list[CompiledCommand] = []
    seq = 0

    def add(kind: str, offset: int, params: dict[str, Any]) -> None:
        nonlocal seq
        seq += 1
        commands.append(_command(at=setup_at + timedelta(seconds=offset), sequence=seq, family=family, kind=kind, params=params))

    add("create_account", 0, {**account, "scenario_mode": mode})
    if account.get("environment") == "production" and mode != "create_production_key_before_enablement":
        add("enable_production", 1, {"account_id": ids.get("account")})
    if ids.get("key") and mode != "create_production_key_before_enablement":
        key_environment = "sandbox" if mode == "create_payment_with_wrong_environment_key" else account.get("environment", "production")
        add("create_api_key", 2, {
            "key_id": ids["key"], "account_id": ids.get("account"),
            "environment": key_environment, "status": "active",
        })
    if ids.get("customer"):
        add("create_customer", 3, {
            "customer_id": ids["customer"], "account_id": ids.get("account"),
            "environment": account.get("environment", "production"), "status": "active",
            "email": "shared-customer@example.test" if mode == "create_customers_with_duplicate_email" else None,
        })
        if mode == "create_customers_with_duplicate_email":
            add("create_customer", 3, {
                "customer_id": f"{ids['customer']}_duplicate", "account_id": ids.get("account"),
                "environment": account.get("environment", "production"), "status": "active",
                "email": "shared-customer@example.test",
            })
    if mode in {"create_subscription_on_starter", "upgrade_plan_then_create_subscription", "create_subscription_on_starter_plan"}:
        add("set_feature_flag", 3, {
            "account_id": ids.get("account"), "environment": account.get("environment", "production"),
            "feature_name": "subscriptions", "enabled": True,
        })
    if ids.get("payment") and mode not in SKIP_PAYMENT_FIXTURE:
        initial = PAYMENT_INITIAL.get(mode, "succeeded" if mode in PAYMENT_SUCCEEDED_FIXTURE else "processing")
        add("create_payment_fixture", 4, {
            "payment_id": ids["payment"], "account_id": ids.get("account"),
            "environment": "production" if mode == "retrieve_resource_from_wrong_environment" else account.get("environment", "production"),
            "customer_id": ids.get("customer"), "status": initial,
            "api_version": family.get("api_version", "2026-07-01"), "amount": 10000, "currency": "USD",
        })
    if ids.get("refund") and mode not in SKIP_REFUND_FIXTURE:
        add("create_refund_fixture", 5, {
            "refund_id": ids["refund"], "payment_id": ids.get("payment"),
            "account_id": ids.get("account"), "environment": account.get("environment", "production"),
            "status": "pending", "amount": 4000, "currency": "USD",
        })
    if ids.get("subscription") and mode not in SKIP_SUBSCRIPTION_FIXTURE:
        add("create_subscription_fixture", 6, {
            "subscription_id": ids["subscription"], "account_id": ids.get("account"),
            "environment": account.get("environment", "production"), "customer_id": ids.get("customer"),
            "status": "active", "amount": 2500, "currency": "USD",
        })
    if ids.get("invoice"):
        add("create_invoice_fixture", 7, {
            "invoice_id": ids["invoice"], "subscription_id": ids.get("subscription"),
            "account_id": ids.get("account"), "environment": account.get("environment", "production"),
            "status": "open", "amount_due": 2500, "currency": "USD",
        })
    if mode == "create_third_endpoint_on_starter":
        for existing_number in (1, 2):
            add("create_endpoint_fixture", 8, {
                "endpoint_id": f"we_{ids['account'].removeprefix('acct_')}_existing_{existing_number}",
                "account_id": ids.get("account"), "environment": account.get("environment", "production"),
                "status": "enabled", "api_version": family.get("api_version", "2026-07-01"),
            })
    if mode == "apply_endpoint_restrictions_after_downgrade":
        for number in range(1, 6):
            endpoint_id = ids["endpoint"] if number == 3 else f"we_{ids['account'].removeprefix('acct_')}_existing_{number}"
            add("create_endpoint_fixture", 8, {
                "endpoint_id": endpoint_id, "account_id": ids.get("account"),
                "environment": account.get("environment", "production"), "status": "enabled",
                "api_version": family.get("api_version", "2026-07-01"),
            })
    elif ids.get("endpoint") and mode != "create_third_endpoint_on_starter":
        add("create_endpoint_fixture", 8, {
            "endpoint_id": ids["endpoint"], "account_id": ids.get("account"),
            "environment": account.get("environment", "production"), "status": "enabled",
            "api_version": family.get("api_version", "2026-07-01"),
        })
    derived_event_id = None
    if ids.get("delivery") and not ids.get("event"):
        derived_event_id = f"evt_{ids['delivery'].removeprefix('del_')}_history"
    event_id = ids.get("event") or derived_event_id
    if event_id:
        add("create_event_fixture", 9, {
            "event_id": event_id, "account_id": ids.get("account"),
            "environment": account.get("environment", "production"), "object_id": ids.get("payment") or ids.get("invoice"),
            "api_version": family.get("api_version", "2026-07-01"), "event_type": "payment.succeeded",
        })
    if ids.get("delivery"):
        add("create_delivery_fixture", 10, {
            "delivery_id": ids["delivery"], "event_id": event_id,
            "endpoint_id": ids.get("endpoint"), "status": "pending",
        })
    if ids.get("incident"):
        add("create_incident_fixture", 11, {
            "incident_id": ids["incident"], "service": "payments", "region": account.get("region", "NA"),
            "status": "active",
        })

    seq += 1
    commands.append(_command(
        at=main_at, sequence=seq, family=family, kind="execute_scenario",
        params={
            "mode": mode, "ids": ids, "account": account,
            "observation_time": family["observation_time"], "expects": family["expects"],
        },
    ))
    return commands
