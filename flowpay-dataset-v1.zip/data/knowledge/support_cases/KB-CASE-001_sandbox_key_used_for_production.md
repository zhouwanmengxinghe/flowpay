---
doc_id: KB-CASE-001
title: Sandbox Key 被用于 Production Payment
doc_type: support_case
authority: historical_case
product_areas: [developer_platform, payments]
api_versions: ["2026-07-01"]
effective_from: "2026-07-08"
effective_to: null
supersedes: []
account_id: acct_aurora_shop
case_status: resolved
error_codes: [FP-4012]
rule_ids: [RULE-ENV-001, RULE-ENV-005, RULE-TENANT-004, RULE-AUTH-002]
related_docs: [KB-BR-002, KB-API-003, KB-API-004, KB-API-005, KB-TS-005, KB-TS-019]
indexing: include
language: zh-CN
---

# Sandbox Key 被用于 Production Payment

## 背景

Aurora Shop 在 2026-07-08 发布新版结账服务，目标是以 API Version `2026-07-01` 创建 Production Payment。

## 用户报告

开发者报告所有创建请求都返回 HTTP 401 和 `FP-4012`。他们确认 Customer ID 来自 Production，并注意到故障与一次 Secret 配置发布同时发生。

## 初始假设

团队初步判断 Key 与资源可能来自不同环境，并准备分别核对部署 Secret 和 Customer 环境。这个方向与错误码含义一致。

## 调查过程

支持人员先按 `customer_id` 检查 `cus_live_AU71`，确认所属 Account 和环境正确。随后根据 `req_AU_0708_19` 检查认证指纹，发现容器实际加载的是 `sk_test_` Key。发布清单中的 Secret 名称正确，但部署变量引用了测试 Secret 路径。

## 关键证据

- Account：`acct_aurora_shop`。
- Request：`req_AU_0708_19`。
- Customer：`cus_live_AU71`，环境为 Production。
- Key 指纹：`keyfp_test_AU09`，所属环境为 Sandbox。
- 错误：`FP-4012 Environment Mismatch`。

## 根因

有效 Sandbox Key 被用于访问 Production 资源，触发环境不匹配。Customer 状态和 API Version 均不是根因。

## 处理结果

团队修正 Secret Manager 路径，部署 `sk_live_` Key，并以新 Request ID 验证创建成功。随后增加启动检查：部署环境与 Key 前缀不匹配时拒绝启动。

## 可复用经验

遇到 FP-4012 应同时核对 Key 环境和资源环境。只确认资源存在不足以完成诊断，也不应把 Sandbox 数据复制当作修复手段。

## 不可泛化部分

本案例不能说明所有 401 都是 Secret 路径错误；`FP-4011` 还可能来自撤销、缺失或格式错误的 Key。
