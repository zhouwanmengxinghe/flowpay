---
doc_id: KB-CASE-006
title: 429 重试风暴被误认为套餐降级
doc_type: support_case
authority: historical_case
product_areas: [developer_platform, operations, accounts]
api_versions: ["2026-07-01"]
effective_from: "2026-07-29"
effective_to: null
supersedes: []
account_id: acct_harbor_docs
case_status: resolved
error_codes: [FP-4291]
rule_ids: [RULE-RATE-003, RULE-RATE-005, RULE-RATE-007, RULE-PLAN-002, RULE-PLAN-005]
related_docs: [KB-BR-004, KB-BR-005, KB-API-034, KB-TS-016, KB-TS-022]
indexing: include
language: zh-CN
---

# 429 重试风暴被误认为套餐降级

## 背景

Harbor Docs 使用 Growth。2026-07-29 的一次短流量峰值后，429 数量没有随原始流量下降，反而持续上升。

## 用户报告

团队看到 Dashboard 中有一条下周期降级申请，判断 FlowPay 已提前按 Starter 的 300 req/min 限流。

## 初始假设

套餐提前降级的假设不成立。Account 记录 `plan_change_HD_0820` 显示降级将在 2026-08-20 生效，故障发生时仍是 Growth。

## 调查过程

支持人员一开始只核对套餐矩阵，确认 Growth 上限后仍无法解释持续 429。查看 `usage_HD_0729_1415` 后发现客户端对每个 429 立即并发重试 5 次，且忽略 `FlowPay-RateLimit-Reset`。原始速率已经降到 700 req/min，但重试把总量放大到 2,860 req/min。

## 关键证据

- Account：`acct_harbor_docs`。
- 套餐：Growth，降级生效日 2026-08-20。
- Usage：`usage_HD_0729_1415`。
- Request 链：`req_HD_429_root`、`req_HD_429_r1`～`r5`。
- Reset Header：12 秒，客户端未遵守。

## 根因

客户端无退避并发重试放大了请求量，形成自维持的 Rate Limit 风暴；不是套餐变化。

## 处理结果

团队停用立即重试，按 Reset Header 等待并加入指数退避、随机抖动和总并发限制。创建请求保持原 Idempotency Key。

## 可复用经验

套餐、Usage 和重试轨迹缺一不可。若只确认套餐，会漏掉请求被客户端自身放大的情况。

## 不可泛化部分

并非所有 429 都来自重试风暴。正常流量超过额度、突发窗口耗尽或已生效降级也可能产生相同错误。

