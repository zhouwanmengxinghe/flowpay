---
doc_id: KB-CASE-010
title: 对 processing Payment 发起 Refund
doc_type: support_case
authority: historical_case
product_areas: [payments, refunds]
api_versions: ["2026-07-01"]
effective_from: "2026-08-11"
effective_to: null
supersedes: []
account_id: acct_fable_market
case_status: resolved
error_codes: [FP-4221]
rule_ids: [RULE-PAY-001, RULE-PAY-004, RULE-REFUND-001, RULE-REFUND-008]
related_docs: [KB-BR-010, KB-BR-012, KB-API-014, KB-API-020, KB-TS-014, KB-TS-021]
indexing: include
language: zh-CN
---

# 对 processing Payment 发起 Refund

## 背景

Fable Market 的订单取消任务在 Payment 创建后 3 秒触发退款。Payment `pay_FA_9012` 当时仍为 `processing`。

## 用户报告

退款创建返回 `FP-4221`。团队认为 Refund 服务延迟，计划每秒重试直到成功。

## 初始假设

Refund 服务延迟的假设不成立。错误发生在业务状态校验：只有 succeeded Payment 才能进入退款流程。

## 调查过程

支持人员最初查看 Webhook Delivery，但是否送达与 Payment 可退款状态无关，这一步没有解释 422。Payment 查询记录 `pay_state_FA_9012_01` 显示退款请求时状态为 `processing`；27 秒后状态变为 `succeeded`。

## 关键证据

- Account：`acct_fable_market`。
- Payment：`pay_FA_9012`。
- Refund Request：`req_FA_refund_01`。
- 请求时状态：`processing`。
- 后续状态记录：`pay_state_FA_9012_02 = succeeded`。

## 根因

订单取消任务没有等待 Payment 最终状态，对 processing Payment 发起了不允许的 Refund。

## 处理结果

任务改为状态驱动：processing 时等待 Payment Event 或有限轮询；succeeded 后再计算退款资格；failed/canceled 则不创建 Refund。团队移除了每秒无界重试。

## 可复用经验

业务动作必须依据查询时的资源状态。FP-4221 是状态错误，不是退款窗口错误或网络故障。

## 不可泛化部分

Payment 后来 succeeded 不意味着所有 processing Payment 最终都会成功，也不保证仍满足套餐、额度和 180 天退款条件。

