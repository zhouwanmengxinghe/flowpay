---
doc_id: KB-CASE-011
title: Starter Account 尝试部分 Refund
doc_type: support_case
authority: historical_case
product_areas: [refunds, accounts]
api_versions: ["2026-04-01"]
effective_from: "2026-08-13"
effective_to: null
supersedes: []
account_id: acct_bloom_studio
case_status: resolved
error_codes: [FP-4031]
rule_ids: [RULE-PLAN-001, RULE-PLAN-004, RULE-REFUND-002, RULE-REFUND-003]
related_docs: [KB-BR-004, KB-BR-012, KB-API-020, KB-API-021, KB-TS-010, KB-TS-020]
indexing: include
language: zh-CN
---

# Starter Account 尝试部分 Refund

## 背景

Bloom Studio 使用 Starter。Payment `pay_BL_882` 金额为 USD 80.00，状态 succeeded，商户希望退回 USD 20.00。

## 用户报告

请求返回 `FP-4031`。开发者已经确认金额在可退款额度内，询问是否为 Starter 的功能限制。

## 初始假设

团队初步判断 Starter 不支持部分 Refund，需要同时核对 Account 套餐和 Payment 剩余可退金额。

## 调查过程

查询 `acct_bloom_studio` 显示套餐为 Starter，且没有待生效升级。Payment `pay_BL_882` 的 `refundable_amount` 为 8000。请求显式发送 `amount=2000`，因此属于部分退款；Starter 只支持一次退回全部剩余金额。

## 关键证据

- Account：`acct_bloom_studio`，Starter。
- Payment：`pay_BL_882`，succeeded。
- 可退款额度：8000 USD 最小单位。
- Refund Request：`req_BL_partial_1`，amount 2000。
- 错误：`FP-4031`。

## 根因

请求使用了 Starter 套餐不提供的部分退款能力，不是金额格式或 Payment 状态问题。

## 处理结果

Merchant 根据业务需要选择退回全部剩余金额，并省略 `amount`。产品随后评估是否升级 Growth 以支持未来部分退款。

## 可复用经验

`refundable_amount > 0` 只表示有额度，不表示套餐支持任意退款方式。应同时查询套餐与 Payment。

## 不可泛化部分

Growth 或 Scale 也不保证每笔部分退款成功；仍需满足 succeeded 状态、180 天窗口和并发额度约束。
