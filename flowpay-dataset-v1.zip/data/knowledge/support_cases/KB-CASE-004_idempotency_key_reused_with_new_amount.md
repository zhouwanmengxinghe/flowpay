---
doc_id: KB-CASE-004
title: 修改金额后复用 Idempotency Key
doc_type: support_case
authority: historical_case
product_areas: [payments, developer_platform]
api_versions: ["2026-01-15"]
effective_from: "2026-07-21"
effective_to: null
supersedes: []
account_id: acct_orbit_media
case_status: resolved
error_codes: [FP-4091]
rule_ids: [RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005]
related_docs: [KB-BR-008, KB-API-007, KB-API-033, KB-TS-013]
indexing: include
language: zh-CN
---

# 修改金额后复用 Idempotency Key

## 背景

Orbit Media 的订单服务为每个订单使用固定 Idempotency Key。客户先支付 USD 12.00，随后加购后将订单金额改为 USD 15.00。

## 用户报告

第二次创建 Payment 返回 `FP-4091`。团队注意到订单金额已经变化，怀疑原 Idempotency Key 不应继续用于这次操作。

## 初始假设

初步假设是同一 Key 在 24 小时内承载了不同参数。支持人员据此对比首次请求和冲突请求，而没有直接更换 Key 重发。

## 调查过程

`req_OR_0721_001` 使用 Key `order-8842-attempt-1` 和金额 `1200`，首次创建 `pay_OR_8842_A`。`req_OR_0721_019` 使用相同 Key 和金额 `1500`。`2026-01-15` 错误详情中的 `conflict_request_id` 指向首次请求。

## 关键证据

- Account：`acct_orbit_media`。
- Idempotency Key：`order-8842-attempt-1`。
- 首次 Request：`req_OR_0721_001`，金额 1200。
- 冲突 Request：`req_OR_0721_019`，金额 1500。
- 首次 Payment：`pay_OR_8842_A`。

## 根因

订单修改后仍复用原业务操作的 Idempotency Key，参数差异触发 FP-4091。

## 处理结果

团队先确认首笔 Payment 结果，再为改价后的新支付意图生成 `order-8842-attempt-2`。自动重试恢复为有限次数，并要求重试参数完全不变。

## 可复用经验

Request ID 追踪一次网络请求；Idempotency Key 标识一次业务操作。订单 ID 可以长期复用，但每个新的支付意图应有新的操作 Key。

## 不可泛化部分

本案例不能说明遇到 FP-4091 就应直接换 Key。必须先确认首次请求结果，避免重复创建 Payment。
