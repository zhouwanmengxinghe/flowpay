---
doc_id: KB-CASE-003
title: Production 暂停被误认为套餐降级
doc_type: support_case
authority: historical_case
product_areas: [accounts, developer_platform]
api_versions: ["2026-07-01"]
effective_from: "2026-07-17"
effective_to: null
supersedes: []
account_id: acct_cedar_ai
case_status: resolved
error_codes: [FP-4032]
rule_ids: [RULE-AUTH-007, RULE-AUTH-008, RULE-PLAN-002, RULE-ERROR-002]
related_docs: [KB-BR-002, KB-BR-004, KB-API-005, KB-TS-011, KB-TS-020]
indexing: include
language: zh-CN
---

# Production 暂停被误认为套餐降级

## 背景

Cedar AI 使用 Growth 套餐处理 Production Payment。2026-07-17 上午，全部 Production Endpoint 开始返回 HTTP 403，Sandbox 保持正常。

## 用户报告

管理员刚提交过下个周期降级到 Starter 的申请，因此团队认定套餐已经提前降级，导致 Payments 功能不可用。

## 初始假设

该假设不成立。套餐降级在计费周期结束时生效，而且一次性 Payment 在 Starter 也可用。错误码实际为 `FP-4032`，不是套餐功能错误 `FP-4031`。

## 调查过程

支持人员先花时间检查了 Growth 与 Starter 功能矩阵，这一步没有解释为什么所有 Production Endpoint 都失败。查询 Account 状态后发现 `production_suspended=true`，状态变更发生于 `2026-07-17T01:42:00Z`。Sandbox 不受该状态影响。

## 关键证据

- Account：`acct_cedar_ai`。
- Request：`req_CE_0717_044`。
- 错误：`FP-4032 Production Access Suspended`。
- 套餐：Growth，降级尚未生效。
- Production 状态记录：`acct_state_CE_0717_suspend`。

## 根因

Account 的 Production 访问被暂停，与尚未生效的套餐降级无关。

## 处理结果

账户状态流程解除暂停后，团队以小流量 Production GET 和 Payment 创建验证恢复，再逐步处理积压请求。降级申请仍按原周期末生效。

## 可复用经验

403 必须先区分 FP-4031 和 FP-4032。Sandbox 正常只能说明环境隔离生效，不能证明 Production 权限正常。

## 不可泛化部分

本案例不提供其他 Account 被暂停的原因。是否暂停以及恢复条件必须查询具体账户状态。

