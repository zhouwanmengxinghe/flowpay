---
doc_id: KB-CASE-014
title: Invoice 重试耗尽导致 Subscription 取消
doc_type: support_case
authority: historical_case
product_areas: [subscriptions, invoices, payments]
api_versions: ["2026-04-01"]
effective_from: "2026-08-20"
effective_to: null
supersedes: []
account_id: acct_tide_crm
case_status: resolved
error_codes: [FP-4024]
rule_ids: [RULE-SUB-005, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006]
related_docs: [KB-BR-013, KB-BR-014, KB-API-023, KB-API-026, KB-API-027, KB-API-028, KB-TS-009]
indexing: include
language: zh-CN
---

# Invoice 重试耗尽导致 Subscription 取消

## 背景

Tide CRM 的 Subscription `sub_TI_315` 使用已过期 Payment Method。该周期 Invoice 从首次失败起依次执行三次自动重试。

## 用户报告

客户在第 8 天更新 Payment Method 后，团队确认原 Subscription 已 canceled，询问是否应创建新 Subscription。

## 初始假设

团队初步判断 canceled 是终态，更新 Payment Method 不会改写历史状态，因此恢复服务需要创建新 Subscription。

## 调查过程

Invoice `in_TI_888` 的 `payment_ids` 包含四笔尝试：首次 `pay_TI_0`，第 1、3、7 天的 `pay_TI_1`、`pay_TI_3`、`pay_TI_7`。四笔都返回 `FP-4024`。最后一次失败后 Invoice 进入 uncollectible，Subscription 同时进入 canceled。

## 关键证据

- Account：`acct_tide_crm`。
- Subscription：`sub_TI_315`，状态 canceled。
- Invoice：`in_TI_888`，状态 uncollectible。
- 四个 Payment：`pay_TI_0`、`pay_TI_1`、`pay_TI_3`、`pay_TI_7`。
- 最后状态时间：2026-08-19T10:00:00Z。

## 根因

首次扣费与第 1、3、7 天三次重试全部因 Payment Method 过期失败，系统按规则耗尽重试并取消 Subscription。

## 处理结果

团队使用更新后的 Payment Method 创建新 Subscription，没有尝试改写旧资源。客服在重试期间提前提醒客户更新方式。

## 可复用经验

需要区分 past_due 的可恢复阶段和 canceled 终态。更新 Payment Method 只影响后续新尝试，不会重写已经耗尽的 Invoice 历史。

## 不可泛化部分

本案例的失败码是 FP-4024；其他 Invoice 也可能因拒绝或资金不足失败，必须查看每笔 Payment。
