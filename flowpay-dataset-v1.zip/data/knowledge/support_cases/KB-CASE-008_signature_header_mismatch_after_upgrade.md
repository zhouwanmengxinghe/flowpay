---
doc_id: KB-CASE-008
title: 升级后 Webhook 签名 Header 不匹配
doc_type: support_case
authority: historical_case
product_areas: [webhooks, developer_platform]
api_versions: ["2026-04-01"]
effective_from: "2026-08-05"
effective_to: null
supersedes: []
account_id: acct_nimbus_ops
case_status: resolved
error_codes: []
rule_ids: [RULE-WEBHOOK-013, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017]
related_docs: [KB-BR-016, KB-API-031, KB-TS-023, KB-REL-004, KB-REL-006]
indexing: include
language: zh-CN
---

# 升级后 Webhook 签名 Header 不匹配

## 背景

Nimbus Ops 将 Payment 请求升级到 `2026-04-01`。Payment 成功，但接收端把新 Event 全部判定为“缺少签名”。

## 用户报告

团队怀疑 Signing Secret 在版本升级时被 FlowPay 自动轮换，并开始在 Dashboard 反复生成新 Secret。

## 初始假设

自动轮换假设不成立。API Version 升级改变的是签名 Header 名称，不要求轮换 Secret。反复轮换反而增加了排查变量。

## 调查过程

第一轮只比较 HMAC 算法，算法和原始请求体均正确，这一步没有解释“Header 缺失”。Delivery `del_NI_0805_33` 的 Event 版本为 `2026-04-01`，请求携带 `FlowPay-Signature`；Merchant 代码仍只读取 `X-FlowPay-Signature`。

## 关键证据

- Account：`acct_nimbus_ops`。
- Event：`evt_NI_pay_771`，API Version `2026-04-01`。
- Delivery：`del_NI_0805_33`，HTTP 400。
- 实际 Header：`FlowPay-Signature`。
- Endpoint：`we_NI_prod_2`。

## 根因

Webhook 消费者没有适配 2026-04-01 起使用的新 Header 名称。Signing Secret 本身不是最初根因。

## 处理结果

团队部署同时识别新旧 Header 的验证器，使用原始正文验签，并在 24 小时内兼容轮换过程中产生的新旧 Secret。重试 Delivery 随后返回 204。

## 可复用经验

签名失败应先检查 Event API Version、Header 名称、原始正文和 Secret 版本。版本迁移期间同一 Endpoint 可能收到不同版本 Event。

## 不可泛化部分

并非所有签名失败都是 Header 名称。服务器时钟、正文重序列化、错误 Endpoint Secret 也会产生相似表现。

