---
doc_id: KB-CASE-007
title: source 在 2026-07-01 中被移除
doc_type: support_case
authority: historical_case
product_areas: [payments, developer_platform]
api_versions: ["2026-07-01"]
effective_from: "2026-08-02"
effective_to: null
supersedes: []
account_id: acct_mosaic_learn
case_status: resolved
error_codes: [FP-4003]
rule_ids: [RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009]
related_docs: [KB-BR-007, KB-API-018, KB-TS-003, KB-REL-005, KB-REL-007, KB-REL-008]
indexing: include
language: zh-CN
---

# source 在 2026-07-01 中被移除

## 背景

Mosaic Learn 将 Account 默认版本从 `2026-04-01` 更新为 `2026-07-01`。旧结账服务仍使用 `source` 创建 Payment。

## 用户报告

升级后所有新支付返回 `FP-4003`。开发者认为 `source` 服务发生故障，因为相同请求在前一天仍成功。

## 初始假设

服务故障假设不成立。`source` 在 `2026-04-01` 只是兼容且带弃用提示，在 `2026-07-01` 已按计划移除。

## 调查过程

Request `req_MO_0802_008` 没有显式 `FlowPay-Version`，因此使用 Account 默认 `2026-07-01`。错误详情 `param=source`。部署包 `checkout_3.8.1` 仍生成 `src_MO_44`，而新服务已经生成 `pm_` ID。此前团队忽略了 2026-04-01 的弃用提示。

## 关键证据

- Account：`acct_mosaic_learn`。
- Request：`req_MO_0802_008`。
- 实际版本：`2026-07-01`。
- 参数：`source=src_MO_44`。
- 错误：`FP-4003 Removed Parameter`。

## 根因

Account 默认版本升级使旧客户端立即采用新契约，而客户端未从 `source` 迁移到 `payment_method`。

## 处理结果

团队临时固定旧服务为 `2026-04-01`，随后将请求字段和 ID 类型迁移为 `payment_method`。Sandbox 验证无弃用提示后再次升级默认版本。

## 可复用经验

修改默认版本是迁移最后一步。请求没有 Header 时仍然有实际版本，排障必须查询 Account 默认值。

## 不可泛化部分

临时回退不是长期解决方案，也不能让 `source` 在 `2026-07-01` 重新合法。其他 FP-4003 应按错误详情确认具体移除字段。

