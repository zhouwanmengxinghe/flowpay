---
doc_id: KB-CASE-016
title: 503 被误诊为 Merchant Webhook 配置错误
doc_type: support_case
authority: historical_case
product_areas: [operations, payments, webhooks]
api_versions: ["2026-07-01"]
effective_from: "2026-08-23"
effective_to: null
supersedes: []
account_id: acct_ember_cloud
case_status: resolved
error_codes: [FP-5031]
rule_ids: [RULE-ERROR-002, RULE-ERROR-003, RULE-WEBHOOK-005]
related_docs: [KB-API-007, KB-TS-018, KB-TS-023, KB-TS-024]
indexing: include
language: zh-CN
---

# 503 被误诊为 Merchant Webhook 配置错误

## 背景

Ember Cloud 位于 APAC。2026-08-23 06:10Z 至 06:24Z，部分 Payment 创建返回 `FP-5031`，失败请求没有创建 Payment 或 Event。

## 用户报告

团队观察到“订单没有 Webhook”，便认为 Endpoint URL 更新失败，并连续修改订阅和 Signing Secret。

## 初始假设

Webhook 配置错误的假设不成立。故障请求在 Payment 创建阶段已经返回 503，没有 Payment 状态变化，也就没有应投递的 Event。

## 调查过程

第一轮反复测试签名，这一步没有关联到任何 Delivery。Request `req_EM_0823_0614` 的服务字段为 Payments，且同时间窗多个 APAC Account 出现 `FP-5031`。Service Status `inc_payments_apac_20260823` 记录 Payments service degraded。已有 Event 的 Delivery 在该 Endpoint 上仍正常返回 204。

## 关键证据

- Account：`acct_ember_cloud`。
- Request：`req_EM_0823_0614`，`FP-5031`。
- Service Incident：`inc_payments_apac_20260823`。
- Endpoint：`we_EM_prod_3`，enabled。
- 对照 Delivery：`del_EM_existing_44`，HTTP 204。

## 根因

APAC Payments 服务临时降级使部分创建请求未形成 Payment/Event；Merchant Webhook 配置不是根因。

## 处理结果

团队停止修改 Webhook 配置，使用相同参数和 Idempotency Key 进行有限退避。Service Status 恢复后请求成功，随后正常产生 Event 和 Delivery。

## 可复用经验

“没有 Webhook”应先确认业务对象和 Event 是否存在。503 需要结合 Request Logs、地区和 Service Status 判断影响范围。

## 不可泛化部分

本案例不表示所有 Webhook 缺失都是平台故障，也不表示每个 FP-5031 都影响 APAC Payments；必须查询具体 Incident。

