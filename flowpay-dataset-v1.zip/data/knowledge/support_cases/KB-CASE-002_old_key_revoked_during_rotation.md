---
doc_id: KB-CASE-002
title: API Key 轮换中过早撤销旧 Key
doc_type: support_case
authority: historical_case
product_areas: [developer_platform, accounts]
api_versions: ["2026-04-01"]
effective_from: "2026-07-12"
effective_to: null
supersedes: []
account_id: acct_lumen_crm
case_status: resolved
error_codes: [FP-4011]
rule_ids: [RULE-AUTH-001, RULE-AUTH-003, RULE-AUTH-004]
related_docs: [KB-BR-006, KB-API-003, KB-TS-004, KB-TS-019]
indexing: include
language: zh-CN
---

# API Key 轮换中过早撤销旧 Key

## 背景

Lumen CRM 在 2026-07-12 轮换 Production Secret Key。Web 服务已经部署新 Key，两个延迟任务 Worker 仍运行旧配置。

## 用户报告

主站调用正常，但周期账单 Worker 持续返回 `FP-4011`。团队认为 FlowPay 在创建新 Key 后自动让旧 Key 过期，要求延长 Key 有效期。

## 初始假设

“新 Key 创建会自动使旧 Key 失效”的假设不成立。旧 Key 可以处于最长 24 小时的 `expiring` 过渡期，除非 Merchant 主动撤销。

## 调查过程

第一轮排查检查了 API Version，但认证行为与版本无关，这一步没有解释差异。对比成功请求 `req_LU_0712_web` 和失败请求 `req_LU_0712_worker` 的 Key 指纹后，发现 Worker 使用 `keyfp_LU_old7`。账户审计记录显示该 Key 在新 Key 创建后 11 分钟被管理员手动撤销。

## 关键证据

- Account：`acct_lumen_crm`。
- 成功 Request：`req_LU_0712_web`，Key 指纹 `keyfp_LU_new8`。
- 失败 Request：`req_LU_0712_worker`，Key 指纹 `keyfp_LU_old7`。
- 旧 Key 状态：`revoked`。
- 错误：`FP-4011 Invalid API Key`。

## 根因

旧 Key 在全部调用方切换前被主动撤销；不是 FlowPay 自动过期，也不是 API Version 变化。

## 处理结果

团队创建另一枚新 Key，先更新全部 Worker 并验证 Request ID，再撤销故障期间使用的旧 Key。轮换流程新增部署清单和 24 小时上限内的观察窗口。

## 可复用经验

Key 轮换应先部署、再验证、最后撤销。`revoked` 即时生效且不可恢复，不能把 `expiring` 兼容窗口当作自动保证。

## 不可泛化部分

本案例的 11 分钟来自该团队操作，不是 FlowPay 固定撤销时间。其他 FP-4011 仍需检查 Header 和 Secret 注入。

