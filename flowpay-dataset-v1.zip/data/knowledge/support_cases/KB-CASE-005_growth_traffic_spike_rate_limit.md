---
doc_id: KB-CASE-005
title: Growth Account 流量峰值触发 Rate Limit
doc_type: support_case
authority: historical_case
product_areas: [developer_platform, operations]
api_versions: ["2026-07-01"]
effective_from: "2026-07-25"
effective_to: null
supersedes: []
account_id: acct_pulse_events
case_status: resolved
error_codes: [FP-4291]
rule_ids: [RULE-RATE-001, RULE-RATE-003, RULE-RATE-004, RULE-RATE-007, RULE-PLAN-005]
related_docs: [KB-BR-005, KB-API-034, KB-TS-016, KB-TS-022]
indexing: include
language: zh-CN
---

# Growth Account 流量峰值触发 Rate Limit

## 背景

Pulse Events 在 2026-07-25 开票后，三个应用实例同时轮询 Payment。Account 使用 Growth，Production 持续上限 1,200 req/min，突发上限 1,500 req/min、最多 20 秒。

## 用户报告

HTTP 429 在开票后两分钟集中出现。开发者提供了三个实例的 Request ID，并询问是否耗尽了 Growth 突发窗口。

## 初始假设

团队初步判断总流量超过 Growth 持续上限，并且突发持续时间过长。调查重点放在 Account 聚合 Usage，而不是单个实例速率。

## 调查过程

Runtime Usage `usage_PU_0725_1000` 显示持续请求达到 1,347 req/min，峰值 1,492 持续 28 秒。虽然峰值未超过 1,500，但超过 1,200 的持续时间长于 Growth 突发窗口。三个实例使用不同 Key，但额度按 Account + Production 共享。

## 关键证据

- Account：`acct_pulse_events`，Growth。
- Usage：`usage_PU_0725_1000`。
- 样本 Request：`req_PU_0725_4297`。
- 错误：`FP-4291`。
- 套餐变更记录：无。

## 根因

开票后的并发轮询超过 Growth 持续额度，并耗尽 20 秒突发窗口。多个 Key 没有提供独立配额。

## 处理结果

团队改用 Webhook 驱动状态更新，轮询增加退避和抖动，并在应用层限制 Account 总并发。429 比例在下一次开票中恢复正常。

## 可复用经验

突发上限不是可持续速率。诊断要同时比较速率和持续时间，并聚合同一 Account 环境的所有 Key。

## 不可泛化部分

本案例不表示 Growth 总能承受 1,492 req/min；能否使用突发额度取决于时间窗和此前流量。
