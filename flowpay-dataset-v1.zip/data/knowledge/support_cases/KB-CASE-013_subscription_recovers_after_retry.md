---
doc_id: KB-CASE-013
title: Invoice 重试成功后 Subscription 恢复 active
doc_type: support_case
authority: historical_case
product_areas: [subscriptions, invoices, payments]
api_versions: ["2026-07-01"]
effective_from: "2026-08-18"
effective_to: null
supersedes: []
account_id: acct_sprout_hr
case_status: resolved
error_codes: [FP-4022]
rule_ids: [RULE-SUB-005, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005]
related_docs: [KB-BR-013, KB-BR-014, KB-API-023, KB-API-027, KB-API-028, KB-TS-007, KB-TS-021]
indexing: include
language: zh-CN
---

# Invoice 重试成功后 Subscription 恢复 active

## 背景

Sprout HR 的 Subscription `sub_SP_204` 在周期扣费首次失败后进入 `past_due`。Customer 随后补充了支付方式资金。

## 用户报告

客服看到一次 `invoice.payment_failed`，三天后 Subscription 恢复 active，团队询问这是否是正常重试流程。

## 初始假设

团队初步判断 `past_due → active` 可能来自后续 Payment 重试成功，并决定检查 Invoice 的完整 `payment_ids`。

## 调查过程

Invoice `in_SP_771` 首次 Payment `pay_SP_771_0` 于 2026-08-15 因 `FP-4022` failed，Subscription 进入 past_due。第 1 天重试 `pay_SP_771_1` 仍失败，第 3 天重试 `pay_SP_771_2` succeeded，Invoice 随即进入 paid。

## 关键证据

- Account：`acct_sprout_hr`。
- Subscription：`sub_SP_204`。
- Invoice：`in_SP_771`，状态 paid。
- Payment：`pay_SP_771_0`、`pay_SP_771_1` failed；`pay_SP_771_2` succeeded。
- 状态记录：`sub_state_SP_0818_active`。

## 根因

团队把一次 `invoice.payment_failed` 误解为全部重试耗尽。第 3 天重试成功后，系统按规则恢复 active。

## 处理结果

客服模板改为“付款失败，正在重试”，只有 Subscription 实际为 canceled 时才发送终止通知。监控同时展示 Invoice `attempt_count` 和 `next_retry_at`。

## 可复用经验

诊断周期扣费必须查看 Invoice 的全部 `payment_ids`。一笔 failed Payment 不代表 Invoice 或 Subscription 的最终结果。

## 不可泛化部分

past_due 不保证一定恢复；第 1、3、7 天重试全部失败后会进入 canceled。
