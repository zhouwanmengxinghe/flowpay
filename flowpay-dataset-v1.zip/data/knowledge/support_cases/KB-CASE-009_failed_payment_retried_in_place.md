---
doc_id: KB-CASE-009
title: failed Payment 被错误地原地重试
doc_type: support_case
authority: historical_case
product_areas: [payments]
api_versions: ["2026-07-01"]
effective_from: "2026-08-08"
effective_to: null
supersedes: []
account_id: acct_verve_games
case_status: resolved
error_codes: [FP-4021, FP-4221]
rule_ids: [RULE-PAY-001, RULE-PAY-002, RULE-ERROR-002]
related_docs: [KB-BR-010, KB-BR-011, KB-API-012, KB-API-013, KB-TS-006, KB-TS-014, KB-TS-021]
indexing: include
language: zh-CN
---

# failed Payment 被错误地原地重试

## 背景

Verve Games 的 Payment `pay_VE_443A` 因 `FP-4021` 进入 `failed`。客户随后更换了 Payment Method，客户端却继续使用原 Payment ID。

## 用户报告

团队调用 confirm 后收到 `FP-4221`，随后确认该 Payment 早已 failed，询问是否必须创建新的支付尝试。

## 初始假设

团队初步判断 `failed` 是终态，confirm 只适用于 `requires_action`，因此更换 Payment Method 后也需要新建 Payment。

## 调查过程

Request `req_VE_0808_create` 显示首次 Payment Method 被拒绝。后续 `req_VE_0808_confirm` 调用了 `/v1/payments/pay_VE_443A/confirm`，但查询结果仍为 `failed`。客户端没有为新的支付意图调用创建 Endpoint。

## 关键证据

- Account：`acct_verve_games`。
- Payment：`pay_VE_443A`，状态 `failed`。
- 首次错误：`FP-4021`。
- 后续 Request：`req_VE_0808_confirm`。
- 后续错误：`FP-4221 Invalid Payment State`。

## 根因

客户端把 failed Payment 当作 requires_action Payment 处理，对终态资源执行了非法 confirm。

## 处理结果

团队使用新 Payment Method 和新 Idempotency Key 创建 `pay_VE_443B`。前端状态分支改为：requires_action 才 confirm，failed/canceled 必须新建。

## 可复用经验

“支付失败”必须落实到准确状态和错误码。Payment Method 更新不会修改历史 Payment 的状态。

## 不可泛化部分

本案例不能说明所有 FP-4221 都来自 failed Payment；对 processing Payment 退款或对 succeeded Payment cancel 也可能触发该错误。
