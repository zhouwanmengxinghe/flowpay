---
doc_id: KB-CASE-015
title: Endpoint 未订阅新版 Payment 成功事件
doc_type: support_case
authority: historical_case
product_areas: [webhooks, payments]
api_versions: ["2026-07-01"]
effective_from: "2026-08-22"
effective_to: null
supersedes: []
account_id: acct_quartz_store
case_status: resolved
error_codes: []
rule_ids: [RULE-PAY-007, RULE-WEBHOOK-002, RULE-WEBHOOK-005, RULE-WEBHOOK-017]
related_docs: [KB-BR-015, KB-API-029, KB-API-030, KB-TS-023, KB-REL-009]
indexing: include
language: zh-CN
---

# Endpoint 未订阅新版 Payment 成功事件

## 背景

Quartz Store 将 Payment 请求升级到 `2026-07-01`，但 Production Endpoint `we_QU_prod_1` 的订阅集合仍只有旧成功事件 `payment.completed`。

## 用户报告

Payment `pay_QU_620` 已 succeeded，Merchant 却没有收到 Webhook。团队认为 FlowPay 创建了 Delivery 但重试系统丢失了记录。

## 初始假设

重试系统丢记录的假设不成立。未订阅 Event Type 时根本不会创建 Delivery，因此没有可重试记录。

## 调查过程

Event `evt_QU_620_success` 的 `api_version` 为 `2026-07-01`，类型是 `payment.succeeded`。Endpoint 状态为 enabled、环境匹配，但 `subscribed_events` 只包含 `payment.completed` 和 `payment.failed`。搜索 Delivery 未找到记录，与未订阅规则一致。

## 关键证据

- Account：`acct_quartz_store`。
- Payment：`pay_QU_620`，succeeded。
- Event：`evt_QU_620_success`，类型 `payment.succeeded`。
- Endpoint：`we_QU_prod_1`，enabled。
- 配置快照：`whcfg_QU_0822_before`。

## 根因

版本升级改变了 Payment 成功 Event 名称，Endpoint 没有订阅 `payment.succeeded`，所以没有创建 Delivery。

## 处理结果

团队增加新事件订阅，并在迁移期保留旧名称。新 Payment 产生 Delivery `del_QU_622_1` 并返回 204。历史未订阅 Event 没有自动补发。

## 可复用经验

Webhook 诊断顺序应是 Event、Endpoint 状态、订阅集合、Delivery。没有 Delivery 时先查是否应该创建，而不是直接查重试。

## 不可泛化部分

并非所有“没收到”都是订阅问题；环境不匹配、disabled、签名失败和接收端非 2xx 也可能导致相似报告。

