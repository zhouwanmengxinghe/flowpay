---
doc_id: KB-CASE-012
title: Refund 超过 180 天窗口
doc_type: support_case
authority: historical_case
product_areas: [refunds, payments]
api_versions: ["2026-07-01"]
effective_from: "2026-08-16"
effective_to: null
supersedes: []
account_id: acct_kite_analytics
case_status: resolved
error_codes: [FP-4222]
rule_ids: [RULE-REFUND-001, RULE-REFUND-005]
related_docs: [KB-BR-012, KB-API-014, KB-API-020, KB-API-022, KB-TS-015]
indexing: include
language: zh-CN
---

# Refund 超过 180 天窗口

## 背景

Kite Analytics 在 2026-08-16 处理一笔历史订单退款。Payment `pay_KI_20260115` 于 2026-01-15T09:00:00Z succeeded，且没有既有 Refund。

## 用户报告

全额退款返回 `FP-4222`。团队看到 `refunded_amount=0`，认为可退款额度计算错误；另一位开发者猜测是 API Version `2026-07-01` 改成同步退款造成的。

## 初始假设

两种假设都不成立。没有既有退款不等于仍在退款期限内；同步确认变化也没有改变 180 天窗口。

## 调查过程

支持人员核对 Payment `succeeded_at` 和 Refund Request `req_KI_0816_refund` 的 UTC 时间。窗口从 Payment 成功时间计算，到请求发生时已明显超过 180 天。订单创建时间和版本发布日期均与期限计算无关。

## 关键证据

- Account：`acct_kite_analytics`。
- Payment：`pay_KI_20260115`，succeeded。
- 成功时间：2026-01-15T09:00:00Z。
- Refund Request：`req_KI_0816_refund`。
- 错误：`FP-4222 Refund Window Expired`。

## 根因

Refund 请求发生在 Payment 成功超过 180 天后，违反退款时限。

## 处理结果

FlowPay API 未创建 Refund。Merchant 按自身客户政策在 FlowPay 之外处理后续补偿，并在批量退款任务中增加 `succeeded_at` 窗口过滤。

## 可复用经验

退款期限使用 Payment `succeeded_at` 的绝对 UTC 时间。额度、套餐和状态满足时，期限仍是独立必要条件。

## 不可泛化部分

本案例不规定 Merchant 在 FlowPay 之外如何补偿，也不能用外部补偿伪造 FlowPay Refund 状态。

