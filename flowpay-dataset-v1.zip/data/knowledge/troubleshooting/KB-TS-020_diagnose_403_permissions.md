---
doc_id: KB-TS-020
title: 403 套餐权限与 Production 暂停诊断
doc_type: troubleshooting
authority: operational_guidance
product_areas: [accounts, developer_platform]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4031, FP-4032]
rule_ids: [RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004, RULE-AUTH-007, RULE-AUTH-008]
related_docs: [KB-BR-002, KB-BR-004, KB-API-005, KB-TS-010, KB-TS-011, KB-TS-019]
indexing: include
language: zh-CN
---

# 403 套餐权限与 Production 暂停诊断

## 现象

认证通过后请求返回 HTTP 403。FlowPay 使用 `FP-4031` 表示功能不在套餐权限内，使用 `FP-4032` 表示整个 Account 的 Production 访问被暂停。

## 决策路径

| 错误码 | 诊断方向 | 关键查询 |
| --- | --- | --- |
| `FP-4031` | 套餐、功能开关、地区和功能附加条件 | Account 已生效套餐、变更时间、Feature Flag |
| `FP-4032` | Production Account 状态 | `production_enabled`、暂停状态、状态时间线 |

## 需要确认的事实

确认 Request ID、请求环境、目标功能、已生效套餐、套餐变更生效时间、Feature Flag 和 Production 暂停状态。用户称“刚升级”或“没有降级”都只是陈述，需要账户数据验证。

## 推荐诊断步骤

1. 精确读取 `error.code`。
2. `FP-4031`：识别受限功能，核对套餐矩阵和 Feature Flag。
3. 检查地区、金额等附加条件，例如 Instant Refund。
4. `FP-4032`：查询 Account Production 暂停状态。
5. 确认 Sandbox 是否独立正常，但不要用它证明 Production 恢复。
6. 修复后进行小流量验证。

## 处理方式

套餐错误应使用套餐支持的能力或完成升级；Production 暂停应走账户恢复流程。创建更多 API Key 无法绕过这两种 Account 级约束。

## 不应做出的判断

HTTP 403 本身不能说明是哪一种权限问题。FP-4031 不证明 Production 被暂停，FP-4032 也不表示套餐降级。若 Key 无效或环境错，应返回 401 类错误。

## 相关文档

- 套餐权限见 `KB-BR-004`，环境与暂停见 `KB-BR-002`。
- 单错误码文档见 `KB-TS-010`、`KB-TS-011`。

