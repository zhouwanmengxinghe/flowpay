---
doc_id: KB-TS-003
title: FP-4003 Removed Parameter
doc_type: troubleshooting
authority: operational_guidance
product_areas: [developer_platform, payments]
api_versions: ["2026-07-01"]
effective_from: "2026-07-01"
effective_to: null
supersedes: []
error_codes: [FP-4003]
rule_ids: [RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009]
related_docs: [KB-BR-007, KB-API-006, KB-API-013, KB-API-018, KB-TS-001, KB-TS-002]
indexing: include
language: zh-CN
---

# FP-4003 Removed Parameter

## 现象

API 返回 HTTP 400 和 `FP-4003`，错误详情指出请求包含当前 API Version 已移除的参数。V1 的主要案例是在 `2026-07-01` 创建 Payment 时继续发送 `source`。

## 含义

参数曾在旧版本中合法，但在请求实际采用的版本中已不再接受。这不是临时服务故障，也不是简单重试可以解决的格式问题。

## 常见原因

- Account 默认版本升级后，旧客户端仍发送 `source`。
- 某个实例显式设置 `2026-07-01`，但部署包仍使用旧请求模型。
- SDK 已升级，业务封装层仍注入旧字段。
- 灰度环境中不同实例使用不同版本和参数。
- 只阅读了旧 API 文档，忽略 Release/Migration Guide。

## 需要确认的事实

确认 Request ID、实际 `FlowPay-Version`、错误中的 `param`、Account 默认版本以及客户端构建版本。若 Header 缺失，实际版本来自 Account 默认值。

## 推荐诊断步骤

1. 用 Request ID 确认实际请求版本和字段。
2. 检查是否为 `2026-07-01 + source`。
3. 查找仍生成旧字段的服务实例或公共封装层。
4. 在 `2026-04-01` 下先迁移到 `payment_method` 并消除弃用提示。
5. 验证 Webhook 事件名称也已完成版本迁移。

## 处理方式

将 `source` 改为 `payment_method`，并按新版本契约重新测试。不要通过静默删除未知字段绕过问题，因为该字段可能承载必要 Payment Method。

## 不应做出的判断

FP-4003 不表示 Payment Method 被拒绝，也不表示 FlowPay 不支持该 Account。若实际版本不是 `2026-07-01`，应重新检查错误详情和请求路径。

## 相关文档

- Payment 参数兼容见 `KB-API-018`，创建接口见 `KB-API-013`。
- 版本选择见 `KB-API-006`。

