---
doc_id: KB-TS-004
title: FP-4011 Invalid API Key
doc_type: troubleshooting
authority: operational_guidance
product_areas: [developer_platform, accounts]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4011]
rule_ids: [RULE-AUTH-001, RULE-AUTH-003, RULE-AUTH-004, RULE-ERROR-002]
related_docs: [KB-BR-006, KB-API-003, KB-API-007, KB-API-008, KB-TS-005, KB-TS-019]
indexing: include
language: zh-CN
---

# FP-4011 Invalid API Key

## 现象

API 返回 HTTP 401 和 `FP-4011`。请求已到达网关并获得 Request ID，但认证未通过。

## 含义

Authorization Header 缺失，Bearer 格式错误，Key 未知、被截断或已处于 `revoked`。Key 轮换后旧 Key 如果被提前撤销，也会出现该错误。

## 常见原因

- 环境变量未注入，Header 实际为空。
- Key 前后含引号、换行或多余空格。
- 部署使用了已撤销的旧 Key。
- Secret Manager 路径指向错误版本。
- 日志脱敏后的值被误当作真实 Key。
- 请求使用了不存在的 Key。

## 需要确认的事实

通过 Request ID 确认 Authorization Header 是否存在和 Key 指纹，不要输出完整 Key。查询 Account Key 列表，核对 Key 所属环境、状态、轮换时间和撤销时间。

## 推荐诊断步骤

1. 检查 Header 是否为 `Authorization: Bearer <key>`。
2. 对比安全指纹，而不是在聊天或日志中复制完整 Key。
3. 查询 Key 当前状态是 `active`、`expiring` 还是 `revoked`。
4. 检查最近轮换是否仍有旧实例。
5. 使用新 Key 发起最小读取请求验证。

## 处理方式

修正 Secret 注入或部署新 Key。已撤销 Key 不可恢复，应创建新 Key并完成安全轮换。不要把 Key 放进客户端代码。

修复后应观察是否仍有旧实例继续产生 401；一次成功请求只能证明该实例使用的新 Key 有效，不能证明全部部署节点已经切换。

## 不应做出的判断

FP-4011 不等于环境不匹配；有效 Key 访问错误环境使用 `FP-4012`。Production 暂停使用 `FP-4032`，Key 本身可能仍有效。

## 相关文档

- Key 生命周期见 `KB-BR-006`，认证格式见 `KB-API-003`。
- 401 综合决策见 `KB-TS-019`。
