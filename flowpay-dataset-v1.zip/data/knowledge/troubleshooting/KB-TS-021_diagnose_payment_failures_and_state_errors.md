---
doc_id: KB-TS-021
title: Payment 失败与状态错误诊断
doc_type: troubleshooting
authority: operational_guidance
product_areas: [payments, refunds]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4021, FP-4022, FP-4023, FP-4024, FP-4221]
rule_ids: [RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-ERROR-002]
related_docs: [KB-BR-010, KB-BR-011, KB-API-012, KB-API-014, KB-TS-006, KB-TS-007, KB-TS-008, KB-TS-009, KB-TS-014]
indexing: include
language: zh-CN
---

# Payment 失败与状态错误诊断

## 现象

用户说“支付失败”可能指请求在认证、参数或限流阶段被拒绝，也可能指已经创建的 Payment 进入 `failed`。先确认是否存在 `payment_id`，再读取 Payment 当前状态和 `error.code`。

## 错误分类

| 错误码 | 含义 | 下一步 |
| --- | --- | --- |
| `FP-4021` | Payment Method 被拒绝 | 更换支付方式，新建 Payment |
| `FP-4022` | 资金不足 | 核对金额，补充资金或更换方式 |
| `FP-4023` | 需要客户操作 | 按 API Version 处理 |
| `FP-4024` | Payment Method 过期 | 更新方式，新建 Payment |
| `FP-4221` | 当前状态不允许请求动作 | 查询状态，选择合法动作 |

## 版本分支

`2025-10-01` 的客户额外操作表现为 `failed + FP-4023`；从 `2026-01-15` 起表现为 `requires_action`。新版本完成 `next_action` 后 confirm 原 Payment；旧版 failed Payment 必须新建。

## 需要确认的事实

查询 Request ID、Payment ID、实际 API Version、当前状态、错误码、金额和 Payment Method 标识。若是 Invoice 扣费，还需查询 Invoice 的全部 `payment_ids`，因为后续重试可能成功。

## 推荐诊断步骤

1. 确认请求是否创建了 Payment。
2. 读取最新状态，避免使用缓存。
3. 按具体错误码分类，不只看 HTTP 402/422。
4. 检查版本是否需要 `requires_action` 流程。
5. failed/canceled 重新收款必须新建 Payment。
6. succeeded 需要退款时转入 Refund 资格检查。

## 处理方式

根据具体错误码向客户提供对应动作。`requires_action` 完成现有 Payment 流程；`failed` 或 `canceled` 的再次收款创建新 Payment；状态非法时先刷新对象再选择允许动作。

## 不应做出的判断

单个 HTTP 402 不能统一解释为余额不足。`processing` 不表示失败，confirm HTTP 200 也不表示最终 succeeded。

## 相关文档

- 状态机见 `KB-BR-010`，失败分类见 `KB-BR-011`。
- 单错误文档见 `KB-TS-006`～`KB-TS-009`、`KB-TS-014`。
