---
doc_id: KB-TS-024
title: 区分 500 内部错误与 503 服务降级
doc_type: troubleshooting
authority: operational_guidance
product_areas: [operations, developer_platform]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-5001, FP-5031]
rule_ids: [RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-IDEMP-004, RULE-RATE-007]
related_docs: [KB-API-007, KB-API-008, KB-API-033, KB-TS-017, KB-TS-018]
indexing: include
language: zh-CN
---

# 区分 500 内部错误与 503 服务降级

## 现象

调用方观察到 `FP-5001`、`FP-5031`，或同一时间窗混合出现 HTTP 500 和 503，需要判断是孤立请求异常还是服务层降级。

## 核心区别

| 错误码 | 表达重点 | 需要验证 |
| --- | --- | --- |
| `FP-5001` | 请求在平台内部处理失败 | 是否为单请求、特定资源或更广问题 |
| `FP-5031` | 所需服务暂时处于降级状态 | 影响服务、地区、时间窗和 Incident |

两者都不应直接归因于 Merchant 配置，也都需要运行时数据确定真实范围。

## 需要确认的事实

收集 Request ID、绝对时间、Account 地区、Endpoint、API Version 和失败比例。查询 Request Logs、同时间窗其他 Account 的错误分布和 Service Status。对创建操作查询是否已经产生资源。

## 推荐诊断步骤

1. 精确区分 `FP-5001` 与 `FP-5031`。
2. 用 Request ID 定位服务和请求结果。
3. 比较同一 Account 其他请求和其他 Account 同类请求。
4. 查询 Service Status 是否存在匹配 Incident。
5. 区分孤立、局部和广泛影响。
6. 恢复后观察一段时间，而不是以一次成功宣告彻底恢复。

## 安全重试

GET 可以有限指数退避重试。创建 Payment、Refund 或 Subscription 必须保持相同参数和 Idempotency Key，并先确认首次请求是否已创建资源。设置最大次数，避免把降级扩大为重试风暴。

## 处理方式

孤立 500 应提交 Request ID 做平台调查；广泛 503 应依据 Service Status 管理降级和恢复。面向用户的错误提示应说明临时不可用，不泄露内部实现。

## 不应做出的判断

一个 Account 的一个 500 不能证明全平台 Incident。一个 503 也不能证明 Webhook 配置错误。重试成功不代表首次请求没有副作用。

## 相关文档

- Request ID 和幂等见 `KB-API-007`、`KB-API-033`。
- 单错误文档见 `KB-TS-017`、`KB-TS-018`。
