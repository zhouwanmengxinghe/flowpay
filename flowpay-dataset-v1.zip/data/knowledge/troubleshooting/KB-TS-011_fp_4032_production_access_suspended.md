---
doc_id: KB-TS-011
title: FP-4032 Production Access Suspended
doc_type: troubleshooting
authority: operational_guidance
product_areas: [accounts, developer_platform]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4032]
rule_ids: [RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-003, RULE-ERROR-002]
related_docs: [KB-BR-002, KB-API-003, KB-API-004, KB-API-005, KB-TS-010, KB-TS-020]
indexing: include
language: zh-CN
---

# FP-4032 Production Access Suspended

## 现象

Production API 返回 HTTP 403 和 `FP-4032`。现有 `sk_live_` Key 可能仍被识别，但 Account 的 Production 访问当前处于暂停状态。

## 含义

这是 Account 级 Production 权限状态，不是 Key 撤销，也不是套餐功能缺失。暂停不会删除 Key 或历史 Production 资源。Sandbox 不受影响。

## 常见原因

- Account 的 Production 访问被平台暂停。
- 部署仅检查 Key 是否存在，没有检查 Account Production 状态。
- 团队看到 Sandbox 正常，误以为 Production 也应正常。
- 用户将该错误误认为套餐降级或 `FP-4031`。

## 需要确认的事实

查询 Account 的 `production_enabled`、Production 暂停状态、状态变更时间和请求环境。确认 Request ID 使用的是 `sk_live_`，并核对 Sandbox 是否只是独立正常。

## 推荐诊断步骤

1. 区分 `FP-4032` 与 `FP-4011`、`FP-4012`、`FP-4031`。
2. 查询 Account 当前 Production 状态。
3. 确认请求确实发生在 Production。
4. 检查暂停影响范围和恢复条件。
5. 恢复后用最小请求验证，不直接放开全部积压流量。

## 处理方式

按 Account 状态处理流程解除暂停。不要通过创建更多 Key 规避，因为暂停应用于整个 Account 的 Production 访问。

## 不应做出的判断

FP-4032 不表示套餐不支持某功能，也不说明 Sandbox 资源可用于 Production。Sandbox 成功不能证明 Production 已恢复。

## 相关文档

- 环境政策见 `KB-BR-002`。
- Production 启用和暂停见 `KB-API-005`。
- 403 综合诊断见 `KB-TS-020`。

