---
doc_id: KB-TS-005
title: FP-4012 Environment Mismatch
doc_type: troubleshooting
authority: operational_guidance
product_areas: [developer_platform, accounts]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4012]
rule_ids: [RULE-ENV-001, RULE-ENV-004, RULE-ENV-005, RULE-TENANT-004, RULE-AUTH-002]
related_docs: [KB-BR-002, KB-API-003, KB-API-004, KB-API-005, KB-TS-004, KB-TS-019]
indexing: include
language: zh-CN
---

# FP-4012 Environment Mismatch

## 现象

API 返回 HTTP 401 和 `FP-4012`。Key 可以被识别，但其所属环境与目标资源或操作环境不同。

## 含义

Sandbox 与 Production 是独立资源空间。`sk_test_` 只能访问 Sandbox，`sk_live_` 只能访问 Production。相同 Account 也不能跨环境引用 Customer、Payment、Event 或 Webhook Endpoint。

## 常见原因

- Production 部署仍使用 `sk_test_`。
- 将 Sandbox `customer_id` 或 `payment_id` 写入 Production 订单。
- 测试任务意外读取 Production Secret。
- Webhook Event 和 Endpoint 分属不同环境。
- 配置文件切换了 Key，但数据库中的资源 ID 没有切换。

## 需要确认的事实

确认 Request ID、Key 前缀和安全指纹、Key 所属环境、目标资源环境以及调用服务的部署环境。资源具体环境需要查询业务记录，不能只从 ID 前缀推断。

## 推荐诊断步骤

1. 确认当前进程实际加载的 Key 前缀。
2. 查询 Key 所属 Account 和环境。
3. 查询目标资源所属环境。
4. 检查 Merchant 的 Sandbox/Production ID 映射是否混用。
5. 使用匹配环境的资源重新测试。

## 处理方式

在目标环境重新创建或查找正确资源，并使用匹配 Secret Key。不要尝试把 Sandbox 资源转移到 Production；FlowPay 不支持跨环境迁移。

## 不应做出的判断

FP-4012 不表示 Key 已撤销，也不表示目标资源一定不存在。若 Key 无效应为 `FP-4011`；若资源属于其他 Account，通常使用 `FP-4041` 的不可见语义。

## 相关文档

- 环境政策见 `KB-BR-002`。
- Sandbox 和 Production 操作见 `KB-API-004`、`KB-API-005`。
- 401 综合诊断见 `KB-TS-019`。

