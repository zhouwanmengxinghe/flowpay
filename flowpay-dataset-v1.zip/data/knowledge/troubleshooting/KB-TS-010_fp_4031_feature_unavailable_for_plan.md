---
doc_id: KB-TS-010
title: FP-4031 Feature Unavailable for Plan
doc_type: troubleshooting
authority: operational_guidance
product_areas: [accounts, developer_platform, subscriptions, refunds, webhooks]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4031]
rule_ids: [RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-004, RULE-REGION-003]
related_docs: [KB-BR-004, KB-API-005, KB-API-021, KB-API-024, KB-API-029, KB-TS-011, KB-TS-020]
indexing: include
language: zh-CN
---

# FP-4031 Feature Unavailable for Plan

## 现象

API 返回 HTTP 403 和 `FP-4031`。认证已经通过，但当前已生效套餐不允许请求的功能，或必要 Feature Flag 未在套餐边界内开启。

典型场景是 Starter Account 使用 active Customer 创建 Subscription：即使 Customer 状态正常、请求参数全部合法，仍会因为 Starter 套餐不支持 Subscription 而被拒绝。普通 Payment 可以创建成功，也不能证明同一账户具备 Subscription 权限。

## 含义

FlowPay 拒绝功能级操作，例如 Starter 创建部分 Refund、Starter 创建 Subscription、非 Scale 自定义 Webhook 重试，或不满足套餐资格时使用 Instant Refund。

## 常见原因

- Account 实际是 Starter，但客户端假设为 Growth。
- 套餐升级尚未完成，或降级已在周期末生效。
- `subscriptions` 或 `instant_refund` 开关未开启。
- 功能还受地区、金额或其他附加条件限制。
- 调用方把 Production 暂停误诊为套餐错误；后者应为 `FP-4032`。

## 需要确认的事实

查询 Account 当前已生效套餐、套餐变更生效时间、相关 Feature Flag、主地区和请求功能。只看用户提交的升级申请不能证明新套餐已生效。

## 推荐诊断步骤

1. 确认错误码是 `FP-4031` 而非 `FP-4032`。
2. 识别请求属于哪项受限功能。
3. 查询请求发生时的已生效套餐。
4. 检查必要 Feature Flag 和地区等附加条件。
5. 选择套餐支持的操作或完成合规升级。

## 处理方式

修正功能使用方式，或在业务允许时升级套餐并等待生效。功能开关不能越过套餐硬限制，不应通过反复写入开关绕过错误。

## 不应做出的判断

FP-4031 不能证明 Secret Key 无效，也不能证明 Production 被平台暂停。Scale 身份也不自动保证 Instant Refund，仍需地区、开关和金额条件。

## 相关文档

- 套餐权限见 `KB-BR-004`。
- 部分退款、Subscription 和 Endpoint 见 `KB-API-021`、`KB-API-024`、`KB-API-029`。
- 403 综合诊断见 `KB-TS-020`。
