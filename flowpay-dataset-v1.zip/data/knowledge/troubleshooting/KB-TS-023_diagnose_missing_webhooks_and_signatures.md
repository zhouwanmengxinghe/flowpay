---
doc_id: KB-TS-023
title: Webhook 未收到与签名失败诊断
doc_type: troubleshooting
authority: operational_guidance
product_areas: [webhooks, operations]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: []
rule_ids: [RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-012, RULE-WEBHOOK-013, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018]
related_docs: [KB-BR-015, KB-BR-016, KB-API-029, KB-API-030, KB-API-031, KB-API-032]
indexing: include
language: zh-CN
---

# Webhook 未收到与签名失败诊断

## 现象

业务对象已经成功或发生状态变化，但 Merchant 没看到预期通知；或者接收端有请求记录，却因签名缺失、签名不匹配或时间戳超限而拒绝处理。

## 分清三个阶段

```text
业务状态变化 → Event 产生 → Delivery 创建 → Merchant 验证和处理
```

“Payment 已成功但没收到 Webhook”可能在任一阶段出现问题。Payment 状态不能证明 Endpoint 订阅和 Delivery 结果。

## 需要确认的事实

查询业务对象状态和 Event ID；查询 Endpoint 所属 Account、环境、状态和 `subscribed_events`；查询 Delivery 的 HTTP 状态、重试次数和响应时间。签名失败还需确认 Event API Version、Header 名称、Secret 轮换时间和 Merchant 服务器时钟。

## 推荐诊断步骤

1. 确认业务对象确实达到会产生 Event 的状态。
2. 根据实际 API Version 确定 Event Type：成功 Payment 可能是 `payment.completed` 或 `payment.succeeded`。
3. 检查 Endpoint 是否同 Account、同环境且 `enabled`。
4. 检查是否订阅实际 Event Type。
5. 查找 Delivery；没有记录时不要先排查签名。
6. 有 Delivery 时查看 2xx、3xx、4xx、5xx 或超时。
7. 到达但签名失败时，检查 Header、原始正文、Secret 和 5 分钟时钟容差。

## 处理方式

修复订阅、Endpoint 状态或接收端响应。签名验证必须使用原始请求体；Secret 轮换后在 24 小时内兼容新旧值。消费者按 `event_id` 去重并尽快返回 2xx。

## 不应做出的判断

没有 Delivery 不等于 FlowPay 重试失败，也可能是未订阅或环境错。签名失败不等于未发送。重复 Event 不一定对应重复 Payment。

## 相关文档

- 投递规则见 `KB-BR-015`，签名政策见 `KB-BR-016`。
- Endpoint、Event、签名和重试见 `KB-API-029`～`KB-API-032`。
