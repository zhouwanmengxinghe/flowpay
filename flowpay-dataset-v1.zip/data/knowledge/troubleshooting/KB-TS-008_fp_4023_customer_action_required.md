---
doc_id: KB-TS-008
title: FP-4023 Customer Action Required
doc_type: troubleshooting
authority: operational_guidance
product_areas: [payments, developer_platform]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4023]
rule_ids: [RULE-PAY-001, RULE-PAY-002, RULE-PAY-005, RULE-VERSION-005]
related_docs: [KB-BR-010, KB-BR-011, KB-API-006, KB-API-012, KB-API-015, KB-TS-006, KB-TS-021]
indexing: include
language: zh-CN
---

# FP-4023 Customer Action Required

## 现象

终端客户需要完成额外验证。`2025-10-01` 中 Payment 进入 `failed` 并返回 `FP-4023`；从 `2026-01-15` 起，同类场景使用 `requires_action` 状态和 `next_action`，不一定以错误终结。

## 含义

处理不能在没有客户参与的情况下继续。正确动作取决于请求实际 API Version，不能只按错误码文本处理。

## 常见原因

- 客户未完成额外验证。
- 前端没有处理 `next_action`。
- 后端升级了 API Version，前端仍把新状态当作普通失败。
- Merchant 对旧版 failed Payment 调用 confirm。
- 请求显式版本与 Account 默认版本不同。

## 需要确认的事实

查询 Request ID、Payment ID、创建请求实际版本、当前状态和 `next_action`。不要只看 Account 当前默认版本，因为单次请求可能通过 Header 覆盖。

## 推荐诊断步骤

1. 确认 Payment 创建时采用的 API Version。
2. `2025-10-01`：确认 Payment 已 failed，完成客户操作后创建新 Payment。
3. `2026-01-15` 及以后：若状态为 `requires_action`，向客户呈现 `next_action`。
4. 客户完成后调用 confirm。
5. 查询最终状态，不把 confirm HTTP 200 当成支付成功。

## 处理方式

新版本应完整实现 `requires_action → confirm → processing` 流程。旧版本不能恢复 failed Payment，应新建支付尝试。

## 不应做出的判断

该现象不等于 Payment Method 被永久拒绝，也不等于资金不足。看到 `FP-4023` 时也不能忽略版本差异直接调用 confirm。

## 相关文档

- 状态机见 `KB-BR-010`。
- 版本 Header 见 `KB-API-006`，confirm 见 `KB-API-015`。
- 综合诊断见 `KB-TS-021`。

