---
doc_id: KB-TS-015
title: FP-4222 Refund Window Expired
doc_type: troubleshooting
authority: operational_guidance
product_areas: [refunds, payments]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4222]
rule_ids: [RULE-REFUND-001, RULE-REFUND-005]
related_docs: [KB-BR-012, KB-API-014, KB-API-020, KB-API-021, KB-API-022, KB-TS-014]
indexing: include
language: zh-CN
---

# FP-4222 Refund Window Expired

## 现象

创建全额或部分 Refund 时返回 HTTP 422 和 `FP-4222`。Payment 可能是 succeeded 且仍有金额，但成功时间已经超过退款期限。

## 含义

FlowPay V1 只允许在 Payment 成功后的 180 天内创建 Refund。时间从 `succeeded_at` 计算，不从订单创建时间、首次退款时间或 Webhook 到达时间计算。

## 常见原因

- Merchant 使用订单创建时间估算窗口。
- 历史 Payment 延迟成功，系统保存了错误基准时间。
- 时区转换把 UTC 时间解释为本地日期。
- 只检查 `refundable_amount` 缓存，没有重新读取 Payment。
- 批量退款任务处理了超过期限的旧交易。

## 需要确认的事实

查询 Payment 当前状态、精确 `succeeded_at`、Refund 请求时间和 UTC 时区。确认 Payment ID 是否正确，以及此前是否已有退款。不要用 Support Ticket 创建时间代替业务时间。

## 推荐诊断步骤

1. 查询 Payment 并确认状态为 succeeded。
2. 读取 `succeeded_at` UTC 时间。
3. 计算请求时是否已超过 180 天。
4. 检查客户端是否使用了错误时区或订单时间。
5. 对批量任务增加窗口过滤。

## 处理方式

超过窗口后 FlowPay API 不再接受 Refund。Merchant 应按照自身客户政策选择 API 外的后续处理方式，但不得伪造或回写 FlowPay Refund 状态。

## 不应做出的判断

FP-4222 不表示 Payment 状态非法；状态非法使用 `FP-4221`。它也不表示套餐不支持部分退款，后者通常使用 `FP-4031`。

## 相关文档

- 退款时限见 `KB-BR-012`。
- Payment 查询和退款额度见 `KB-API-014`、`KB-API-022`。

