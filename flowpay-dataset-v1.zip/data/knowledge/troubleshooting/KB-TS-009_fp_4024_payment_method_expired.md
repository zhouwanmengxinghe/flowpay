---
doc_id: KB-TS-009
title: FP-4024 Payment Method Expired
doc_type: troubleshooting
authority: operational_guidance
product_areas: [payments]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4024]
rule_ids: [RULE-PAY-001, RULE-PAY-002, RULE-ERROR-002]
related_docs: [KB-BR-011, KB-API-004, KB-API-012, KB-API-013, KB-TS-006, KB-TS-007, KB-TS-021]
indexing: include
language: zh-CN
---

# FP-4024 Payment Method Expired

## 现象

Payment 返回 HTTP 402 和 `FP-4024`，通常进入 `failed`。Sandbox 中可用 `pm_test_expired` 验证客户端处理。

## 含义

请求引用的 Payment Method 已过有效期，不能用于完成本次收款。FlowPay V1 将其与一般拒绝和资金不足分开编码。

## 常见原因

- Customer 保存的默认 Payment Method 过期。
- Subscription 长期使用旧 Payment Method，续费时才暴露问题。
- 客户已更新支付方式，但 Merchant 仍引用旧 ID。
- 重试逻辑复用了原 failed Payment 或旧请求参数。

## 需要确认的事实

查询 Payment、Customer 或 Subscription 当前引用的 Payment Method ID、错误码和失败时间。确认 Merchant 系统中新旧 Payment Method 映射。不要把敏感支付信息写入日志。

## 推荐诊断步骤

1. 通过 Payment ID 确认 `FP-4024` 和 failed 状态。
2. 确认请求使用的 Payment Method ID。
3. 引导客户提供新的有效 Payment Method。
4. 更新 Merchant 侧映射或后续 Subscription 使用信息。
5. 创建新 Payment；不要尝试恢复原 failed Payment。

## 处理方式

更换 Payment Method 后重新发起收款。对于 Subscription，还应确保后续 Invoice 扣费引用已更新的方式，否则重试可能继续失败。

## 不应做出的判断

FP-4024 不表示 Customer 资源已删除，也不表示 API Key 或 Account 过期。它只描述本次 Payment Method 的有效性结果。

## 相关文档

- Payment 失败分类见 `KB-BR-011`。
- Payment 对象和创建见 `KB-API-012`、`KB-API-013`。
- 综合 Payment 诊断见 `KB-TS-021`。

