---
doc_id: KB-TS-018
title: FP-5031 Service Temporarily Degraded
doc_type: troubleshooting
authority: operational_guidance
product_areas: [operations, developer_platform]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-5031]
rule_ids: [RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-IDEMP-004]
related_docs: [KB-API-007, KB-API-008, KB-API-033, KB-TS-017, KB-TS-024]
indexing: include
language: zh-CN
---

# FP-5031 Service Temporarily Degraded

## 现象

API 返回 HTTP 503 和 `FP-5031`，表示处理请求所需的 FlowPay 服务暂时降级。错误通常带有 Request ID。

## 含义

平台当前无法在正常服务水平下处理请求。影响可能局限于某个服务、地区或时间窗，也可能更广。错误本身不说明某个 Merchant 配置错误。

## 常见原因

- Payments、Webhooks 或其他内部服务处于降级状态。
- 区域性服务事件。
- 上游依赖暂时不可用。
- 服务恢复期间仍有少量失败请求。

以上都必须由 Service Status 和 Request Logs 验证。

## 需要确认的事实

确认 Request ID、服务 Endpoint、Account 地区、时间范围、失败比例和 Service Status。检查是所有 Account 都受影响，还是单 Account 仅在特定请求上失败。

## 推荐诊断步骤

1. 用 Request ID 定位服务和时间。
2. 查询 Service Status 是否存在对应 Incident。
3. 比较同时间窗其他 Account 和 Endpoint 的错误率。
4. 检查恢复后请求是否成功。
5. 对创建操作确认幂等和首次结果。

## 处理方式

使用有上限的指数退避。创建 Payment、Refund 或 Subscription 时保持相同 Idempotency Key。若 Incident 持续，向调用方展示临时不可用状态，避免重试风暴。

## 不应做出的判断

FP-5031 不表示 Secret Key、套餐或 Webhook Endpoint 配置有误。Merchant 未收到 Webhook 也不能只凭一个 503 断言 Webhook 服务是根因，需查询具体 Delivery。

## 相关文档

- 错误格式和幂等见 `KB-API-008`、`KB-API-033`。
- 500 与 503 综合区分见 `KB-TS-024`。

