---
doc_id: KB-TS-012
title: FP-4041 Resource Not Found or Not Visible
doc_type: troubleshooting
authority: operational_guidance
product_areas: [developer_platform]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4041]
rule_ids: [RULE-TENANT-002, RULE-TENANT-003, RULE-TENANT-004, RULE-ENV-001]
related_docs: [KB-BR-001, KB-BR-002, KB-API-014, KB-API-022, KB-API-028]
indexing: include
language: zh-CN
---

# FP-4041 Resource Not Found or Not Visible

## 现象

资源读取或动作请求返回 HTTP 404 和 `FP-4041`。FlowPay 使用相同响应表示“资源不存在”和“资源对当前 Account 或环境不可见”。

## 含义

该设计避免通过错误差异枚举其他租户资源。仅凭 FP-4041 不能确定 ID 拼写错误、资源属于另一个 Account，还是 Sandbox/Production 混用。

## 常见原因

- 资源 ID 拼写错误或截断。
- 使用 Account A 的 Key 查询 Account B 的资源。
- Production Key 查询 Sandbox ID，或反向查询。
- Merchant 保存了过期或错误的资源映射。
- 将 Request ID、Event ID 当作 Payment ID 使用。

## 需要确认的事实

确认 Request ID、Endpoint 路径、资源 ID 类型、Key 所属 Account 与环境，以及 Merchant 侧创建资源时保存的映射。不要尝试通过其他 Account Key 枚举资源。

## 推荐诊断步骤

1. 根据 ID 前缀确认资源类型与 Endpoint 匹配。
2. 检查完整 ID 是否被截断。
3. 查询 Key 的 Account 和环境。
4. 从资源创建响应或 Merchant 映射确认资源来源。
5. 在正确 Account 和环境中重试读取。

## 处理方式

修复资源 ID 映射或环境配置。若目标资源确实未创建，应按业务流程创建新资源，而不是复用另一个环境的 ID。

## 不应做出的判断

FP-4041 不能证明资源已经被删除，也不能证明其他 Account 中不存在同名 ID。它也不同于有效 Key 访问错误环境时可能出现的 `FP-4012`，应结合请求上下文判断。

## 相关文档

- 租户隔离见 `KB-BR-001`，环境隔离见 `KB-BR-002`。
- Payment、Refund、Invoice 查询见 `KB-API-014`、`KB-API-022`、`KB-API-028`。

