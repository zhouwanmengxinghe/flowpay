---
doc_id: KB-TS-016
title: FP-4291 Rate Limit Exceeded
doc_type: troubleshooting
authority: operational_guidance
product_areas: [developer_platform, operations]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4291]
rule_ids: [RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007, RULE-PLAN-005]
related_docs: [KB-BR-005, KB-API-004, KB-API-034, KB-TS-022]
indexing: include
language: zh-CN
---

# FP-4291 Rate Limit Exceeded

## 现象

API 返回 HTTP 429 和 `FP-4291`。`2026-07-01` 响应还可能包含 `FlowPay-RateLimit-Reset` 秒数。

## 含义

当前 Account 和环境在持续或突发窗口中超过调用额度。所有 Key 和 Endpoint 共享该 Account 环境的额度；创建更多 Key 不会提高上限。

## 常见原因

- 正常流量峰值超过持续或突发上限。
- 多个服务或 Key 同时共享同一额度。
- 客户端收到 429 后立即并发重试，形成重试风暴。
- Sandbox 测试错误套用 Production 套餐上限。
- 套餐降级已经生效，但客户端仍按旧上限发送。

## 需要确认的事实

查询请求环境、请求发生时已生效套餐、Runtime Usage、突发窗口、多个调用方和重试模式。仅凭 FP-4291 不能确定是套餐变化还是流量上升。

## 推荐诊断步骤

1. 以 Request ID 和时间定位 429。
2. 区分 Sandbox 固定上限与 Production 套餐上限。
3. 查询实际 Usage 和突发持续时间。
4. 检查多 Key、多实例和批处理任务。
5. 检查 429 后是否形成重试放大。

## 处理方式

遵守 Reset Header；没有 Header 时使用指数退避和随机抖动。创建请求保持相同 Idempotency Key，并限制并发和最大重试次数。

如果流量确实长期超过持续上限，应先削峰、缓存和合并查询，再评估套餐；如果只是短时批任务，应调度到更平缓的时间窗。

## 不应做出的判断

FP-4291 不证明套餐被降级，也不表示 Payment Method、Webhook 投递或平台服务本身失败。Webhook 投递不计入 Merchant API Rate Limit。

## 相关文档

- 限流政策见 `KB-BR-005`，Header 与退避见 `KB-API-034`。
- 429 综合诊断见 `KB-TS-022`。
