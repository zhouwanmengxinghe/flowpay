---
doc_id: KB-TS-022
title: 套餐用量、Runtime 保留期与 429 重试诊断
doc_type: troubleshooting
authority: operational_guidance
product_areas: [developer_platform, operations, accounts]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4291]
rule_ids: [RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007, RULE-PLAN-001, RULE-PLAN-005]
related_docs: [KB-BR-004, KB-BR-005, KB-API-034, KB-TS-016]
indexing: include
language: zh-CN
---

# 套餐用量、Runtime 保留期与 429 重试诊断

## 现象

一段时间内出现大量 HTTP 429 和 `FP-4291`，用户可能怀疑套餐被降级，也可能观察到重试后错误继续增加。

`FP-4291` 只能证明请求在当时超过 Account + 环境的持续或突发额度，不能单独证明套餐被降级。完整结论需要 Account 套餐、实际 Usage 和请求时间窗三类证据。

## 上限选择

```text
先看环境
├─ Sandbox：固定 120 req/min，burst 180
└─ Production：看请求发生时已生效套餐
   ├─ Starter：300 / 450
   ├─ Growth：1,200 / 1,500
   └─ Scale：5,000 / 6,000
```

后一个值是有限时间突发上限，不是可持续速率。

## 需要确认的事实

- Account 和环境。
- 请求发生时套餐，而不是当前页面显示或变更申请时间。
- 分钟 Usage 和突发窗口。
- 所有 Key、服务、批任务的合计流量。
- 429 后重试次数和并发。
- `2026-07-01` 的 Reset Header。

## 推荐诊断步骤

1. 按 Request ID 和绝对时间定位样本。
2. 查询 Account 套餐变更时间线。
3. 查询对应环境 Runtime Usage。
4. 将实际流量与持续、突发上限分别比较。
5. 检查多个 Key 是否共享同一配额。
6. 检查重试是否放大流量。

## 处理方式

优先遵守 `FlowPay-RateLimit-Reset`，否则指数退避并加随机抖动；设置客户端并发上限。创建操作复用原 Idempotency Key。

## Runtime 查询保留期

套餐还决定 Agent 可通过 Runtime Tool 查询 Request Logs 和 Usage 的时间窗口：Starter 为 7 天，Growth 为 30 天，Scale 为 90 天。Tool 以查询时刻和当时已生效套餐计算 `available_from`；请求时间早于该边界时返回 `retention_exceeded`，不返回窗口外的日志正文。

SQL 中的 Account、Payment 等业务对象可以保留得更久。业务对象仍存在，只能证明该对象事实仍可查询，不能证明同一时刻的完整 Request Log 也处于 Runtime 可见窗口。底层模拟文件或审计日志即使仍存在，也不能绕过产品保留期提供给 Agent。

遇到 `retention_exceeded` 时，应报告实际 `available_from` 和证据边界。需要长期审计时，应在业务系统中预先采用符合产品规则的长期留存方案；不要把数据库对象拼成并不存在的历史请求内容。

## 不应做出的判断

看到 429 不能直接建议升级套餐。若根因是无界重试，即使升级也可能再次耗尽额度。Webhook Delivery 不计入该额度，但 Webhook 消费者随后调用 API 会计入。

## 相关文档

- 套餐和限流政策见 `KB-BR-004`、`KB-BR-005`。
- Header 与退避见 `KB-API-034`。
- 单错误说明见 `KB-TS-016`。
