---
doc_id: KB-TS-013
title: FP-4091 Duplicate Idempotency Key
doc_type: troubleshooting
authority: operational_guidance
product_areas: [developer_platform, payments, refunds, subscriptions]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4091]
rule_ids: [RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006]
related_docs: [KB-BR-008, KB-API-007, KB-API-008, KB-API-033]
indexing: include
language: zh-CN
---

# FP-4091 Duplicate Idempotency Key

## 现象

创建 Payment、Refund 或 Subscription 时返回 HTTP 409 和 `FP-4091`。从 `2026-01-15` 起，错误详情可能包含首次请求的 `conflict_request_id`。

## 含义

在同一 Account、环境和 Endpoint 的 24 小时保留期内，相同 Idempotency Key 已用于不同的有效参数。FlowPay 拒绝第二种业务意图，避免同一个重试标识产生歧义。

## 常见原因

- 重试时修改了金额、币种、Customer 或 Payment Method。
- 把固定字符串作为所有请求的 Idempotency Key。
- 订单修改后仍复用原业务操作 Key。
- 多个服务实例对同一 Key 生成不同请求。
- 调用方把 Request ID 当作 Idempotency Key 管理。

## 需要确认的事实

确认当前 Request ID、Idempotency Key、Endpoint、Account、环境和标准化请求参数。`2026-01-15` 及以后可根据 `conflict_request_id` 查首次请求；旧版本需从 Merchant 记录定位。

## 推荐诊断步骤

1. 停止自动重试，防止持续冲突。
2. 比较当前请求与首次请求的业务参数。
3. 判断当前操作是原请求重试还是新的业务意图。
4. 原请求重试：恢复完全相同参数和相同 Key。
5. 新业务意图：使用新 Key，并明确处理首次资源结果。

## 处理方式

修正 Key 生成和持久化策略。Key 应按业务操作生成，不应按进程、用户或 Endpoint 永久复用。

## 不应做出的判断

FP-4091 不表示 FlowPay 已经创建了第二个资源，也不说明首次请求失败。不要简单换 Key 重发而不先确认首次结果，否则可能产生重复业务资源。

## 相关文档

- 幂等政策见 `KB-BR-008`，使用方式见 `KB-API-033`。
- Request ID 区别见 `KB-API-007`。

