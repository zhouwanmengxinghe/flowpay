---
doc_id: KB-TS-006
title: FP-4021 Payment Method Declined
doc_type: troubleshooting
authority: operational_guidance
product_areas: [payments]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4021]
rule_ids: [RULE-PAY-001, RULE-PAY-002, RULE-ERROR-002]
related_docs: [KB-BR-011, KB-API-012, KB-API-013, KB-API-014, KB-TS-007, KB-TS-008, KB-TS-009, KB-TS-021]
indexing: include
language: zh-CN
---

# FP-4021 Payment Method Declined

## 现象

创建或处理 Payment 时返回 HTTP 402 和 `FP-4021`，Payment 通常进入 `failed`。Sandbox 中可使用 `pm_test_declined` 复现。

## 含义

Payment Method 被支付处理路径拒绝。该错误与资金不足、需要客户操作和支付方式过期分别使用不同错误码。

## 常见原因

- Payment Method 被拒绝使用。
- 支付方式提供方拒绝本次交易。
- Merchant 重复使用已经不可用的 Payment Method。
- 客户端把一个旧 Payment 的失败误当成新 Payment 仍可确认。

FlowPay V1 不模拟银行卡网络的细粒度拒绝原因，因此不要推断真实发卡行或风控模型结论。

## 需要确认的事实

查询 Payment ID、当前状态、`error.code`、请求版本、Customer 和 Payment Method 标识。确认是否为新 Payment，还是调用方正在重复操作一个已经 failed 的资源。

## 推荐诊断步骤

1. 通过 Request ID 和 Payment ID确认实际错误码。
2. 区分 `FP-4021`、`FP-4022`、`FP-4023` 和 `FP-4024`。
3. 确认 Payment 已进入 `failed` 终态。
4. 提示客户更换 Payment Method。
5. 使用新 Idempotency Key 创建新的 Payment。

## 处理方式

不要原地重试 failed Payment。让客户更换支付方式后创建新 Payment，并保留原 Payment 作为失败尝试记录。

## 不应做出的判断

FP-4021 不能证明余额不足，也不能证明 FlowPay 服务降级。HTTP 402 相同不意味着处置相同。

## 相关文档

- Payment 失败分类见 `KB-BR-011`。
- 对象与创建见 `KB-API-012`、`KB-API-013`。
- 综合诊断见 `KB-TS-021`。

