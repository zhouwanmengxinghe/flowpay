---
doc_id: KB-TS-007
title: FP-4022 Insufficient Funds
doc_type: troubleshooting
authority: operational_guidance
product_areas: [payments]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4022]
rule_ids: [RULE-PAY-001, RULE-PAY-002, RULE-ERROR-002]
related_docs: [KB-BR-011, KB-API-004, KB-API-012, KB-API-013, KB-TS-006, KB-TS-008, KB-TS-021]
indexing: include
language: zh-CN
---

# FP-4022 Insufficient Funds

## 现象

Payment 返回 HTTP 402 和 `FP-4022`，通常进入 `failed`。Sandbox 可通过 `pm_test_insufficient` 复现。

## 含义

Payment Method 对本次金额没有足够资金。该错误是支付结果，不是 Merchant Account 的 FlowPay 套餐余额，也不是 API 调用额度不足。

## 常见原因

- 终端客户支付方式资金不足。
- 客户误认为订单金额使用主货币单位，实际请求金额高于预期。
- 重试时修改了金额，但仍使用旧业务提示。
- Merchant 把 Rate Limit “额度”与资金余额混淆。

## 需要确认的事实

查询 Payment 的金额、币种、状态、错误码和创建 Request ID。确认金额以最小货币单位表示，避免把 USD 1200 误认为 USD 12.00 之外的数值。不要收集或记录敏感支付凭据。

## 推荐诊断步骤

1. 确认错误确实为 `FP-4022`，不是其他 HTTP 402 错误。
2. 检查金额和币种是否符合订单意图。
3. 确认 Payment 已进入 failed 终态。
4. 提示客户补充资金或更换 Payment Method。
5. 创建新的 Payment，不原地恢复旧资源。

## 处理方式

如果金额正确，由客户更换支付方式或在资金可用后重新支付。新尝试使用新 Payment 和新业务幂等键。

Merchant 面向客户展示时应使用可行动但不过度暴露内部细节的提示，并保留原 failed Payment 供订单尝试记录和后续支持查询。

## 不应做出的判断

FP-4022 不表示 FlowPay Rate Limit 已耗尽，也不表示 Merchant 套餐需要升级。它也不能证明所有后续支付都会失败。

## 相关文档

- Payment 失败分类见 `KB-BR-011`。
- 金额字段见 `KB-API-012`，创建接口见 `KB-API-013`。
- 综合 Payment 诊断见 `KB-TS-021`。
