---
doc_id: KB-TS-019
title: 401 认证失败诊断决策树
doc_type: troubleshooting
authority: operational_guidance
product_areas: [developer_platform, accounts]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4011, FP-4012]
rule_ids: [RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-ENV-001, RULE-ENV-005]
related_docs: [KB-BR-002, KB-BR-006, KB-API-003, KB-API-007, KB-TS-004, KB-TS-005, KB-TS-020]
indexing: include
language: zh-CN
---

# 401 认证失败诊断决策树

## 现象

请求返回 HTTP 401。FlowPay 至少区分 `FP-4011 Invalid API Key` 和 `FP-4012 Environment Mismatch`；只看 HTTP 状态会丢失关键根因。

## 诊断决策

```text
HTTP 401
├─ FP-4011
│  ├─ Authorization 缺失/格式错误
│  ├─ Key 未知或被截断
│  └─ Key 已 revoked
└─ FP-4012
   ├─ sk_test_ 访问 Production 资源
   ├─ sk_live_ 访问 Sandbox 资源
   └─ 资源 ID 来自另一环境
```

## 需要确认的事实

收集 Request ID、调用服务、部署环境、Key 安全指纹和目标资源 ID。查询 Account Key 状态和所属环境；查询目标资源环境。禁止在工单或普通日志中粘贴完整 Secret Key。

## 推荐诊断步骤

1. 读取响应 `error.code`，不要只记录 401。
2. 检查 Authorization Header 是否为 Bearer 格式。
3. `FP-4011`：核对 Key 是否 active/expiring，检查轮换和撤销时间。
4. `FP-4012`：核对 Key 与资源是否同环境。
5. 使用最小 GET 请求验证修复。
6. 如果响应实际为 `FP-4032`，转入 Production 暂停路径。

## 处理方式

Key 无效时修复 Secret 注入或轮换；环境不匹配时使用目标环境的 Key 和资源。不要把 Sandbox ID 复制到 Production。

## 不应做出的判断

401 不证明 Account 套餐不足，也不证明 Production 被暂停。`sk_live_` 前缀正确也不能证明 Key 当前有效。

## 相关文档

- Secret Key 使用见 `KB-API-003`。
- FP-4011、FP-4012 详解见 `KB-TS-004`、`KB-TS-005`。
- 403 决策见 `KB-TS-020`。

