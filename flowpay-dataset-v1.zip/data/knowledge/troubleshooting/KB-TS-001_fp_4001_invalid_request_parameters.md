---
doc_id: KB-TS-001
title: FP-4001 Invalid Request Parameters
doc_type: troubleshooting
authority: operational_guidance
product_areas: [developer_platform]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4001]
rule_ids: [RULE-ERROR-001, RULE-ERROR-002, RULE-MONEY-001, RULE-MONEY-002]
related_docs: [KB-API-002, KB-API-008, KB-API-013, KB-API-024, KB-TS-021]
indexing: include
language: zh-CN
---

# FP-4001 Invalid Request Parameters

## 现象

API 返回 HTTP 400，`error.code` 为 `FP-4001`。响应可能通过 `error.param` 指出金额、币种、Email、时间范围或其他非法字段。

## 含义

请求已到达 FlowPay，但请求体、Query String 或字段组合不符合当前 Endpoint 和 API Version 的契约。该错误发生在业务处理前，原样重试通常不会成功。

## 常见原因

- 缺少必填字段或字段类型错误。
- 金额使用浮点数，或超出 50～100,000,000 最小货币单位范围。
- 币种不受 Account 主地区支持。
- 枚举值、时间戳、分页 cursor 或 metadata 格式非法。
- 向动作 Endpoint 提交了不接受的业务字段。
- 使用了当前版本不认识的字段组合。

## 需要确认的事实

确认 Request ID、实际 Endpoint、HTTP 方法、`FlowPay-Version`、错误中的 `param` 和经过脱敏的请求参数。涉及币种时还需要查询 Account 主地区；涉及资源状态时不要把 FP-4001 与 FP-4221 混为一谈。

## 推荐诊断步骤

1. 按 Request ID 找到实际请求，而不是依赖客户端准备发送的日志。
2. 对照对应 API Doc 检查必填字段、类型和枚举。
3. 确认金额为整数最小单位。
4. 检查版本 Header 是否改变了参数要求。
5. 只修正明确有问题的字段后重新请求。

## 处理方式

修正客户端验证和序列化逻辑。不要将 400 作为网络错误无限重试；创建型请求修正参数后应使用符合业务意图的 Idempotency Key。

## 不应做出的判断

FP-4001 不能证明平台服务异常，也不能证明 Payment Method 被拒绝。若响应是 `FP-4003`，应按版本移除参数处理，而不是继续当作普通格式错误。

## 相关文档

- 请求格式见 `KB-API-002`，错误对象见 `KB-API-008`。
- Payment 与 Subscription 参数见 `KB-API-013`、`KB-API-024`。

