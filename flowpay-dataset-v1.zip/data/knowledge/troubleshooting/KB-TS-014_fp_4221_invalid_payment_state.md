---
doc_id: KB-TS-014
title: FP-4221 Invalid Payment State
doc_type: troubleshooting
authority: operational_guidance
product_areas: [payments, refunds]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4221]
rule_ids: [RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-REFUND-001, RULE-REFUND-008]
related_docs: [KB-BR-010, KB-BR-012, KB-API-014, KB-API-015, KB-API-016, KB-API-020, KB-TS-021]
indexing: include
language: zh-CN
---

# FP-4221 Invalid Payment State

## 现象

对 Payment 执行 confirm、cancel 或 Refund 等动作时返回 HTTP 422 和 `FP-4221`。资源存在且可见，但当前状态不允许该动作。

## 含义

FlowPay 状态机拒绝非法跳转。例如对 `processing` Payment 退款、对 `failed` Payment confirm、对 `succeeded` Payment cancel，都会违反状态约束。

## 常见原因

- 客户端使用缓存状态，实际 Payment 已变化。
- 在 Payment 仍 `processing` 时发起 Refund。
- 失败后尝试原地重试或 confirm。
- 对 succeeded Payment 调用 cancel，而不是创建 Refund。
- 多个并发动作读取了同一个旧状态。

## 需要确认的事实

查询 Payment ID 的实时业务状态、动作 Endpoint、请求时间和 API Version。若操作是 Refund，还需查询 succeeded 时间、套餐和退款额度，但 FP-4221 首先表示状态条件不满足。

## 推荐诊断步骤

1. 用 Payment ID 获取最新状态。
2. 将请求动作与允许状态表对照。
3. 检查是否有并发 confirm、cancel 或 Refund。
4. `requires_action` 才可 confirm/cancel。
5. `succeeded` 才可进入退款资格检查。
6. failed/canceled 需要创建新 Payment。

## 处理方式

根据最新状态选择合法动作，并在客户端使用状态条件控制按钮和后台任务。不要通过反复重试等待状态机接受非法操作。

## 不应做出的判断

FP-4221 不等于退款窗口过期；后者使用 `FP-4222`。它也不表示资源不存在或 Key 无效。

## 相关文档

- Payment 状态机见 `KB-BR-010`，退款资格见 `KB-BR-012`。
- Payment 查询见 `KB-API-014`。
- 综合状态诊断见 `KB-TS-021`。

