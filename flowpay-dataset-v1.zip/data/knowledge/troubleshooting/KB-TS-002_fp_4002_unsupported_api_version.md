---
doc_id: KB-TS-002
title: FP-4002 Unsupported API Version
doc_type: troubleshooting
authority: operational_guidance
product_areas: [developer_platform]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
error_codes: [FP-4002]
rule_ids: [RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-ERROR-001]
related_docs: [KB-BR-007, KB-API-006, KB-API-007, KB-API-008, KB-TS-003]
indexing: include
language: zh-CN
---

# FP-4002 Unsupported API Version

## 现象

请求返回 HTTP 400 和 `FP-4002`。常见于 `FlowPay-Version` Header 拼写或取值错误，或客户端请求了 FlowPay 不支持的日期版本。

## 含义

FlowPay 无法为请求选择有效 API Version。平台不会自动回退到最近版本，因此请求不会继续执行目标业务操作。

## 常见原因

- Header 值不是 `YYYY-MM-DD` 格式。
- 使用了不存在的发布日，例如 `2026-06-01`。
- Header 被代理拼接、截断或添加空白。
- SDK 配置覆盖了应用显式设置的版本。
- Account 默认版本配置异常，而请求没有 Header。

支持版本为 `2025-10-01`、`2026-01-15`、`2026-04-01` 和 `2026-07-01`。

## 需要确认的事实

获取 Request ID，并确认 FlowPay 实际收到的 Header。若请求没有 Header，查询 Account 默认 API Version。不要只查看源码常量，因为代理、SDK 或不同实例可能修改最终请求。

## 推荐诊断步骤

1. 使用 Request ID 检查实际 `FlowPay-Version`。
2. 与支持版本列表做精确字符串比较。
3. 检查 Header 名称、日期和多余字符。
4. 若未发送 Header，确认 Account 默认版本。
5. 修正后用测试请求验证，再恢复流量。

## 处理方式

选择明确支持的版本。升级到新版本前先阅读迁移差异，不能只把 Header 改成最新日期而不修改参数和 Webhook 消费逻辑。

## 不应做出的判断

FP-4002 不表示某字段已经移除；已移除参数使用 `FP-4003`。它也不说明 Account 套餐或 Production 状态有问题。

## 相关文档

- 版本政策见 `KB-BR-007`，Header 用法见 `KB-API-006`。
- Request ID 见 `KB-API-007`，移除参数见 `KB-TS-003`。

