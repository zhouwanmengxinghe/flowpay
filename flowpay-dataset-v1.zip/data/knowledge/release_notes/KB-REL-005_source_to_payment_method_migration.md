---
doc_id: KB-REL-005
title: source 到 payment_method 迁移指南
doc_type: migration_guide
authority: official
product_areas: [payments, developer_platform]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
release_date: "2026-04-01"
effective_from: "2026-04-01"
effective_to: null
change_types: [deprecated, removed]
supersedes: []
rule_ids: [RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009]
related_docs: [KB-BR-007, KB-API-006, KB-API-013, KB-API-018, KB-TS-003, KB-REL-004, KB-REL-007]
indexing: include
language: zh-CN
---

# source 到 payment_method 迁移指南

## 时间线

- 2026-04-01：`payment_method` 成为推荐参数；`source` 仍兼容但产生弃用提示。
- 2026-07-01：`source` 被移除，提交时返回 `FP-4003 Removed Parameter`。

## 请求对比

旧请求：

```json
{"customer_id":"cus_example","amount":1200,"currency":"USD","source":"src_example"}
```

新请求：

```json
{"customer_id":"cus_example","amount":1200,"currency":"USD","payment_method":"pm_example"}
```

不要在同一请求中同时发送 `source` 和 `payment_method`。两个字段的 ID 类型不同，不能只重命名 JSON Key 而继续传旧 `src_` 值。

## 迁移步骤

1. 将 Sandbox 请求固定为 `2026-04-01`。
2. 更新 Payment Method 创建或保存流程，取得 `pm_` ID。
3. 将 Payment 创建字段改为 `payment_method`。
4. 确认响应不再包含 `source` 弃用提示。
5. 覆盖成功、拒绝、资金不足和 requires_action 测试。
6. 检查所有服务实例和公共 SDK 封装。
7. 再以 `2026-07-01` 测试，确认没有 `FP-4003`。

## 兼容期

`2026-04-01` 是唯一明确的参数兼容阶段。旧 Account 默认版本不会自动升级，但显式发送 `2026-07-01` 的单次请求会立即应用移除规则。

## 回退边界

回退 Header 可以临时恢复旧参数契约，但不应作为长期修复。已使用 `pm_` 的新集成应保持新参数，避免双轨逻辑持续扩散。

## 相关文档

- 参数矩阵见 `KB-API-018`，创建 Payment 见 `KB-API-013`。
- `FP-4003` 排障见 `KB-TS-003`。
- 2026-04-01 和 2026-07-01 说明见 `KB-REL-004`、`KB-REL-007`。

