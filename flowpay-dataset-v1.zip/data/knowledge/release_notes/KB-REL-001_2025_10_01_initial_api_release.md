---
doc_id: KB-REL-001
title: 2025-10-01 初始 API Release
doc_type: release_note
authority: official
product_areas: [developer_platform, payments, refunds, webhooks]
api_versions: ["2025-10-01"]
release_date: "2025-10-01"
effective_from: "2025-10-01"
effective_to: null
change_types: [added]
supersedes: []
rule_ids: [RULE-VERSION-001, RULE-VERSION-003, RULE-VERSION-006, RULE-PAY-001, RULE-IDEMP-001, RULE-WEBHOOK-009]
related_docs: [KB-BR-007, KB-API-006, KB-API-013, KB-API-031, KB-REL-002, KB-REL-010]
indexing: include
language: zh-CN
---

# 2025-10-01 初始 API Release

## 发布与生效日期

- 发布日期：2025-10-01。
- 生效日期：2025-10-01。
- API Version：`2025-10-01`。
- 变更类型：`added`。

## 初始能力

本版本建立 FlowPay V1 的基础契约，包括 Customer、Payment、Refund、Subscription、Invoice、Webhook Endpoint、Secret Key 认证、Idempotency Key 和 Request ID。

Payment 创建使用 `source` 参数。Payment 状态包括 `processing`、`succeeded`、`failed` 和 `canceled`；需要客户额外操作的场景以 `failed + FP-4023` 表示，尚无 `requires_action` 状态。

## Webhook 契约

Payment 成功事件名为 `payment.completed`。Webhook 签名使用 `X-FlowPay-Signature` Header。默认重试在首次失败后的 1 分钟、5 分钟、30 分钟、2 小时、8 小时和 24 小时执行。

## Refund 行为

Refund 创建默认异步处理。成功创建通常先返回 `pending`，随后通过对象查询或 Webhook 得到 `succeeded`、`failed` 或 `canceled` 结果。

## 兼容与迁移

这是初始版本，不存在上一个 FlowPay API Version 或兼容迁移期。后续版本不会自动改变使用 `FlowPay-Version: 2025-10-01` 的请求行为；调用方应根据明确版本文档处理。

## 已知边界

本版本不支持 `requires_action`、`payment_method` 参数、`FlowPay-Signature` Header、`payment.succeeded` 事件或 `FlowPay-RateLimit-Reset` Header。

## 相关文档

- 版本政策见 `KB-BR-007`，Header 用法见 `KB-API-006`。
- Payment 创建见 `KB-API-013`，签名见 `KB-API-031`。
- 下一版本见 `KB-REL-002`，完整时间线见 `KB-REL-010`。

