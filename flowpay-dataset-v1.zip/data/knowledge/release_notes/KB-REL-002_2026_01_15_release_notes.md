---
doc_id: KB-REL-002
title: 2026-01-15 Release Notes
doc_type: release_note
authority: official
product_areas: [payments, webhooks, developer_platform]
api_versions: ["2026-01-15"]
release_date: "2026-01-15"
effective_from: "2026-01-15"
effective_to: null
change_types: [added, changed]
supersedes: []
rule_ids: [RULE-PAY-003, RULE-PAY-005, RULE-IDEMP-005, RULE-VERSION-005]
related_docs: [KB-BR-007, KB-BR-010, KB-API-015, KB-API-033, KB-REL-001, KB-REL-003, KB-REL-004]
indexing: include
language: zh-CN
---

# 2026-01-15 Release Notes

## 发布与生效日期

- 发布日期：2026-01-15。
- 生效日期：2026-01-15。
- API Version：`2026-01-15`。
- 变更类型：`added`、`changed`。

## Payment 客户操作流程

本版本新增 Payment 状态 `requires_action` 和 Event Type `payment.action_required`。当终端客户需要完成额外验证时，Payment 不再立即进入 failed；Merchant 应呈现响应中的 `next_action`，完成后调用 confirm。

旧行为与新行为：

| 场景 | `2025-10-01` | `2026-01-15` |
| --- | --- | --- |
| 需要客户操作 | `failed + FP-4023` | `requires_action` |
| 后续处理 | 创建新 Payment | confirm 原 Payment |

## 幂等冲突详情

`FP-4091` 的 `error.details` 新增 `conflict_request_id`，用于定位首次使用该 Idempotency Key 的请求。幂等作用域和 24 小时保留期没有变化。

## 保持不变

Payment 创建仍使用 `source`。成功事件仍为 `payment.completed`。Webhook 签名仍使用 `X-FlowPay-Signature`。Refund 默认仍先返回 `pending`。

## 兼容期

`2025-10-01` 继续按原契约支持，不自动获得 `requires_action`。迁移需要同时更新后端状态机、前端客户操作流程和 Webhook Event 消费者。

## 相关文档

- Payment 状态机见 `KB-BR-010`，confirm 见 `KB-API-015`。
- 幂等键见 `KB-API-033`。
- 完整迁移步骤见 `KB-REL-003`。

