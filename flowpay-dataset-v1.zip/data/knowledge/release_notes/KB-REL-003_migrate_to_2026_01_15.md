---
doc_id: KB-REL-003
title: 迁移至 2026-01-15
doc_type: migration_guide
authority: official
product_areas: [payments, webhooks, developer_platform]
api_versions: ["2025-10-01", "2026-01-15"]
release_date: "2026-01-15"
effective_from: "2026-01-15"
effective_to: null
change_types: [changed]
supersedes: []
rule_ids: [RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-005, RULE-VERSION-002, RULE-VERSION-009]
related_docs: [KB-BR-010, KB-API-006, KB-API-012, KB-API-015, KB-REL-001, KB-REL-002]
indexing: include
language: zh-CN
---

# 迁移至 2026-01-15

## 迁移范围

- 指南发布日期：2026-01-15。
- 源版本：`2025-10-01`。
- 目标版本：`2026-01-15`。
- 主要变更：Payment 客户操作流程和幂等冲突详情。

## 行为差异

旧版本把需要额外验证的 Payment 表示为 `failed + FP-4023`，调用方在客户完成操作后创建新 Payment。目标版本新增 `requires_action`，调用方应保留原 Payment，完成 `next_action` 后执行 confirm。

`failed` 仍是终态。迁移不能把旧 failed Payment 直接转换或 confirm。

## 迁移步骤

1. 在 Sandbox 请求中显式发送 `FlowPay-Version: 2026-01-15`。
2. 更新 Payment 状态枚举，接受 `requires_action`。
3. 将 `next_action` 传递给前端或客户交互层。
4. 客户完成后调用 `/v1/payments/{id}/confirm`。
5. 处理 `payment.action_required` Event。
6. 保留 `payment.completed` 成功事件处理。
7. 可选读取 `FP-4091.details.conflict_request_id`。
8. 验证后再修改 Account 默认版本。

## 兼容期

`2025-10-01` 在支持期内保持旧行为。单次请求 Header 可以用于灰度，不会改变 Account 默认版本。迁移期间不要根据 Account 默认版本猜测某个 Event，应读取 Event 的 `api_version`。

## 回退

若需要临时回退，可显式使用 `2025-10-01`，但新版本创建的 `requires_action` Payment 不应由旧客户端继续处理。先停止新流量，再处理在途对象。

## 相关文档

- Release Notes 见 `KB-REL-002`。
- 版本 Header 见 `KB-API-006`，Payment 对象和 confirm 见 `KB-API-012`、`KB-API-015`。

