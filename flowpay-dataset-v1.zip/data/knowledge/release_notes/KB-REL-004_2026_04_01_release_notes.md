---
doc_id: KB-REL-004
title: 2026-04-01 Release Notes
doc_type: release_note
authority: official
product_areas: [payments, webhooks, developer_platform]
api_versions: ["2026-04-01"]
release_date: "2026-04-01"
effective_from: "2026-04-01"
effective_to: null
change_types: [added, changed, deprecated]
supersedes: []
rule_ids: [RULE-VERSION-005, RULE-WEBHOOK-016, RULE-WEBHOOK-017]
related_docs: [KB-BR-007, KB-API-018, KB-API-031, KB-REL-002, KB-REL-005, KB-REL-006, KB-REL-007]
indexing: include
language: zh-CN
---

# 2026-04-01 Release Notes

## 发布与生效日期

- 发布日期：2026-04-01。
- 生效日期：2026-04-01。
- API Version：`2026-04-01`。
- 变更类型：`added`、`changed`、`deprecated`。

## Payment Method 参数

创建 Payment 推荐使用 `payment_method`。旧参数 `source` 在本版本仍被接受，但响应包含弃用提示。这是兼容窗口，调用方应在升级到 `2026-07-01` 前完成迁移。

| 行为 | `2026-01-15` | `2026-04-01` |
| --- | --- | --- |
| Payment 参数 | `source` | 推荐 `payment_method`，兼容 `source` |
| `source` 结果 | 正常 | 正常但带弃用提示 |

## Webhook 签名 Header

签名 Header 从 `X-FlowPay-Signature` 改为 `FlowPay-Signature`。本版本不再同时发送旧 Header。Signing Secret、HMAC 计算和 5 分钟时间戳容差不变。

## 保持不变

Payment 成功 Event 仍为 `payment.completed`。Refund 默认仍先返回 `pending`。`requires_action` 和 `payment.action_required` 延续 `2026-01-15` 行为。

## 兼容与风险

`source` 只有本版本的过渡兼容，不应作为长期依赖。Webhook Header 没有双写兼容期，升级请求或默认版本前必须先部署能读取新 Header 的消费者。

## 相关文档

- Payment 参数迁移见 `KB-REL-005`。
- 签名 Header 迁移见 `KB-REL-006`。
- 参数与签名接口见 `KB-API-018`、`KB-API-031`。

