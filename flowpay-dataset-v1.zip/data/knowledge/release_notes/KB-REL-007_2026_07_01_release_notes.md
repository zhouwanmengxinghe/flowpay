---
doc_id: KB-REL-007
title: 2026-07-01 Release Notes
doc_type: release_note
authority: official
product_areas: [payments, refunds, webhooks, developer_platform]
api_versions: ["2026-07-01"]
release_date: "2026-07-01"
effective_from: "2026-07-01"
effective_to: null
change_types: [added, changed, removed]
supersedes: []
rule_ids: [RULE-VERSION-005, RULE-PAY-007, RULE-WEBHOOK-016, RULE-REFUND-001, RULE-RATE-007]
related_docs: [KB-BR-007, KB-API-018, KB-API-019, KB-API-030, KB-API-034, KB-REL-005, KB-REL-008, KB-REL-009]
indexing: include
language: zh-CN
---

# 2026-07-01 Release Notes

## 发布与生效日期

- 发布日期：2026-07-01。
- 生效日期：2026-07-01。
- API Version：`2026-07-01`。
- 变更类型：`added`、`changed`、`removed`。

## Removed：source

Payment 创建不再接受 `source`。必须发送 `payment_method`；继续提交旧参数返回 `FP-4003`。`2026-04-01` 的弃用兼容期在本版本结束。

## Changed：Payment 成功事件

Payment 成功 Event 从 `payment.completed` 更名为 `payment.succeeded`。Endpoint 必须订阅实际事件名称；订阅旧名称不会自动匹配新 Event。

## Changed：Refund 创建响应

普通 Refund 从默认异步改为优先同步确认。满足条件时创建响应可直接返回 `succeeded`，否则仍返回 `pending`。调用方必须处理两种状态，不能假设所有退款都会同步完成。

## Added：Rate Limit Reset Header

HTTP 429 响应新增 `FlowPay-RateLimit-Reset`，值为建议等待秒数。客户端应优先遵守该值，并继续使用指数退避和随机抖动。

## 保持不变

Webhook 签名 Header 继续使用 `FlowPay-Signature`。`requires_action`、confirm 流程、幂等作用域和 Refund 180 天窗口不变。

## 兼容边界

这些行为只适用于实际采用 `2026-07-01` 的请求或 Event。旧版本不会自动切换事件名或 Refund 默认响应。

## 相关文档

- 完整升级步骤见 `KB-REL-008`。
- 参数迁移见 `KB-REL-005`，事件迁移见 `KB-REL-009`。
- Refund 和 Rate Limit 见 `KB-API-019`、`KB-API-034`。

