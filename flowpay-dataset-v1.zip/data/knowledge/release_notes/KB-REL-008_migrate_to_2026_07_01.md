---
doc_id: KB-REL-008
title: 迁移至 2026-07-01
doc_type: migration_guide
authority: official
product_areas: [payments, refunds, webhooks, developer_platform]
api_versions: ["2026-04-01", "2026-07-01"]
release_date: "2026-07-01"
effective_from: "2026-07-01"
effective_to: null
change_types: [added, changed, removed]
supersedes: []
rule_ids: [RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009, RULE-PAY-007, RULE-REFUND-001, RULE-RATE-007]
related_docs: [KB-BR-007, KB-API-006, KB-API-018, KB-API-019, KB-API-030, KB-API-034, KB-REL-005, KB-REL-006, KB-REL-007, KB-REL-009]
indexing: include
language: zh-CN
---

# 迁移至 2026-07-01

## 迁移范围

- 指南发布日期：2026-07-01。
- 推荐源版本：`2026-04-01`。
- 目标版本：`2026-07-01`。
- 影响：Payment 参数、成功 Event、Refund 初始状态和 429 Header。

## 升级前检查

确认所有 Payment 创建已使用 `payment_method`，Webhook 消费者能处理 `FlowPay-Signature`，并且系统不会假设 Refund 创建后必定为 `pending`。

## 迁移步骤

1. 在 `2026-04-01` 下消除所有 `source` 弃用提示。
2. 为 Endpoint 增加 `payment.succeeded` 订阅。
3. 让消费者同时处理 `payment.completed` 与 `payment.succeeded`。
4. 更新 Refund 流程，接受创建时直接 `succeeded` 或 `pending`。
5. 读取 `FlowPay-RateLimit-Reset` 并保留指数退避。
6. 在 Sandbox 显式发送 `FlowPay-Version: 2026-07-01`。
7. 覆盖成功、requires_action、退款和 429 场景。
8. 灰度 Production 请求，观察 Request ID、Event 和 Delivery。
9. 最后修改 Account 默认版本。

## 兼容期

`2026-04-01` 继续按其支持期运行，但 `2026-07-01` 请求没有 `source` 兼容。迁移期间新旧 Event 名称可能同时出现，取决于产生 Event 的请求版本。

## 回退

回退前先处理已经由新版本产生的 Event 和 Refund。将 Header 改回旧版本不会撤销已创建对象，也不会重命名已经产生的 Event。

## 相关文档

- Release Notes 见 `KB-REL-007`。
- 参数、签名和事件专项指南见 `KB-REL-005`、`KB-REL-006`、`KB-REL-009`。

