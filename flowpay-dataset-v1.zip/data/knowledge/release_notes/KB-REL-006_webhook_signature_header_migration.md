---
doc_id: KB-REL-006
title: Webhook 签名 Header 迁移指南
doc_type: migration_guide
authority: official
product_areas: [webhooks, developer_platform]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
release_date: "2026-04-01"
effective_from: "2026-04-01"
effective_to: null
change_types: [changed]
supersedes: []
rule_ids: [RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018]
related_docs: [KB-BR-016, KB-API-006, KB-API-031, KB-TS-023, KB-REL-004, KB-REL-008]
indexing: include
language: zh-CN
---

# Webhook 签名 Header 迁移指南

## 变更时间线

- `2025-10-01`、`2026-01-15`：`X-FlowPay-Signature`。
- `2026-04-01`、`2026-07-01`：`FlowPay-Signature`。
- 新 Header 生效日期：2026-04-01。

`2026-04-01` 起不再同时发送旧 Header。HMAC-SHA256 算法、`timestamp.raw_body` 签名内容和 5 分钟时间戳容差不变。

## 迁移步骤

1. 在 Webhook 接收端增加 `FlowPay-Signature` Header 读取能力。
2. 保留旧 Header 读取能力，以处理旧版本 Event。
3. 继续使用原始请求字节验签，不重新序列化 JSON。
4. 在 Sandbox 产生显式 `2026-04-01` Event。
5. 验证新 Header、Signing Secret 和 `event_id` 去重。
6. 覆盖 Secret 轮换兼容期测试。
7. 再升级 Account 默认版本或 Production 请求版本。

## 混合版本处理

公开 API Event 沿用请求版本，周期任务 Event 使用 Account 当时默认版本。迁移期间同一 Endpoint 可能收到不同版本 Event，因此消费者应同时识别新旧 Header，而不是根据部署日期猜测。

## Secret 轮换

Header 迁移不要求轮换 Signing Secret。若同时轮换，新 Secret 立即用于新投递，旧 Secret 在 24 小时内有效；重试使用重试时的当前 Secret 重新签名。

## 回退边界

仅回退请求版本会重新产生旧 Header，但不能修复已经到达的新版本 Event。接收端应先实现双 Header 读取，再执行版本变更。

## 相关文档

- 签名政策见 `KB-BR-016`，验证实现见 `KB-API-031`。
- Webhook 综合排障见 `KB-TS-023`。
- 2026-04-01 Release Notes 见 `KB-REL-004`。

