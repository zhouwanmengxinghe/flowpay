---
doc_id: KB-REL-010
title: API Version 支持与弃用时间线
doc_type: migration_guide
authority: official
product_areas: [developer_platform]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
release_date: "2026-07-01"
effective_from: "2026-07-01"
effective_to: null
change_types: [added, deprecated, removed]
supersedes: []
rule_ids: [RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-VERSION-005, RULE-VERSION-006, RULE-VERSION-007, RULE-VERSION-008, RULE-VERSION-009]
related_docs: [KB-BR-004, KB-BR-007, KB-API-006, KB-REL-001, KB-REL-002, KB-REL-004, KB-REL-007]
indexing: include
language: zh-CN
---

# API Version 支持与弃用时间线

## 支持版本

| API Version | 发布日期 | 最低支持至 | 关键变化 |
| --- | --- | --- | --- |
| `2025-10-01` | 2025-10-01 | 2026-10-01 | 初始契约，`source`、旧签名 Header |
| `2026-01-15` | 2026-01-15 | 2027-01-15 | `requires_action`、幂等冲突详情 |
| `2026-04-01` | 2026-04-01 | 2027-04-01 | `payment_method` 过渡、新签名 Header |
| `2026-07-01` | 2026-07-01 | 2027-07-01 | 移除 `source`、新成功 Event、Refund 与 429 变化 |

“最低支持至”由每个版本至少支持 12 个月的政策计算，不等于已经宣布的最终停止日期。正式废弃必须另行发布迁移指南和生效日期。

## 版本选择

请求 Header 优先于 Account 默认版本。不支持的版本返回 `FP-4002`，不会自动回退。读取文档和排障时必须以请求实际版本为准。

## 主要弃用链

- `source`：2026-04-01 弃用，2026-07-01 移除。
- `X-FlowPay-Signature`：2026-04-01 起由 `FlowPay-Signature` 替代。
- `payment.completed`：2026-07-01 请求改用 `payment.succeeded`。

## Scale 版本冻结延期

Scale Account 可申请最多 90 天冻结延期。延期只延长该 Account 使用旧版本的时间，不改变新建 Account 的可选版本，也不会让新版本重新接受已移除参数。

## 迁移要求

版本废弃前应完成 Sandbox 验证、显式 Header 灰度、Webhook 消费兼容和 Production 小流量观察。修改默认版本是迁移最后一步。

## 相关文档

- 正式支持政策见 `KB-BR-007`，版本 Header 见 `KB-API-006`。
- 各 Release 见 `KB-REL-001`、`KB-REL-002`、`KB-REL-004`、`KB-REL-007`。

