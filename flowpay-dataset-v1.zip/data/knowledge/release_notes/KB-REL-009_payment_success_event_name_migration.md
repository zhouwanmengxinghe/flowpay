---
doc_id: KB-REL-009
title: Payment 成功 Event 名称迁移指南
doc_type: migration_guide
authority: official
product_areas: [payments, webhooks]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
release_date: "2026-07-01"
effective_from: "2026-07-01"
effective_to: null
change_types: [changed]
supersedes: []
rule_ids: [RULE-PAY-007, RULE-WEBHOOK-005, RULE-WEBHOOK-012, RULE-WEBHOOK-017]
related_docs: [KB-BR-015, KB-API-006, KB-API-029, KB-API-030, KB-API-032, KB-TS-023, KB-REL-007, KB-REL-008]
indexing: include
language: zh-CN
---

# Payment 成功 Event 名称迁移指南

## 变更

- `2025-10-01`、`2026-01-15`、`2026-04-01`：`payment.completed`。
- `2026-07-01`：`payment.succeeded`。
- 新名称生效日期：2026-07-01。

两个名称表示不同 API Version 下的 Payment succeeded 业务结果，不是两个不同成功状态。

## Endpoint 迁移

1. 在现有 Endpoint 的 `subscribed_events` 中增加 `payment.succeeded`。
2. 暂时保留 `payment.completed`，处理旧版本请求和在途 Event。
3. 将两个 Event Type 路由到同一幂等业务处理器。
4. 使用 `event_id` 去重，不按 Event Type + Payment ID重复开通服务。
5. 在 Sandbox 分别产生 `2026-04-01` 和 `2026-07-01` Payment。
6. 查询 Delivery，确认两个名称均可返回 2xx。
7. 所有事件来源迁移后再移除旧订阅。

## 混合版本原因

公开 API Event 沿用创建请求版本，平台周期任务使用 Account 默认版本。只修改 Account 默认版本不能改变显式旧版本请求，也不能重写历史 Event。因此迁移期内收到两个名称是正常现象。

## 常见失败

- 只订阅 `payment.completed`，导致新版本 Event 没有 Delivery。
- 把两个 Event 当作两个业务成功动作，造成重复履约。
- 看到 Payment succeeded 就断言 Webhook 已送达，没有查询 Endpoint 和 Delivery。

## 兼容与回退

保留双订阅是推荐兼容方式。回退请求版本只影响之后产生的 Event，不会改变已产生的 `payment.succeeded`。

## 相关文档

- Event Type 见 `KB-API-030`，Endpoint 管理见 `KB-API-029`。
- 未收到 Webhook 排障见 `KB-TS-023`。
- 2026-07-01 迁移见 `KB-REL-008`。

