---
doc_id: KB-API-007
title: Request ID 与请求追踪
doc_type: api_doc
authority: official
product_areas: [developer_platform, operations]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-REQ-001, RULE-REQ-002, RULE-REQ-003]
related_docs: [KB-API-002, KB-API-008, KB-API-014, KB-API-033]
indexing: include
language: zh-CN
---

# Request ID 与请求追踪

## Request ID 是什么

每个到达 FlowPay API 网关的请求都会生成唯一 `request_id`，格式以 `req_` 开头。即使请求在认证阶段被拒绝，仍会有 Request ID。它用于关联客户端日志、FlowPay Request Logs 和支持调查。

Request ID 不是 Customer、Payment 或 Refund 等业务资源 ID，不能用它调用资源查询 Endpoint。

## 从响应获取

成功响应在 `FlowPay-Request-Id` Header 中返回 Request ID。错误响应还在 JSON 的 `error.request_id` 中返回相同值：

```http
FlowPay-Request-Id: req_01JEXAMPLE
```

```json
{
  "error": {
    "code": "FP-4011",
    "message": "Invalid API key.",
    "request_id": "req_01JEXAMPLE"
  }
}
```

客户端应在每次请求完成后记录该 Header，并与自身 trace ID、订单 ID 和幂等键建立关联。不要记录完整 Secret Key 或敏感请求正文。

## 诊断用途

Request ID 可以帮助确认：

- 请求是否到达 FlowPay。
- 使用了哪个 Endpoint、环境和 API Version。
- 返回的 HTTP 状态、错误码和延迟。
- 重试是否产生了多个独立请求。

它不能单独证明业务操作只执行一次。相同 Idempotency Key 的每次网络请求仍有不同 Request ID，但可能返回同一个资源结果。

## Webhook 的标识

Webhook Delivery 使用 `event_id` 和 `delivery_id` 追踪，不应与 Merchant 调用 API 的 Request ID 混用。Merchant 接收 Webhook 后再调用 FlowPay API时，新调用会获得新的 Request ID。

## 支持调查

提交问题时，优先提供完整 Request ID、绝对时间、环境和 Account ID。若完全没有 Request ID，请先检查请求是否到达 FlowPay 基础地址、DNS、TLS 和本地网络层。

## 相关文档

- 通用响应格式见 `KB-API-002`。
- 错误对象见 `KB-API-008`。
- Payment 查询使用 Payment ID，见 `KB-API-014`。
- Request ID 与幂等键的区别见 `KB-API-033`。

