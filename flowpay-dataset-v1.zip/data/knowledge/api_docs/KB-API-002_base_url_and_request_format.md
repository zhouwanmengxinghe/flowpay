---
doc_id: KB-API-002
title: API 基础 URL 与请求格式
doc_type: api_doc
authority: official
product_areas: [developer_platform]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-AUTH-001, RULE-VERSION-002, RULE-VERSION-003, RULE-REQ-001, RULE-MONEY-001, RULE-MONEY-002]
related_docs: [KB-API-001, KB-API-003, KB-API-006, KB-API-007, KB-API-008]
indexing: include
language: zh-CN
---

# API 基础 URL 与请求格式

## 基础地址

FlowPay V1 的基础地址是：

```text
https://api.flowpay.example/v1
```

Sandbox 与 Production 使用同一基础地址，由 Secret Key 前缀和所属环境决定请求环境。Endpoint 路径中的 `/v1` 是产品 API 主版本，不等同于日期格式的 `FlowPay-Version`。

## HTTPS 与编码

所有请求必须使用 HTTPS。请求和响应正文使用 UTF-8 JSON。发送 JSON 时设置：

```http
Content-Type: application/json
Accept: application/json
```

对象字段使用 `snake_case`。时间戳使用带 UTC 时区的 ISO 8601 字符串，例如 `2026-08-27T03:30:00Z`。金额使用最小货币单位的整数，不能传浮点数。

## 通用 Header

```http
Authorization: Bearer sk_test_example
FlowPay-Version: 2026-07-01
Content-Type: application/json
Idempotency-Key: merchant-operation-id
```

`Authorization` 用于认证；`FlowPay-Version` 可覆盖 Account 默认版本；`Idempotency-Key` 只用于支持幂等的创建型 POST 请求。

## HTTP 方法

- `GET`：读取对象或列表，不修改状态。
- `POST`：创建对象或执行 confirm、cancel 等动作。
- `PATCH`：更新允许修改的字段。
- `DELETE`：执行 API 明确定义的删除或软删除。

资源 ID 放在路径中，例如 `GET /v1/payments/pay_123`。过滤、分页和时间范围放在 Query String 中。

## 通用响应

成功响应返回对应 JSON 对象。创建通常返回 HTTP 201；读取和动作成功通常返回 200。每个到达 API 网关的请求都会获得唯一 `request_id`，它可能同时出现在响应 Header 和 JSON 错误对象中。

列表响应使用：

```json
{
  "data": [],
  "has_more": false,
  "next_cursor": null
}
```

## 版本和环境边界

不支持的 `FlowPay-Version` 返回 `FP-4002`，不会自动回退。使用 Sandbox Key 访问 Production 资源或反向访问返回 `FP-4012`。基础 URL 相同不表示两个环境共享资源。

## 相关文档

- 快速开始见 `KB-API-001`。
- Secret Key 认证见 `KB-API-003`。
- 版本 Header 见 `KB-API-006`。
- Request ID 和错误格式见 `KB-API-007`、`KB-API-008`。

