---
doc_id: KB-API-029
title: Webhook Endpoint 管理
doc_type: api_doc
authority: official
product_areas: [webhooks, accounts]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-PLAN-003, RULE-PLAN-004, RULE-ENV-004]
related_docs: [KB-BR-004, KB-BR-015, KB-BR-016, KB-API-004, KB-API-030, KB-API-031, KB-API-032]
indexing: include
language: zh-CN
---

# Webhook Endpoint 管理

## Endpoint

```http
POST   /v1/webhook_endpoints
GET    /v1/webhook_endpoints/{endpoint_id}
PATCH  /v1/webhook_endpoints/{endpoint_id}
DELETE /v1/webhook_endpoints/{endpoint_id}
```

Endpoint 属于当前 Secret Key 的 Account 和环境。Sandbox Event 只投递给 Sandbox Endpoint，Production 同理。

## 创建参数

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `url` | string | 是 | 可公开访问的 HTTPS 地址 |
| `subscribed_events` | array | 是 | 明确订阅的 Event Type |
| `description` | string | 否 | 便于识别的说明 |
| `retry_policy` | object | 否 | 仅 Scale 可自定义 |

创建返回 HTTP 201、Endpoint 对象和 Signing Secret。完整 Secret 只在创建或轮换时显示一次，应立即安全保存。

```json
{
  "id":"we_01JEXAMPLE",
  "url":"https://merchant.example.test/flowpay",
  "status":"enabled",
  "subscribed_events":["payment.succeeded"],
  "signing_secret":"whsec_example"
}
```

## 更新与删除

PATCH 可修改 URL、订阅事件、描述和允许的重试策略。将 `enabled` 设为 false 会使 Endpoint 进入 `disabled`，不再为新 Event 创建 Delivery。

DELETE 表示永久移除接收配置，历史 Delivery 仍按数据保留期保存。若 Merchant 端返回 HTTP 410，FlowPay 也会立即禁用 Endpoint。

## 套餐上限

Starter、Growth、Scale 分别允许 2、5、15 个 Endpoint。套餐降级生效后，超出新上限的较新 Endpoint 进入 `restricted`，不会被删除。`restricted` 和 `disabled` 都不接收新 Event，但原因不同。

## 错误

- `FP-4001`：URL、事件名称或重试策略非法。
- `FP-4031`：超过套餐能力或非 Scale 使用自定义重试。
- `FP-4041`：Endpoint 不存在或不可见。

## 相关文档

- Endpoint 与套餐规则见 `KB-BR-015`、`KB-BR-004`。
- 事件名称见 `KB-API-030`。
- 签名与重试见 `KB-API-031`、`KB-API-032`。

