---
doc_id: KB-API-013
title: 创建 Payment
doc_type: api_doc
authority: official
product_areas: [payments]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-PAY-005, RULE-PAY-006, RULE-MONEY-001, RULE-MONEY-002, RULE-REGION-001, RULE-IDEMP-001, RULE-IDEMP-004, RULE-IDEMP-005]
related_docs: [KB-BR-003, KB-BR-008, KB-BR-010, KB-API-009, KB-API-012, KB-API-014, KB-API-018, KB-API-033]
indexing: include
language: zh-CN
---

# 创建 Payment

## Endpoint

```http
POST /v1/payments
```

创建 Payment 应发送 `Idempotency-Key`，以便安全处理网络超时和重试。

## 请求参数

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `customer_id` | string | 是 | 同 Account、同环境的 active Customer |
| `amount` | integer | 是 | 50～100,000,000 个最小货币单位 |
| `currency` | string | 是 | Account 主地区支持的币种 |
| `payment_method` | string | 按版本 | `2026-04-01` 起推荐，`2026-07-01` 必填 |
| `source` | string | 按版本 | 旧版本参数，`2026-07-01` 已移除 |
| `metadata` | object | 否 | Merchant 自定义字符串键值 |

## 示例

```bash
curl https://api.flowpay.example/v1/payments \
  -X POST \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY" \
  -H "FlowPay-Version: 2026-07-01" \
  -H "Idempotency-Key: order-9001-attempt-1" \
  -H "Content-Type: application/json" \
  -d '{
    "customer_id":"cus_01JEXAMPLE",
    "amount":1200,
    "currency":"USD",
    "payment_method":"pm_example"
  }'
```

成功创建返回 HTTP 201 和 Payment。首次状态可能为 `processing`、`requires_action`、`succeeded` 或 `failed`，取决于版本和处理结果。

## 版本行为

- `2025-10-01`、`2026-01-15`：使用 `source`。
- `2026-04-01`：推荐 `payment_method`，仍兼容 `source` 并返回弃用提示。
- `2026-07-01`：仅使用 `payment_method`；提交 `source` 返回 `FP-4003`。

## 错误

- `FP-4001`：金额、币种或参数格式非法。
- `FP-4003`：使用已移除参数。
- `FP-4041`：Customer 不存在或不可见。
- `FP-4091`：相同 Idempotency Key 使用不同参数。
- `FP-4021`～`FP-4024`：支付方式处理失败。

## 相关文档

- Payment 对象见 `KB-API-012`，查询见 `KB-API-014`。
- Payment Method 版本兼容见 `KB-API-018`。
- 幂等键见 `KB-API-033`。

