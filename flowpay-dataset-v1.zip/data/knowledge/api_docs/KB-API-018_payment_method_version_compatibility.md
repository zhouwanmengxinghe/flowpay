---
doc_id: KB-API-018
title: Payment Method 参数与版本兼容
doc_type: api_doc
authority: official
product_areas: [payments, developer_platform]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-005, RULE-VERSION-009, RULE-PAY-005]
related_docs: [KB-BR-007, KB-BR-010, KB-API-006, KB-API-008, KB-API-013]
indexing: include
language: zh-CN
---

# Payment Method 参数与版本兼容

## 参数演进

FlowPay 的 Payment 创建参数从 `source` 迁移到 `payment_method`。实际可用参数由请求的 `FlowPay-Version` 决定，不由客户端 SDK 版本或 Account 创建时间决定。

| API Version | `source` | `payment_method` |
| --- | --- | --- |
| `2025-10-01` | 必填 | 不使用 |
| `2026-01-15` | 必填 | 不使用 |
| `2026-04-01` | 兼容但已弃用 | 推荐 |
| `2026-07-01` | 已移除，返回 `FP-4003` | 必填 |

在 `2026-04-01` 中继续使用 `source` 可以完成请求，但响应包含弃用提示。该兼容期不延续到 `2026-07-01`。

## 示例

旧版本请求：

```json
{
  "customer_id":"cus_01JEXAMPLE",
  "amount":1200,
  "currency":"USD",
  "source":"src_example"
}
```

`2026-07-01` 请求：

```json
{
  "customer_id":"cus_01JEXAMPLE",
  "amount":1200,
  "currency":"USD",
  "payment_method":"pm_example"
}
```

## 迁移步骤

1. 显式设置 `FlowPay-Version: 2026-04-01`。
2. 将请求字段从 `source` 改为 `payment_method`。
3. 确认不再收到弃用提示。
4. 验证 Payment 状态和 Webhook 消费。
5. 再测试并切换到 `2026-07-01`。

不要在同一请求中同时发送两个字段，以免客户端逻辑依赖不明确的优先级。

## 常见错误

- `FP-4003`：当前请求使用 `2026-07-01` 但仍发送 `source`。
- `FP-4001`：缺少该版本所需的 Payment Method 参数，或字段格式无效。

查看旧文档发现 `source` 并不能证明它适用于当前请求。排查时必须检查实际 `FlowPay-Version` Header；Header 缺失时检查 Account 默认版本。

## 相关文档

- 版本选择政策见 `KB-BR-007` 和 `KB-API-006`。
- 创建 Payment 见 `KB-API-013`。
- 错误对象见 `KB-API-008`。

