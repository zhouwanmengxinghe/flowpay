---
doc_id: KB-API-005
title: Production 启用与暂停
doc_type: api_doc
authority: official
product_areas: [accounts, developer_platform]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-ENV-003, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-PLAN-002]
related_docs: [KB-BR-002, KB-BR-004, KB-BR-006, KB-API-003, KB-API-004, KB-API-029]
indexing: include
language: zh-CN
---

# Production 启用与暂停

## 启用条件

Account 创建后默认只有 Sandbox。完成生产启用后，账户状态包含 `production_enabled: true`，此时才可创建 `sk_live_` Secret Key 并访问 Production API。

Production 启用属于 Account 管理流程，不通过 Payment API 隐式完成。尚未启用时尝试创建 Production Key 会被拒绝。

## 上线步骤

1. 确认 Account 主地区和已生效套餐。
2. 完成 Production 启用，使 `production_enabled=true`。
3. 创建 `sk_live_` Key，并存入服务端 Secret Manager。
4. 在 Production 重新创建必要的 Customer 映射和 Webhook Endpoint。
5. 选择并验证 Account 默认 API Version。
6. 以小流量执行 Payment 和 Webhook 验证，再逐步放量。

Sandbox 数据不会复制。特别是，`cus_`、`pay_` 和 `we_` 等 Sandbox ID 不能直接用于 Production 请求。

## Production 暂停

平台可以暂停某个 Account 的 Production 访问。暂停期间，现有 `sk_live_` Key 和历史 Production 资源不会被删除，但 Production API 请求返回 HTTP 403 和 `FP-4032 Production Access Suspended`。

Sandbox 不受 Production 暂停影响。Developer 可以继续测试，但不能用 Sandbox 成功结果证明暂停已经解除。

## 套餐变更

Production 启用和套餐是两个不同维度。启用 Production 不会升级套餐；套餐升级立即生效，降级在当前计费周期结束时生效。Rate Limit 和功能权限使用请求发生时的已生效套餐。

## 常见边界

- `sk_live_` 存在不代表 Production 当前可用，仍需检查暂停状态。
- `FP-4032` 不表示 Key 已撤销；撤销或无效 Key 使用 `FP-4011`。
- Production 启用不复制 Sandbox Webhook Signing Secret。
- Account 当前是否启用或暂停属于业务状态，必须查询账户数据。

## 相关文档

- 环境政策见 `KB-BR-002`，套餐生效见 `KB-BR-004`。
- Secret Key 管理见 `KB-API-003`。
- Sandbox 差异见 `KB-API-004`。
- Production Webhook 配置见 `KB-API-029`。

