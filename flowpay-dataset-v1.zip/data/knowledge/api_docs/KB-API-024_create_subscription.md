---
doc_id: KB-API-024
title: 创建 Subscription
doc_type: api_doc
authority: official
product_areas: [subscriptions, customers]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-006, RULE-CUSTOMER-004, RULE-IDEMP-001, RULE-IDEMP-004, RULE-PLAN-001, RULE-PLAN-004]
related_docs: [KB-BR-004, KB-BR-013, KB-API-009, KB-API-023, KB-API-025, KB-API-033]
indexing: include
language: zh-CN
---

# 创建 Subscription

## Endpoint

```http
POST /v1/subscriptions
```

创建请求需要 Growth 或 Scale 套餐、已开启的 `subscriptions` Feature Flag，以及同 Account、同环境的 active Customer。

## 请求参数

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `customer_id` | string | 是 | active Customer |
| `amount` | integer | 是 | 每周期金额，最小货币单位 |
| `currency` | string | 是 | Customer 所属 Account 地区支持的币种 |
| `interval` | string | 是 | `month` 或 `year` |
| `payment_method` | string | 是 | 周期扣费使用的 Payment Method |
| `trial_days` | integer | 否 | 1～30，只能创建时设置 |
| `metadata` | object | 否 | Merchant 自定义字符串键值 |

## 示例

```bash
curl https://api.flowpay.example/v1/subscriptions \
  -X POST \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY" \
  -H "Idempotency-Key: membership-user-42" \
  -H "Content-Type: application/json" \
  -d '{
    "customer_id":"cus_01JEXAMPLE",
    "amount":2900,
    "currency":"USD",
    "interval":"month",
    "payment_method":"pm_example",
    "trial_days":14
  }'
```

有试用期时返回 `trialing`；没有试用期时进入正常计费流程。创建返回 HTTP 201。

## 不可变字段

创建后不能更换 `customer_id` 或 `currency`。需要改变时取消原 Subscription 并创建新资源。试用期也不能在创建后补加、延长或重新开始。

## 错误

- `FP-4031`：套餐不支持 Subscription 或功能开关未生效。
- `FP-4041`：Customer 不存在或不可见。
- `FP-4221`：Customer 已删除或状态不允许。
- `FP-4001`：金额、币种、interval 或试用期非法。
- `FP-4091`：相同 Idempotency Key 使用不同参数。

## 相关文档

- 套餐权限见 `KB-BR-004`，Subscription 生命周期见 `KB-BR-013`。
- 对象字段见 `KB-API-023`，取消见 `KB-API-025`。
- 幂等创建见 `KB-API-033`。

