---
doc_id: KB-API-019
title: Refund 对象
doc_type: api_doc
authority: official
product_areas: [refunds, payments]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-REFUND-001, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-MONEY-003, RULE-MONEY-004]
related_docs: [KB-BR-012, KB-API-012, KB-API-020, KB-API-021, KB-API-022]
indexing: include
language: zh-CN
---

# Refund 对象

## 概述

Refund 表示对一个 succeeded Payment 退回全部或部分金额的请求。每个 Refund 只属于原 Payment 所属的 Account 和环境，币种继承原 Payment。

## 对象字段

```json
{
  "id":"re_01JEXAMPLE",
  "object":"refund",
  "payment_id":"pay_01JEXAMPLE",
  "amount":500,
  "currency":"USD",
  "status":"pending",
  "mode":"standard",
  "failure_code":null,
  "created_at":"2026-08-27T04:00:00Z",
  "succeeded_at":null
}
```

| 字段 | 说明 |
| --- | --- |
| `payment_id` | 原 succeeded Payment |
| `amount` | 最小货币单位整数 |
| `currency` | 与 Payment 相同 |
| `status` | `pending`、`succeeded`、`failed` 或 `canceled` |
| `mode` | `standard` 或满足条件时的 `instant` |
| `failure_code` | Refund 失败时的原因 |

## 状态

```text
create
├──> succeeded
└──> pending
       ├──> succeeded
       ├──> failed
       └──> canceled
```

`pending` Refund 暂时占用 Payment 的可退款额度。进入 `failed` 或 `canceled` 后额度释放；进入 `succeeded` 后计入已退款金额。

## 版本差异

`2025-10-01` 至 `2026-04-01` 默认先返回 `pending`。从 `2026-07-01` 起，符合条件的普通 Refund 可以在创建响应中直接为 `succeeded`，否则仍返回 `pending`。调用方必须按实际状态处理，不能假设创建成功就等于退款完成。

## 资格边界

只有 succeeded 且成功时间未超过 180 天的 Payment 可以退款。套餐决定是否支持部分退款；Instant Refund 还需要 Scale、NA/EU、功能开关和金额条件。

## 相关文档

- 完整退款政策见 `KB-BR-012`。
- Payment 对象见 `KB-API-012`。
- 全额和部分退款见 `KB-API-020`、`KB-API-021`。
- 查询状态和额度见 `KB-API-022`。

