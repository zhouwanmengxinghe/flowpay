---
doc_id: KB-API-011
title: 更新与删除 Customer
doc_type: api_doc
authority: official
product_areas: [customers]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-CUSTOMER-001, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005, RULE-TENANT-003]
related_docs: [KB-BR-009, KB-API-009, KB-API-010, KB-API-012, KB-API-023]
indexing: include
language: zh-CN
---

# 更新与删除 Customer

## 更新 Endpoint

```http
PATCH /v1/customers/{customer_id}
```

可更新 `email`、`name` 和 `metadata`。不能修改 Customer ID、所属 Account、环境、创建时间或状态。

```bash
curl https://api.flowpay.example/v1/customers/cus_01JEXAMPLE \
  -X PATCH \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY" \
  -H "Content-Type: application/json" \
  -d '{"email":"new-address@example.test"}'
```

Email 更新不会触发 Customer 合并，也不会修改历史 Payment 上保存的其他交易字段。

## 删除 Endpoint

```http
DELETE /v1/customers/{customer_id}
```

删除是软删除。成功返回更新后的 Customer，对象状态为 `deleted` 并设置 `deleted_at`。删除不可撤销。

Customer 被删除后：

- 不能用于创建新 Payment。
- 不能用于创建新 Subscription。
- 历史 Payment、Refund、Subscription 和 Invoice 仍可按各自权限查询。
- 已有 Subscription 不会自动取消，应单独调用 Subscription 取消动作。

## 状态限制

只有 `active` Customer 可以更新。对 `deleted` Customer 再次更新或删除不会恢复资源；调用方应读取当前状态并停止重复操作。

## 错误

- `FP-4001`：可更新字段格式错误，或尝试修改只读字段。
- `FP-4041`：Customer 不存在、属于其他 Account 或环境不可见。
- `FP-4221`：当前 Customer 状态不允许操作。

## 边界

删除 Customer 不是退款、取消 Payment 或取消 Subscription 的快捷方式。每个业务对象有独立生命周期。若要终止订阅，应先调用 Subscription cancel；若要退款，应基于 Payment 状态和退款额度创建 Refund。

## 相关文档

- Customer 生命周期见 `KB-BR-009`，对象字段见 `KB-API-009`。
- Payment 对象见 `KB-API-012`。
- Subscription 取消见 `KB-API-025`。

