---
doc_id: KB-API-004
title: Sandbox 测试环境
doc_type: api_doc
authority: official
product_areas: [developer_platform, testing]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-ENV-001, RULE-ENV-002, RULE-ENV-004, RULE-ENV-005, RULE-RATE-002, RULE-AUTH-008]
related_docs: [KB-BR-002, KB-BR-005, KB-API-001, KB-API-003, KB-API-005, KB-API-013, KB-API-029]
indexing: include
language: zh-CN
---

# Sandbox 测试环境

## 概述

每个 FlowPay Account 创建后立即获得 Sandbox。Sandbox 用于开发集成、验证状态处理和演练 Webhook，不产生真实资金活动。它与 Production 使用相同 API 基础地址，但必须使用 `sk_test_` Secret Key。

## 资源隔离

Sandbox Customer、Payment、Refund、Subscription、Invoice、Event 和 Webhook Endpoint 只存在于 Sandbox。它们不会自动复制到 Production，也不能被 Production Key 读取。

上线前需要在 Production 重新创建 Customer 映射、Webhook Endpoint 和其他配置。不要把 Sandbox 资源 ID 保存为 Production 业务映射。

## 测试 Payment Method

Sandbox 提供固定测试 Payment Method：

| 值 | 预期结果 |
| --- | --- |
| `pm_test_success` | Payment 进入成功处理路径 |
| `pm_test_declined` | 返回支付方式拒绝语义 |
| `pm_test_insufficient` | 返回资金不足语义 |
| `pm_test_action` | 在支持版本进入 `requires_action` |
| `pm_test_expired` | 返回支付方式过期语义 |

测试值只在 Sandbox 有效。测试结果仍遵守请求版本，例如 `pm_test_action` 在 `2025-10-01` 中表现为 `failed + FP-4023`，在 `2026-01-15` 及以后进入 `requires_action`。

## Sandbox Rate Limit

Sandbox 固定为持续 120 req/min、突发 180 req/min，与 Account 套餐无关。大量自动化测试应限制并发并使用幂等键，避免 429 和重复资源。

## Webhook 测试

Sandbox Event 只能投递给 Sandbox Endpoint。可使用公开可访问的测试接收地址或本地隧道，但 Endpoint 必须为 `enabled` 并订阅对应事件。签名规则与 Production 相同，并受事件 API Version 影响。

## 不可推断的结论

Sandbox 测试成功只能证明测试环境下的请求、版本和配置可工作。它不能证明 Production 已启用、Production Key 有效、Production Endpoint 已配置，或正式服务当前没有运行事件。

## 相关文档

- 环境边界见 `KB-BR-002`，Sandbox 限流见 `KB-BR-005`。
- 快速开始和认证见 `KB-API-001`、`KB-API-003`。
- Payment 创建见 `KB-API-013`，Endpoint 管理见 `KB-API-029`。

