---
doc_id: KB-API-032
title: Webhook 重试与 Event 去重
doc_type: api_doc
authority: official
product_areas: [webhooks, operations]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-018]
related_docs: [KB-BR-015, KB-BR-016, KB-API-029, KB-API-030, KB-API-031]
indexing: include
language: zh-CN
---

# Webhook 重试与 Event 去重

## 成功响应

Merchant Endpoint 返回 HTTP 200～299 时，FlowPay 将 Delivery 标记为成功。HTTP 3xx 不会被跟随，按失败处理。HTTP 4xx 和 5xx 一般进入重试；HTTP 410 表示 Endpoint 已永久移除，FlowPay 会立即禁用 Endpoint。

任意 Attempt 返回 2xx 后，都应取消尚未执行的重试调度。若系统把 204 等成功响应错分为失败并继续调度，应修正响应分类、将 Delivery 投影为 `delivered`，并取消多余调度。

Endpoint 应在完成签名验证和可靠保存 Event 后尽快返回 2xx。耗时业务处理可以转交内部队列，避免因响应超时触发重复投递。

## 默认重试计划

首次失败后的重试时间为：

1. 1 分钟。
2. 5 分钟。
3. 30 分钟。
4. 2 小时。
5. 8 小时。
6. 24 小时。

完成 6 次重试仍失败后，Delivery 进入 `exhausted`。这些时间均相对首次失败计算。

进入 `exhausted` 后应停止继续投递，并向 Merchant 展示从首次 Attempt 到六次重试的完整失败时间线；默认计划下合计是 7 次 Attempt，而不是 6 次。

Scale 可以配置最多 8 次重试，但从首次失败到最后一次重试的总窗口不得超过 72 小时。Starter 和 Growth 使用默认策略。

## 至少一次投递

FlowPay 使用至少一次语义。Merchant 可能已经处理 Event，但响应在网络中丢失，FlowPay 因此再次发送同一 `event_id`。重复 Delivery 不是新的业务事件。

推荐处理方式：

1. 验证签名和时间戳。
2. 在持久化存储中以 `event_id` 原子写入去重记录。
3. 若已存在，直接返回 2xx，不重复执行业务动作。
4. 若不存在，保存 Event 并提交业务处理。
5. 返回 2xx。

不要只用 Payment ID 去重，因为同一 Payment 可以产生多个不同 Event Type。

## Secret 与重试

重试发生时使用当时的当前 Signing Secret 重新签名。Secret 轮换期间，消费者需要接受新 Secret，并在 24 小时窗口内兼容旧 Secret。

## 相关文档

- 投递政策见 `KB-BR-015`。
- Endpoint 管理见 `KB-API-029`，Event Type 见 `KB-API-030`。
- 签名验证见 `KB-API-031`。
