---
doc_id: KB-API-021
title: 创建部分 Refund
doc_type: api_doc
authority: official
product_areas: [refunds, payments]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-007, RULE-IDEMP-001, RULE-PLAN-004]
related_docs: [KB-BR-004, KB-BR-012, KB-API-019, KB-API-020, KB-API-022, KB-API-033]
indexing: include
language: zh-CN
---

# 创建部分 Refund

## Endpoint

```http
POST /v1/refunds
```

传入小于 Payment 当前剩余可退金额的 `amount` 时创建部分 Refund。该能力只对 Growth 和 Scale 开放；Starter 请求返回 `FP-4031 Feature Unavailable for Plan`。

## 请求参数

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `payment_id` | string | 是 | succeeded Payment |
| `amount` | integer | 是 | 大于 0，且不超过当前可申请额度 |
| `mode` | string | 否 | 默认 `standard`，可选 `instant` |
| `reason` | string | 否 | Merchant 记录原因 |

Refund 不接收 `currency`，它自动继承 Payment 币种。

```bash
curl https://api.flowpay.example/v1/refunds \
  -X POST \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY" \
  -H "FlowPay-Version: 2026-07-01" \
  -H "Idempotency-Key: refund-order-9001-item-2" \
  -H "Content-Type: application/json" \
  -d '{"payment_id":"pay_01JEXAMPLE","amount":500}'
```

## 额度计算

创建时的可申请额度等于原始金额减去 succeeded 和 pending Refund 金额。多个并发 Refund 不能使总额超过 Payment 金额。pending Refund 失败或取消后，其额度才重新释放。

## Instant 模式

`mode: instant` 仅在 Scale、NA/EU、`instant_refund` 开关开启且金额不超过 100,000 个最小单位时可用，同时仍需满足状态和 180 天窗口。Instant 条件不满足不表示普通 Refund 也不可用。

## 错误

- `FP-4031`：套餐不支持部分退款或 Instant 功能。
- `FP-4221`：Payment 状态不可退款。
- `FP-4222`：退款窗口已过。
- `FP-4001`：金额无效或超过可申请额度。
- `FP-4091`：幂等参数冲突。

## 相关文档

- 套餐权限见 `KB-BR-004`，完整退款规则见 `KB-BR-012`。
- 全额退款见 `KB-API-020`，额度查询见 `KB-API-022`。

