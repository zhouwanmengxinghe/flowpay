---
doc_id: KB-API-009
title: Customer 对象
doc_type: api_doc
authority: official
product_areas: [customers]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005, RULE-TENANT-001, RULE-TENANT-004]
related_docs: [KB-BR-009, KB-API-010, KB-API-011, KB-API-012, KB-API-023]
indexing: include
language: zh-CN
---

# Customer 对象

## 概述

Customer 保存 Merchant 的终端客户档案，并作为 Payment 和 Subscription 的关联对象。Customer 只属于一个 Account 和一个环境，不能转移到其他租户或在 Sandbox、Production 之间复制。

## 对象字段

```json
{
  "id": "cus_01JEXAMPLE",
  "object": "customer",
  "email": "buyer@example.test",
  "name": "Demo Buyer",
  "status": "active",
  "metadata": {"merchant_user_id": "user_42"},
  "created_at": "2026-08-27T03:30:00Z",
  "updated_at": "2026-08-27T03:30:00Z",
  "deleted_at": null
}
```

| 字段 | 含义 |
| --- | --- |
| `id` | 以 `cus_` 开头的稳定 ID |
| `email` | 联系信息，不是唯一键 |
| `name` | 可选显示名称 |
| `status` | `active` 或 `deleted` |
| `metadata` | Merchant 自定义字符串键值，不能替代业务字段 |
| `created_at` / `updated_at` | UTC 时间戳 |
| `deleted_at` | 软删除时间；未删除时为 `null` |

## 生命周期

新建 Customer 为 `active`。执行删除后进入 `deleted`，不能恢复，也不能创建新的 Payment 或 Subscription。删除不会移除历史 Payment、Refund、Subscription 或 Invoice，它们继续保留 Customer ID。

## 标识边界

Email 可以重复，也可以更新。需要精确关联时使用 `customer_id`。FlowPay 不按 Email 自动合并 Customer，也不保证同一 Email 只有一个 Customer。

Customer ID 在另一个 Account 或环境中不可见。读取不可见资源和不存在资源都使用 `FP-4041`，避免泄露租户信息。

## 相关文档

- 生命周期政策见 `KB-BR-009`。
- 创建 Customer 见 `KB-API-010`，更新和删除见 `KB-API-011`。
- Payment 和 Subscription 对 Customer 的要求见 `KB-API-012`、`KB-API-023`。

