---
doc_id: KB-API-033
title: 使用 Idempotency-Key
doc_type: api_doc
authority: official
product_areas: [developer_platform, payments, refunds, subscriptions]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006, RULE-REQ-003]
related_docs: [KB-BR-008, KB-API-007, KB-API-008, KB-API-013, KB-API-020, KB-API-021, KB-API-024, KB-API-034]
indexing: include
language: zh-CN
---

# 使用 Idempotency-Key

## 适用请求

创建 Payment、Refund 和 Subscription 的 POST 请求支持：

```http
Idempotency-Key: merchant-operation-id
```

同一业务操作的首次请求和安全重试应使用相同 Key。新的业务操作必须使用新 Key。

## 作用域和保留期

幂等作用域由 Account、环境、Endpoint 和 Key 文本共同组成。相同 Key 在 Sandbox 与 Production、不同 Account 或不同创建 Endpoint 中互不冲突。

FlowPay 保留结果 24 小时：

- 相同 Key、相同有效参数：返回首次结果，不创建新资源。
- 相同 Key、不同参数：返回 HTTP 409 和 `FP-4091`。
- 24 小时后再次使用：作为新请求处理，可能创建新资源。

幂等键不是长期订单唯一约束。超过 24 小时后，客户端不能继续依赖旧 Key 去重；Merchant 应持久保存订单 ID 到 FlowPay 资源 ID 的映射，用业务侧订单关联窗口外的新请求和新资源。

## 示例

```bash
curl https://api.flowpay.example/v1/payments \
  -X POST \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY" \
  -H "Idempotency-Key: order-9001-attempt-1" \
  -H "Content-Type: application/json" \
  -d '{"customer_id":"cus_01JEXAMPLE","amount":1200,"currency":"USD","payment_method":"pm_example"}'
```

如果网络超时，保持请求参数不变并复用该 Key。不要通过更换 Key 来绕过未知结果，否则可能重复创建 Payment。

## 与 Request ID 的区别

每次网络请求都有新的 `request_id`，即使复用 Idempotency Key 返回同一资源。Request ID 用于追踪一次请求；Idempotency Key 用于关联多次重试的同一业务操作。

从 `2026-01-15` 起，`FP-4091` 的详情可包含首次请求的 `conflict_request_id`。

## 相关文档

- 正式幂等政策见 `KB-BR-008`。
- Request ID 见 `KB-API-007`，错误格式见 `KB-API-008`。
- 创建 Payment、Refund、Subscription 见 `KB-API-013`、`KB-API-020`、`KB-API-021`、`KB-API-024`。
