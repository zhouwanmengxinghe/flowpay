---
doc_id: KB-API-003
title: 使用 Secret Key 认证
doc_type: api_doc
authority: official
product_areas: [developer_platform, accounts]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008, RULE-ENV-001, RULE-ENV-005]
related_docs: [KB-BR-002, KB-BR-006, KB-API-002, KB-API-004, KB-API-005, KB-API-008]
indexing: include
language: zh-CN
---

# 使用 Secret Key 认证

## Authorization Header

FlowPay API 使用 Bearer Secret Key 认证：

```http
Authorization: Bearer sk_test_example
```

Sandbox Key 以 `sk_test_` 开头，Production Key 以 `sk_live_` 开头。Key 只属于一个 Account 和一个环境，不能跨 Account 或跨环境使用。

## Key 状态

Key 状态为 `active`、`expiring` 或 `revoked`。`active` 和轮换过渡期内的 `expiring` Key 可以调用 API；`revoked` Key 立即失效且不能恢复。缺失、格式错误、未知或已撤销的 Key 返回 HTTP 401 和 `FP-4011`。

环境不匹配使用不同错误：有效 Sandbox Key 访问 Production 资源时返回 `FP-4012`。Production 被暂停时，Key 本身可能仍有效，但请求返回 `FP-4032`。

## 安全存储

V1 Secret Key 对所属环境具有完整 API 权限，不提供细粒度 Scope。Key 应只存放在服务端 Secret Manager 或受保护环境变量中，不应提交到源码、发送到浏览器或写入普通日志。

API 响应不会返回完整 Secret Key。创建时展示的值应立即保存；后续如丢失，应创建新 Key 并轮换，而不是尝试读取旧值。

## 轮换流程

1. 创建同 Account、同环境的新 Key。
2. 部署新 Key，并验证产生成功 Request ID。
3. 让旧 Key 进入 `expiring`，最长保留 24 小时。
4. 确认全部调用方已切换后撤销旧 Key。

创建多个 Key 不会增加 Rate Limit，因为额度按 Account 和环境共享。

## 请求示例

```bash
curl https://api.flowpay.example/v1/customers \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY" \
  -H "FlowPay-Version: 2026-07-01"
```

## 错误区分

| 错误 | 含义 |
| --- | --- |
| `FP-4011` | Key 缺失、未知、格式错误或已撤销 |
| `FP-4012` | Key 环境与目标资源环境不同 |
| `FP-4032` | Account 的 Production 访问被暂停 |

## 相关文档

- 环境政策见 `KB-BR-002`，完整 Key 生命周期见 `KB-BR-006`。
- Sandbox 和 Production 操作见 `KB-API-004`、`KB-API-005`。
- 错误响应格式见 `KB-API-008`。

