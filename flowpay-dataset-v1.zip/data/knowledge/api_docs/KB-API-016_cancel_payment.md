---
doc_id: KB-API-016
title: 取消 Payment
doc_type: api_doc
authority: official
product_areas: [payments]
api_versions: ["2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2026-01-15"
effective_to: null
supersedes: []
rule_ids: [RULE-PAY-001, RULE-PAY-003, RULE-PAY-005]
related_docs: [KB-BR-010, KB-API-012, KB-API-014, KB-API-015]
indexing: include
language: zh-CN
---

# 取消 Payment

## Endpoint

```http
POST /v1/payments/{payment_id}/cancel
```

只有状态为 `requires_action` 的 Payment 可以由 Merchant 主动取消。取消成功后 Payment 进入终态 `canceled`，不能恢复或再次确认。

## 示例

```bash
curl https://api.flowpay.example/v1/payments/pay_01JEXAMPLE/cancel \
  -X POST \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY" \
  -H "FlowPay-Version: 2026-07-01"
```

成功返回 HTTP 200 和状态为 `canceled` 的 Payment 对象。

## 状态限制

- `requires_action`：允许取消。
- `processing`：不能取消，等待最终结果。
- `succeeded`：不能取消；需要退回资金时创建 Refund。
- `failed`：已经是终态，无需取消。
- `canceled`：已经是终态，不能恢复。

对不允许状态调用返回 `FP-4221`。调用方应先查询 Payment，避免根据页面状态或旧缓存做决定。

## 版本要求

该动作适用于 `2026-01-15` 及以后版本，因为旧版本没有 `requires_action`。在 `2025-10-01` 中，需要客户操作的支付直接表现为 `failed + FP-4023`，不存在可取消的等待状态。

## 取消与退款的区别

取消只终止尚未完成的 `requires_action` Payment，不移动已成功资金。Refund 只适用于 `succeeded` Payment。两者不能互换：对 succeeded Payment 调用 cancel 不会退款，对 requires_action Payment 创建 Refund 也不会成功。

## 相关文档

- Payment 生命周期见 `KB-BR-010`。
- 对象和最新状态查询见 `KB-API-012`、`KB-API-014`。
- 完成待操作支付见 `KB-API-015`。
- Refund 创建见 `KB-API-020`、`KB-API-021`。

