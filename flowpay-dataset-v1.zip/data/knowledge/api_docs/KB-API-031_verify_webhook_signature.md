---
doc_id: KB-API-031
title: 验证 Webhook 签名
doc_type: api_doc
authority: official
product_areas: [webhooks, developer_platform]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018]
related_docs: [KB-BR-016, KB-API-003, KB-API-006, KB-API-029, KB-API-030, KB-API-032]
indexing: include
language: zh-CN
---

# 验证 Webhook 签名

## Header 名称

签名 Header 由 Event 的 API Version 决定：

| Event API Version | Header |
| --- | --- |
| `2025-10-01`、`2026-01-15` | `X-FlowPay-Signature` |
| `2026-04-01`、`2026-07-01` | `FlowPay-Signature` |

从 `2026-04-01` 起不再同时发送旧 Header。迁移时应确保消费者读取正确名称。

## 签名内容

Header 包含时间戳 `t` 和签名 `v1`。待签名内容为：

```text
{timestamp}.{raw_request_body}
```

使用 Endpoint Signing Secret 计算 HMAC-SHA256，并以恒定时间比较结果。必须使用收到的原始请求字节；解析 JSON 后重新序列化会改变正文并导致验证失败。

## 验证步骤

1. 根据 Event 版本读取正确 Header。
2. 解析 `t` 和一个或多个 `v1` 值。
3. 检查时间戳与服务器时间差不超过 5 分钟。
4. 使用 Endpoint 当前或仍在兼容期内的 Signing Secret 计算签名。
5. 恒定时间比较，成功后解析 Event。
6. 按 `event_id` 去重，再执行业务处理。

## Secret 轮换

新 Secret 在轮换后立即用于新投递。旧 Secret 保持 24 小时有效；重试会使用重试发生时的当前 Secret 重新签名。过渡期内消费者应同时接受新旧 Secret，确认所有实例更新后移除旧值。

Webhook Signing Secret 与 API Secret Key 不同。使用 `sk_live_` 或 `sk_test_` 验证签名会失败。

## 常见失败

- 读取了错误版本的 Header。
- 使用解析后的 JSON 而非原始正文。
- Endpoint 对应 Secret 选错。
- Secret 已轮换但服务实例未更新。
- 服务器时钟偏差超过 5 分钟。

## 相关文档

- 完整签名政策见 `KB-BR-016`。
- Endpoint 与 Secret 创建见 `KB-API-029`。
- Event 版本见 `KB-API-030`。
- 重试和去重见 `KB-API-032`。

