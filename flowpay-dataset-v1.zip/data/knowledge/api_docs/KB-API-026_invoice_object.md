---
doc_id: KB-API-026
title: Invoice 对象
doc_type: api_doc
authority: official
product_areas: [invoices, subscriptions, payments]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-007, RULE-INVOICE-008]
related_docs: [KB-BR-014, KB-API-023, KB-API-027, KB-API-028]
indexing: include
language: zh-CN
---

# Invoice 对象

## 概述

Invoice 表示 Subscription 一个计费周期的应收账单。V1 每个周期生成一份 Invoice，并通过关联 Payment 完成自动扣费。

## 对象字段

```json
{
  "id":"in_01JEXAMPLE",
  "object":"invoice",
  "subscription_id":"sub_01JEXAMPLE",
  "customer_id":"cus_01JEXAMPLE",
  "amount_due":2900,
  "currency":"USD",
  "status":"open",
  "payment_ids":["pay_01JEXAMPLE"],
  "attempt_count":1,
  "next_retry_at":"2026-08-28T00:00:00Z",
  "created_at":"2026-08-27T00:00:00Z",
  "paid_at":null
}
```

`payment_ids` 按尝试顺序保存关联 Payment。因为 failed Payment 是终态，每次自动重试都会创建新 Payment。`attempt_count` 包含首次尝试。

## 状态

| 状态 | 含义 |
| --- | --- |
| `draft` | 尚未定稿，不发起扣费 |
| `open` | 已定稿，等待首次扣费或后续重试 |
| `paid` | 某次关联 Payment 成功 |
| `uncollectible` | 首次尝试和三次重试均失败 |
| `void` | 已作废，不再扣费 |

`draft` 和 `open` 可以进入 `void`。`paid`、`uncollectible` 和 `void` 不能通过 void 操作改写状态。退回 paid Invoice 的资金应操作其 Payment 和 Refund，不应修改 Invoice。

## 与 Subscription 的关系

首次扣费失败后 Invoice 保持 `open`，Subscription 进入 `past_due`。任一重试成功后 Invoice 为 `paid`，Subscription 恢复 `active`。重试耗尽后 Invoice 为 `uncollectible`，Subscription 为 `canceled`。

## 相关文档

- Invoice 状态政策见 `KB-BR-014`。
- Subscription 对象见 `KB-API-023`。
- 扣费时间线和查询见 `KB-API-027`、`KB-API-028`。

