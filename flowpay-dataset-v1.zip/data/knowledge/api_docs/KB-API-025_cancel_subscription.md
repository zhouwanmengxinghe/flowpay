---
doc_id: KB-API-025
title: 取消 Subscription
doc_type: api_doc
authority: official
product_areas: [subscriptions]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-SUB-004, RULE-SUB-005, RULE-CUSTOMER-003]
related_docs: [KB-BR-013, KB-API-011, KB-API-023, KB-API-024, KB-API-026]
indexing: include
language: zh-CN
---

# 取消 Subscription

## Endpoint

```http
POST /v1/subscriptions/{subscription_id}/cancel
```

默认在当前计费周期结束时取消。要立即取消，显式传入 `immediate: true`。

## 周期末取消

```json
{
  "immediate": false
}
```

成功后 `cancel_at_period_end` 变为 `true`，Subscription 在 `current_period_end` 前保持当前状态。周期结束时进入 `canceled`。因此，安排取消后立即读取，看到 `status: active` 是预期行为。

## 立即取消

```json
{
  "immediate": true
}
```

Subscription 立即进入 `canceled`。V1 不因立即取消自动创建 Refund；若业务需要退回已支付金额，必须针对相应 succeeded Payment 单独执行退款资格判断。

## 状态限制

`trialing`、`active` 和 `past_due` 可以请求取消。`canceled` 是终态，不能恢复，也不接受再次取消来改变时间或重新激活。恢复服务必须创建新 Subscription。

## Customer 删除

删除 Customer 不会自动取消 Subscription。若 Merchant 希望终止后续计费，应先读取 Customer 关联的 Subscription 并调用取消 Endpoint，再按数据保留需求删除 Customer。

## 示例

```bash
curl https://api.flowpay.example/v1/subscriptions/sub_01JEXAMPLE/cancel \
  -X POST \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY" \
  -H "Content-Type: application/json" \
  -d '{"immediate":false}'
```

## 错误

- `FP-4041`：Subscription 不存在或不可见。
- `FP-4221`：当前状态不允许该取消动作。
- `FP-4001`：参数格式非法。

## 相关文档

- 生命周期和取消语义见 `KB-BR-013`。
- Subscription 字段见 `KB-API-023`，创建见 `KB-API-024`。
- Customer 软删除见 `KB-API-011`。

