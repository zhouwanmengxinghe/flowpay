---
doc_id: KB-API-014
title: 查询 Payment
doc_type: api_doc
authority: official
product_areas: [payments]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-TENANT-002, RULE-TENANT-003, RULE-TENANT-004, RULE-PAY-001, RULE-VERSION-005, RULE-REQ-003]
related_docs: [KB-BR-001, KB-BR-010, KB-API-007, KB-API-012, KB-API-013, KB-API-017, KB-API-022]
indexing: include
language: zh-CN
---

# 查询 Payment

## Endpoint

```http
GET /v1/payments/{payment_id}
```

使用 Payment ID 读取当前状态、金额、Customer、错误和退款摘要。Request ID 不能替代 Payment ID。

## 示例

```bash
curl https://api.flowpay.example/v1/payments/pay_01JEXAMPLE \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY" \
  -H "FlowPay-Version: 2026-07-01"
```

成功返回 HTTP 200 和 Payment 对象。

## 状态读取

Payment 可能在首次创建响应后继续变化，例如从 `processing` 进入 `succeeded` 或 `failed`。读取 Endpoint 返回查询发生时的业务状态。客户端可以轮询，但生产集成通常应同时处理 Webhook，并限制轮询频率。

若 Payment 为 `requires_action`，响应包含完成操作所需的 `next_action`。若为 `failed`，`error` 包含支付错误码。`succeeded_at` 只在成功后有值。

## 退款摘要

响应中的 `refunded_amount` 只统计成功 Refund，`refundable_amount` 还会扣除 pending Refund 占用，并受 180 天窗口影响。需要查看每笔 Refund 时，应使用 Refund 查询或相应列表能力。

## API Version

读取时指定的版本可以改变字段表达，但不会改变 Payment 内部状态。例如旧版本不提供 `requires_action` 表达；版本相关问题应结合 Payment 创建时版本和当前读取版本解释。

## 错误

- `FP-4011`：Secret Key 无效。
- `FP-4012`：Key 与资源环境不匹配。
- `FP-4041`：Payment 不存在、属于其他 Account 或不可见。
- `FP-4291`：查询频率超过限额。

`FP-4041` 不透露资源是否属于其他租户。先确认环境和 Account，再核对 ID。

## 相关文档

- Payment 对象和状态机见 `KB-API-012`、`KB-BR-010`。
- 创建见 `KB-API-013`，列表过滤见 `KB-API-017`。
- Refund 额度见 `KB-API-022`。

