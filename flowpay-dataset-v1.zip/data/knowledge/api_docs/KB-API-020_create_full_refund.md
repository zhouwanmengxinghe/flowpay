---
doc_id: KB-API-020
title: 创建全额 Refund
doc_type: api_doc
authority: official
product_areas: [refunds, payments]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-008, RULE-IDEMP-001, RULE-IDEMP-004]
related_docs: [KB-BR-012, KB-API-019, KB-API-021, KB-API-022, KB-API-033]
indexing: include
language: zh-CN
---

# 创建全额 Refund

## Endpoint

```http
POST /v1/refunds
```

省略 `amount` 时，FlowPay 对 Payment 当前全部剩余可退金额创建 Refund。发送 `Idempotency-Key` 以避免网络重试产生重复退款。

## 请求参数

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `payment_id` | string | 是 | 状态为 succeeded 的 Payment |
| `mode` | string | 否 | `standard`，或满足条件时使用 `instant` |
| `reason` | string | 否 | Merchant 记录原因 |
| `metadata` | object | 否 | 自定义字符串键值 |

全额退款请求不传 `amount`。这里的“全额”是当前剩余可退金额，而不一定是 Payment 原始金额；若此前已有成功的部分 Refund，本次退回剩余部分。

## 示例

```bash
curl https://api.flowpay.example/v1/refunds \
  -X POST \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY" \
  -H "FlowPay-Version: 2026-07-01" \
  -H "Idempotency-Key: refund-order-9001-rest" \
  -H "Content-Type: application/json" \
  -d '{"payment_id":"pay_01JEXAMPLE","reason":"customer_request"}'
```

成功返回 HTTP 201 和 Refund。状态可能是 `pending` 或 `succeeded`，取决于 API Version 和处理条件。

## 资格检查

FlowPay 验证 Payment 状态、成功时间、剩余可退金额和已有 pending Refund。Starter 支持一次对剩余金额的全额退款，但不支持拆分为多次部分退款。

## 错误

- `FP-4041`：Payment 不存在或不可见。
- `FP-4221`：Payment 不是 succeeded。
- `FP-4222`：成功时间超过 180 天。
- `FP-4091`：相同幂等键使用了不同参数。
- `FP-4001`：没有剩余可退金额或请求格式非法。

## 相关文档

- Refund 对象见 `KB-API-019`。
- 部分退款见 `KB-API-021`，额度查询见 `KB-API-022`。
- 幂等键见 `KB-API-033`。

