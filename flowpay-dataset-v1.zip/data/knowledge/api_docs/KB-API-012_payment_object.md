---
doc_id: KB-API-012
title: Payment 对象
doc_type: api_doc
authority: official
product_areas: [payments]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-MONEY-001, RULE-MONEY-002]
related_docs: [KB-BR-010, KB-BR-011, KB-API-013, KB-API-014, KB-API-015, KB-API-016, KB-API-019]
indexing: include
language: zh-CN
---

# Payment 对象

## 概述

Payment 表示一次向 Customer 收款的尝试。每次重试失败支付都应创建新 Payment；`failed` Payment 不会原地恢复。

## 对象字段

```json
{
  "id":"pay_01JEXAMPLE",
  "object":"payment",
  "customer_id":"cus_01JEXAMPLE",
  "amount":1200,
  "currency":"USD",
  "status":"processing",
  "payment_method_id":"pm_example",
  "error":null,
  "refunded_amount":0,
  "refundable_amount":0,
  "created_at":"2026-08-27T03:30:00Z",
  "succeeded_at":null
}
```

`amount` 使用最小货币单位。`error` 在处理失败时包含支付错误码和说明。`refunded_amount` 统计成功退款，`refundable_amount` 根据状态、期限以及成功或 pending Refund 计算。

## 状态

| 状态 | 含义 | 可执行动作 |
| --- | --- | --- |
| `requires_action` | 等待 Customer 完成额外验证 | confirm、cancel |
| `processing` | FlowPay 正在处理 | 查询状态 |
| `succeeded` | 收款成功 | 有条件创建 Refund |
| `failed` | 收款失败终态 | 新建 Payment 重试 |
| `canceled` | 已取消终态 | 新建 Payment |

`requires_action` 只在 `2026-01-15` 及以后版本出现。旧版本将同类情况表示为 `failed + FP-4023`。

## Refund 字段

Payment `succeeded` 只是可退款的必要条件。`refundable_amount` 还受 180 天窗口、套餐、已有 Refund 和 pending 额度占用影响。非 succeeded Payment 通常显示为 0。

## 事件

成功事件在 `2026-07-01` 前为 `payment.completed`，在该版本起为 `payment.succeeded`。事件已经产生不表示特定 Endpoint 已成功接收。

## 相关文档

- 状态机见 `KB-BR-010`，失败分类见 `KB-BR-011`。
- 创建与查询见 `KB-API-013`、`KB-API-014`。
- confirm、cancel 见 `KB-API-015`、`KB-API-016`。
- Refund 对象见 `KB-API-019`。

