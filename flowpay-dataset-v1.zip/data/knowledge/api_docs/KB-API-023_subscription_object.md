---
doc_id: KB-API-023
title: Subscription 对象
doc_type: api_doc
authority: official
product_areas: [subscriptions, customers]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006]
related_docs: [KB-BR-013, KB-API-009, KB-API-024, KB-API-025, KB-API-026, KB-API-027]
indexing: include
language: zh-CN
---

# Subscription 对象

## 概述

Subscription 表示 Customer 的周期性计费关系。它只对 Growth 和 Scale Account 开放，并要求 `subscriptions` 功能开关开启。

## 对象字段

```json
{
  "id":"sub_01JEXAMPLE",
  "object":"subscription",
  "customer_id":"cus_01JEXAMPLE",
  "status":"active",
  "amount":2900,
  "currency":"USD",
  "interval":"month",
  "current_period_start":"2026-08-01T00:00:00Z",
  "current_period_end":"2026-09-01T00:00:00Z",
  "trial_end":null,
  "cancel_at_period_end":false,
  "canceled_at":null
}
```

`amount` 使用最小货币单位。`interval` 在 V1 为 `month` 或 `year`。Customer 和币种创建后不可修改；需要改变时取消原 Subscription 并创建新资源。

## 状态

| 状态 | 含义 |
| --- | --- |
| `trialing` | 处于创建时设置的试用期 |
| `active` | 正常计费 |
| `past_due` | 当前 Invoice 首次扣费失败，等待重试 |
| `canceled` | 已取消终态，不可恢复 |

试用期只能在创建时设置 1～30 天。首次 Invoice 扣费失败后进入 `past_due`；第 1、3、7 天重试任一次成功可恢复 `active`，全部失败后进入 `canceled`。

## 取消字段

`cancel_at_period_end: true` 表示已安排周期末取消，此时当前状态可能仍是 `active` 或 `past_due`。只有取消真正生效后，`status` 才是 `canceled`。立即取消会直接进入终态。

## 读取

```http
GET /v1/subscriptions/{subscription_id}
```

返回查询时的最新状态。Customer 删除不会自动删除或取消现有 Subscription。

## 相关文档

- 生命周期政策见 `KB-BR-013`。
- 创建和取消见 `KB-API-024`、`KB-API-025`。
- Invoice 对象和扣费见 `KB-API-026`、`KB-API-027`。

