---
doc_id: KB-API-010
title: 创建 Customer
doc_type: api_doc
authority: official
product_areas: [customers]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-005, RULE-TENANT-004, RULE-REQ-001]
related_docs: [KB-BR-009, KB-API-003, KB-API-009, KB-API-011, KB-API-013]
indexing: include
language: zh-CN
---

# 创建 Customer

## Endpoint

```http
POST /v1/customers
```

使用当前 Secret Key 所属的 Account 和环境创建 Customer。Sandbox Key 创建 Sandbox Customer，Production Key 创建 Production Customer。

## 请求参数

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `email` | string | 是 | 合法 Email，长度不超过 254 |
| `name` | string | 否 | 显示名称，长度不超过 120 |
| `metadata` | object | 否 | 最多 20 个字符串键值 |

Email 不要求唯一。若 Merchant 需要避免重复 Customer，应在自身系统保存用户 ID 与 `customer_id` 的映射。

## 示例

```bash
curl https://api.flowpay.example/v1/customers \
  -X POST \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY" \
  -H "Content-Type: application/json" \
  -H "FlowPay-Version: 2026-07-01" \
  -d '{
    "email":"buyer@example.test",
    "name":"Demo Buyer",
    "metadata":{"merchant_user_id":"user_42"}
  }'
```

成功返回 HTTP 201，Customer 状态为 `active`：

```json
{
  "id":"cus_01JEXAMPLE",
  "object":"customer",
  "email":"buyer@example.test",
  "name":"Demo Buyer",
  "status":"active"
}
```

## 错误

- `FP-4001`：Email、名称或 metadata 不符合格式。
- `FP-4011`：Secret Key 无效。
- `FP-4032`：Production 被暂停。
- `FP-4291`：当前 Account 和环境超过 Rate Limit。

Customer 创建不使用 Payment、Refund 和 Subscription 的业务幂等策略。Merchant 若因网络中断无法确认结果，应使用自身唯一用户映射查询和去重，避免仅按 Email 猜测。

## 相关文档

- Customer 字段见 `KB-API-009`。
- 认证见 `KB-API-003`。
- 更新和软删除见 `KB-API-011`。
- 使用 Customer 创建 Payment 见 `KB-API-013`。

