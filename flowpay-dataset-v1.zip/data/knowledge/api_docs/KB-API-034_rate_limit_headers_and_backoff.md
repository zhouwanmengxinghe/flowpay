---
doc_id: KB-API-034
title: Rate Limit Header 与退避
doc_type: api_doc
authority: official
product_areas: [developer_platform, operations]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007, RULE-PLAN-005]
related_docs: [KB-BR-005, KB-API-004, KB-API-006, KB-API-008, KB-API-033]
indexing: include
language: zh-CN
---

# Rate Limit Header 与退避

## 超限响应

超过 Account 和环境的调用额度时，FlowPay 返回 HTTP 429：

```json
{
  "error": {
    "code":"FP-4291",
    "message":"Rate limit exceeded.",
    "request_id":"req_01JEXAMPLE"
  }
}
```

从 API Version `2026-07-01` 开始，响应增加：

```http
FlowPay-RateLimit-Reset: 12
```

值表示建议等待的秒数。旧版本没有该 Header，仍应执行指数退避。

## 限额来源

Sandbox 固定为持续 120 req/min、突发 180 req/min。Production 使用已生效套餐：Starter 300/450、Growth 1,200/1,500、Scale 5,000/6,000；后一个数值是有限时间突发上限，不是持续额度。

同一 Account 和环境的所有 Key、所有 Endpoint 共享额度。Webhook 投递不计入 Merchant API Rate Limit。

## 推荐退避

1. 若有 `FlowPay-RateLimit-Reset`，至少等待指定时间。
2. 没有 Header 时，从短延迟开始指数增加。
3. 加入随机抖动，避免所有实例同时重试。
4. 设置最大重试次数和总时间。
5. 创建型请求保持相同 Idempotency Key。
6. 不要在 429 后立即并发重放全部积压请求。

## 诊断 429

错误本身不能证明套餐降级。需要确认请求环境、请求发生时已生效套餐、实际 Usage、多个 Key 或服务是否共享额度，以及重试是否放大流量。套餐降级申请尚未生效时，仍使用原套餐上限。

## 版本与错误处理

不要因为旧版本没有 Reset Header 就把 429 当作不可重试，也不要只根据 HTTP 429 忽略 `FP-4291` 和 Request ID。若同时出现 500/503，应分别按平台错误策略处理。

## 相关文档

- 完整 Rate Limit 政策见 `KB-BR-005`。
- Sandbox 限额见 `KB-API-004`。
- 版本 Header 见 `KB-API-006`。
- 幂等安全重试见 `KB-API-033`。

