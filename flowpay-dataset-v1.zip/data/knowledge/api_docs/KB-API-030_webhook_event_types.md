---
doc_id: KB-API-030
title: 订阅 Webhook Event Type
doc_type: api_doc
authority: official
product_areas: [webhooks, payments, refunds, subscriptions, invoices]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-WEBHOOK-005, RULE-WEBHOOK-017, RULE-PAY-007, RULE-VERSION-005]
related_docs: [KB-BR-007, KB-BR-015, KB-API-006, KB-API-027, KB-API-029, KB-API-031, KB-API-032]
indexing: include
language: zh-CN
---

# 订阅 Webhook Event Type

## 显式订阅

Webhook Endpoint 只接收 `subscribed_events` 中明确列出的 Event Type。未订阅事件时不会创建 Delivery，这不属于投递失败。更新订阅只影响更新后的新 Event，不补发此前未订阅的事件。

## 支持事件

### Payment

- `payment.action_required`
- `payment.processing`
- `payment.completed`：`2025-10-01` 至 `2026-04-01`
- `payment.succeeded`：`2026-07-01` 起
- `payment.failed`

### Refund

- `refund.succeeded`
- `refund.failed`

### Subscription

- `subscription.created`
- `subscription.updated`
- `subscription.canceled`

### Invoice

- `invoice.created`
- `invoice.paid`
- `invoice.payment_failed`

## 版本来源

公开 API 操作产生的 Event 沿用请求的 `FlowPay-Version`。平台周期任务产生的 Event 使用 Account 当时默认版本。成功 Payment 在 `2026-07-01` 中使用 `payment.succeeded`，此前版本使用 `payment.completed`。

迁移期间可在 Endpoint 中同时订阅旧、新成功事件名称，直到所有产生事件的请求和后台任务都切换完成。两个名称代表不同版本下的同类业务结果，不应把它们当作两个成功状态。

## Event Envelope

```json
{
  "id":"evt_01JEXAMPLE",
  "type":"payment.succeeded",
  "api_version":"2026-07-01",
  "created_at":"2026-08-27T05:00:00Z",
  "data":{"object":{"id":"pay_01JEXAMPLE"}}
}
```

消费者应先按 `type` 路由，再读取 `data.object`。使用 `event_id` 做去重。

## 相关文档

- API Version 选择见 `KB-API-006`。
- Endpoint 配置见 `KB-API-029`。
- 签名与重复投递见 `KB-API-031`、`KB-API-032`。
- Invoice 事件语义见 `KB-API-027`。

