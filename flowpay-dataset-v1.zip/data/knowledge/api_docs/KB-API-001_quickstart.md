---
doc_id: KB-API-001
title: FlowPay API 快速开始
doc_type: api_doc
authority: official
product_areas: [developer_platform]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-ENV-001, RULE-ENV-002, RULE-AUTH-001, RULE-VERSION-001, RULE-VERSION-003, RULE-REQ-001]
related_docs: [KB-BR-002, KB-BR-006, KB-BR-007, KB-API-002, KB-API-003, KB-API-004, KB-API-010, KB-API-013]
indexing: include
language: zh-CN
---

# FlowPay API 快速开始

## 概述

本指南使用 Sandbox Secret Key 创建一个 Customer，再为该 Customer 创建 Payment。Sandbox 中的对象和资金都是模拟数据，不会进入 Production。

## 准备工作

从 FlowPay Dashboard 获取以 `sk_test_` 开头的 Sandbox Secret Key。请求基础地址为 `https://api.flowpay.example`，所有 V1 Endpoint 使用 `/v1` 前缀。Secret Key 只能放在服务端。

```bash
export FLOWPAY_TEST_KEY="sk_test_example"
```

## 创建 Customer

```bash
curl https://api.flowpay.example/v1/customers \
  -X POST \
  -H "Authorization: Bearer $FLOWPAY_TEST_KEY" \
  -H "Content-Type: application/json" \
  -H "FlowPay-Version: 2026-07-01" \
  -d '{"email":"dev@example.test","name":"Demo Customer"}'
```

成功响应返回 `customer_id` 和 `status: active`。保存 `customer_id`，后续资源关联必须使用 ID，不能假设 Email 唯一。

## 创建 Payment

```bash
curl https://api.flowpay.example/v1/payments \
  -X POST \
  -H "Authorization: Bearer $FLOWPAY_TEST_KEY" \
  -H "Content-Type: application/json" \
  -H "FlowPay-Version: 2026-07-01" \
  -H "Idempotency-Key: demo-payment-001" \
  -d '{
    "customer_id":"cus_example",
    "amount":1200,
    "currency":"USD",
    "payment_method":"pm_test_success"
  }'
```

金额使用最小货币单位，`1200` 表示 USD 12.00。响应中的 Payment 可能为 `processing`、`requires_action`、`succeeded` 或 `failed`；不要只依赖首次响应，必要时查询 Payment 或处理 Webhook。

## 请求追踪与错误

每个请求都有 `request_id`。联系支持或查询日志时应提供该 ID。错误响应包含稳定的 `error.code`，例如无效 Key 使用 `FP-4011`，环境不匹配使用 `FP-4012`。

## Production 前的检查

切换到 Production 前，需要启用 Production、创建 `sk_live_` Key、重新创建 Production Customer 和 Webhook Endpoint。Sandbox 资源不会复制到 Production。

## 相关文档

- 基础请求格式见 `KB-API-002`，认证见 `KB-API-003`。
- Sandbox 策略见 `KB-API-004`。
- Customer 创建见 `KB-API-010`，Payment 创建见 `KB-API-013`。

