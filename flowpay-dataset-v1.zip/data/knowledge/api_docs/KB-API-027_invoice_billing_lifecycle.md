---
doc_id: KB-API-027
title: Invoice 扣费生命周期
doc_type: api_doc
authority: official
product_areas: [invoices, subscriptions, payments]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-PAY-002]
related_docs: [KB-BR-014, KB-API-012, KB-API-023, KB-API-026, KB-API-028, KB-API-030]
indexing: include
language: zh-CN
---

# Invoice 扣费生命周期

## 周期开始

FlowPay 为每个 Subscription 计费周期生成 Invoice。Invoice 从 `draft` 定稿为 `open` 后创建 Payment 并执行首次扣费。

## 成功路径

关联 Payment 成功时：

1. Payment 进入 `succeeded`。
2. Invoice 进入 `paid` 并设置 `paid_at`。
3. Subscription 保持或恢复 `active`。
4. FlowPay 产生 `invoice.paid`，并按 Payment 事件版本产生相应成功事件。

## 失败与重试

首次扣费失败后，Invoice 保持 `open`，Subscription 进入 `past_due`。FlowPay 在首次失败后的第 1、3、7 天执行三次重试。

```text
首次失败
  ├─ 第 1 天重试
  ├─ 第 3 天重试
  └─ 第 7 天重试
```

任一次成功即停止剩余重试，Invoice 进入 `paid`，Subscription 恢复 `active`。全部三次重试失败后，Invoice 进入 `uncollectible`，Subscription 进入 `canceled`。

每次重试创建新 Payment。调用方在诊断时应查看 `payment_ids` 全部尝试，不能只看第一笔 failed Payment。

## Webhook 事件

可用事件包括 `invoice.created`、`invoice.payment_failed`、`invoice.paid`、`subscription.updated` 和 `subscription.canceled`。收到一次 `invoice.payment_failed` 不能证明重试已经耗尽；它可能对应首次或中间尝试。

事件产生也不证明特定 Endpoint 已收到，应另查订阅和 Delivery。

## 时间边界

第 1、3、7 天均以首次失败时间为基准，不是在上一次失败后继续累加。具体 `next_retry_at` 以 Invoice 对象为准。

## 相关文档

- 正式扣费政策见 `KB-BR-014`。
- Invoice 和 Subscription 字段见 `KB-API-026`、`KB-API-023`。
- 查询所有 Payment 尝试见 `KB-API-028`。
- 事件类型见 `KB-API-030`。

