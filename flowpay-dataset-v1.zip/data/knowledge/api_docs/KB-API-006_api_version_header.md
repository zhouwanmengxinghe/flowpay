---
doc_id: KB-API-006
title: 使用 FlowPay-Version Header
doc_type: api_doc
authority: official
product_areas: [developer_platform]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-VERSION-005, RULE-VERSION-009]
related_docs: [KB-BR-007, KB-API-002, KB-API-008, KB-API-018, KB-API-030, KB-API-031]
indexing: include
language: zh-CN
---

# 使用 FlowPay-Version Header

## 选择请求版本

每个 Account 有一个默认 API Version。请求未提供版本 Header 时，FlowPay 使用该默认版本。要为单次请求覆盖版本，发送：

```http
FlowPay-Version: 2026-07-01
```

支持值为 `2025-10-01`、`2026-01-15`、`2026-04-01` 和 `2026-07-01`。不支持的值返回 HTTP 400 和 `FP-4002`，不会自动改用最接近版本。

## Header 的作用范围

Header 只影响当前请求。它不会修改 Account 默认版本，也不会转换资源内部状态。相同 Payment 在不同版本下读取仍是同一资源，但字段表示、可接受参数、默认处理和事件名称可能不同。

## 主要差异

| 版本 | Payment 参数 | 成功事件 | 签名 Header |
| --- | --- | --- | --- |
| `2025-10-01` | `source` | `payment.completed` | `X-FlowPay-Signature` |
| `2026-01-15` | `source` | `payment.completed` | `X-FlowPay-Signature` |
| `2026-04-01` | 推荐 `payment_method`，兼容 `source` | `payment.completed` | `FlowPay-Signature` |
| `2026-07-01` | 仅 `payment_method` | `payment.succeeded` | `FlowPay-Signature` |

`2026-07-01` 中提交 `source` 返回 `FP-4003`。`2026-01-15` 起支持 Payment `requires_action`。

## 事件版本

公开 API 操作产生的 Event 沿用该请求的版本。未带 Header 的请求使用 Account 默认版本，因此其 Event 也采用默认版本。平台内部周期任务产生的 Event 使用任务发生时的 Account 默认版本。

## 迁移建议

迁移时先显式为测试请求设置新版本，验证参数、响应和 Webhook 消费，再修改 Account 默认版本。不要仅修改默认版本而忽略异步事件消费者。

## 相关文档

- 完整支持政策见 `KB-BR-007`。
- 错误格式见 `KB-API-008`。
- Payment Method 兼容性见 `KB-API-018`。
- 事件名称和签名 Header 见 `KB-API-030`、`KB-API-031`。

