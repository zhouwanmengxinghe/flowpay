---
doc_id: KB-API-022
title: 查询 Refund 与可退款额度
doc_type: api_doc
authority: official
product_areas: [refunds, payments]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-MONEY-004, RULE-TENANT-003]
related_docs: [KB-BR-012, KB-API-014, KB-API-019, KB-API-020, KB-API-021]
indexing: include
language: zh-CN
---

# 查询 Refund 与可退款额度

## 查询 Refund

```http
GET /v1/refunds/{refund_id}
```

返回 Refund 当前状态、金额、原 Payment、模式、失败原因和时间戳。

```bash
curl https://api.flowpay.example/v1/refunds/re_01JEXAMPLE \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY"
```

`pending` 可能继续进入 `succeeded`、`failed` 或 `canceled`。生产集成可结合 `refund.succeeded`、`refund.failed` Webhook 处理最终结果。

## 查询 Payment 退款摘要

```http
GET /v1/payments/{payment_id}
```

Payment 响应提供：

- `refunded_amount`：所有 succeeded Refund 的累计金额。
- `pending_refund_amount`：正在处理的 Refund 占用金额。
- `refundable_amount`：查询时仍可申请的金额。

```text
refundable_amount = original amount
                  - refunded_amount
                  - pending_refund_amount
```

若 Payment 不在可退款状态或超过 180 天窗口，`refundable_amount` 为 0。该字段不表示 Account 套餐一定允许部分退款。

## 并发注意事项

额度是查询时快照。在查询后到创建 Refund 前，另一请求可能占用额度。调用方必须处理创建请求返回的额度冲突，不能把先前读取值当作锁。每个创建请求应使用独立、稳定的 Idempotency Key。

## 错误

- `FP-4041`：Refund 或 Payment 不存在、属于其他 Account 或环境不可见。
- `FP-4291`：查询过于频繁。

## 判断边界

Refund `succeeded` 证明该笔退款完成；Payment 的 `refunded_amount` 汇总多笔结果。不要仅凭 Payment 状态 `succeeded` 推断它从未退款，也不要仅凭 `refundable_amount > 0` 推断当前套餐支持部分退款。

## 相关文档

- Refund 对象见 `KB-API-019`。
- 全额和部分退款见 `KB-API-020`、`KB-API-021`。
- Payment 查询见 `KB-API-014`。

