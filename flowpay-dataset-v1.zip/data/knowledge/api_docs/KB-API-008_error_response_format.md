---
doc_id: KB-API-008
title: API 错误响应格式
doc_type: api_doc
authority: official
product_areas: [developer_platform, operations]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-REQ-001, RULE-VERSION-004]
related_docs: [KB-BR-011, KB-API-002, KB-API-003, KB-API-006, KB-API-007, KB-API-034]
indexing: include
language: zh-CN
---

# API 错误响应格式

## 标准结构

FlowPay API 错误使用稳定 JSON 结构：

```json
{
  "error": {
    "code": "FP-4001",
    "message": "Invalid request parameters.",
    "param": "amount",
    "request_id": "req_01JEXAMPLE",
    "details": {}
  }
}
```

`code` 是程序应优先判断的 FlowPay 错误码；`message` 面向开发者，可能在不改变语义的情况下调整；`param` 仅在错误对应具体参数时出现；`request_id` 用于日志关联；`details` 保存版本支持的附加信息。

## HTTP 状态与错误码

| HTTP | 常见错误码 | 类型 |
| ---: | --- | --- |
| 400 | `FP-4001`、`FP-4002`、`FP-4003` | 参数或版本 |
| 401 | `FP-4011`、`FP-4012` | 认证或环境 |
| 402 | `FP-4021`～`FP-4024` | 支付处理结果 |
| 403 | `FP-4031`、`FP-4032` | 套餐或 Production 权限 |
| 404 | `FP-4041` | 资源不存在或不可见 |
| 409 | `FP-4091` | 幂等冲突 |
| 422 | `FP-4221`、`FP-4222` | 资源状态或退款窗口 |
| 429 | `FP-4291` | Rate Limit |
| 500 | `FP-5001` | 平台内部处理 |
| 503 | `FP-5031` | 服务临时降级 |

相同 HTTP 状态可能对应不同根因，客户端不能只按 401、403 或 402 处理，应同时判断 `error.code`。

## 重试分类

- 参数、认证、套餐和状态错误：先修正条件，不要原样自动重试。
- `FP-4091`：比较首次请求参数，不要盲目更换 Key 掩盖重复操作。
- `FP-4291`：遵守等待提示并指数退避。
- `FP-5001`、`FP-5031`：在使用幂等键的前提下有限重试，并检查服务状态。
- Payment Method 类失败：根据具体错误提示终端客户采取行动。

## 版本字段

从 `2026-01-15` 起，`FP-4091` 的 `details` 可包含 `conflict_request_id`。从 `2026-07-01` 起，429 响应增加 `FlowPay-RateLimit-Reset` Header。旧版本缺失这些字段不代表错误类型不同。

## 相关文档

- Payment 失败分类见 `KB-BR-011`。
- API Version 见 `KB-API-006`。
- Request ID 见 `KB-API-007`。
- Rate Limit Header 与退避见 `KB-API-034`。

