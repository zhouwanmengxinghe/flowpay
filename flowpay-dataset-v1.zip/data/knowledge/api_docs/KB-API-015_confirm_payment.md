---
doc_id: KB-API-015
title: 确认 requires_action Payment
doc_type: api_doc
authority: official
product_areas: [payments]
api_versions: ["2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2026-01-15"
effective_to: null
supersedes: []
rule_ids: [RULE-PAY-001, RULE-PAY-003, RULE-PAY-005]
related_docs: [KB-BR-010, KB-BR-011, KB-API-006, KB-API-012, KB-API-013, KB-API-014, KB-API-016]
indexing: include
language: zh-CN
---

# 确认 requires_action Payment

## Endpoint

```http
POST /v1/payments/{payment_id}/confirm
```

该动作仅用于状态为 `requires_action` 的 Payment。在终端客户完成 `next_action` 指定的验证后，Merchant 调用 confirm 让原 Payment 继续进入 `processing`。

## 版本要求

`requires_action` 从 API Version `2026-01-15` 开始支持。`2025-10-01` 中，同类支付表现为 `failed + FP-4023`，不能对该终态 Payment 调用 confirm；应在客户完成必要操作后创建新 Payment。

## 请求

confirm 不接收新的金额、币种、Customer 或 Payment Method。它继续处理既有 Payment：

```bash
curl https://api.flowpay.example/v1/payments/pay_01JEXAMPLE/confirm \
  -X POST \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY" \
  -H "FlowPay-Version: 2026-07-01"
```

成功返回 HTTP 200。Payment 通常进入 `processing`，之后再进入 `succeeded` 或 `failed`。调用方不应把 confirm 的 HTTP 200 当作最终支付成功。

## 状态限制

| 当前状态 | confirm 结果 |
| --- | --- |
| `requires_action` | 允许，进入后续处理 |
| `processing` | 不允许重复确认 |
| `succeeded` | 不允许，已是终态 |
| `failed` | 不允许，必须新建 Payment |
| `canceled` | 不允许，必须新建 Payment |

状态不允许时返回 `FP-4221 Invalid Payment State`。

## 并发与重复请求

在发送 confirm 前先读取最新 Payment 状态。多个客户端同时确认可能只有第一次有效，其余请求应按最新状态处理。confirm 不是修改支付金额的接口。

## 相关文档

- Payment 状态机见 `KB-BR-010`，版本差异见 `KB-API-006`。
- Payment 对象和查询见 `KB-API-012`、`KB-API-014`。
- 取消待操作 Payment 见 `KB-API-016`。

