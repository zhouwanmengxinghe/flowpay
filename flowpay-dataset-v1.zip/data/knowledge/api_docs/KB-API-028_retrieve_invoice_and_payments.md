---
doc_id: KB-API-028
title: 查询 Invoice 与关联 Payment
doc_type: api_doc
authority: official
product_areas: [invoices, subscriptions, payments]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-TENANT-003]
related_docs: [KB-BR-014, KB-API-014, KB-API-023, KB-API-026, KB-API-027]
indexing: include
language: zh-CN
---

# 查询 Invoice 与关联 Payment

## 查询 Invoice

```http
GET /v1/invoices/{invoice_id}
```

返回 Invoice 当前状态、Subscription、Customer、金额、尝试次数、下次重试时间和 `payment_ids`。

```bash
curl https://api.flowpay.example/v1/invoices/in_01JEXAMPLE \
  -H "Authorization: Bearer $FLOWPAY_SECRET_KEY"
```

## 查询 Payment 尝试

读取 Invoice 后，按 `payment_ids` 查询每笔 Payment：

```http
GET /v1/payments/{payment_id}
```

数组按扣费尝试顺序排列。第一笔 failed Payment 不代表 Invoice 最终失败；后续重试可能成功。`attempt_count` 包含首次尝试，例如值为 2 表示首次加一次重试。

## 状态解释

- `open + next_retry_at`：已定稿，可能等待首次处理或重试。
- `paid`：至少一笔关联 Payment succeeded。
- `uncollectible`：首次和第 1、3、7 天三次重试都失败。
- `void`：账单已作废，不再扣费。

Subscription 状态应单独查询。通常首次失败使其 `past_due`，重试成功恢复 `active`，耗尽后进入 `canceled`。

## 错误

- `FP-4041`：Invoice 不存在、属于其他 Account 或环境不可见。
- `FP-4291`：频繁轮询超过 Rate Limit。

## 查询建议

需要解释扣费失败时，应组合 Invoice、全部关联 Payment 和对应错误码。需要判断 Webhook 是否送达，还必须查询 Endpoint 和 Delivery；Invoice 状态本身只能证明业务处理结果。

## 相关文档

- Invoice 对象和扣费流程见 `KB-API-026`、`KB-API-027`。
- Payment 精确查询见 `KB-API-014`。
- Subscription 状态见 `KB-API-023`。

