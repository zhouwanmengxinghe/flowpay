---
doc_id: KB-API-017
title: Payment 列表、过滤与分页
doc_type: api_doc
authority: official
product_areas: [payments]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-TENANT-001, RULE-TENANT-004, RULE-PAY-001]
related_docs: [KB-BR-001, KB-BR-010, KB-API-002, KB-API-012, KB-API-014]
indexing: include
language: zh-CN
---

# Payment 列表、过滤与分页

## Endpoint

```http
GET /v1/payments
```

列表只返回当前 Secret Key 所属 Account 和环境中的 Payment。Sandbox、Production 分开查询，不能通过参数跨环境聚合。

## 过滤参数

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `customer_id` | string | 只返回指定 Customer 的 Payment |
| `status` | string | `requires_action`、`processing`、`succeeded`、`failed` 或 `canceled` |
| `created_after` | timestamp | 创建时间下界，包含 |
| `created_before` | timestamp | 创建时间上界，不包含 |
| `limit` | integer | 每页 1～100，默认 20 |
| `cursor` | string | 上一页返回的 `next_cursor` |

过滤条件可以组合。例如查询某 Customer 在指定时间窗内失败的 Payment。

## 响应

```json
{
  "data": [
    {"id":"pay_01JEXAMPLE","status":"failed","amount":1200,"currency":"USD"}
  ],
  "has_more": true,
  "next_cursor": "cur_example"
}
```

结果按 `created_at` 倒序排列。`cursor` 是不透明值，调用方不应解析或长期保存。继续分页时保持其他过滤条件不变。

## 版本和状态

`requires_action` 过滤只对 `2026-01-15` 及以后版本有意义。使用旧版本读取同类历史对象时，应按照该版本的状态表示解释结果。

列表适合查找业务对象，不用于精确统计 Rate Limit 或实时故障数量；运行时调用量应使用 Observability Tool。

## 错误

- `FP-4001`：时间范围、状态、limit 或 cursor 非法。
- `FP-4041`：`customer_id` 不存在或不可见。
- `FP-4291`：查询频率超过限额。

## 相关文档

- 列表通用结构见 `KB-API-002`。
- Payment 字段见 `KB-API-012`，精确查询见 `KB-API-014`。
- 租户和环境边界见 `KB-BR-001`。

