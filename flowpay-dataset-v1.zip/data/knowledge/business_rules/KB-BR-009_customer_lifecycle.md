---
doc_id: KB-BR-009
title: Customer 生命周期
doc_type: business_rule
authority: official
product_areas: [customers]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-CUSTOMER-001, RULE-CUSTOMER-002, RULE-CUSTOMER-003, RULE-CUSTOMER-004, RULE-CUSTOMER-005]
related_docs: [KB-BR-001, KB-BR-002, KB-BR-010, KB-BR-013]
indexing: include
language: zh-CN
---

# Customer 生命周期

## Customer 的作用

Customer 是 Merchant 在 FlowPay 中保存的终端客户档案，用于关联 Payment 和 Subscription。Customer 不是 FlowPay 的直接租户，也不拥有 API Key；所有 Customer 操作都由其所属 Merchant Account 发起。

每个 Customer 只属于一个 Account 和一个环境。Customer 创建后不能转移到其他 Account，也不能从 Sandbox 迁移到 Production。需要在另一个 Account 或环境中使用相同终端客户时，必须创建新的 Customer 资源。

## 状态

Customer 只有两个状态：

```text
active ── delete ──> deleted
```

`active` Customer 可以在满足其他业务规则时创建新的 Payment 或 Subscription。删除 Customer 采用软删除：进入 `deleted` 后不能恢复，也不能用于创建新 Payment 或 Subscription，但历史业务记录仍然保留其 Customer ID。

FlowPay 不会因为删除 Customer 而删除、取消或改写已存在的 Payment、Refund、Subscription 和 Invoice。若 Merchant 还需要终止一个活动 Subscription，应按照 Subscription 取消规则单独操作，不能把删除 Customer 当作取消订阅的替代方式。

## 身份与精确关联

Customer ID 是业务对象关联的稳定标识。Email 不是唯一键，同一 Account 内可以存在多个使用相同 Email 的 Customer，且 Email 可能被更新。任何精确查询、Payment 创建或 Subscription 创建都应使用 Customer ID，而不是假设 Email 唯一。

Customer ID 仍受租户和环境隔离约束。即使调用方知道另一个 Account 的 Customer ID，也不能读取该资源或将其用于当前 Account 的 Payment。

## 操作判断

| 场景 | 是否允许 |
| --- | --- |
| 为同 Account、同环境的 active Customer 创建 Payment | 允许，仍需满足 Payment 规则 |
| 为 deleted Customer 创建 Payment | 不允许 |
| 为 Sandbox Customer 创建 Production Subscription | 不允许 |
| 删除 Customer 后查询其历史 Payment | 允许查询，取决于调用方权限和保留策略 |
| 删除 Customer 后自动删除 Payment | 不会发生 |
| 使用 Email 作为唯一 Customer 标识 | 不支持该假设 |

## 边界与反例

反例：Customer 已删除不代表历史 Payment 无效。已成功 Payment 仍可能在退款期限内可退款，判断时需要查询 Payment，而不是仅看 Customer 状态。

反例：两个 Customer 使用相同 Email 不代表它们是重复资源。FlowPay 不做自动合并，Merchant 应维护自身系统与 Customer ID 的映射。

静态政策不能证明某个 Customer 当前是 `active` 还是 `deleted`。具体问题需要查询 Customer 业务状态。

## 相关知识

- Customer 的租户和环境边界见 `KB-BR-001`、`KB-BR-002`。
- 创建 Payment 的状态约束见 `KB-BR-010`。
- 创建 Subscription 的资格见 `KB-BR-013`。

