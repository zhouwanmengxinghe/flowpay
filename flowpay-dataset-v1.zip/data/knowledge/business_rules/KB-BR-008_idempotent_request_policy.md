---
doc_id: KB-BR-008
title: 幂等请求策略
doc_type: business_rule
authority: official
product_areas: [developer_platform, payments, refunds, subscriptions]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-IDEMP-001, RULE-IDEMP-002, RULE-IDEMP-003, RULE-IDEMP-004, RULE-IDEMP-005, RULE-IDEMP-006]
related_docs: [KB-BR-001, KB-BR-005, KB-BR-007, KB-BR-010, KB-BR-012, KB-BR-013]
indexing: include
language: zh-CN
---

# 幂等请求策略

## 适用操作

FlowPay 的创建 Payment、Refund 和 Subscription 请求支持 `Idempotency-Key`。幂等用于在网络超时、连接中断或客户端安全重试时避免重复创建资源。读取请求不依赖幂等键，更新或取消操作若有专门契约则按对应 API 文档执行。

幂等键由 Merchant 生成。它应在一次业务操作的所有重试中保持相同，在新的业务操作中更换。

## 作用域

幂等记录的作用域由以下四项共同决定：

- Account。
- 环境。
- API Endpoint。
- `Idempotency-Key` 值。

相同文本的 Key 在不同 Account、不同环境或不同 Endpoint 中不会互相冲突。例如，在创建 Payment 和创建 Refund 时都使用 `order-1001`，属于两个独立作用域；Sandbox 和 Production 使用同一文本也分别计算。

## 24 小时保留期

FlowPay 保留幂等结果 24 小时。在保留期内：

- 相同作用域、相同 Key、完全相同参数：返回第一次请求的结果，不创建第二个资源。
- 相同作用域、相同 Key、不同参数：返回 HTTP 409 和 `FP-4091 Duplicate Idempotency Key with Different Parameters`。

超过 24 小时后，记录过期，再使用相同 Key 会被视为新请求，可能创建新资源。因此，幂等键不能替代 Merchant 自己的长期订单唯一性约束。

从 API Version `2026-01-15` 开始，幂等冲突响应增加 `conflict_request_id`，可用于定位首次请求；旧版本没有该字段，但冲突语义相同。

## 参数相同的含义

“参数相同”指经过 FlowPay 标准化后的有效请求参数一致，包括金额、币种、Customer、Payment Method 和影响行为的可选项。仅改变无业务含义的传输格式不一定构成冲突，但改变金额、资源引用或功能选项会构成不同请求。

## 安全重试流程

1. 在首次创建请求前生成幂等键。
2. 请求超时或收到可重试平台错误时，使用相同参数和相同 Key 重试。
3. 若收到 `FP-4091`，停止自动重试，比较当前请求与首次请求。
4. 若业务意图确实发生变化，生成新 Key 并明确发起新的业务操作。

## 边界与反例

反例：第一次创建 USD 100 Payment，第二次用相同 Key 改为 USD 120，不会更新原 Payment，而会返回 `FP-4091`。

反例：同一 Key 超过 24 小时后再次使用，FlowPay 可能创建第二个资源。Merchant 若需要永久防止重复订单，应保存自己的订单 ID 和资源映射。

反例：幂等不能让非法操作变合法。对 `processing` Payment 发起 Refund 即使带幂等键，仍会因 Payment 状态不允许而失败。

## 相关知识

- 幂等作用域中的 Account 和环境见 `KB-BR-001`。
- 限流后的安全退避见 `KB-BR-005`。
- 版本差异见 `KB-BR-007`。
- Payment、Refund 和 Subscription 创建约束见 `KB-BR-010`、`KB-BR-012`、`KB-BR-013`。

