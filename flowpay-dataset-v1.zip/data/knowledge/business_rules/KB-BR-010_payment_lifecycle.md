---
doc_id: KB-BR-010
title: Payment 生命周期与状态机
doc_type: business_rule
authority: official
product_areas: [payments]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-PAY-001, RULE-PAY-002, RULE-PAY-003, RULE-PAY-004, RULE-PAY-005, RULE-PAY-006, RULE-PAY-007, RULE-MONEY-001, RULE-MONEY-002]
related_docs: [KB-BR-003, KB-BR-007, KB-BR-008, KB-BR-009, KB-BR-011, KB-BR-012, KB-BR-015]
indexing: include
language: zh-CN
---

# Payment 生命周期与状态机

## 创建前提

Payment 表示 Merchant 向 End Customer 发起的一次收款。创建时必须引用同 Account、同环境且状态为 `active` 的 Customer，币种必须受 Account 主地区支持，金额必须在 50 至 100,000,000 个最小货币单位之间。

创建参数受 API Version 影响：`2025-10-01` 使用 `source`；`2026-04-01` 推荐 `payment_method`，同时暂时兼容 `source`；`2026-07-01` 已移除 `source`，继续提交会返回 `FP-4003`。

## 状态机

Payment 的状态集合是 `requires_action`、`processing`、`succeeded`、`failed` 和 `canceled`。

```text
create
├── requires_action ── confirm ──> processing
│          └── expire/cancel ────> canceled
└── processing
       ├──> succeeded
       └──> failed
```

`succeeded`、`failed` 和 `canceled` 是终态。终态 Payment 不会回到 `processing`。特别是，失败后的重新付款必须创建新的 Payment；FlowPay 不支持把原 `failed` Payment 原地恢复为成功。

只有 `requires_action` 可以由 Merchant 主动取消。`processing` 表示 FlowPay 正在处理，调用方不能通过取消操作强制终止。只有 `succeeded` Payment 才具有退款资格，且仍需满足退款期限、套餐和剩余金额等规则。

## `requires_action` 的版本差异

`requires_action` 从 API Version `2026-01-15` 开始提供，用于需要终端用户完成额外验证的支付。在 `2025-10-01` 中，同类情况不会进入该状态，而是表现为 `failed`，错误码为 `FP-4023 Customer Action Required`。

这意味着不能只看业务症状判断状态；必须同时检查请求使用的 API Version。

## 事件

Payment 进入重要状态时会产生事件。成功事件在 `2025-10-01`、`2026-01-15` 和 `2026-04-01` 中名为 `payment.completed`，在 `2026-07-01` 中名为 `payment.succeeded`。事件名称由产生该 Payment 操作所使用的版本决定。

事件产生不等于某个 Merchant Endpoint 已经收到事件。是否投递还取决于 Endpoint 环境、状态、订阅事件类型和实际 Delivery 结果。

## 操作决策

| 当前状态 | 可确认 | 可主动取消 | 可退款 | 可原地重试 |
| --- | --- | --- | --- | --- |
| requires_action | 是 | 是 | 否 | 不适用 |
| processing | 否 | 否 | 否 | 否 |
| succeeded | 否 | 否 | 有条件 | 否 |
| failed | 否 | 否 | 否 | 否，必须新建 |
| canceled | 否 | 否 | 否 | 否，必须新建 |

## 边界与反例

反例：Payment 已经 `processing` 并不意味着最终一定成功，也不能提前退款。

反例：Payment 已经 `succeeded` 只满足退款的状态条件，不保证仍在 180 天窗口内，也不保证套餐支持部分退款。

具体 Payment 当前状态必须查询 Payment 业务数据，不能从本政策推断。

## 相关知识

- 金额和币种规则见 `KB-BR-003`。
- 版本参数差异见 `KB-BR-007`。
- 创建请求幂等见 `KB-BR-008`。
- 失败分类见 `KB-BR-011`，退款资格见 `KB-BR-012`。
- Payment 事件投递见 `KB-BR-015`。

