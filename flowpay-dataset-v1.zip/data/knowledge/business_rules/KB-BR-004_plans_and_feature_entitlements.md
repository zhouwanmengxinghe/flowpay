---
doc_id: KB-BR-004
title: 商户套餐与功能权限
doc_type: business_rule
authority: official
product_areas: [accounts, developer_platform]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-PLAN-001, RULE-PLAN-002, RULE-PLAN-003, RULE-PLAN-004, RULE-PLAN-005]
related_docs: [KB-BR-003, KB-BR-005, KB-BR-012, KB-BR-013, KB-BR-015]
indexing: include
language: zh-CN
---

# 商户套餐与功能权限

## 套餐层级

FlowPay V1 提供 Starter、Growth 和 Scale 三个套餐。套餐决定 Production Rate Limit、Webhook Endpoint 数量、数据查询保留期和高级功能的硬上限。功能开关只能在套餐允许的范围内开启，不能越过套餐限制。

| 能力 | Starter | Growth | Scale |
| --- | ---: | ---: | ---: |
| Production 持续请求 | 300 req/min | 1,200 req/min | 5,000 req/min |
| Production 突发请求 | 450 / 10 秒 | 1,500 / 20 秒 | 6,000 / 30 秒 |
| Webhook Endpoint | 2 | 5 | 15 |
| 数据查询保留期 | 7 天 | 30 天 | 90 天 |
| 全额退款 | 支持 | 支持 | 支持 |
| 部分退款 | 不支持 | 支持 | 支持 |
| Subscription / Invoice | 不支持 | 支持 | 支持 |
| 自定义 Webhook 重试 | 不支持 | 不支持 | 支持 |
| Instant Refund | 不支持 | 不支持 | 有条件支持 |
| 版本冻结延期 | 不支持 | 不支持 | 最多 90 天 |

一次性支付和标准 Webhook 在三个套餐中均可用，但 Production 仍需完成生产启用。

## 功能开关

部分功能同时受套餐和 Feature Flag 控制。例如 Growth、Scale 具备 Subscription 资格，但只有 `subscriptions` 开关开启后才能使用；Scale 的 Instant Refund 还要求 `instant_refund` 开关开启，并满足地区和金额规则。

套餐资格是硬边界。给 Starter Account 写入 `subscriptions=true` 不能使其获得订阅能力。调用套餐不支持的功能时返回 `FP-4031 Feature Unavailable for Plan`。

## 升级和降级

套餐升级立即生效。升级完成后，新请求使用新套餐的权限和 Production Rate Limit。

套餐降级在当前计费周期结束时生效。在生效前仍按原套餐处理；提交降级申请不等于限额已经变化。降级生效后，如果 Webhook Endpoint 数量超过新套餐上限，FlowPay 不删除配置，而是按创建时间保留最早的可用数量，其余 Endpoint 进入 `restricted`，停止接收新事件并保留历史记录。

## 权限判断顺序

判断某项能力是否可用时，应依次确认：

1. 当前请求环境是否允许该能力。
2. 套餐变更是否已经生效。
3. 已生效套餐是否包含该能力。
4. 必需的 Feature Flag 是否开启。
5. 地区、资源状态、版本等附加条件是否满足。

## 边界与反例

反例：Growth 的突发上限是 1,500 req/min，不等于可以持续以 1,500 req/min 调用。持续超过 1,200 req/min 仍可能触发 Rate Limit。

反例：Scale Account 不一定能执行 Instant Refund。若位于 APAC、功能开关关闭、Payment 不可退款或金额超限，仍然不允许。

静态套餐规则不能证明某个 Account 当前套餐。遇到具体商户问题，需要查询其已生效套餐和变更生效时间。

## 相关知识

- 地区和币种限制见 `KB-BR-003`。
- 完整 Rate Limit 计算见 `KB-BR-005`。
- Refund 权限见 `KB-BR-012`。
- Subscription 资格见 `KB-BR-013`。
- Endpoint 降级后的投递行为见 `KB-BR-015`。

