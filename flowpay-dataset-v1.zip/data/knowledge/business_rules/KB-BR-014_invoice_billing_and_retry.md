---
doc_id: KB-BR-014
title: Invoice 扣费与重试策略
doc_type: business_rule
authority: official
product_areas: [invoices, subscriptions, payments]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-INVOICE-001, RULE-INVOICE-002, RULE-INVOICE-003, RULE-INVOICE-004, RULE-INVOICE-005, RULE-INVOICE-006, RULE-INVOICE-007, RULE-INVOICE-008]
related_docs: [KB-BR-010, KB-BR-011, KB-BR-013, KB-BR-015]
indexing: include
language: zh-CN
---

# Invoice 扣费与重试策略

## Invoice 的作用

FlowPay 为 Subscription 的每个计费周期生成一个 Invoice。Invoice 汇总该周期应收金额，并通过关联 Payment 完成扣费。V1 中 Invoice 只服务于 Subscription，不提供独立的一次性手工账单能力。

## 状态机

Invoice 状态包括 `draft`、`open`、`paid`、`uncollectible` 和 `void`。

```text
draft ── finalize ──> open
open ── payment succeeds ──> paid
open ── retries exhausted ─> uncollectible
draft/open ── void ────────> void
```

Invoice 创建时为 `draft`。定稿后进入 `open` 并创建关联 Payment。Payment 成功后，Invoice 进入 `paid`。`paid` Invoice 不能再 `void`；需要退回已支付金额时，应依据 Payment 和 Refund 规则处理，而不是修改 Invoice 状态。

## 自动扣费与重试时间线

首次 Payment 失败时，Invoice 保持 `open`，Subscription 进入 `past_due`。FlowPay 随后在首次失败后的第 1、3、7 天重试，共 3 次重试，不包含首次尝试。

| 阶段 | Invoice | Subscription |
| --- | --- | --- |
| Invoice 定稿、等待扣费 | open | active 或 trialing 结束处理中 |
| 首次扣费失败 | open | past_due |
| 任一重试成功 | paid | active |
| 第 1、3、7 天重试全部失败 | uncollectible | canceled |

每次重试会创建新的 Payment，因为 `failed` Payment 是终态，不能原地恢复。Invoice 保留与各次尝试的关联，以便解释最终状态。

## 事件

Invoice 生命周期可产生 `invoice.created`、`invoice.paid` 和 `invoice.payment_failed`。Subscription 状态变化可产生 `subscription.updated` 或 `subscription.canceled`。事件产生后是否送达某个 Endpoint，需要单独检查 Webhook 订阅和 Delivery 状态。

## Void 边界

`draft` 或尚未支付的 `open` Invoice 可以按 API 契约进入 `void`。`paid`、`uncollectible` 和已经 `void` 的 Invoice 不通过重复 void 操作改变结论。Void 一个 Invoice 不等于删除 Subscription，后续计费是否继续取决于 Subscription 状态。

## 边界与反例

反例：首次扣费失败不会立即取消 Subscription，而是先进入 `past_due` 并等待三次重试。

反例：Invoice `open` 不代表从未尝试扣费；它可能已经失败一次或多次，必须查询关联 Payment 和时间线。

反例：收到 `invoice.payment_failed` 后不能推断所有重试已经耗尽，该事件也会在早期失败阶段产生。

具体 Invoice 当前状态、已执行几次重试和关联 Payment 结果属于业务状态，必须查询相关记录。

## 相关知识

- Payment 终态与重新创建要求见 `KB-BR-010`。
- Payment 失败分类见 `KB-BR-011`。
- Subscription 的 `past_due` 与恢复见 `KB-BR-013`。
- Invoice 事件投递见 `KB-BR-015`。
