---
doc_id: KB-BR-012
title: Refund 资格、额度与时限
doc_type: business_rule
authority: official
product_areas: [refunds, payments]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-REFUND-001, RULE-REFUND-002, RULE-REFUND-003, RULE-REFUND-004, RULE-REFUND-005, RULE-REFUND-006, RULE-REFUND-007, RULE-REFUND-008, RULE-MONEY-003, RULE-MONEY-004]
related_docs: [KB-BR-003, KB-BR-004, KB-BR-007, KB-BR-008, KB-BR-010]
indexing: include
language: zh-CN
---

# Refund 资格、额度与时限

## 基础资格

只有状态为 `succeeded` 的 Payment 可以创建 Refund。对 `requires_action`、`processing`、`failed` 或 `canceled` Payment 发起退款会返回 `FP-4221 Invalid Payment State`。

Payment 成功超过 180 天后不可退款，返回 `FP-4222 Refund Window Expired`。180 天窗口从 Payment 成功时间开始计算，不从订单创建时间、首次退款时间或 Merchant 收到 Webhook 的时间计算。

## 套餐差异

- Starter：只支持一次对当前剩余可退金额进行全额退款。
- Growth：支持全额和多次部分退款。
- Scale：支持全额和多次部分退款，并可能使用 Instant Refund。

Starter 的“全额”指创建退款时的全部剩余可退金额。Starter 不允许用多个小额 Refund 拆分退款。调用套餐不支持的部分退款时，使用套餐功能不可用语义。

## 金额和币种

Refund 必须沿用原 Payment 币种。成功 Refund 的累计金额不得超过原 Payment 金额。创建新 Refund 时，FlowPay 同时计算 `succeeded` 和 `pending` Refund，因为正在处理的退款会暂时占用额度。

```text
可申请额度 = Payment 原始金额
           - succeeded Refund 金额
           - pending Refund 金额
```

当 `pending` Refund 进入 `failed` 或 `canceled` 后，其占用金额重新释放；进入 `succeeded` 后则转为永久扣减。

## Refund 状态

Refund 状态包括 `pending`、`succeeded`、`failed` 和 `canceled`。

```text
create
├──> succeeded
└──> pending
       ├──> succeeded
       ├──> failed
       └──> canceled
```

从 API Version `2026-07-01` 开始，符合条件的普通 Refund 可在创建时同步确认并直接返回 `succeeded`；否则仍返回 `pending`。旧版本默认先返回 `pending`。版本变化不改变总额度和 180 天期限。

## Instant Refund

Instant Refund 必须同时满足：Scale 套餐、Account 主地区为 NA 或 EU、`instant_refund` 功能开关开启、金额不超过 100,000 个最小货币单位，以及所有基础退款条件。任何一个条件不满足都不能使用 Instant Refund，但可能仍可使用普通 Refund。

## 判断步骤

1. 查询 Payment 当前状态和成功时间。
2. 查询 Account 已生效套餐、地区和相关功能开关。
3. 汇总该 Payment 的 `pending` 与 `succeeded` Refund。
4. 验证请求金额、币种和退款方式。
5. 根据请求 API Version 判断初始返回行为。

## 边界与反例

反例：Payment `succeeded` 不等于可以无限期退款；超过 180 天仍会失败。

反例：某笔 pending Refund 尚未成功，也会暂时占用额度，不能并发创建导致总额超限的第二笔 Refund。

反例：Scale + EU 只满足 Instant Refund 的部分条件，功能开关和金额仍需确认。

## 相关知识

- 币种与金额表示见 `KB-BR-003`。
- 套餐权限见 `KB-BR-004`。
- Refund 的版本行为见 `KB-BR-007`。
- 幂等创建见 `KB-BR-008`。
- Payment 可退款状态见 `KB-BR-010`。

