---
doc_id: KB-BR-005
title: API Rate Limit 策略
doc_type: business_rule
authority: official
product_areas: [developer_platform, operations]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-RATE-001, RULE-RATE-002, RULE-RATE-003, RULE-RATE-004, RULE-RATE-005, RULE-RATE-006, RULE-RATE-007, RULE-PLAN-005]
related_docs: [KB-BR-002, KB-BR-004, KB-BR-007]
indexing: include
language: zh-CN
---

# API Rate Limit 策略

## 统计边界

FlowPay 的 API Rate Limit 按 `Account + 环境` 统计。同一 Account 在一个环境中的所有 Secret Key、所有 API Endpoint 共享该环境的请求额度；创建更多 Key 不会获得额外额度。Sandbox 和 Production 分开统计，另一个 Account 的请求也不会占用当前 Account 的额度。

Webhook 投递是 FlowPay 主动发往 Merchant 的请求，不计入 Merchant API Rate Limit。

## Sandbox 限额

Sandbox 对所有套餐使用相同上限：持续 120 req/min，短时突发最高 180 req/min。套餐升级不会提高 Sandbox 上限，排查 Sandbox 429 时也不应套用 Production 的套餐数值。

## Production 限额

| 已生效套餐 | 持续上限 | 短时突发上限 |
| --- | ---: | ---: |
| Starter | 300 req/min | 450 req/min，最多 10 秒 |
| Growth | 1,200 req/min | 1,500 req/min，最多 20 秒 |
| Scale | 5,000 req/min | 6,000 req/min，最多 30 秒 |

突发上限用于吸收短时间峰值，不是新的持续速率。请求持续超过套餐常规上限，即使没有超过突发数值，也可能在突发窗口耗尽后被限流。

升级立即生效，降级只在当前计费周期结束时生效。Rate Limit 依据请求发生时已经生效的套餐计算，不能依据升级或降级申请的提交时间判断。

## 超限响应和重试

超过限制时，FlowPay 返回 HTTP 429 和 `FP-4291 Rate Limit Exceeded`。从 API Version `2026-07-01` 开始，响应还包含 `FlowPay-RateLimit-Reset` Header；旧版本没有该 Header，但仍应使用指数退避。

客户端应避免立即并发重试。推荐优先遵守响应中的等待提示，在没有明确提示时使用指数退避和随机抖动，并确保创建类请求带有 Idempotency Key。

## 诊断具体 429 所需证据

正式规则只能提供上限，不能说明某个 Account 为什么在某一时刻收到 429。具体诊断至少需要确认：

1. 请求属于 Sandbox 还是 Production。
2. Production 请求发生时的已生效套餐。
3. 对应分钟和突发窗口内的实际 Usage。
4. 是否有多个 Key 或服务共同使用同一 Account 配额。
5. 客户端是否在收到 429 后形成重试风暴。

## 边界与反例

反例：出现 `FP-4291` 不等于套餐被降级。流量峰值、多个应用共享额度或错误的重试策略都可能产生相同错误。必须结合 Account 状态和 Runtime Usage 判断。

反例：Growth 的 1,500 req/min 是短时突发上限，不表示可以持续一分钟稳定发送 1,500 个请求。

反例：Webhook 大量重试不会直接消耗 Merchant API 配额，但 Merchant 接收 Webhook 后自行调用 API 的行为仍会计入额度。

## 相关知识

- 环境区分见 `KB-BR-002`。
- 套餐生效与变更见 `KB-BR-004`。
- `2026-07-01` 的 Header 行为见 `KB-BR-007`。

