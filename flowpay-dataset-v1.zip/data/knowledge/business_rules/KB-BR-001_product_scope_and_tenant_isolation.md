---
doc_id: KB-BR-001
title: FlowPay 产品范围与租户隔离
doc_type: business_rule
authority: official
product_areas: [platform, accounts]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-TENANT-001, RULE-TENANT-002, RULE-TENANT-003, RULE-TENANT-004]
related_docs: [KB-BR-002, KB-BR-004, KB-BR-007]
indexing: include
language: zh-CN
---

# FlowPay 产品范围与租户隔离

## 适用范围

FlowPay 是面向互联网公司和开发者的在线支付基础设施。V1 提供 Customer、Payment、Refund、Subscription、Invoice、Webhook、API Key、调用额度和运行状态等能力。本政策定义这些能力的所有权边界，以及请求跨越账户或环境时的处理方式。

FlowPay 的直接客户是 Merchant Account。Developer 代表 Merchant 使用 Secret Key 调用 API；End Customer 是 Merchant 的终端用户，不直接持有 FlowPay 的账户权限。

## Account 是租户边界

每个 Customer、Payment、Refund、Subscription、Invoice、Webhook Endpoint 和 Event 都只归属于一个 Account。资源创建后不能转移到另一个 Account。业务对象之间的关联也必须位于同一 Account，例如 Payment 不能引用另一 Account 的 Customer，Refund 不能引用另一 Account 的 Payment。

API Key 同样只属于一个 Account。使用 Account A 的 Key 查询 Account B 的资源时，FlowPay 不返回目标资源内容，也不透露该资源是否真实存在。此类请求使用统一的“资源不存在或不可见”语义，以避免通过错误差异枚举其他租户的数据。

## 环境也是隔离边界

同一 Account 内的 Sandbox 与 Production 仍是两个相互隔离的资源空间。Sandbox Customer 不能用于创建 Production Payment，Sandbox Event 也不能投递给 Production Webhook Endpoint。即使两个环境中偶然出现相同的资源 ID 文本，它们也不代表同一个业务对象。

环境隔离和租户隔离必须同时满足：一个请求只有在 Account、环境和资源所有权均匹配时才可访问目标资源。

## 允许和禁止的行为

| 场景 | 结果 |
| --- | --- |
| 使用 Account A 的 Production Key 查询 A 的 Production Payment | 允许 |
| 使用 Account A 的 Sandbox Key 查询 A 的 Production Payment | 拒绝，属于环境不匹配 |
| 使用 Account A 的 Key 查询 Account B 的 Payment | 拒绝，返回资源不可见语义 |
| 使用 A 的 Customer 创建 A 的 Payment | 允许，仍需满足 Customer 状态等规则 |
| 将已创建的 Payment 转移给另一个 Account | 不允许 |

## 边界与反例

租户隔离只说明资源是否可见，不说明可见资源当前是否允许操作。例如，Developer 能读取本 Account 的 Payment，并不代表该 Payment 一定可以退款；是否可退款还取决于 Payment 状态、成功时间、套餐和剩余可退金额。

反例：看到 `FP-4041` 不能直接断言资源 ID 拼写错误。相同错误也可能表示资源属于其他 Account 或其他环境。诊断时应先确认 Key 的所属 Account 与环境，再确认资源 ID。

## 相关知识

- Sandbox 与 Production 的具体行为见 `KB-BR-002`。
- 套餐权限不改变租户所有权，见 `KB-BR-004`。
- API Version 只改变表示和行为版本，不改变资源归属，见 `KB-BR-007`。

