---
doc_id: KB-BR-006
title: API Key 生命周期与轮换
doc_type: business_rule
authority: official
product_areas: [developer_platform, accounts]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-AUTH-001, RULE-AUTH-002, RULE-AUTH-003, RULE-AUTH-004, RULE-AUTH-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008]
related_docs: [KB-BR-001, KB-BR-002, KB-BR-005]
indexing: include
language: zh-CN
---

# API Key 生命周期与轮换

## Key 类型与所有权

FlowPay V1 使用 Secret Key 认证。Sandbox Key 使用 `sk_test_` 前缀，Production Key 使用 `sk_live_` 前缀。每个 Key 只属于一个 Account 和一个环境，不能转移、改换环境或用于访问其他 Account 的资源。

V1 不实现细粒度 OAuth Scope。一个有效 Secret Key 对所属 Account 和环境拥有完整 API 权限，因此 Merchant 应把 Key 只保存在可信服务端，不应放入浏览器、移动客户端、公开仓库或日志正文。

## 生命周期状态

Key 有三个状态：

- `active`：可正常使用。
- `expiring`：轮换过渡期内仍可使用，最长 24 小时。
- `revoked`：已撤销，立即失效且不可恢复。

缺失、格式错误、未知或已经撤销的 Key 返回 HTTP 401 和 `FP-4011 Invalid API Key`。环境与资源不匹配则返回 `FP-4012`，这与 Key 本身无效是两个不同问题。

## 安全轮换

推荐轮换流程：

1. 创建同 Account、同环境的新 Key。
2. 将新 Key 部署到全部调用方。
3. 验证新 Key 已产生成功请求。
4. 保留旧 Key 进入 `expiring`，处理尚未更新的实例。
5. 在不超过 24 小时的过渡期内撤销旧 Key。

旧 Key 在 `expiring` 期间仍是有效 Key。若在所有实例更新前提前撤销，未更新实例将立即收到 `FP-4011`。过渡期最长 24 小时，不表示旧 Key 必须保留完整 24 小时。

## Production 条件

Account 创建后即可使用 Sandbox Key。只有 `production_enabled=true` 的 Account 才能创建 Production Key。Production 被暂停时，已有 `sk_live_` 不会被自动删除或改成 `revoked`，但请求统一返回 `FP-4032 Production Access Suspended`；Sandbox Key 仍可使用。

这一区分对诊断很重要：`FP-4011` 指向 Key 有效性，`FP-4032` 指向 Account 的 Production 访问状态。

## 边界与反例

反例：Key 前缀正确不代表 Key 有效。一个 `sk_live_` 可能未知、已撤销，或所属 Account 的 Production 已暂停。

反例：创建第二个 Key不会增加 Rate Limit，因为额度按 Account 和环境共享，而不是按 Key 计算。

反例：轮换 Webhook Signing Secret 与轮换 API Secret Key 是两套独立流程。Webhook Secret 用于验证投递签名，不能调用 FlowPay API。

具体 Account 有哪些 Key、Key 当前状态和最近使用时间属于业务状态，应查询 Account 数据，不能仅凭本政策推断。

## 相关知识

- Account 与资源隔离见 `KB-BR-001`。
- Sandbox、Production 启用和暂停见 `KB-BR-002`。
- 多 Key 共享 Rate Limit 见 `KB-BR-005`。

