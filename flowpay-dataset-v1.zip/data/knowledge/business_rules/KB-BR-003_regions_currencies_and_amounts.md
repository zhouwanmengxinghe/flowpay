---
doc_id: KB-BR-003
title: 服务地区、支持币种与金额规则
doc_type: business_rule
authority: official
product_areas: [accounts, payments, refunds]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-REGION-001, RULE-REGION-002, RULE-REGION-003, RULE-MONEY-001, RULE-MONEY-002, RULE-MONEY-003, RULE-MONEY-004]
related_docs: [KB-BR-004, KB-BR-010, KB-BR-012]
indexing: include
language: zh-CN
---

# 服务地区、支持币种与金额规则

## Account 主地区

FlowPay V1 支持三个主地区：北美 `NA`、欧洲 `EU` 和亚太 `APAC`。每个 Account 创建时选择一个主地区，创建后不能通过公开 API 修改。V1 不提供跨地区迁移、数据复制或多主地区能力。

地区影响可用币种和部分功能，但不改变资源 ID 格式、租户隔离规则或 API Version 选择方式。

## 支持币种

| 主地区 | 支持币种 |
| --- | --- |
| NA | USD、CAD |
| EU | EUR、GBP |
| APAC | SGD、JPY、AUD |

Payment 使用的币种必须属于 Account 主地区的支持列表。Refund 不能更换币种，必须沿用原 Payment 的币种。

`instant_refund` 只在 NA 和 EU 可用；它还要求 Scale 套餐、功能开关开启以及金额满足 Instant Refund 限额。仅满足地区条件并不足以使用该功能。

## 金额表示

所有金额使用整数，单位是对应币种的最小货币单位。例如 USD 10.25 表示为 `1025`。JPY 不使用小数单位，因此 JPY 500 直接表示为 `500`。

Payment 金额必须位于 50 至 100,000,000 个最小货币单位之间，包含上下边界。这里的 50 是统一的数值下限，不做实时汇率换算。超出范围的请求属于参数错误。

## Refund 金额约束

Refund 币种继承原 Payment，调用方不能提交不同币种。所有已成功 Refund 的累计金额不能超过 Payment 原始金额；创建新 Refund 时，还必须考虑正在处理的 `pending` Refund 对剩余额度的占用。

部分退款能力还受套餐约束：Starter 只能执行一次剩余金额的全额退款，Growth 和 Scale 才支持多次部分退款。

## 边界示例

| 场景 | 结果 |
| --- | --- |
| NA Account 创建 USD Payment | 允许 |
| NA Account 创建 EUR Payment | 不允许，币种不在地区列表 |
| JPY Payment 使用金额 `500` | 表示 JPY 500 |
| USD Payment 使用金额 `49` | 不允许，低于最小金额 |
| USD Payment 使用金额 `50` | 允许，达到下边界 |
| 对 EUR Payment 创建 USD Refund | 不允许，Refund 不得换币种 |

## 反例与查询边界

反例：Account 位于 EU 并不代表它一定可以使用 Instant Refund。还必须验证套餐、功能开关、Payment 状态、退款时限和金额。

本规则只说明合法地区、币种和金额范围。某个 Account 当前属于哪个地区、某笔 Payment 的币种和剩余可退金额，必须查询对应业务状态，不能从静态规则文档推断。

## 相关知识

- 套餐和 Instant Refund 权限见 `KB-BR-004`。
- Payment 状态与金额创建条件见 `KB-BR-010`。
- Refund 资格和额度计算见 `KB-BR-012`。

