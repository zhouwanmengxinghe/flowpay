---
doc_id: KB-BR-016
title: Webhook 签名验证与 Signing Secret 轮换
doc_type: business_rule
authority: official
product_areas: [webhooks, developer_platform]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-WEBHOOK-013, RULE-WEBHOOK-014, RULE-WEBHOOK-015, RULE-WEBHOOK-016, RULE-WEBHOOK-017, RULE-WEBHOOK-018]
related_docs: [KB-BR-006, KB-BR-007, KB-BR-015]
indexing: include
language: zh-CN
---

# Webhook 签名验证与 Signing Secret 轮换

## Signing Secret 的作用

每个 Webhook Endpoint 有自己的 Signing Secret。FlowPay 使用该 Secret 对投递的时间戳和原始请求体签名，Merchant 使用相同 Secret 验证请求来自 FlowPay 且正文未被修改。

Signing Secret 不是 API Secret Key。它不能用于调用 FlowPay API，也不受 `sk_test_`、`sk_live_` 前缀规则管理。不同 Endpoint 的 Secret 不可互换，Sandbox 与 Production Endpoint 的 Secret 也相互隔离。

## 签名 Header 的版本差异

| 事件 API Version | 签名 Header |
| --- | --- |
| `2025-10-01`、`2026-01-15` | `X-FlowPay-Signature` |
| `2026-04-01`、`2026-07-01` | `FlowPay-Signature` |

从 `2026-04-01` 开始，FlowPay 不再同时发送旧 Header。Merchant 若升级事件版本但仍只读取 `X-FlowPay-Signature`，会将合法投递误判为签名缺失。

公开 API 操作产生的事件使用该请求的 API Version；订阅周期任务等内部操作使用 Account 当时默认版本。因此，在迁移期间应依据事件实际版本处理 Header，而不是假设所有投递立即采用同一名称。

## 验证要求

Merchant 应使用收到的原始请求字节进行验证，不能先解析 JSON、重新格式化后再计算签名。签名时间戳默认允许与接收端时间相差 5 分钟，用于降低重放风险。

标准验证过程是：

1. 从适用版本的 Header 读取时间戳和签名。
2. 检查时间戳与当前时间差不超过 5 分钟。
3. 使用当前 Endpoint 的有效 Signing Secret 和原始请求体计算期望签名。
4. 使用恒定时间比较验证签名。
5. 验证成功后，再按 `event_id` 执行业务去重。

时间戳超出容差并不自动表示 FlowPay 生成了错误签名，也可能是 Merchant 服务器时钟偏差或消息在中间层滞留。

## Secret 轮换

轮换 Endpoint Signing Secret 后，新 Secret 立即用于新投递，旧 Secret 继续有效 24 小时。Merchant 应在过渡期同时接受新旧 Secret：先部署新 Secret 验证能力，再触发轮换，确认新投递通过后移除旧 Secret。

24 小时是最大兼容窗口。旧 Secret 到期后，即使历史重试最初使用旧 Secret，后续投递也应按当时有效 Secret 验证。Merchant 不应无限期保留旧 Secret。

## 常见错误边界

- 使用 API Secret Key 验证 Webhook：一定失败，因为密钥用途不同。
- 对解析后的 JSON 重新序列化再验签：空格或字段顺序变化会导致不匹配。
- 升级到 `2026-04-01` 后只读取旧 Header：会表现为签名缺失。
- 轮换后立即删除旧 Secret：尚在过渡中的实例可能拒绝合法投递。
- 服务器时钟偏差超过 5 分钟：可能被判定为时间戳无效。

## 反例与查询边界

反例：签名验证失败不证明 FlowPay 没有发送，也不证明 Endpoint 未订阅事件。它说明 Delivery 已到达 Merchant 验证环节，需要分别检查 Header、原始请求体、Secret 版本和时钟。

本政策说明正确验证方式，但不能证明某个 Endpoint 当前使用哪个 Secret 版本或某次 Delivery 携带了哪个 Header；具体情况需要查询 Webhook 配置与 Delivery 记录。

## 相关知识

- API Key 和 Signing Secret 的区别见 `KB-BR-006`。
- API Version 的选择见 `KB-BR-007`。
- Endpoint 状态、订阅、投递和重试见 `KB-BR-015`。
