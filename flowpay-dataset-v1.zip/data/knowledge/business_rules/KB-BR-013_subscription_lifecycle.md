---
doc_id: KB-BR-013
title: Subscription 生命周期
doc_type: business_rule
authority: official
product_areas: [subscriptions, customers]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-SUB-001, RULE-SUB-002, RULE-SUB-003, RULE-SUB-004, RULE-SUB-005, RULE-SUB-006]
related_docs: [KB-BR-004, KB-BR-008, KB-BR-009, KB-BR-014]
indexing: include
language: zh-CN
---

# Subscription 生命周期

## 使用资格

Subscription 和 Invoice 只对 Growth、Scale 套餐开放，并要求 Account 的 `subscriptions` 功能开关开启。Starter 即使存在同名功能开关，也不能越过套餐硬限制。创建 Subscription 还要求 Customer 属于同 Account、同环境且状态为 `active`。

一个 Subscription 只关联一个 Customer 和一种币种。创建后不能把 Subscription 转移到其他 Customer，也不能更改计费币种；需要改变这些身份属性时，应取消原 Subscription 并创建新资源。

## 状态机

Subscription 状态包括 `trialing`、`active`、`past_due` 和 `canceled`。

```text
trialing ── trial ends ──> active
active ── invoice payment fails ──> past_due
past_due ── retry succeeds ───────> active
past_due ── retries exhausted ────> canceled
trialing/active/past_due ─────────> canceled
```

`canceled` 是终态，不能恢复为 `active`。Merchant 需要重新订阅时必须创建新的 Subscription。

## 试用期

试用期只能在创建 Subscription 时设置，长度为 1～30 天。创建后不能补加、重新开始或延长试用期。没有试用期的 Subscription 按正常计费流程进入 `active`；有试用期的 Subscription 先进入 `trialing`，试用结束后进入计费周期。

试用结束后的账单处理仍受 Invoice 和 Payment 结果影响。仅知道试用期结束，不能证明首笔 Invoice 已支付成功。

## 扣费失败与恢复

活动订阅的 Invoice 首次扣费失败后，Subscription 进入 `past_due`。FlowPay 在第 1、3、7 天执行重试；任何一次重试成功，Subscription 恢复 `active`。全部重试失败后，Subscription 进入 `canceled`。

`past_due` 表示当前账单需要追缴，不等于订阅已经永久取消。是否会恢复必须查看后续 Invoice Payment 结果。

## 主动取消

主动取消默认在当前计费周期结束时生效。在生效前，Subscription 继续保持原状态并提供到周期末。只有显式请求立即取消时，才立即进入 `canceled`。

取消 Customer 不能替代取消 Subscription。Customer 软删除不会自动改变已经存在的 Subscription；Merchant 应在删除 Customer 前按业务需要单独处理订阅。

## 边界与反例

反例：Growth 套餐并不自动保证 Subscription 可创建，还需要 `subscriptions` 开关和有效 Customer。

反例：Subscription 进入 `past_due` 不表示已经完成全部重试，也不应立即当作终态处理。

反例：周期末取消请求已经提交，不代表 Subscription 当下就是 `canceled`。需要查看取消生效时间和当前状态。

具体 Subscription 状态、试用结束时间和取消方式属于业务状态，必须查询 Subscription 记录。

## 相关知识

- 套餐和功能开关见 `KB-BR-004`。
- 创建操作幂等见 `KB-BR-008`。
- Customer 状态要求见 `KB-BR-009`。
- Invoice 扣费和重试见 `KB-BR-014`。
