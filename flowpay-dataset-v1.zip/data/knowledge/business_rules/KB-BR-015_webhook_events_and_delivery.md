---
doc_id: KB-BR-015
title: Webhook 事件、Endpoint 与投递策略
doc_type: business_rule
authority: official
product_areas: [webhooks, payments, subscriptions, invoices]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-ENV-004, RULE-PLAN-003, RULE-WEBHOOK-001, RULE-WEBHOOK-002, RULE-WEBHOOK-003, RULE-WEBHOOK-004, RULE-WEBHOOK-005, RULE-WEBHOOK-006, RULE-WEBHOOK-007, RULE-WEBHOOK-008, RULE-WEBHOOK-009, RULE-WEBHOOK-010, RULE-WEBHOOK-011, RULE-WEBHOOK-012, RULE-WEBHOOK-017]
related_docs: [KB-BR-002, KB-BR-004, KB-BR-007, KB-BR-010, KB-BR-014, KB-BR-016]
indexing: include
language: zh-CN
---

# Webhook 事件、Endpoint 与投递策略

## Event、Endpoint 和 Delivery

FlowPay 中三者含义不同：

- **Event**：业务状态变化产生的事件记录，例如 Payment 成功。
- **Webhook Endpoint**：Merchant 配置的接收地址、环境和订阅事件集合。
- **Delivery**：某个 Event 向某个 Endpoint 的一次投递过程及重试结果。

Payment 成功只证明 Event 应按规则产生，不证明某个 Endpoint 一定订阅了它，也不证明 Delivery 已成功。

## Endpoint 所有权与状态

Endpoint 只属于一个 Account 和一个环境。Sandbox Event 不会投递到 Production Endpoint，反之亦然。Endpoint 状态包括：

- `enabled`：可以接收新事件。
- `disabled`：不产生新的 Delivery。
- `restricted`：因套餐降级超过 Endpoint 数量上限，不接收新事件但保留历史记录。

套餐降级不会删除超额 Endpoint。FlowPay 按创建时间保留最早的可用数量，其余进入 `restricted`。

Endpoint 必须显式订阅事件类型。未订阅某事件时，不产生该 Event 到该 Endpoint 的 Delivery；这不是投递失败。

## 标准事件与版本

主要事件包括 `payment.action_required`、`payment.processing`、`payment.failed`、`refund.succeeded`、`refund.failed`、Subscription 和 Invoice 系列事件。

Payment 成功事件在 `2025-10-01` 至 `2026-04-01` 中名为 `payment.completed`，从 `2026-07-01` 起名为 `payment.succeeded`。公开 API 操作产生的事件沿用请求版本；平台周期任务产生的事件使用 Account 当时默认版本。

升级后，如果 Endpoint 仍只订阅旧事件名称，它不会自动匹配新名称。Merchant 应在迁移期间明确更新订阅集合。

## 成功判定与重试

HTTP 200～299 视为成功。FlowPay 不跟随 HTTP 3xx 重定向，3xx 按失败处理。HTTP 4xx 和 5xx 一般进入重试；HTTP 410 是例外，它表示 Endpoint 已永久移除，FlowPay 会立即禁用该 Endpoint。

默认重试安排在首次失败后的：1 分钟、5 分钟、30 分钟、2 小时、8 小时和 24 小时。完成 6 次重试仍未成功后，Delivery 进入 `exhausted`。

Scale 可以自定义重试间隔，但最多 8 次，首次失败到最后一次重试的总窗口不得超过 72 小时。Starter 和 Growth 使用默认策略。

## 至少一次语义

FlowPay 使用“至少一次”投递语义。网络中断可能导致 Merchant 已处理请求，但 FlowPay 未收到成功响应，从而再次投递同一 Event。Merchant 必须使用稳定的 `event_id` 去重，不能仅依据请求到达时间或业务对象 ID 去重。

## 诊断顺序

当业务对象状态已变化但 Merchant 表示未收到 Webhook 时，应依次确认：

1. Event 是否按适用 API Version 产生。
2. Endpoint 是否属于相同 Account 和环境。
3. Endpoint 是否为 `enabled`。
4. Endpoint 是否订阅实际事件名称。
5. 是否存在 Delivery，以及最近响应和重试状态。
6. 若收到但拒绝，是否为签名验证问题。

## 反例

反例：没有 Delivery 记录不一定是平台漏发，也可能是 Endpoint 未订阅、已禁用或环境不匹配。

反例：返回 302 不算投递成功，FlowPay 不会跟随跳转。

反例：同一 Event 收到两次不一定是两个 Payment；至少一次语义允许重复投递。

## 相关知识

- 环境策略见 `KB-BR-002`，套餐 Endpoint 上限见 `KB-BR-004`。
- 事件版本见 `KB-BR-007`。
- Payment 和 Invoice 事件来源见 `KB-BR-010`、`KB-BR-014`。
- 签名验证与 Secret 轮换见 `KB-BR-016`。

