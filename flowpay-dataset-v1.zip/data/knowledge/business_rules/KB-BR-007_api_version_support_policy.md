---
doc_id: KB-BR-007
title: API Version 选择与支持策略
doc_type: business_rule
authority: official
product_areas: [developer_platform, payments, webhooks]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-VERSION-001, RULE-VERSION-002, RULE-VERSION-003, RULE-VERSION-004, RULE-VERSION-005, RULE-VERSION-006, RULE-VERSION-007, RULE-VERSION-008, RULE-VERSION-009]
related_docs: [KB-BR-004, KB-BR-005, KB-BR-008, KB-BR-010, KB-BR-015, KB-BR-016]
indexing: include
language: zh-CN
---

# API Version 选择与支持策略

## 支持版本

FlowPay V1 识别四个日期格式版本：`2025-10-01`、`2026-01-15`、`2026-04-01` 和 `2026-07-01`。每个 Account 有一个默认 API Version；请求可以通过 `FlowPay-Version` Header 临时覆盖该次请求的版本。没有 Header 时使用 Account 默认版本。

传入不支持的版本会返回 `FP-4002 Unsupported API Version`，FlowPay 不会静默回退到最近版本。

## 版本改变什么

API Version 可以改变请求参数名、响应字段、Webhook 事件名称和默认行为，但不会复制或转换资源的内部业务状态。同一 Payment 在不同版本中读取时仍代表同一个资源，只是表达方式可能不同。

| 版本 | 关键行为 |
| --- | --- |
| `2025-10-01` | 创建 Payment 使用 `source`；成功事件为 `payment.completed`；签名 Header 为 `X-FlowPay-Signature` |
| `2026-01-15` | 新增 `requires_action`、`payment.action_required` 和幂等冲突详情 |
| `2026-04-01` | 推荐 `payment_method`，`source` 仅兼容且带弃用提示；签名 Header 改为 `FlowPay-Signature` |
| `2026-07-01` | 移除 `source`；成功事件改为 `payment.succeeded`；Refund 默认确认方式变化；429 新增 Reset Header |

使用 `2026-07-01` 提交 `source` 返回 `FP-4003 Removed Parameter`，不能因为该参数在旧文档中存在就继续使用。

## Webhook 的版本来源

公开 API 操作产生的事件沿用该请求的 API Version。订阅周期任务等平台内部操作产生的事件使用 Account 当时的默认 API Version。事件名称和签名 Header 都必须按照事件采用的版本解释。

因此，同一个 Account 在短时间内可能收到不同版本形态的事件，例如部分请求显式覆盖版本而后台订阅任务使用默认版本。消费者应根据实际事件契约处理，而不是只依据 Account 当前默认版本猜测历史事件。

## 支持与弃用

每个版本至少支持 12 个月。FlowPay 在废弃版本前必须发布迁移指南。Scale 套餐可以申请最多 90 天的版本冻结延期；延期只延长该 Account 的旧版本使用时间，不改变新建 Account 可选版本，也不让已移除参数自动出现在新版本中。

## 判断适用规则

回答版本相关问题时，应确认：请求实际 Header、Account 默认版本、事件产生方式和请求发生时间。不能把“当前最新文档”默认应用于旧请求。

## 边界与反例

反例：Account 默认版本是 `2026-04-01`，但某请求显式指定 `2026-07-01`，则该请求不能使用 `source`，成功事件也采用新名称。

## 相关知识

- 套餐的版本冻结资格见 `KB-BR-004`。
- 429 Header 差异见 `KB-BR-005`。
- Payment 状态差异见 `KB-BR-010`。
- Webhook 事件与签名见 `KB-BR-015`、`KB-BR-016`。
