---
doc_id: KB-BR-011
title: Payment 失败分类与处置边界
doc_type: business_rule
authority: official
product_areas: [payments, operations]
api_versions: ["2025-10-01", "2026-01-15", "2026-04-01", "2026-07-01"]
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-PAY-001, RULE-PAY-002, RULE-PAY-005, RULE-ERROR-001, RULE-ERROR-002, RULE-ERROR-003, RULE-ERROR-004]
related_docs: [KB-BR-005, KB-BR-006, KB-BR-007, KB-BR-010]
indexing: include
language: zh-CN
---

# Payment 失败分类与处置边界

## 失败不只由 Payment Method 引起

开发者所说的“支付失败”可能发生在请求进入支付处理之前，也可能是 Payment 已创建后进入 `failed`。HTTP 状态相同不代表根因相同，错误码和资源状态必须一起解释。

## 支付方式类错误

| 错误码 | 含义 | 标准处置 |
| --- | --- | --- |
| `FP-4021` | Payment Method Declined | 提示客户更换支付方式或联系支付方式提供方 |
| `FP-4022` | Insufficient Funds | 提示客户补充资金或更换支付方式 |
| `FP-4023` | Customer Action Required | 在旧版本中表示需要额外操作；新版本使用 `requires_action` 流程 |
| `FP-4024` | Payment Method Expired | 更新或更换支付方式 |

`FP-4023` 具有版本差异：在 `2025-10-01` 中 Payment 进入 `failed`；从 `2026-01-15` 开始，支持的请求进入 `requires_action`，Merchant 应引导客户完成验证后确认 Payment。

## 请求、权限和状态类错误

- `FP-4001`：请求参数非法，通常应修正请求后再发起。
- `FP-4003`：使用了当前版本已移除的参数，应按迁移规则改用新参数。
- `FP-4011`、`FP-4012`：Key 无效或环境不匹配，请求未按预期访问目标环境。
- `FP-4031`、`FP-4032`：套餐不支持功能或 Production 被暂停。
- `FP-4091`：幂等键与首次参数不一致，不应盲目更换金额后继续重试。
- `FP-4221`：对当前 Payment 状态执行了不允许的操作。
- `FP-4291`：请求速率超限，不表示支付方式被拒绝。

这些错误有些不会创建 Payment，有些针对已有 Payment 的非法操作。诊断时应检查响应是否包含 `payment_id`，并查询资源当前状态。

## 平台错误

`FP-5001 Internal Processing Error` 和 `FP-5031 Service Temporarily Degraded` 表示平台内部处理或临时可用性问题，不应仅凭错误码归因于 Merchant 配置。客户端可以在遵守幂等和退避策略的前提下重试，但要结合 Request Log 和 Service Status 判断具体影响。

## 重试边界

`failed` 是 Payment 终态，不能原地重试。需要再次收款时创建新 Payment。网络超时且未知首次请求结果时，应使用相同 Idempotency Key 查询或安全重试，避免重复创建。

对于 `requires_action`，完成客户操作后确认现有 Payment，不要创建第二笔 Payment。对于参数、认证、套餐和状态类错误，应先修正对应条件，再决定是否新建请求。

## 反例

反例：看到 HTTP 402 就统一提示“余额不足”是错误的，`FP-4021`、`FP-4022`、`FP-4023` 和 `FP-4024` 的处置不同。

反例：看到 HTTP 503 就检查 Webhook 配置不能证明根因，因为 503 可能发生在 Payment API 服务层。

反例：用户称“付款失败”不代表 Payment 状态一定是 `failed`；它可能仍在 `processing`、等待操作，或请求在认证阶段就被拒绝。

## 相关知识

- 429 的判断见 `KB-BR-005`。
- Key 与环境错误见 `KB-BR-006`。
- 版本差异见 `KB-BR-007`。
- Payment 状态机见 `KB-BR-010`。

