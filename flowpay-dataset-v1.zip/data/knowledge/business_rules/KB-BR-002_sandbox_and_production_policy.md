---
doc_id: KB-BR-002
title: Sandbox 与 Production 环境策略
doc_type: business_rule
authority: official
product_areas: [developer_platform, accounts]
api_versions: all_supported
effective_from: "2025-10-01"
effective_to: null
supersedes: []
rule_ids: [RULE-ENV-001, RULE-ENV-002, RULE-ENV-003, RULE-ENV-004, RULE-ENV-005, RULE-AUTH-006, RULE-AUTH-007, RULE-AUTH-008]
related_docs: [KB-BR-001, KB-BR-005, KB-BR-006, KB-BR-015]
indexing: include
language: zh-CN
---

# Sandbox 与 Production 环境策略

## 两种运行环境

FlowPay 提供 `sandbox` 和 `production` 两个环境。Sandbox 用于开发、集成测试和故障复现，其中的客户、支付和资金都是模拟数据；Production 用于正式业务。两个环境共享产品规则，但资源、密钥、Webhook 和调用额度完全隔离。

Account 创建后立即获得 Sandbox 访问能力。Production 只有在账户完成生产启用并满足 `production_enabled=true` 后才可使用。启用 Production 不会复制 Sandbox 中已有的 Customer、Payment 或 Webhook 配置。

## Key 与资源必须匹配环境

Sandbox Secret Key 使用 `sk_test_` 前缀，只能访问 Sandbox。Production Secret Key 使用 `sk_live_` 前缀，只能访问 Production。使用正确 Account 但错误环境的 Key 访问资源时，请求返回 `FP-4012 Environment Mismatch`。

环境匹配适用于所有资源关联：

- Sandbox Customer 只能创建 Sandbox Payment。
- Sandbox Payment 只能产生 Sandbox Event。
- Sandbox Event 只能投递给 Sandbox Webhook Endpoint。
- Production 的资源关系遵守同样规则。

## Production 启用与暂停

未启用 Production 的 Account 不能创建 `sk_live_` Key。Production 启用后，可以创建和轮换 Production Key。平台也可以暂停某个 Account 的 Production 访问；暂停不会删除现有 Key 或业务记录，但所有 Production API 请求返回 `FP-4032 Production Access Suspended`。

Production 暂停不影响 Sandbox。Developer 可以继续在 Sandbox 复现问题，但 Sandbox 成功不代表 Production 已恢复，也不能证明 Production Key 当前有效。

## Rate Limit 与环境

Sandbox 使用固定的 120 req/min 持续上限和 180 req/min 突发上限，不随套餐变化。Production 才使用当前已生效套餐对应的 Rate Limit。判断某次 429 时，必须先确认请求环境，再选择正确上限。

## 决策示例

| 条件 | 允许访问 | 典型失败 |
| --- | --- | --- |
| `sk_test_` + Sandbox 资源 | 是 | — |
| `sk_live_` + Production 资源，Production 已启用 | 是 | — |
| `sk_test_` + Production 资源 | 否 | `FP-4012` |
| 未启用 Production 时创建 `sk_live_` | 否 | Production 尚不可用 |
| Production 被暂停后使用现有 `sk_live_` | 否 | `FP-4032` |

## 边界与反例

反例：一个请求使用 `sk_live_` 并不自动证明它访问的是 Production 中存在的资源。仍需检查 Key 是否有效、资源是否属于同一 Account，以及 Production 是否被暂停。

同样，Sandbox 中创建了相同 ID 文本的 Customer，也不能用它满足 Production Payment 的 Customer 关联要求。环境是资源身份的一部分。

## 相关知识

- 租户与环境的组合隔离见 `KB-BR-001`。
- Sandbox 和 Production 的限流差异见 `KB-BR-005`。
- Key 生命周期见 `KB-BR-006`。
- Webhook 的环境匹配见 `KB-BR-015`。

