# FlowPay Dataset V1 冻结发布

- Release ID：`flowpay-dataset-v1`
- Dataset Version：`1.0.0`
- 状态：`frozen`
- 发布日期：`2026-09-01`
- Manifest SHA-256：`2e50d09e8898ce0aa4eb3f02698ac0ef76484f9e9c90c4ffac318d12d3e77a5f`

本目录不复制大型数据库和日志文件；`release_manifest.json` 使用项目相对路径和 SHA-256 将所有冻结工件绑定为一个版本。

## 数据规模

- Published Knowledge：100 份 / 809 个 Chunk
- Scenario Family：75 个
- Benchmark：300 题
- 文档证据单元：633 个
- SQL / Runtime Selector：535 个

## 冻结质量门禁

- `evidence_exists`：300/300
- `fully_retrievable_top20`：300/300
- `required_document_units_retrieved`：633/633
- `structured_selectors_stable`：535/535
- `instance_diagnosis_complete`：180/180
- `assertion_support_proxy`：530/530
- `canonical_invariants`：14/14
- `knowledge_leakage_scan`：passed
- `question_route_leakage_scan`：passed
- `offline_fixture_strict`：300/300

## 可见性边界

- 100 份 Published Markdown 可以进入 RAG。
- SQLite 和 Runtime 只能通过九个只读类型化工具访问。
- Blueprint、标准答案、Evidence Selector 和解析结果只用于隐藏评测。
- Audit Event Journal 禁止提供给 Agent。
- 历史 DeepSeek 运行结果不属于 Dataset V1。

## 关于重新生成

V1 已经冻结，发布器（`dataset_release.py` 与 `release-dataset` 命令）随课程精简一并移除，
本目录是它留下的记录。需要复现时从 git 历史取回。

`release_manifest.json` 里的路径与 SHA-256 仍然有效，可以用来校验本机的数据是否与冻结版一致。
