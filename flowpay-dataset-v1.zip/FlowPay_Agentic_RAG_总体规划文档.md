# FlowPay Agentic RAG 教程项目总体规划文档

> 围绕虚拟支付基础设施 SaaS 构建 8 类异构数据、检索工具与可评测 Agentic RAG 场景

> 核心定位  不是把所有信息统一向量化，而是构造“文档知识 + 结构化业务状态 + 运行时动态状态”的异构知识环境，让 Agent 决定何时检索、检索什么、调用哪个数据源以及何时停止。

版本：V1.0    |    文档语言：中文    |    项目性质：教程 / Synthetic Benchmark

# 目录与阅读顺序

1. 项目目标与设计原则

2. FlowPay 产品与业务边界

3. 核心业务对象与业务流程

4. 八类数据的总体设计

5. 八类数据的详细规划

6. 数据存储与检索方式

7. Agentic RAG 系统架构与工具接口

8. 数据规模与构造原则

9. Synthetic Data 生成方法

10. 评测问题设计与 Benchmark

11. 项目目录与工程组织

12. 实施顺序、验收标准与风险控制

> 阅读建议  先把第 2～5 节当成“业务与数据字典”，再看第 7～10 节理解 Agentic RAG 如何消费这些数据。开发过程中，所有新增数据都必须能追溯到业务事实或评测问题，避免为了“数据量”而造无意义内容。

# 1. 项目目标与设计原则

## 1.1 项目目标

本项目以虚拟支付基础设施 SaaS “FlowPay”为业务背景，构建一套可复现、可扩展、可评测的 Agentic RAG 教程环境。目标不是复刻真实 Stripe，而是抽取支付基础设施最适合教学的业务结构，并用受控的 synthetic data 展示从朴素 RAG 到 Agent-controlled Retrieval、Routing、Tool Use、Reflection 的演化。

- **业务目标：**让读者可以把 FlowPay 当成一个真实存在的开发者支付平台来理解。
- **数据目标：**同时具备非结构化知识、结构化业务状态和动态运行状态。
- **Agent 目标：**让 Agent 的价值体现在“决策检索过程”，而不是堆叠 Agent 数量。
- **评测目标：**每个问题都能知道正确答案、必要证据、所需工具和期望检索轨迹。
- **教程目标：**同一套业务世界与数据可以贯穿全部章节，避免每章更换 Demo。

## 1.2 设计原则

| 原则 | 含义 | 落地方式 |
| --- | --- | --- |
| 业务一致性 | 所有数据共享同一套事实与规则 | 先生成 Ground Truth，再派生文档、数据库、日志和问答 |
| 异构优先 | 不把所有数据都塞进 Vector DB | 文档走 Retriever，业务记录走 SQL，动态状态走 Tool/API |
| 小而复杂 | 规模适中但信息依赖足够丰富 | 优先制造跨源、多跳、时序和冲突信息，而不是盲目加文档 |
| 可验证 | Agent 每一步都可以评估 | 保存 evidence_ids、required_tools、expected_hops、final_answer |
| 可扩展 | 后续可放大数据规模 | 生成器参数化，实体 ID 和关联关系稳定 |
| 教学清晰 | 每个能力对应明确失败案例 | Naive RAG 与 Agentic RAG 使用同一问题做对照 |

## 1.3 非目标

- 不模拟真实资金清算、银行卡网络、PCI 合规全流程。
- 不追求与 Stripe API 字段一一对应，所有命名与规则独立设计。
- 第一版不覆盖争议/拒付、税务、Marketplace Connect、复杂风控模型等高复杂度模块。
- 不把“Multi-Agent”当成项目成立的必要条件，单 Agent 也可以实现完整 Agentic RAG。

# 2. FlowPay 产品与业务边界

## 2.1 产品一句话定义

> 产品定义  FlowPay 是面向互联网公司和开发者的在线支付基础设施平台。商户通过 API 完成收款、退款、订阅扣费和 Webhook 通知，并通过账户、套餐、API Key、调用额度与运行状态管理其接入。

## 2.2 四个核心角色

| 角色 | 示例 | 含义 |
| --- | --- | --- |
| Merchant / Account | Acme AI、SuperCRM | FlowPay 的直接客户，即接入支付能力的互联网公司 |
| Developer | Acme 后端工程师 | 调用 FlowPay API、配置 Webhook、处理技术故障的人 |
| End Customer | 购买 Acme 服务的用户 | 向 Merchant 付款的人，在 FlowPay 内表现为 Customer |
| FlowPay Platform | 虚拟支付平台 | 提供 API、交易处理、订阅、Webhook 与运行时基础设施 |

## 2.3 V1 产品范围

| 业务域 | 能力 | 是否纳入 V1 |
| --- | --- | --- |
| Payments | 创建支付、支付状态、失败原因 | 是 |
| Refunds | 全额/部分退款、退款状态 | 是 |
| Customers | 商户终端客户档案 | 是 |
| Subscriptions | 周期扣费、订阅状态 | 是 |
| Invoices | 订阅账单与支付关联 | 是（简化） |
| Webhooks | 事件订阅、投递、重试 | 是 |
| Developer Platform | API Key、环境、API 版本、Rate Limit | 是 |
| Operations | Usage、Request Logs、Service Status | 是 |
| Disputes / Tax / Connect | 拒付、税务、平台分账 | 否 |

# 3. 核心业务对象与业务流程

## 3.1 核心对象关系

```text
FlowPay
└── Account (商户公司)
    ├── Merchant Plan / Subscription
    ├── API Keys
    ├── End Customers
    │   ├── Payments
    │   │   └── Refunds
    │   └── Customer Subscriptions
    │       └── Invoices
    │           └── Payments
    ├── Webhook Endpoints
    └── Runtime State
        ├── API Usage
        ├── Request Logs
        ├── Webhook Deliveries
        └── Service Status
```

## 3.2 支付流程

```text
终端用户点击付款
    ↓
Merchant Backend 调用 POST /v1/payments
    ↓
FlowPay 创建 Payment
    ↓
processing → succeeded / failed
    ↓
产生 Event
    ↓
Webhook 投递给 Merchant
    ↓
Merchant 根据结果开通服务 / 提示失败
```

## 3.3 订阅流程

```text
Customer Subscription
    ↓ 到期
生成 Invoice
    ↓
创建 Payment
    ↓
支付成功 → subscription 保持 active
支付失败 → retry → past_due / canceled
```

## 3.4 技术支持问题的三层信息

| 层级 | 它回答的问题 | 典型数据 | 访问方式 |
| --- | --- | --- | --- |
| Knowledge | 规则是什么？错误码是什么意思？ | Published Business Rules、API Docs、Troubleshooting、Release Notes、Cases | Vector / Hybrid Retriever |
| Business State | 这个商户现在是什么配置？这笔交易是什么状态？ | Accounts、Payments、Webhook Config | SQL |
| Runtime State | 刚刚发生了什么？平台当前是否异常？ | Usage、Request Logs、Delivery Logs、Status | Tool / Mock API |

> 为什么这很适合 Agentic RAG  一个真实支持问题经常同时需要“规则 + 当前业务状态 + 实时运行状态”。Agent 的价值不是多说几句话，而是决定先查哪里、下一步查什么、证据是否足够。

# 4. 八类数据的总体设计

| 编号 | 数据种类 | 形态 | 主要存储 | Agent 访问方式 | 核心用途 |
| --- | --- | --- | --- | --- | --- |
| D1 | Published Business Rules + API / Product Docs | 非结构化 | Vector DB | search_business_rules / search_api_docs | 权威业务规则、API 定义与参数 |
| D2 | Troubleshooting / Error Docs | 非结构化 | Vector DB | search_troubleshooting | 错误码、排障路径、解决办法 |
| D3 | Release Notes / Migration Guides | 非结构化 + 时间元数据 | Vector DB | search_release_notes | 版本变化、废弃字段、Breaking Change |
| D4 | Support Cases / Historical Cases | 半结构化文本 | Vector DB | search_support_cases | 相似案例、历史处置经验 |
| D5 | Merchant / Account Data | 结构化 | SQL | query_accounts | 商户套餐、地区、版本、API Key、环境 |
| D6 | Payment Business Data | 结构化 | SQL | query_payments | Customer、Payment、Refund、Subscription、Invoice |
| D7 | Webhook Configuration Data | 结构化 | SQL | query_webhooks | Endpoint、订阅事件、启停配置 |
| D8 | Runtime Observability Data | 动态结构化 | Mock API / Tool | get_runtime_* | Usage、请求日志、投递日志、服务状态 |

八类数据的边界原则：D1～D4 表达“可检索知识”，D5～D7 表达“业务事实状态”，D8 表达“运行时事实”。D1 内部进一步分为 Published Business Rules 和 API / Product Docs 两个独立语料集合。三类事实不能互相替代。比如套餐上限来自 Published Rules，某商户当前购买的套餐来自 Account SQL，今天实际请求量来自 Runtime Tool。

# 5. 八类数据的详细规划

## D1. Published Business Rules + API / Product Docs

Published Business Rules 描述权威资格、上限、状态机和策略；API / Product Docs 描述开发者公开的产品能力与 API 契约。二者同属 D1 知识层，但使用独立集合和 Retriever，避免将规范裁决与操作说明混为一谈。

### 包含内容

- 套餐、环境、版本和权限规则
- Payment、Refund、Subscription、Invoice 状态机
- Webhook 投递、重试与签名规则
- Payments API
- Refunds API
- Customers API
- Subscriptions / Invoices API
- Webhooks API
- Authentication
- Idempotency
- Rate Limits
- Sandbox / Production
- API Versioning
### 推荐字段

doc_id、title、doc_type、product_area、api_version、effective_from、deprecated、rule_ids、body

### 推荐规模

V1 固定为 16 份 Published Business Rules + 34 份 API / Product Docs，共 50 份。

## D2. Troubleshooting / Error Docs

描述错误码、症状、可能原因、诊断步骤和处理方式，是技术支持场景中最直接的知识来源。

### 包含内容

- FP-4011 Invalid API Key
- FP-4012 Environment Mismatch
- FP-4031 Feature Unavailable
- FP-4091 Duplicate Idempotency Key
- FP-4221 Invalid Payment State
- FP-4291 Rate Limit Exceeded
- FP-5001 Internal Error
- FP-5031 Service Degraded
### 推荐字段

doc_id、error_code、symptoms、causes、diagnostic_steps、resolution、related_product_area

### 推荐规模

V1 固定为 24 份。

## D3. Release Notes / Migration Guides

用于制造时间维度和版本差异，让检索不仅看语义，还需要考虑 API Version、发布时间与有效性。

### 包含内容

- 字段新增/废弃
- 默认行为变化
- Webhook 事件名称调整
- Rate Limit 规则变化
- SDK 兼容性
- Known Issues
- Migration Steps
### 推荐字段

release_id、api_version、release_date、change_type、affected_area、body、supersedes

### 推荐规模

V1 固定为 10 份，覆盖 Canonical Rules 中定义的版本时间线。

## D4. Support Cases / Historical Cases

模拟开发者支持历史。与官方文档不同，它表达“别人遇到过什么、最后怎么定位”，适合相似案例检索。

### 包含内容

- 认证失败
- 429 限流
- Webhook 未收到
- Payment 失败
- 退款状态异常
- 升级后字段失效
- 服务事件误判
### 推荐字段

case_id、subject、description、symptoms、resolution、root_cause、created_at、product_area

### 推荐规模

V1 固定为 16 份 Published Support Cases，控制重复模板比例，保留噪声和错误假设。案例不得冒充当前 Account 的动态事实。

## D5. Merchant / Account Data

描述 FlowPay 的直接客户当前处于什么配置，是 Agent 查询“这个客户是谁、买了什么、接入方式如何”的来源。

### 包含内容

- Accounts
- Merchant Plans
- API Keys
- API Version
- Region
- Production Enablement
- Feature Flags
### 推荐字段

account_id、company_name、plan、region、api_version、production_enabled、created_at

### 推荐规模

Canonical Snapshot 约 120 个 Accounts，关联约 240～320 个 API Keys。

## D6. Payment Business Data

描述交易业务事实。不能被 chunk 检索替代，因为问题常涉及精确 ID、状态过滤、聚合和关联查询。

### 包含内容

- End Customers
- Payments
- Refunds
- Customer Subscriptions
- Invoices
### 推荐字段

customer_id、payment_id、refund_id、subscription_id、invoice_id、status、amount、currency、error_code、timestamps

### 推荐规模

Customers 2,500～3,500；Payments 18,000～24,000；Refunds 1,200～2,000；Subscriptions 800～1,200；Invoices 3,000～5,000。

## D7. Webhook Configuration Data

描述 Merchant 配置了哪些 Webhook endpoint、订阅了哪些事件，以及 endpoint 当前是否启用。它是“平台有没有发送”和“商户有没有正确配置”之间的关键桥梁。

### 包含内容

- Webhook Endpoints
- Subscribed Events
- Signing Secret Version
- Endpoint Status
- Retry Policy Override（可选）
### 推荐字段

endpoint_id、account_id、url_alias、enabled、subscribed_events、created_at、updated_at

### 推荐规模

约 220～320 个 Endpoints，严格遵守各套餐上限。

## D8. Runtime Observability Data

表达“现在和刚刚发生了什么”。数据时效性高，采用 Tool / Mock API 查询，不做 embedding。

### 包含内容

- API Usage
- Request Logs
- Webhook Delivery Logs
- Service Status
### 推荐字段

timestamp、account_id、request_id、endpoint、http_status、latency_ms、event_id、delivery_status、service、service_status

### 推荐规模

Usage 采用分钟/小时聚合；Request Logs 50,000～80,000；Webhook Delivery Attempts 15,000～30,000；Service Incidents 20～30。

# 6. 数据存储与检索方式

## 6.1 为什么不把八类数据全部 chunk 化

FlowPay 的设计目标是异构检索。文档适合语义检索，但账户、交易、配置和运行状态需要精确查询、过滤、聚合或实时读取。如果把它们全部文本化进入 Vector DB，会丢失结构化查询能力，也会弱化 Agent 选择工具的意义。

| 数据 | 是否切 Chunk | 原因 |
| --- | --- | --- |
| D1 Published Rules + API Docs | 是，分两个集合 | 权威规则与 API 长文本适合语义/混合检索，但必须独立 routing |
| D2 Troubleshooting | 是 | 错误描述与用户问题通常语义匹配 |
| D3 Release Notes | 是 | 需要语义检索 + metadata filter |
| D4 Support Cases | 是/按字段拼接 | 相似案例适合向量检索，但不作为当前账户事实 |
| D5 Account | 否 | 精确 ID、套餐、版本、权限查询 |
| D6 Payment | 否 | 交易状态、金额、聚合、关联查询 |
| D7 Webhook Config | 否 | 配置项精确匹配与关联查询 |
| D8 Runtime | 否 | 实时/短期状态，应按 Tool/API 查询 |

## 6.2 推荐基础设施

| 层 | 推荐技术 | 备注 |
| --- | --- | --- |
| Vector / Hybrid | Qdrant / pgvector / Chroma | 教程可优先 Chroma 或 Qdrant；支持 metadata filter |
| SQL | SQLite → PostgreSQL | 教程本地 SQLite 足够，接口设计保持可迁移 |
| Mock API | FastAPI 或 Python Tool | D8 可先由函数读取 JSON/Parquet，再升级 HTTP |
| LLM Orchestration | LangGraph / 自定义 Agent Loop | 强调状态、工具调用和停止条件 |
| Evaluation | 自定义 evaluator + RAGAS/LangSmith 可选 | 核心指标由项目自己定义，不依赖单一框架 |

# 7. Agentic RAG 系统架构与工具接口

## 7.1 总体架构

```text
User Question
      ↓
   Agent / Planner
      │
      ├── search_business_rules(query, filters)
      ├── search_api_docs(query, filters)
      ├── search_troubleshooting(query, filters)
      ├── search_release_notes(query, api_version)
      ├── search_support_cases(query, account_id?)
      ├── query_accounts(question / structured params)
      ├── query_payments(question / structured params)
      ├── query_webhooks(question / structured params)
      └── get_runtime_state(resource_id / account_id / service)
      │
      ↓
Evidence State
      ↓
Enough evidence? ── No → plan next action / rewrite query
      │ Yes
      ↓
Final Answer + Citations + Tool Trace
```

## 7.2 推荐工具粒度

工具不宜过细，否则 Agent 选择空间膨胀；也不宜过粗，否则不同知识源的 routing 价值被吞掉。八个数据层形成 9 个逻辑工具：D1 的 Published Business Rules 与 API / Product Docs 分开检索，D5～D8 继续按数据边界提供 typed、read-only 操作。Agent 不执行任意 SQL。

| Tool | 输入示例 | 输出 |
| --- | --- | --- |
| search_business_rules | query, product_area, effective_at | 权威规则与状态机证据 |
| search_api_docs | query, product_area, api_version | Top-K chunks + doc metadata |
| search_troubleshooting | query, error_code? | 错误文档证据 |
| search_release_notes | query, version/date filter | 版本变化证据 |
| search_support_cases | query, product_area? | 相似历史工单 |
| query_accounts | operation + account_id + as_of | 账户与接入配置 |
| query_payments | operation + typed object filters | 交易业务结果 |
| query_webhooks | operation + account/environment/object ID | Webhook 配置与摘要 |
| get_runtime_state | operation + typed time/object filters | Usage/Logs/Delivery/Status |

## 7.3 Agent 的最小决策循环

> 1. 读取用户问题与当前 evidence
> 2. 判断能否直接回答
> 3. 若不能，选择一个最有信息增益的 Tool
> 4. 生成该 Tool 所需查询参数
> 5. 观察结果并更新 evidence
> 6. 判断是否仍有关键事实缺失 / 冲突
> 7. 必要时继续检索或换 Tool
> 8. 达到停止条件后生成答案，并引用实际证据

> Agentic 的核心  系统复杂度并不来自“必须有很多 Agent”，而来自把 Retrieval 从固定流水线变成模型可以动态控制的动作：是否检索、去哪检索、搜什么、搜几轮、什么时候停止。

# 8. 数据规模与构造原则

## 8.1 推荐整体规模

| 数据种类 | 建议 V1 规模 | 主要目的 |
| --- | --- | --- |
| D1 Published Rules + API Docs | 16 + 34 份 | 形成权威规则与 API/产品知识 |
| D2 Troubleshooting / Error | 24 份 | 覆盖核心错误与排障 |
| D3 Release Notes / Migration | 10 份 | 制造版本与时间差异 |
| D4 Support Cases | 16 份 | 提供相似历史案例与噪声 |
| D5 Merchant / Account | 约 120 Accounts | 制造套餐、版本、环境差异 |
| D6 Payment Business | 数万行规则系统投影 | 支持精确交易状态与关联查询 |
| D7 Webhook Config | 约 220～320 Endpoints | 支持 Webhook 配置诊断 |
| D8 Runtime Observability | 约 50,000～80,000 Request Logs 等 | 支持实时/近实时故障诊断 |
| Evaluation Queries | 恰好 300 条 | 60 Dev / 240 Test |

向量库原始文档固定为 100 份，chunk 数由后续 chunking 策略确定。SQL 与 Runtime 数据无需 embedding，因此总体数据可以有数万行，但检索索引依然保持轻量，适合教程本地运行。

## 8.2 数据复杂度比数据量更重要

- 建立同义表达：同一错误在 Docs、Tickets 和用户问题中的表述不同。
- 建立 Distractor：多个错误都可能表现为 401/403/429/503，不能靠关键词唯一命中。
- 建立版本冲突：旧文档与新文档规则不同，必须看 api_version / effective_date。
- 建立跨源依赖：答案必须组合 Account + Docs + Runtime，而不是单源可得。
- 建立用户错误假设：问题中可带“是不是限流？”等猜测，Agent 需要验证而不是迎合。
- 建立失败检索路径：部分 query 第一次只找到不完整证据，要求 Agent 二次检索。

# 9. Synthetic Data 生成方法

## 9.1 总体原则：先规则与问题合同，后运行系统生成事实

```text
Canonical Rules + 100 Published Docs
        ↓
Freeze 300 Questions + Ground Truth Assertions
        ↓
Evidence Contracts + Scenario Specs + Reserved IDs
        ↓
Deterministic Simulator + Fixed-seed Background Commands
        ↓
SQLite + Runtime Logs + Usage + Delivery Attempts
        ↓
Resolve Evidence + Validation + Immutable Snapshot
```

## 9.2 Canonical Ground Truth 应包含什么

- 产品规则：套餐上限、功能可用性、Rate Limit、退款条件、Webhook 重试规则。
- 版本规则：不同 API Version 的参数、默认行为、deprecated 字段。
- 账户状态：每个 Merchant 当前套餐、版本、地区、环境和 Key 状态。
- 交易状态：Payment / Refund / Subscription / Invoice 的有效状态机。
- 事件状态：Webhook Endpoint、Event、Delivery 的关联关系。
- 运行事件：服务降级时间窗、请求异常、Usage 峰值。

## 9.3 推荐生成流程

1. 冻结 Canonical Rules、100 份 Published 文档及其 manifest。
2. 在任何结构化数据生成前，写完并冻结 300 条问题、Ground Truth Assertions、Required Tools 与 Evidence Contracts。
3. 按 Scenario Family 预留稳定 ID，编写声明式 Scenario Specs；同一 Family 不跨 Dev / Test。
4. 将 Scenario Specs 编译为业务命令，并与固定种子的背景命令按时间合并。
5. 用 Python + SQLite 确定性模拟器运行统一状态机，SQL、Runtime、Usage 和日志均由实际执行流沉淀，禁止 LLM 直接生成结构化事实。
6. 解析 Evidence Selectors、执行不变量和反证校验，只有 300 题全部闭合后才发布 Canonical Snapshot。

## 9.4 推荐的评测样本格式

```json
{
  "id": "q_0187",
  "question": "Acme 今天大量出现 FP-4291，是不是因为套餐被降级？",
  "type": "multi_source",
  "difficulty": "hard",
  "ground_truth_answer": "不是套餐变化，而是调用速率超过 Growth 限额。",
  "required_sources": ["accounts", "api_docs", "runtime_usage"],
  "required_tools": ["query_accounts", "search_api_docs", "get_runtime_state"],
  "evidence_ids": ["acct_acme", "doc_rate_limit_growth", "usage_acme_20260826"],
  "expected_hops": 3
}
```

# 10. 评测问题设计与 Benchmark

## 10.1 建议 300 条评测问题分布

| 问题类型 | 数量 | 比例 | 主要验证能力 |
| --- | --- | --- | --- |
| Simple Retrieval | 70 | 23% | 单次知识检索，验证基础 RAG |
| Multi-document | 50 | 17% | 两个或多个文档证据组合 |
| Multi-hop | 60 | 20% | 后一步查询依赖前一步结果 |
| Multi-source | 70 | 23% | Vector + SQL / Runtime Tool |
| Temporal / Version-aware | 25 | 8% | 版本、有效期、旧文档冲突 |
| Tool-use / Diagnostic | 25 | 8% | 日志、Usage、Status 与业务判断 |

## 10.2 典型 Benchmark 问题

| 类型 | 示例问题 | 期望数据源 |
| --- | --- | --- |
| 简单知识 | FP-4091 是什么意思？ | D2 |
| 版本问题 | 2026-07 API Version 中 source 参数为什么失效？ | D1 + D3 |
| 账户 + 文档 | Acme 的 Growth 套餐是否支持 1,500 req/min？ | D5 + D1 |
| 支付诊断 | pay_8J2 为什么失败，应该怎么处理？ | D6 + D2 |
| Webhook 诊断 | Payment 已成功但商户没收到 webhook，原因是什么？ | D6 + D7 + D8 + D1/D2 |
| 服务异常 | 今天所有 503 是不是因为商户配置错误？ | D2 + D8 |
| 相似案例 | 有没有与当前 signature mismatch 类似的历史工单？ | D4 + D2 |
| 反事实验证 | 用户认为 429 是套餐降级，证据是否支持？ | D5 + D8 + D1 |

## 10.3 核心评测指标

| 指标 | 说明 |
| --- | --- |
| Answer Correctness | 最终答案是否与 ground truth 一致 |
| Evidence Recall | 是否找到了回答所需的关键 evidence_ids |
| Citation Correctness | 答案引用是否真正支持对应结论 |
| Tool Selection Accuracy | 是否调用了必要工具，是否调用明显无关工具 |
| Routing Accuracy | 是否选择了正确文档集合 / 数据源 |
| Hop Completion | 多跳问题是否完成所有必要步骤 |
| Unnecessary Tool Calls | 是否过度检索、重复查询 |
| Latency / Token Cost | Agentic 增益与成本的权衡 |
| Stop Accuracy | 证据充分时能否停止，证据不足时能否继续 |

> 最重要的对照实验  同一套 300 条问题同时跑 Naive RAG 与 Agentic RAG。预期结果不是“所有问题 Agentic 都更高”，而是简单问题差距小，Multi-hop / Multi-source / Temporal / Tool-use 问题上 Agentic 优势明显，同时成本和延迟更高。

# 11. 项目目录与工程组织

```text
flowpay-agentic-rag/
├── README.md
├── docs/                         # 教程文章 / 架构说明
├── data/
│   ├── knowledge/
│   │   ├── business_rules/       # D1a
│   │   ├── api_docs/             # D1b
│   │   ├── troubleshooting/      # D2
│   │   ├── release_notes/        # D3
│   │   └── support_cases/        # D4
│   ├── generated/canonical/
│   │   ├── flowpay.sqlite        # D5～D7，同一快照
│   │   ├── runtime/              # D8
│   │   ├── audit/                # Agent 不可见
│   │   └── manifest.json
│   └── eval/                     # 发布视图，隐藏 Test GT
├── generators/
│   ├── ground_truth/
│   ├── documents/
│   ├── sql/
│   ├── runtime/
│   └── eval/
├── ingestion/
│   ├── chunking.py
│   ├── embeddings.py
│   └── index.py
├── tools/
│   ├── document_tools.py
│   ├── account_tools.py
│   ├── payment_tools.py
│   ├── webhook_tools.py
│   └── runtime_tools.py
├── agents/
│   ├── naive_rag.py
│   ├── agentic_rag.py
│   └── prompts.py
└── evaluation/
    ├── run_benchmark.py
    ├── metrics.py
    └── reports/
```

工程上建议保持“数据生成”和“Agent 实现”解耦。只要数据接口契约不变，后续可以替换 Vector DB、LLM、Agent Framework，而不需要重做业务世界。

# 12. 实施顺序、验收标准与风险控制

## 12.1 推荐实施顺序

| 顺序 | 工作项 | 完成标志 |
| --- | --- | --- |
| 1 | 业务规则冻结 | 确定套餐、API Version、错误码、状态机、Webhook 重试、Rate Limit 等核心规则。 |
| 2 | 100 份 Published 文档冻结 | 16 Rules + 34 API + 24 Troubleshooting + 10 Release + 16 Cases。 |
| 3 | 系统、数据库与 Tool Contract | 冻结 Python + SQLite 模拟器、D5～D8 Schema 和 9 个 typed tools。 |
| 4 | Benchmark 设计冻结 | 在生成数据前完成 300 条问题、Ground Truth Assertions、Evidence Contracts 与 60/240 Family 切分。 |
| 5 | Scenario 编译与数据生成 | 用 Scenario Commands + 固定种子背景流量运行规则系统，自然沉淀 SQL / Runtime。 |
| 6 | 索引、工具与证据校验 | 完成 Vector Index、只读 tools，并解析 300 条 Evidence Contract。 |
| 7 | Naive RAG Baseline | 建立固定 Top-K 检索与答案生成。 |
| 8 | Agentic RAG | 加入 Tool Selection、Query Rewrite、Multi-hop、Stop Decision。 |
| 9 | 评测与报告 | 统一跑 Benchmark，输出按问题类型拆分的效果、成本和延迟。 |

## 12.2 数据层验收标准

- 八个数据层全部存在，100 份 Published 文档数量固定，D5～D8 均有明确 schema、生成命令和可追溯证据。
- 所有跨源问题可以通过稳定 ID 追踪到 ground truth，禁止依赖人工记忆判答案。
- 文档中的套餐、版本、错误码等规则与 SQL / Runtime 状态不出现无意冲突。
- 有意冲突必须带时间、版本或 authority 元数据，并可通过规则确定正确来源。
- SQL 数据支持精确查询与关联，Runtime Tool 支持按 account/request/event/service 查询。
- Vector DB 中不存放需要精确统计或实时读取的业务记录副本作为主数据源。

## 12.3 Agent 层验收标准

- Agent 可以只调用一个 Retriever 回答简单问题。
- Agent 可以根据已有证据主动进行第二次/第三次检索，而不是固定调用次数。
- Agent 可以在 Vector、SQL 和 Runtime Tool 之间选择正确来源。
- Agent 能识别“用户猜测不正确”的情况并通过证据反驳。
- Agent 能处理 API Version / 时间有效性，不默认最新文档总是适用于旧账户。
- Agent 能在证据充分后停止，防止无限循环与无意义 Tool Call。

## 12.4 主要风险与控制

| 风险 | 表现 | 控制方案 |
| --- | --- | --- |
| Synthetic 数据过于模板化 | Embedding 检索近乎关键词匹配 | LLM 改写 + 多语言风格 + Distractor + 相似错误 |
| 事实不一致 | Docs、SQL、Logs 对同一事件说法矛盾 | Single Source of Truth + 自动一致性校验 |
| Agent 过度调用工具 | 成本高、轨迹冗长 | 最大步数、信息增益约束、重复调用检测 |
| 数据源边界模糊 | 所有问题都能靠 Vector DB 解决 | 结构化与动态状态不文本化为主检索数据 |
| Benchmark 泄漏 | Question 与 Ticket/Docs 语言高度一致 | 生成问答时做独立 paraphrase，并隔离 eval seeds |
| 评测只看最终答案 | Agent 碰巧猜对也得高分 | 同时评 Tool、Evidence、Hop、Citation、Cost |

# 13. 最终项目定义

> 最终定义  FlowPay Agentic RAG 教程项目是一套围绕虚拟支付基础设施 SaaS 构建的异构检索与推理环境。它包含 5 个非结构化知识语料集合（归入 D1～D4）、3 类结构化业务数据和 1 类动态运行数据，共 8 个数据层、9 个逻辑工具；300 条问题与 Evidence Contract 先冻结，再由确定性规则系统产生可验证事实，用于比较固定检索式 RAG 与 Agent-controlled Retrieval 的效果与成本。

## 13.1 一页式摘要

| 维度 | 规划 |
| --- | --- |
| 虚拟产品 | FlowPay，Developer-first Payment Infrastructure |
| 业务模块 | Payments、Refunds、Customers、Subscriptions、Invoices、Webhooks、Developer Platform、Operations |
| 数据种类 | 8 种：D1～D8 |
| 知识数据 | D1 Published Rules + API Docs、D2 Troubleshooting、D3 Release Notes、D4 Support Cases；共 100 份 |
| SQL 数据 | D5 Account、D6 Payment Business、D7 Webhook Config |
| 动态数据 | D8 Runtime Observability |
| Vector 规模 | 100 份原始文档，chunk 数由索引策略确定 |
| 业务记录规模 | 数万行 SQL / Runtime 记录 |
| Benchmark | 恰好 300 条；60 Dev / 240 Test；75 个 Scenario Family |
| 核心 Agent 能力 | Tool Selection、Query Planning、Iterative Retrieval、Evidence Reflection、Stop Decision |
| 核心对照 | Naive RAG vs Agentic RAG，同数据、同问题、同评价口径 |

## 13.2 下一步应产出的设计物

1. FlowPay 业务规则表：套餐、错误码、API Version、状态机与 Webhook 重试规则。

2. 确定性模拟系统设计：固定时钟、命令流、状态机、Event Journal 与投影。

3. SQLite / Runtime 数据模型与生成、场景编译、回放规范。

4. 300 条 Benchmark Blueprint、Evidence Contract、60/240 Family 切分与覆盖矩阵。

5. 9 个 typed Agent Tool Contract：每个 Tool 的输入、输出、错误处理和可观测字段。

以上设计已分别落地在 `docs/01_system` 与 `docs/02_benchmark`，实现阶段必须遵守这些 V1.0 契约。

— End of Planning Document —
