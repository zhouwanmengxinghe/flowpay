# FlowPay 业务规则总表

> 文档性质：Canonical Business Rules / Single Source of Truth  
> 文档版本：V1.0  
> 适用项目：FlowPay Agentic RAG 教程与 Synthetic Benchmark  
> 是否进入向量库：否  
> 下游产物：Published Business Rules、API/Product Docs、Troubleshooting、Release Notes、Support Cases、结构化数据与 Benchmark

## 1. 文档目的

本文件定义 FlowPay V1 业务世界中稳定、可计算、可验证的事实和约束。所有公开知识文档、历史案例和后续结构化数据都必须由本文件派生，不得自行创造与本文件冲突的产品行为。

本文件可以包含内部规则编号、生成提示和验证约束，因此不直接进入向量库。面向 Agent 检索的规则应改写为独立的 Published Business Rules 文档，并保留对应的 `rule_ids`。

### 1.1 规则解释优先级

出现表面冲突时，按以下顺序判断：

1. 先检查环境、账户地区、套餐、功能开关、资源当前状态等适用条件。
2. 再检查请求使用的 API Version 和规则生效时间。
3. 在适用条件相同的情况下，较新的有效规则覆盖旧规则。
4. Support Case 中的用户描述和中间判断不构成正式规则。
5. 无法通过上述条件消解的冲突视为数据缺陷，禁止进入发布语料。

### 1.2 V1 复杂度边界

FlowPay V1 只覆盖足以支撑约 100 份向量知识文档的业务复杂度：

- 3 个商户套餐。
- 3 个服务地区。
- 2 个运行环境。
- 4 个 API Version。
- 5 个主要业务对象和 Webhook 事件体系。
- 18 个标准错误码。
- 一套有限状态机、版本迁移规则和可控例外。

V1 不覆盖银行卡网络细节、争议与拒付、税务、平台分账、多方资金托管、真实清算、PCI 全流程和机器学习风控模型。

---

## 2. 产品、角色与租户边界

### 2.1 产品定义

FlowPay 是面向互联网公司和开发者的在线支付基础设施平台。商户通过 API 完成一次性收款、退款、周期订阅扣费和 Webhook 通知，并通过账户、套餐、API Key、调用额度和运行状态管理接入。

### 2.2 核心角色

- **Merchant Account**：接入 FlowPay 的公司，是权限、套餐、版本和业务数据的租户边界。
- **Developer**：代表 Merchant 调用 API、配置 Webhook 和排查故障。
- **End Customer**：向 Merchant 付款或订阅 Merchant 服务的终端用户。
- **FlowPay Platform**：处理 API、支付状态、账单和事件投递的平台。

### 2.3 租户隔离规则

- `RULE-TENANT-001`：Customer、Payment、Refund、Subscription、Invoice、Webhook Endpoint 和 Event 均归属于唯一 Account。
- `RULE-TENANT-002`：Account A 的 API Key 不得读取或修改 Account B 的资源。
- `RULE-TENANT-003`：跨账户访问统一返回资源不可见，不透露目标资源是否存在。
- `RULE-TENANT-004`：Sandbox 与 Production 中的资源相互隔离；即使 ID 文本相同，也视为不同资源。

---

## 3. 环境、地区与货币

### 3.1 运行环境

FlowPay 只有两个环境：

- `sandbox`：用于测试，数据和资金均为模拟。
- `production`：用于真实业务模拟，必须完成生产启用。

规则：

- `RULE-ENV-001`：Sandbox Key 只能访问 Sandbox 资源；Production Key 只能访问 Production 资源。
- `RULE-ENV-002`：Account 创建后立即获得 Sandbox 权限。
- `RULE-ENV-003`：Production 必须经过 `production_enabled=true` 后才能创建 Production Key。
- `RULE-ENV-004`：Sandbox 事件不能投递至仅标记为 Production 的 Webhook Endpoint，反之亦然。
- `RULE-ENV-005`：环境不匹配返回 `FP-4012`。

### 3.2 服务地区

FlowPay V1 支持：

- `NA`：北美。
- `EU`：欧洲。
- `APAC`：亚太。

一个 Account 只有一个主地区。V1 不支持跨地区复制或迁移。

- `RULE-REGION-001`：地区影响可用币种和部分功能，但不改变资源 ID 规则。
- `RULE-REGION-002`：Account 主地区创建后不可通过公开 API 修改。
- `RULE-REGION-003`：`instant_refund` 仅在 NA 和 EU 可用。

### 3.3 币种与金额

支持币种：

- NA：USD、CAD。
- EU：EUR、GBP。
- APAC：SGD、JPY、AUD。

金额使用最小货币单位的整数表示；JPY 不使用小数单位。

- `RULE-MONEY-001`：Payment 最小金额为等值 50 个最小货币单位。
- `RULE-MONEY-002`：Payment 最大金额为 100,000,000 个最小货币单位。
- `RULE-MONEY-003`：Refund 币种必须与原 Payment 相同。
- `RULE-MONEY-004`：所有成功 Refund 的累计金额不得超过原 Payment 金额。

---

## 4. 商户套餐与功能权限

### 4.1 套餐定义

FlowPay V1 有三个套餐：

| 套餐 | 适用对象 | 持续请求上限 | 短时突发上限 | Webhook Endpoint 上限 | 数据查询保留期 |
| --- | --- | ---: | ---: | ---: | ---: |
| Starter | 小型项目 | 300 req/min | 450 req/min，最多 10 秒 | 2 | 7 天 |
| Growth | 成长型业务 | 1,200 req/min | 1,500 req/min，最多 20 秒 | 5 | 30 天 |
| Scale | 高流量业务 | 5,000 req/min | 6,000 req/min，最多 30 秒 | 15 | 90 天 |

### 4.2 功能矩阵

| 功能 | Starter | Growth | Scale | 额外条件 |
| --- | --- | --- | --- | --- |
| 一次性支付 | 是 | 是 | 是 | Production 需启用 |
| 全额退款 | 是 | 是 | 是 | Payment 可退款 |
| 部分退款 | 否 | 是 | 是 | Payment 可退款 |
| 订阅与账单 | 否 | 是 | 是 | `subscriptions` 开关开启 |
| Webhook | 是 | 是 | 是 | 不超过 Endpoint 上限 |
| 自定义 Webhook 重试 | 否 | 否 | 是 | 只能在允许范围内调整 |
| Instant Refund | 否 | 否 | 是 | 仅 NA、EU 且开关开启 |
| 版本冻结延期 | 否 | 否 | 是 | 最多延期 90 天 |

规则：

- `RULE-PLAN-001`：套餐决定默认功能上限，功能开关不能越过套餐硬限制。
- `RULE-PLAN-002`：套餐升级立即生效；降级在当前计费周期结束时生效。
- `RULE-PLAN-003`：降级不会自动删除超额 Webhook Endpoint，但仅保留按创建时间最早的可用数量，其他 Endpoint 进入 `restricted`。
- `RULE-PLAN-004`：访问套餐不支持的功能返回 `FP-4031`。
- `RULE-PLAN-005`：Rate Limit 依据请求发生时已生效的套餐计算，而不是依据套餐变更申请时间。

---

## 5. API Key、认证与权限

### 5.1 Key 类型和状态

Key 类型：

- Sandbox Secret Key：前缀 `sk_test_`。
- Production Secret Key：前缀 `sk_live_`。

Key 状态：`active`、`expiring`、`revoked`。

- `RULE-AUTH-001`：请求必须使用有效 Secret Key；缺失、格式错误、未知或已撤销的 Key 返回 `FP-4011`。
- `RULE-AUTH-002`：Key 只属于一个 Account 和一个环境。
- `RULE-AUTH-003`：Key 轮换时旧 Key 可处于最长 24 小时的 `expiring` 状态，期间仍可用。
- `RULE-AUTH-004`：撤销即时生效，且不可恢复。
- `RULE-AUTH-005`：V1 不实现细粒度 OAuth Scope；所有有效 Secret Key 具有所属环境的完整 API 权限。

### 5.2 Production 启用

- `RULE-AUTH-006`：未启用 Production 的 Account 无法创建 `sk_live_` Key。
- `RULE-AUTH-007`：Production 被暂停时，现有 Production Key 保留但请求返回 `FP-4032`。
- `RULE-AUTH-008`：Sandbox 不受 Production 暂停影响。

---

## 6. API Version 体系

### 6.1 版本选择

FlowPay 使用日期格式版本：

- `2025-10-01`
- `2026-01-15`
- `2026-04-01`
- `2026-07-01`

规则：

- `RULE-VERSION-001`：Account 有一个默认 API Version。
- `RULE-VERSION-002`：请求可通过 `FlowPay-Version` Header 临时指定该请求版本。
- `RULE-VERSION-003`：Header 未提供时使用 Account 默认版本。
- `RULE-VERSION-004`：不支持的版本返回 `FP-4002`，不会自动回退。
- `RULE-VERSION-005`：资源内部状态不因读取版本不同而改变，但字段名称、事件名称和默认行为可以变化。

### 6.2 版本变化时间线

#### 2025-10-01：基础版本

- Payment 创建参数使用 `source`。
- Payment 成功事件名为 `payment.completed`。
- Webhook 签名 Header 为 `X-FlowPay-Signature`。
- Refund 默认异步处理。

#### 2026-01-15

- 新增幂等冲突详情字段 `conflict_request_id`。
- 新增 Payment 状态 `requires_action`。
- 新增 `payment.action_required` 事件。
- 旧行为继续兼容 `2025-10-01`。

#### 2026-04-01

- Payment 创建参数由 `source` 迁移为 `payment_method`。
- 在此版本中，`source` 仍可使用，但响应包含弃用提示。
- Webhook 签名 Header 改为 `FlowPay-Signature`；旧 Header 不再发送。
- Payment 成功事件仍为 `payment.completed`。

#### 2026-07-01

- `source` 参数被移除，使用时返回 `FP-4003`。
- Payment 成功事件由 `payment.completed` 更名为 `payment.succeeded`。
- Refund 创建默认行为由异步改为同步确认：符合条件时直接返回 `succeeded`，否则仍返回 `pending`。
- Rate Limit 响应新增 `FlowPay-RateLimit-Reset` Header。

### 6.3 版本支持策略

- `RULE-VERSION-006`：每个版本至少支持 12 个月。
- `RULE-VERSION-007`：版本废弃必须先发布迁移指南。
- `RULE-VERSION-008`：Scale 套餐可以申请最多 90 天的版本冻结延期；延期不改变新建 Account 可选择的版本。
- `RULE-VERSION-009`：文档回答必须以请求实际版本为准，不能默认最新版本适用于所有 Account。

---

## 7. 请求、幂等与 Rate Limit

### 7.1 Request ID

- `RULE-REQ-001`：每个到达 API 网关的请求都会产生唯一 `request_id`，前缀为 `req_`。
- `RULE-REQ-002`：认证前即被拒绝的请求仍然具有 Request ID。
- `RULE-REQ-003`：Request ID 可用于查询请求日志，但不等同于资源 ID。

### 7.2 幂等规则

- `RULE-IDEMP-001`：创建 Payment、Refund 和 Subscription 的 POST 请求支持 `Idempotency-Key`。
- `RULE-IDEMP-002`：幂等键作用域为 Account、环境和 API Endpoint 的组合。
- `RULE-IDEMP-003`：幂等结果保留 24 小时。
- `RULE-IDEMP-004`：同一幂等键和完全相同参数返回第一次请求的结果，不创建新资源。
- `RULE-IDEMP-005`：同一幂等键使用不同参数返回 `FP-4091`。
- `RULE-IDEMP-006`：超过 24 小时后复用相同幂等键视为新请求。

### 7.3 Rate Limit

- `RULE-RATE-001`：限流以 Account + 环境为统计边界。
- `RULE-RATE-002`：Sandbox 使用固定 120 req/min、180 burst，不受套餐影响。
- `RULE-RATE-003`：Production 使用当前已生效套餐的持续和突发上限。
- `RULE-RATE-004`：超过限制返回 HTTP 429 和 `FP-4291`。
- `RULE-RATE-005`：429 不代表套餐发生变化；必须结合 Account 套餐和 Runtime Usage 判断根因。
- `RULE-RATE-006`：Webhook 投递不计入 Merchant API Rate Limit。
- `RULE-RATE-007`：重试 429 应使用指数退避，并优先遵守响应中的重试时间提示。

---

## 8. Customer 规则

Customer 是 Merchant 在 FlowPay 中保存的终端客户档案。

- `RULE-CUSTOMER-001`：Customer 只属于一个 Account 和一个环境。
- `RULE-CUSTOMER-002`：Customer 可处于 `active` 或 `deleted`。
- `RULE-CUSTOMER-003`：删除采用软删除；已存在的 Payment、Refund、Subscription 和 Invoice 仍保留 Customer ID。
- `RULE-CUSTOMER-004`：已删除 Customer 不能创建新 Payment 或 Subscription。
- `RULE-CUSTOMER-005`：Customer Email 不是唯一键，不能用它替代 Customer ID 做精确关联。

---

## 9. Payment 规则

### 9.1 Payment 状态

状态集合：

- `requires_action`
- `processing`
- `succeeded`
- `failed`
- `canceled`

状态流转：

```text
create
├── requires_action ── confirm ──> processing
│          └── expire/cancel ────> canceled
└── processing
       ├──> succeeded
       └──> failed
```

- `RULE-PAY-001`：`succeeded`、`failed` 和 `canceled` 是终态。
- `RULE-PAY-002`：`failed` Payment 不会恢复为 `processing` 或 `succeeded`；重试必须创建新 Payment。
- `RULE-PAY-003`：只有 `requires_action` 可以由 Merchant 主动取消。
- `RULE-PAY-004`：只有 `succeeded` Payment 可以创建 Refund。
- `RULE-PAY-005`：`requires_action` 只适用于 API Version `2026-01-15` 及以后版本；旧版本将同类场景表现为 `failed` 和 `FP-4023`。
- `RULE-PAY-006`：Payment 必须引用同 Account、同环境且为 `active` 的 Customer。
- `RULE-PAY-007`：Payment 成功后产生一个成功事件；事件名称由请求 API Version 决定。

### 9.2 Payment 失败分类

- 支付方式被拒绝：`FP-4021`。
- 资金不足：`FP-4022`。
- 需要用户进一步操作：旧版本为 `FP-4023`，新版本进入 `requires_action`。
- 支付方式已过期：`FP-4024`。
- 参数或状态不合法：使用 400/422 类错误，不创建成功 Payment。

---

## 10. Refund 规则

### 10.1 Refund 状态

状态集合：`pending`、`succeeded`、`failed`、`canceled`。

```text
create
├──> succeeded
└──> pending
       ├──> succeeded
       ├──> failed
       └──> canceled
```

- `RULE-REFUND-001`：只有 `succeeded` Payment 可以退款。
- `RULE-REFUND-002`：Starter 只支持对剩余可退金额进行一次全额退款。
- `RULE-REFUND-003`：Growth 和 Scale 支持多次部分退款。
- `RULE-REFUND-004`：所有 `succeeded` 和 `pending` Refund 的金额之和不得超过 Payment 剩余可退金额。
- `RULE-REFUND-005`：Payment 成功超过 180 天后不可退款，返回 `FP-4222`。
- `RULE-REFUND-006`：`pending` Refund 暂时占用可退款额度；进入 `failed` 或 `canceled` 后，该笔金额重新释放。
- `RULE-REFUND-007`：符合 Scale、NA/EU、功能开关开启且金额不超过 100,000 最小单位时，可以使用 Instant Refund。
- `RULE-REFUND-008`：对非 succeeded Payment 发起退款返回 `FP-4221`。

---

## 11. Subscription 与 Invoice 规则

### 11.1 Subscription

状态集合：`trialing`、`active`、`past_due`、`canceled`。

```text
trialing ── trial ends ──> active
active ── invoice payment fails ──> past_due
past_due ── retry succeeds ───────> active
past_due ── retries exhausted ────> canceled
trialing/active/past_due ─────────> canceled
```

- `RULE-SUB-001`：Subscription 仅对 Growth 和 Scale 开放。
- `RULE-SUB-002`：一个 Subscription 只关联一个 Customer 和一种币种。
- `RULE-SUB-003`：试用期只能在创建时设置，范围为 1～30 天。
- `RULE-SUB-004`：主动取消默认为周期末生效；显式传入立即取消时才立即进入 `canceled`。
- `RULE-SUB-005`：`canceled` 是终态，恢复订阅必须新建 Subscription。
- `RULE-SUB-006`：Subscription 创建后不能更换 Customer 或币种；需要改变时必须取消原 Subscription 并创建新资源。

### 11.2 Invoice

状态集合：`draft`、`open`、`paid`、`uncollectible`、`void`。

- `RULE-INVOICE-001`：每个订阅周期生成一个 Invoice。
- `RULE-INVOICE-002`：Invoice 从 `draft` 定稿后进入 `open`，并创建 Payment。
- `RULE-INVOICE-003`：关联 Payment 成功后 Invoice 进入 `paid`。
- `RULE-INVOICE-004`：首次扣费失败后，在第 1、3、7 天重试，共 3 次重试。
- `RULE-INVOICE-005`：首次失败使 Subscription 进入 `past_due`；任一重试成功则恢复 `active`。
- `RULE-INVOICE-006`：全部重试失败后 Invoice 进入 `uncollectible`，Subscription 进入 `canceled`。
- `RULE-INVOICE-007`：`paid` Invoice 不可 `void`。
- `RULE-INVOICE-008`：`draft` 或 `open` Invoice 可以进入 `void`；`paid`、`uncollectible` 和 `void` 不能通过 void 操作改变状态。

---

## 12. Webhook 规则

### 12.1 Endpoint 状态

状态集合：`enabled`、`disabled`、`restricted`。

- `RULE-WEBHOOK-001`：Endpoint 属于唯一 Account 和环境。
- `RULE-WEBHOOK-002`：只有 `enabled` Endpoint 接收新事件。
- `RULE-WEBHOOK-003`：`disabled` Endpoint 不产生投递记录。
- `RULE-WEBHOOK-004`：`restricted` 表示受套餐降级影响，不接收新事件，但保留历史投递记录。
- `RULE-WEBHOOK-005`：Endpoint 必须显式订阅事件类型；未订阅不产生投递。

### 12.2 标准事件

- `payment.action_required`
- `payment.processing`
- `payment.completed`（`2025-10-01` 至 `2026-04-01`）
- `payment.succeeded`（`2026-07-01` 起）
- `payment.failed`
- `refund.succeeded`
- `refund.failed`
- `subscription.created`
- `subscription.updated`
- `subscription.canceled`
- `invoice.created`
- `invoice.paid`
- `invoice.payment_failed`

### 12.3 投递成功与重试

- `RULE-WEBHOOK-006`：HTTP 200～299 视为投递成功。
- `RULE-WEBHOOK-007`：HTTP 3xx 不跟随重定向，视为失败。
- `RULE-WEBHOOK-008`：HTTP 4xx 和 5xx 均进入重试；HTTP 410 是例外，会立即禁用 Endpoint。
- `RULE-WEBHOOK-009`：默认在首次失败后的 1 分钟、5 分钟、30 分钟、2 小时、8 小时和 24 小时重试。
- `RULE-WEBHOOK-010`：完成 6 次重试仍失败后，Delivery 进入 `exhausted`。
- `RULE-WEBHOOK-011`：Scale 可自定义重试间隔，但最多 8 次且总窗口不得超过 72 小时。
- `RULE-WEBHOOK-012`：事件按“至少一次”语义投递，Merchant 必须按 `event_id` 去重。

### 12.4 签名

- `RULE-WEBHOOK-013`：签名使用 Endpoint 当前 Signing Secret 生成。
- `RULE-WEBHOOK-014`：Secret 轮换后，旧 Secret 保持 24 小时有效。
- `RULE-WEBHOOK-015`：签名时间戳默认容差为 5 分钟。
- `RULE-WEBHOOK-016`：签名 Header 名称由事件采用的 API Version 决定，见版本时间线。
- `RULE-WEBHOOK-017`：由公开 API 操作产生的事件沿用该请求的 API Version；由订阅周期任务等平台内部操作产生的事件使用 Account 当时的默认 API Version。
- `RULE-WEBHOOK-018`：Secret 轮换后新投递立即使用新 Secret；重试会使用重试发生时的当前 Secret 重新签名，旧 Secret 仅在 24 小时兼容窗口内继续有效。

---

## 13. 错误码目录

| 错误码 | HTTP | 标准含义 | 主要适用域 |
| --- | ---: | --- | --- |
| FP-4001 | 400 | Invalid Request Parameters | 通用 API |
| FP-4002 | 400 | Unsupported API Version | 版本 |
| FP-4003 | 400 | Removed Parameter | 版本迁移 |
| FP-4011 | 401 | Invalid API Key | 认证 |
| FP-4012 | 401 | Environment Mismatch | 环境 |
| FP-4021 | 402 | Payment Method Declined | Payment |
| FP-4022 | 402 | Insufficient Funds | Payment |
| FP-4023 | 402 | Customer Action Required | Payment / 旧版本 |
| FP-4024 | 402 | Payment Method Expired | Payment |
| FP-4031 | 403 | Feature Unavailable for Plan | 套餐 |
| FP-4032 | 403 | Production Access Suspended | 账户 |
| FP-4041 | 404 | Resource Not Found or Not Visible | 通用资源 |
| FP-4091 | 409 | Duplicate Idempotency Key with Different Parameters | 幂等 |
| FP-4221 | 422 | Invalid Payment State | Payment / Refund |
| FP-4222 | 422 | Refund Window Expired | Refund |
| FP-4291 | 429 | Rate Limit Exceeded | 限流 |
| FP-5001 | 500 | Internal Processing Error | 平台内部 |
| FP-5031 | 503 | Service Temporarily Degraded | 平台服务 |

约束：

- `RULE-ERROR-001`：错误码含义在同一 API Version 内必须唯一。
- `RULE-ERROR-002`：HTTP 状态相同不代表根因相同，排障文档必须同时依据错误码和上下文。
- `RULE-ERROR-003`：`FP-5001` 和 `FP-5031` 不应被文档直接归因于 Merchant 配置。
- `RULE-ERROR-004`：Support Case 可以包含对错误码的错误解释，但最终根因必须可由证据纠正。

---

## 14. 业务事件与知识边界

### 14.1 正式知识可以回答的内容

Published Rules、API Docs、Troubleshooting 和 Release Notes 可以回答：

- 产品规则是什么。
- 某错误码通常表示什么。
- 某状态允许哪些操作。
- 某 API Version 的参数和事件名称是什么。
- 应该按照什么步骤诊断。

### 14.2 正式知识不能单独断言的内容

仅凭 Markdown 知识文档不能确定：

- 某 Account 当前购买了什么套餐。
- 某 API Key 当前是否有效。
- 某 Payment、Refund 或 Subscription 当前是什么状态。
- 某 Endpoint 是否启用或订阅了某事件。
- 某次请求是否超过 Rate Limit。
- 平台在某个时间点是否发生服务降级。

这类结论必须在后续系统中查询结构化业务状态或运行时状态。知识文档只能说明判断规则和查询方法。

---

## 15. 有意冲突与干扰项规则

允许构造以下表面冲突：

- 不同 API Version 对同一字段、事件名称或默认行为的描述不同。
- Support Case 中用户猜测与最终根因不同。
- 相同 HTTP 状态对应多个错误码和多个原因。
- 同一症状可能由套餐、配置、请求参数或平台事件导致。
- 旧 Release Note 被新 Release Note 的规则替代。

禁止构造以下不可消解冲突：

- 同一版本、同一条件下存在两个不同硬上限。
- 状态机出现未定义的逆向跳转。
- 官方规则和适用版本 API 文档在相同条件下结论不同。
- Support Case 的最终根因违反 Canonical Rule。
- 文档用静态知识断言某个动态事件一定已经发生。

---

## 16. 入库知识规模约束

本项目目标是最终形成约 100 份进入向量库的 Markdown 文档。Canonical 文件、生成规范、Benchmark 答案和工程说明不计入这 100 份。

| 入库知识类型 | 文档数 | 复杂度职责 |
| --- | ---: | --- |
| Published Business Rules | 16 | 权威业务规则、状态机、套餐与策略 |
| API / Product Docs | 34 | 接口契约、参数、对象和开发者操作 |
| Troubleshooting / Error Docs | 24 | 错误码、症状、诊断与处理 |
| Release Notes / Migration Guides | 10 | 版本变化、废弃、迁移和时间冲突 |
| Support Cases | 16 | 相似案例、噪声、错误假设和跨源诊断 |
| **合计** | **100** | — |

该规模应产生约 600～1,000 个 chunks。不得通过重复改写同一规则机械凑数；每份文档必须承担独立检索意图或评测作用。

---

## 17. Canonical 变更流程

1. 新规则必须分配稳定的 `rule_id`。
2. 修改规则时必须说明受影响的 API Version、文档类型和下游文档。
3. 修改状态机、套餐上限、错误码或版本时间线时，必须重新运行一致性检查。
4. Published 文档必须记录其依赖的 `rule_ids`。
5. 已用于 Benchmark 的规则不得静默修改；必须同步更新 Ground Truth 和受影响样本。
6. 任何超出 V1 非目标的新业务模块，都需要先评估是否突破 100 份入库文档的复杂度预算。
