# FlowPay 项目目录与文件说明

本文用非技术化语言说明 FlowPay 项目中每个主要文件夹和文件的用途，以及哪些内容可以提供给 Agent、哪些内容必须隐藏。

最简单的理解是：

- `data/`：真正的数据成品；
- `benchmark/`：用来考试的题目、标准答案和审计结果；
- `docs/`：给人看的设计说明；
- `src/`：生成数据、查询数据和运行评测的程序；
- `scripts/`：生成设计和报告的构建脚本；
- `tests/`：防止程序和数据被改坏的自动检查。

## 1. 项目根目录

### `FlowPay_Agentic_RAG_总体规划文档.md`

最初的总体规划，说明整个项目为什么做、准备哪些知识和结构化数据、如何设计 300 道题以及如何进行后续评测。

### `README.md`

项目操作手册。里面记录编译场景、运行模拟器、构建知识索引、解析证据、运行审计和冻结 Dataset V1 的命令。

### `pyproject.toml`

Python 项目配置，定义项目名称、版本、Python 包路径等基础信息。

### `.DS_Store`

macOS 自动生成的目录显示信息，与 FlowPay 数据和程序无关，可以忽略。

## 2. `data/`：真正的数据成品

### 2.1 `data/knowledge/`

这里保存准备放入业务 RAG 的 100 份 Published Knowledge，是 Agent 可以检索的静态知识。

#### `business_rules/`：16 份业务规则

包括套餐权限、环境隔离、支付状态机、退款资格、Subscription 生命周期、Invoice 规则和 Webhook 规则。

这是知识库中优先级最高的一类。其他文档不能推翻这里的正式规则。可以把它理解为 FlowPay 的法律和公司制度。

#### `api_docs/`：34 份 API 与产品文档

说明具体接口、参数、对象字段、错误码和版本行为，例如：

- 如何创建、查询、确认或取消 Payment；
- 如何创建 Refund、Subscription 和 Webhook Endpoint；
- Webhook 如何验签；
- 幂等键和限流响应头如何使用。

可以把它理解为开发者产品说明书。

#### `troubleshooting/`：24 份排障文档

说明遇到错误或异常时应该检查什么、可能是什么原因以及如何处理，例如：

- `FP-4031` 为什么出现；
- 支付失败如何区分原因；
- Webhook 没有收到如何排查；
- 500 和 503 有什么区别。

可以把它理解为客服和技术支持的排障手册。它必须遵守业务规则，不能覆盖正式规则。

#### `release_notes/`：10 份版本文档

记录不同 API 版本之间发生的变化以及迁移方式，例如参数废弃、Webhook 签名请求头变化和 Payment 事件名称变化。

可以把它理解为 FlowPay 的版本历史。

#### `support_cases/`：16 份案例

记录过去发生过的典型问题和解决过程。案例可以用于类比，但不能因为案例相似就直接认定当前用户也是相同原因。

可以把它理解为过去的客服工单案例库。

### 2.2 `data/generated/canonical/`

这里是确定性模拟器生成的虚拟 FlowPay 公司现场。

#### `flowpay.sqlite`

核心结构化数据库，保存：

- Account；
- Customer；
- Payment；
- Refund；
- Subscription；
- Invoice；
- Webhook Endpoint、Event 和 Delivery；
- API Key；
- Feature Flag；
- 套餐变更记录。

Agent 不能执行任意 SQL，只能通过设计好的只读类型化工具访问。

#### `runtime/api_requests.jsonl`

保存每次 API 请求的时间、接口、HTTP 状态码、错误码和脱敏参数，用来还原某次请求实际发生了什么。

#### `runtime/service_incidents.jsonl`

保存平台服务异常，例如某个地区的 Payments 服务出现 503。

#### `runtime/usage_buckets.jsonl`

保存每分钟请求量、成功量、错误量和限流量，用于分析 Rate Limit 和流量问题。

#### `runtime/webhook_delivery_attempts.jsonl`

保存 Webhook 每一次投递、返回状态、失败原因和重试过程。

#### `audit/event_journal.jsonl`

模拟器产生的完整事件流水，相当于上帝视角 Ground Truth。它不能提供给 Agent，也不能作为 Agent 可调用的数据源。

#### `audit/invariant_report.json`

记录数据一致性检查结果，包括金额、状态机、租户隔离、对象引用和敏感信息检查。

#### `manifest.json`

这批 Canonical 数据的身份证，记录 Seed、冻结时间、设计版本、数据数量以及每个文件的 SHA-256。

### 2.3 `data/index/`

这里保存 100 份知识文档经过切分后的本地检索索引。

#### `knowledge_chunks.jsonl`

保存 809 个知识片段。每个片段都有稳定的 `doc:<doc_id>#<chunk_id>` Evidence ID。

原文档相当于一本书，Chunk 相当于可以单独检索的一段。

#### `index_manifest.json`

记录文档数量、Chunk 数量和索引文件哈希。

### 2.4 `data/releases/flowpay_dataset_v1/`

这里是最终的 Dataset V1 冻结发布包。

#### `release_manifest.json`

统一绑定组成 Dataset V1 的 169 个文件，记录每个文件的项目相对路径、字节数和 SHA-256。

#### `release_manifest.sha256`

记录 `release_manifest.json` 自身的校验值。

#### `README.md`

人类可读的 Dataset V1 发布说明，包括数据规模、质量门禁、可见性边界和重新生成命令。

该目录不复制大型数据库和日志，只负责证明哪些文件共同组成 FlowPay Dataset V1，以及这些文件有没有发生变化。

## 3. `benchmark/`：考试系统

### 3.1 `benchmark/design/`

这里是数据生成之前设计好的试卷、标准答案和证据要求。

#### `benchmark_blueprints.jsonl`

保存 300 道题的完整蓝图，包括：

- 用户开场问题；
- 多轮披露脚本；
- 隐藏标准答案；
- 必需文档；
- 必需查询工具；
- Evidence Selector；
- 禁止的错误结论。

这份文件不能提供给被测 Agent，否则相当于泄漏标准答案和资料位置。

#### `scenario_specs.yaml`

保存 75 个业务场景，例如退款失败、订阅被套餐限制、Invoice 重试和 Webhook 投递失败。

#### `entity_reservations.json`

预先保留 Account、Payment、Request 等 Benchmark 编号，防止生成背景数据时发生 ID 冲突。

#### `coverage_matrix.md`

检查 100 份文档、110 条规则、九个逻辑工具和所有查询操作是否都被题目覆盖。

#### `design_manifest.json`

记录设计文件数量、知识文档来源、生成器版本和所有设计文件哈希。

### 3.2 `benchmark/compiled/`

这里保存从 75 个 Scenario 编译出的模拟器执行命令。

#### `compiled_commands.jsonl`

保存 375 条模拟器命令。Scenario 是业务剧本，这些命令是模拟器实际执行的动作清单。

#### `compile_manifest.json`

记录命令数量、设计版本和编译结果哈希。

### 3.3 `benchmark/resolved/`

数据生成完成后，这里负责把每道题和实际证据对应起来。

#### `evidence_resolution.jsonl`

逐题记录最终对应的文档 Chunk、数据库记录、Runtime 日志和 Evidence ID。

#### `resolved_blueprints.jsonl`

在原 Blueprint 基础上补充实际 Evidence ID、实例轨迹和实例化答案。

#### `resolution_manifest.json`

记录 300 道题是否全部解析成功，以及解析文件哈希。

可以把整个目录理解为：在标准答案旁边附上完整证明材料。

## 4. `docs/`：人类说明文档

### 4.1 `docs/00_foundation/`

保存项目最基础的规范。

#### `FlowPay_业务规则总表.md`

110 条 Canonical Rule 的总来源。

#### `FlowPay_知识语料生成与约束规范.md`

规定哪些文档可以进入 RAG、文档权威级别、冲突处理方式和知识语料写作要求。

#### `FlowPay_项目目录与文件说明.md`

也就是本文，用人话解释整个工程目录。

### 4.2 `docs/01_system/`

保存系统和数据设计说明。

#### `FlowPay_数据生成场景编译与回放规范.md`

说明 Scenario 如何编译成命令、如何运行以及如何重放。

#### `FlowPay_确定性模拟系统设计.md`

说明为什么相同 Seed 可以生成完全相同的数据，以及模拟器如何保证可验证性。

### 4.3 `docs/02_benchmark/`

#### `FlowPay_300题Benchmark设计规范.md`

说明题型、单轮与多轮比例、证据要求和评测原则。这套题现在由仓库上层的
`scripts/benchmark/` 驱动，本工程不再自带评测器。

## 5. `src/flowpay_simulator/`：程序代码

本工程只负责造数据，因此这里只剩生成链路。

- `models.py`：内部数据模型；
- `engine.py`：模拟器主引擎；
- `recipes.py`：不同业务场景如何产生数据；
- `background.py`：生成普通背景流量，避免数据库里只有 Benchmark 目标记录；
- `compiler.py`：把 Scenario 编译成模拟器命令；
- `scenario_yaml.py`：读取和校验 YAML 场景；
- `storage.py`：写入 SQLite、Runtime、Audit 和 Manifest；
- `validation.py`：执行数据一致性检查；
- `cli.py`：命令行入口，只有 `compile` 与 `simulate` 两条；
- `simulated_user.py`：Benchmark 多轮题里按需回答追问的确定性模拟用户，
  由 `scripts/benchmark/simulated.py` 引用；
- `__init__.py`：Python Package 标记文件。

## 6. `scripts/`：构建脚本

### `build_benchmark_design.py`

从源场景定义生成 300 道 Blueprint、75 个 Scenario、实体预留表和覆盖矩阵。
产物已冻结入库，正常情况下不需要重跑。

## 7. `tests/`：自动质检

### `test_simulator.py`

检查数据生成是否确定、背景数据和 Benchmark 数据是否隔离。

### `test_compiler.py`

检查 75 个 Scenario、300 道题和编译结果是否完整。

## 8. Agent 可见性总结

### 可以进入业务 RAG

- `data/knowledge/` 下的 100 份 Published Markdown。

### 只能通过类型化工具访问

- `data/generated/canonical/flowpay.sqlite`；
- `data/generated/canonical/runtime/`。

### 必须对 Agent 隐藏

- `benchmark/design/` 中的标准答案和 Evidence Contract；
- `benchmark/resolved/` 中的解析答案与目标证据；
- `data/generated/canonical/audit/event_journal.jsonl`。

## 9. 一句话总结

`data/` 是成品，`benchmark/` 是试卷和证明材料，`docs/` 是说明书，`src/` 是生产线，
`scripts/` 是构建工具，`tests/` 是质检系统。评测系统本身在仓库上层的 `scripts/benchmark/`。
