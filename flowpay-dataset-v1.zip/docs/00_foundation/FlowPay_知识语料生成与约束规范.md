# FlowPay 知识语料生成与约束规范

> 文档性质：Corpus Authoring Contract  
> 文档版本：V1.0  
> 上游事实源：[FlowPay 业务规则总表](./FlowPay_业务规则总表.md)  
> 是否进入向量库：否  
> 目标：约束 100 份可检索 Markdown 知识文档的选题、结构、权威性、版本、生成和验收

## 1. 目标与适用范围

本规范用于生产 FlowPay Agentic RAG 的五类向量知识文档：

1. Published Business Rules。
2. API / Product Docs。
3. Troubleshooting / Error Docs。
4. Release Notes / Migration Guides。
5. Support Cases。

本规范不定义 SQL、运行时日志或 Mock API 数据，也不允许知识文档替代这些数据源回答账户当前状态、具体交易状态或实时平台状态。

---

## 2. 文档体系与数量预算

### 2.1 固定预算

| 类别 | 数量 | 权威等级 | 主要回答 |
| --- | ---: | ---: | --- |
| Published Business Rules | 16 | A | 平台允许什么、限制什么、状态如何变化 |
| API / Product Docs | 34 | A | 开发者如何调用、参数和响应是什么 |
| Troubleshooting / Error Docs | 24 | B | 某症状和错误应如何诊断、处理 |
| Release Notes / Migration Guides | 10 | A（限适用时间） | 哪些规则在何时、哪个版本发生变化 |
| Support Cases | 16 | C | 类似问题曾如何表现和定位 |
| **合计** | **100** | — | — |

允许在实施时上下浮动不超过 5 份，但最终应通过合并或拆分回到 `95～105` 份范围。每类数量变化都必须说明对 Benchmark 覆盖的影响。

### 2.2 复杂度设计原则

100 份文档不追求覆盖真实支付平台的全部能力，而要覆盖有限规则之间的组合：

- 套餐 × 功能权限。
- 环境 × API Key。
- API Version × 字段/事件/默认行为。
- Payment 状态 × Refund 操作。
- Subscription × Invoice × Payment。
- Webhook 配置 × 事件订阅 × 投递重试。
- 错误码 × 相似症状 × 多种潜在根因。

复杂度主要来自条件组合、多跳依赖、版本冲突和数据源边界，而不是来自增加业务模块。

---

## 3. 目录与文件命名

建议目录：

```text
data/knowledge/
├── business_rules/       # KB-BR-001 ～ KB-BR-016
├── api_docs/             # KB-API-001 ～ KB-API-034
├── troubleshooting/      # KB-TS-001 ～ KB-TS-024
├── release_notes/        # KB-REL-001 ～ KB-REL-010
└── support_cases/        # KB-CASE-001 ～ KB-CASE-016
```

文件命名使用：

```text
{doc_id}_{lower_snake_case_slug}.md
```

示例：

```text
KB-BR-004_rate_limit_policy.md
KB-API-012_create_a_payment.md
KB-TS-009_diagnose_fp_4291.md
KB-REL-007_migrate_to_2026_07_01.md
KB-CASE-011_webhook_signature_mismatch_after_upgrade.md
```

`doc_id` 一经发布不得复用。删除文档时保留 ID 墓碑记录。

---

## 4. 通用 Front Matter

所有入库 Markdown 必须以 YAML Front Matter 开头：

```yaml
---
doc_id: KB-BR-004
title: Rate Limit Policy
doc_type: business_rule
authority: official
product_areas: [developer_platform]
api_versions: [2025-10-01, 2026-01-15, 2026-04-01, 2026-07-01]
effective_from: 2025-10-01
effective_to: null
supersedes: []
rule_ids: [RULE-RATE-001, RULE-RATE-002]
related_docs: [KB-API-030, KB-TS-009]
indexing: include
language: zh-CN
---
```

### 4.1 必填字段

- `doc_id`：全局稳定文档 ID。
- `title`：人类可读标题。
- `doc_type`：`business_rule`、`api_doc`、`troubleshooting`、`release_note`、`migration_guide` 或 `support_case`。
- `authority`：`official`、`operational_guidance` 或 `historical_case`。
- `product_areas`：一个或多个产品域。
- `api_versions`：适用版本列表；与版本无关时写 `all_supported`。
- `effective_from`：生效日期。
- `rule_ids`：对应 Canonical Rule。
- `indexing`：入库文档固定为 `include`。
- `language`：第一版固定为 `zh-CN`。

### 4.2 条件字段

- `effective_to`：规则停止适用时填写。
- `supersedes`：替代旧文档时填写旧 `doc_id`。
- `related_docs`：仅引用真实存在的文档。
- `error_codes`：排障或案例涉及错误码时填写。
- `account_id`：只允许 Support Case 使用匿名化合成 Account ID。
- `case_status`：Support Case 使用 `resolved` 或 `closed_without_root_cause`。

---

## 5. 权威性与冲突处理

### 5.1 权威等级

- **A / official**：Published Business Rules、API Docs、Release Notes 和 Migration Guides。
- **B / operational_guidance**：Troubleshooting，提供诊断路径，不替代具体状态查询。
- **C / historical_case**：Support Cases，允许包含用户误判、过时做法和非普遍经验。

### 5.2 Agent 应用顺序

回答问题时，文档是否适用按以下条件共同决定：

```text
环境/套餐/地区等适用条件
        ↓
API Version 与 effective date
        ↓
authority
        ↓
具体内容是否直接支持结论
```

较高权威但版本不适用的文档，不能覆盖较低权威但适用于当前场景的证据。Support Case 不能单独证明平台正式规则。

### 5.3 允许出现的冲突

- 同一参数在不同版本中有不同名称。
- 同一成功事件在不同版本中有不同事件名。
- 用户在 Case 中认为是限流，但最终证据显示为服务降级。
- 旧 Migration Guide 中的过渡行为被新版移除。
- 多个错误产生相似的 401、403、422、429 或 503 症状。

每个有意冲突必须能通过 metadata 或正文中的明确条件消解。

---

## 6. Published Business Rules 编写规范

### 6.1 定位

Published Business Rules 是知识库中最高权威的业务规则表达，回答“平台允许什么、限制什么、状态如何变化”。它们由 Canonical 总表派生，但不得携带内部生成信息、Benchmark ID 或隐藏业务状态。

### 6.2 16 份选题预算

1. FlowPay 产品范围与租户隔离。
2. Sandbox 与 Production 环境策略。
3. 服务地区与支持币种。
4. 套餐与功能权限。
5. Rate Limit 策略。
6. API Key 生命周期与轮换。
7. API Version 支持策略。
8. 幂等请求策略。
9. Customer 生命周期。
10. Payment 生命周期与状态机。
11. Payment 失败分类。
12. Refund 资格、额度与时限。
13. Subscription 生命周期。
14. Invoice 扣费与重试策略。
15. Webhook 事件与投递策略。
16. Webhook 签名与 Secret 轮换。

### 6.3 必须包含

- 规则目的和适用范围。
- 明确条件、允许行为和禁止行为。
- 状态机或决策表（适用时）。
- 边界条件和至少一个反例。
- 与 API Docs、Troubleshooting 的关联链接。
- 对应 `rule_ids`。

### 6.4 禁止包含

- 某个具体 Account 当前套餐或 Key 状态。
- 某笔具体 Payment 的真实状态。
- 某次服务事件是否发生。
- Benchmark 正确答案或 `expected_hops`。
- “总是”“一定”等超出适用条件的绝对化措辞。

---

## 7. API / Product Docs 编写规范

### 7.1 定位

API Docs 回答“开发者怎样操作”。它应描述资源、Endpoint、参数、响应、错误和示例，但不重复整篇业务政策。

### 7.2 34 份选题预算

#### 入门与平台基础：8 份

1. 快速开始。
2. API 基础 URL 与请求格式。
3. 使用 Secret Key 认证。
4. Sandbox 测试环境。
5. Production 启用。
6. API Version Header。
7. Request ID 与请求追踪。
8. 错误响应格式。

#### Customers 与 Payments：10 份

9. Customer 对象。
10. 创建 Customer。
11. 更新与删除 Customer。
12. Payment 对象。
13. 创建 Payment。
14. 查询 Payment。
15. 确认需要操作的 Payment。
16. 取消 Payment。
17. Payment 列表与过滤。
18. Payment Method 参数与版本兼容。

#### Refunds：4 份

19. Refund 对象。
20. 创建全额退款。
21. 创建部分退款。
22. 查询 Refund 与退款额度。

#### Subscriptions 与 Invoices：6 份

23. Subscription 对象。
24. 创建 Subscription。
25. 取消 Subscription。
26. Invoice 对象。
27. Invoice 扣费生命周期。
28. 查询 Invoice 与关联 Payment。

#### Webhooks 与开发者能力：6 份

29. Webhook Endpoint 管理。
30. 订阅事件类型。
31. 验证 Webhook 签名。
32. Webhook 重试与事件去重。
33. 使用 Idempotency Key。
34. Rate Limit Header 与退避。

### 7.3 标准结构

```markdown
# 标题

## 概述
## Endpoint
## 请求参数
## 响应字段
## 状态与业务约束
## 错误
## 示例
## 版本说明
## 相关文档
```

同一 API 的版本差异应在正文中显式标注，不能靠文件发布日期让读者猜测。

---

## 8. Troubleshooting / Error Docs 编写规范

### 8.1 定位

Troubleshooting 回答“遇到这种症状应该查什么”。它必须把规则判断和事实查询分开，不能仅凭症状宣布具体账户或具体请求的根因。

### 8.2 24 份选题预算

#### 错误码专项：18 份

为 Canonical Error Catalog 中每个标准错误码各生成一份文档。

#### 跨错误综合诊断：6 份

19. 401 认证失败诊断决策树。
20. 403 权限与 Production 暂停诊断。
21. Payment 失败与状态错误诊断。
22. 429 流量峰值、套餐和重试诊断。
23. Webhook 未收到与签名失败诊断。
24. 500/503 商户问题与平台故障区分。

### 8.3 标准结构

```markdown
# 错误码或症状

## 现象
## 含义
## 常见原因
## 需要确认的事实
## 推荐诊断步骤
## 处理方式
## 不应做出的判断
## 相关文档
```

“需要确认的事实”必须指出应该查询账户、业务状态或运行时状态中的哪一类信息，但不写入合成数据的真实答案。

---

## 9. Release Notes / Migration Guides 编写规范

### 9.1 定位

该类文档专门承载时间和版本变化，是版本感知检索的主要依据。

### 9.2 10 份选题预算

1. 2025-10-01 初始 API Release。
2. 2026-01-15 Release Notes。
3. 迁移至 2026-01-15。
4. 2026-04-01 Release Notes。
5. `source` 到 `payment_method` 迁移指南。
6. Webhook 签名 Header 迁移指南。
7. 2026-07-01 Release Notes。
8. 迁移至 2026-07-01。
9. Payment 成功事件名称迁移指南。
10. API Version 支持与弃用时间线。

### 9.3 必须包含

- 发布日期与生效日期。
- 受影响的 API Version。
- `added`、`changed`、`deprecated`、`removed` 或 `known_issue` 类型。
- 旧行为、新行为和明确迁移步骤。
- 是否存在兼容期。
- `supersedes` 和相关文档。

禁止使用“当前”“最近”等依赖阅读时间的模糊表达，应写绝对日期和版本号。

---

## 10. Support Cases 编写规范

### 10.1 定位

Support Case 表达“类似问题曾怎样发生和被定位”，用于相似案例检索和制造合理噪声。它不是正式规则，也不保证案例结论可直接迁移到其他 Account。

### 10.2 16 份场景预算

1. 使用 Sandbox Key 调用 Production。
2. Key 轮换后旧 Key 被过早撤销。
3. Production 暂停被误认为套餐限制。
4. 同一幂等键使用不同金额。
5. 流量突增触发 Growth Rate Limit。
6. 429 被用户误认为套餐降级。
7. `source` 在 2026-07-01 中失效。
8. 升级后 Webhook 签名 Header 不匹配。
9. Payment 失败后尝试原地重试。
10. 对 processing Payment 发起退款。
11. Starter 尝试部分退款。
12. Refund 超过 180 天窗口。
13. Subscription 重试后恢复 active。
14. Invoice 重试耗尽导致取消。
15. Endpoint 未订阅 Payment 成功事件。
16. 503 被误诊为 Merchant Webhook 配置错误。

### 10.3 标准结构

```markdown
# Case 标题

## 背景
## 用户报告
## 初始假设
## 调查过程
## 关键证据
## 根因
## 处理结果
## 可复用经验
## 不可泛化部分
```

### 10.4 噪声约束

- 约 50% Case 应包含至少一个用户错误假设。
- 约 25% Case 应包含一次无效或方向错误的初步排查。
- 最终根因必须符合 Canonical Rules。
- 关键证据只引用合成实体 ID，不复制 Benchmark 问题原句。
- Case 不应都以相同模板句式开头或结尾。

---

## 11. 文风与语言多样性

### 11.1 官方文档

- 使用准确、克制、可执行的说明性语言。
- 条件和例外必须显式写出。
- API 名称、字段、状态和错误码使用固定拼写。
- 不使用营销口号或真实支付品牌名称。

### 11.2 排障文档

- 以症状和决策步骤组织内容。
- 对可能原因使用概率中性的表述。
- 清楚标出需要查询的证据，避免“通常就是某原因”的武断表述。

### 11.3 Support Case

- 可以使用更自然的支持工单语言、缩写和不完整描述。
- 用户描述可以混淆 Payment、Invoice、Event 等术语。
- 最终处置部分必须恢复到标准术语和准确 ID。

### 11.4 多样性边界

允许同义表达和句式变化，但以下字符串不得随意改写：

- API Endpoint。
- 参数名和响应字段。
- 对象状态。
- 错误码。
- API Version。
- 资源 ID。
- Event Type。

---

## 12. 文档长度与 Chunk 设计

### 12.1 建议长度

- Published Rules：1,200～2,500 中文字。
- API Docs：800～1,800 中文字。
- Troubleshooting：900～1,600 中文字。
- Release/Migration：700～1,500 中文字。
- Support Case：700～1,300 中文字。

### 12.2 标题层级

- 每份文档只有一个 H1。
- 主要检索单元使用 H2。
- H3 只用于参数组、版本差异或步骤子项。
- 不允许为凑 Chunk 数量使用无语义标题。

### 12.3 Chunk 原则

- 优先按 H2 语义边界切分。
- 单个 Chunk 目标 350～700 中文字。
- 状态机、决策表和紧邻解释不得拆开。
- Front Matter 作为 metadata 保存，不与正文重复嵌入。
- 每个 Chunk 必须继承 `doc_id`、`doc_type`、`authority`、`api_versions`、`effective_from` 和 `rule_ids`。

目标总量约为 600～1,000 chunks。若 100 份文档产生远超该范围的 chunks，应优先检查是否过度拆分或内容越界。

---

## 13. 数据源边界约束

知识文档可以描述查询规则，但不能伪造当前事实。

| 问题 | Markdown 可以提供 | Markdown 不能直接提供 |
| --- | --- | --- |
| 套餐是否支持部分退款 | 套餐规则 | 某 Account 当前套餐 |
| Payment 是否可退款 | 可退款状态和时限 | 某 Payment 当前状态和时间 |
| 为什么出现 429 | 可能原因和诊断步骤 | 某分钟真实请求量 |
| 为什么没收到 Webhook | 配置和投递判断路径 | Endpoint 当前配置和本次投递结果 |
| 503 是否为平台故障 | 错误含义和验证方法 | 某时段服务状态 |

任何文档若能直接回答本应查询 SQL 或 Runtime Tool 的具体事实，都可能破坏异构检索设计，必须修改或隔离。

---

## 14. Benchmark 防泄漏规则

- Canonical 总表和本规范不得进入向量索引。
- Benchmark 文件、Ground Truth、required tools、evidence IDs 列表不得进入知识目录。
- Support Case 不得复述 Benchmark 问题的完整句子。
- 问题和语料使用不同随机种子、不同改写批次。
- 文档不得出现“该问题的正确答案是”或“Agent 应调用”等评测提示。
- 评测问题可以引用知识文档 ID 作为 Ground Truth，但知识文档不能反向引用评测问题 ID。

---

## 15. 生成顺序

1. 冻结 Canonical Business Rules。
2. 先生成 16 份 Published Business Rules。
3. 基于 Published Rules 生成 34 份 API / Product Docs。
4. 基于错误码、状态机和 API Docs 生成 24 份 Troubleshooting。
5. 基于版本时间线生成 10 份 Release/Migration 文档。
6. 最后生成 16 份 Support Cases，引入受控噪声和跨文档引用。
7. 执行结构、规则、版本、引用、重复度和泄漏检查。
8. 通过验收后再切 Chunk 和创建向量索引。

---

## 16. 自动校验要求

### 16.1 结构校验

- 文档数量和分类符合预算。
- `doc_id` 唯一，文件名和 Front Matter 一致。
- 必填 metadata 完整且类型正确。
- `related_docs`、`supersedes` 和 `rule_ids` 都可解析。

### 16.2 事实校验

- 套餐上限与 Canonical 一致。
- 状态名和状态流转合法。
- 错误码含义和 HTTP 状态一致。
- 版本参数、事件名和 Header 适用范围正确。
- Webhook 重试次数和时间窗正确。
- Refund 金额、状态和时限规则正确。

### 16.3 语料质量校验

- 不存在大段重复或只替换实体名的模板文档。
- 每份文档至少覆盖一个独立检索意图。
- 有意冲突具备可消解的版本或条件 metadata。
- Support Case 的最终根因有 Canonical Rule 支持。
- 静态文档未泄漏具体动态事实或 Benchmark 答案。

### 16.4 建议阈值

- 文档总数：95～105。
- 无效内部链接：0。
- 未解析 `rule_id`：0。
- 同版本硬规则冲突：0。
- 完全重复文档：0。
- 高度相似文档对：人工复核后保留率不超过总文档的 10%。

---

## 17. 单篇文档验收清单

每篇知识文档发布前必须确认：

- [ ] 它属于既定的 100 份文档预算。
- [ ] 它有独立的检索意图，不是为了凑数。
- [ ] Front Matter 完整。
- [ ] 所有规则都能追溯到 `rule_ids`。
- [ ] API Version、生效时间和适用范围明确。
- [ ] 没有把账户、交易或运行时当前状态写成静态知识。
- [ ] 没有泄漏 Benchmark 问题、答案或工具轨迹。
- [ ] 与同类文档不存在无意冲突。
- [ ] 相关文档链接真实存在。
- [ ] 标题和段落适合语义切分。

---

## 18. 第一层完成标准

当以下条件满足时，规则与约束层可以视为冻结：

1. Canonical 总表覆盖套餐、环境、版本、认证、限流、状态机、Webhook 和错误码。
2. 业务复杂度被限制在约 100 份向量文档可以充分表达的范围内。
3. 五类知识语料的数量、权威性和选题清单已经确定。
4. 版本冲突和 Support Case 噪声都有明确的可消解规则。
5. 知识文档与未来 SQL/Runtime 数据的边界明确。
6. 后续生成器可以依据 `rule_ids` 自动校验文本一致性。

