# FlowPay 300 题 Benchmark 设计规范

> 文档版本：V1.1  
> 文档性质：Benchmark Design Contract  
> 上游事实：110 条 Canonical Rules + 100 份 Published Knowledge Docs  
> 配套系统：FlowPay 确定性模拟器、SQLite Snapshot、Runtime Mock API  
> 是否进入业务向量库：否

## 1. 目标

本 Benchmark 用同一套 300 条问题比较 Naive RAG 与 Agentic RAG，重点评测 Agent 是否能：

- 选择正确知识源和 typed tool。
- 从模糊首轮描述中识别大致产品领域，并提出有针对性的澄清问题。
- 联合规则、API 文档、账户事实、业务对象和 Runtime 证据。
- 处理版本、历史时间、相似案例和冲突信息。
- 在证据充分时停止，在证据不足时拒绝猜测。
- 给出可核验答案，而不是碰巧说对。

正式问题在结构化数据生成之前冻结。随后由 Scenario Specs 驱动模拟器生成所需事实和干扰项。

## 2. 固定规模与分类

| 题型 | 总数 | Dev | Test | 主要能力 |
| --- | ---: | ---: | ---: | --- |
| Simple Retrieval | 70 | 14 | 56 | 单文档直接检索、事实定位 |
| Multi-document | 50 | 10 | 40 | 同类或跨类文档整合 |
| Multi-hop | 60 | 12 | 48 | 连续查询、实体关联、条件推理 |
| Multi-source | 70 | 14 | 56 | Vector + SQL / Runtime 联合 |
| Temporal / Versioned | 25 | 5 | 20 | `as_of`、版本变化、历史配置 |
| Tool-use / Diagnostic | 25 | 5 | 20 | 日志、Usage、Status 与根因判断 |
| **合计** | **300** | **60** | **240** | — |

题型是主标签；一道题可以有次级能力标签，但只计入一个主分类。

## 3. Scenario Family 切分

300 道题组织为 75 个 Scenario Family，每个 Family 固定 4 道题：

- 15 个 Dev Family，共 60 题。
- 60 个 Test Family，共 240 题。
- 同一 Family 的实体、因果链和干扰项共享，但四道题考察角度不同。
- 一个 Family 必须整体进入 Dev 或 Test，禁止跨集拆分。
- Family ID、实体 ID、错误指纹、时间窗口和叙事模板不得在两个 split 间复用。

题型配额不要求每个 Family 内四题同型；先按 Family 防泄漏切分，再在各 split 内满足上表精确配额。

## 4. 题目冻结顺序

每道题按以下顺序完成：

1. 选择未充分覆盖的 Rule、Knowledge Doc、Tool Operation 和能力标签。
2. 定义 Scenario Family 的业务因果故事。
3. 写事实断言、负向断言和允许的答案边界。
4. 声明 Required Sources、Tools、Hops 和 Evidence Selectors。
5. 预留 Account、Object、Request、Event 等稳定 ID。
6. 写模糊的用户首轮描述，并定义“被问到才披露”的用户事实池。
7. 冻结 Blueprint。
8. 之后才编写/编译 Scenario Commands 并生成结构化数据。

自然语言题目不是第一步。先固定可验证的事实合同，可以避免出现问法漂亮但无法客观评分的题。

## 5. Blueprint Schema

`benchmark_blueprints.jsonl` 每行一题，至少包含：

```json
{
  "schema_version": "1.1",
  "question_id": "FP-BM-MS-0042",
  "split": "test",
  "scenario_family_id": "sf_rate_retry_11",
  "scenario_id": "sc_bm_rate_retry_0042",
  "question_type": "multi_source",
  "secondary_tags": ["diagnostic", "rate_limit"],
  "difficulty": 4,
  "question": "线上支付突然失败了，测试时一直正常。",
  "conversation": {
    "mode": "progressive_disclosure",
    "initial_user_message": "线上支付突然失败了，测试时一直正常。",
    "disclosure_policy": "only_answer_information_categories_the_assistant_explicitly_requests",
    "required_clarification_categories": ["goal", "symptom_details", "account_context", "occurrence_time", "identifiers"],
    "max_clarification_turns": 5,
    "available_user_facts": []
  },
  "as_of": "2026-08-12T10:02:00Z",
  "api_version_context": "2026-01-15",
  "ground_truth": {
    "canonical_answer": "...",
    "required_assertions": [],
    "acceptable_variants": [],
    "negative_assertions": []
  },
  "required_sources": ["business_rules", "account_sql", "runtime_usage"],
  "required_tools": ["search_business_rules", "query_accounts", "get_runtime_state"],
  "optional_tools": ["search_troubleshooting"],
  "forbidden_shortcuts": ["support_case_as_current_fact"],
  "expected_hops": [],
  "evidence_selectors": [],
  "planned_evidence_ids": ["doc:KB-BR-..."],
  "resolved_evidence_ids": [],
  "instance_diagnosis_contract": {
    "required": true,
    "must_use_user_identifiers": true,
    "must_describe_selector_observations": true,
    "must_reconstruct_timeline_when_available": true,
    "must_derive_solution_from_observed_state": true,
    "static_rule_only_answer_is_accepted": false
  },
  "stop_condition": "..."
}
```

### 5.1 Ground Truth

- `canonical_answer` 是标准参考，不是唯一允许措辞。
- `required_assertions` 应尽量结构化，例如状态、金额、错误码、时间关系和因果结论。
- `negative_assertions` 防止常见错误，例如把 429 解释为套餐自动降级。
- 数值、枚举、实体关系和时间使用确定性 evaluator；只有自由文本解释使用可选 LLM Judge。

### 5.2 Evidence

- `planned_evidence_ids` 只用于生成前已存在的 Published 文档。
- 动态 SQL / Runtime 证据使用语义 `evidence_selectors` 预先声明。
- 模拟完成后写入 `resolved_evidence_ids`。
- 正式测试 Ground Truth 保存这些 ID，但不对被测 Agent 暴露。

### 5.3 单轮与多轮信息披露

- Simple Retrieval 与 Multi-document 共 120 题采用 `single_turn_complete`：用户第一句话已经包含回答知识问题所需的正常业务信息，不应强制追问。
- Multi-hop、Multi-source、Temporal 和 Diagnostic 共 180 题采用 `progressive_disclosure`，根据题目需要安排 2～4 次澄清。
- `question` 保存用户第一轮消息。单轮题可以承载完整的用户可见案情；多轮题只能保存模糊开场。
- 所有第一轮都不得包含 ISO 时间、Benchmark 实体 ID、文档名称或工具路线。
- 多轮题的精确 `as_of` 保存在评分侧；用户被追问时只用“8 月 12 日中午前后”等自然表达回答。
- 多轮题的 `available_user_facts` 属于模拟用户，不直接进入 Agent Context。Agent 问到某类信息后，Runner 才把对应 `user_value` 加入对话。
- 结构化 Selector 所需的账户、环境、时间和对象参数必须能由已披露事实取得，禁止运行器在首轮暗中注入。
- 澄清问题必须随产品领域和证据缺口变化；不得让支付、退款、账单和 Webhook 共用同一套固定问句。

### 5.4 编号驱动的实例诊断

180 道需要 SQL / Runtime 的题必须把用户后续提供的 Account、Payment、Refund、Subscription、Invoice、Request、Event 或 Delivery ID 真正用于类型化查询。编号不是对话装饰，也不能只作为最终答案中的复述字段。

实例诊断的固定顺序是：

1. 用用户已披露的编号查询对象当前状态、所属范围和关联对象；
2. 用 Request ID、Delivery ID 等查询实际请求或投递轨迹；
3. 先向用户说明查到的参数、状态、错误码和时间顺序；
4. 再检索并应用当时有效的业务规则；
5. 根据实例状态给出解决方案。

只复述“规则上可能是什么原因”不算通过。动态题必须同时覆盖冻结的事实断言和模拟数据生成后解析出的 `trajectory_assertions`。例如幂等冲突题不能只说“相同 Key 不可换参数”，还要查出第一次金额、第二次金额、两次 HTTP 结果和原 Payment 的最终金额。

## 6. 六类题的设计约束

### 6.1 Simple Retrieval，70 题

- 答案主要来自一份 Published 文档和一个直接证据片段。
- 不要求 SQL / Runtime 才能作答。
- 覆盖规则、API 参数、错误解释和版本事实。
- 仍应包含容易混淆的邻近文档，避免纯关键词命中。

### 6.2 Multi-document，50 题

- 至少需要两份 Published 文档，且信息不可完全由其中一份替代。
- 应包含规则 + API、规则 + Troubleshooting、Release + API 等组合。
- Support Case 可以提供经验，但必须由权威文档约束最终结论。

### 6.3 Multi-hop，60 题

- 至少两个依赖 hop，后一查询参数来自前一证据。
- 例：Payment → Refund → 套餐规则；Invoice → Payment Attempts → Subscription 状态。
- Ground Truth 必须标出 hop 顺序和中间实体。

### 6.4 Multi-source，70 题

- 至少联合两种物理来源，且至少一种为 Vector、一种为 SQL 或 Runtime。
- 文档回答“规则是什么”，SQL / Runtime 回答“该账户实际发生了什么”。
- 仅使用任一来源都不能得到完整答案。

### 6.5 Temporal / Versioned，25 题

- 必须存在当前事实与历史事实的可区分差异。
- 评分合同必须明确 `as_of` 或 API Version；用户侧只有在被追问后才提供自然时间范围或部署版本，不允许使用冻结时刻状态替代历史状态。
- 覆盖版本默认值、迁移窗口、套餐生效、Secret 轮换和日志保留期。

### 6.6 Tool-use / Diagnostic，25 题

- 至少检查 Request、Usage、Delivery Attempt 或 Service Incident。
- 设计两个以上表面相似根因，例如配置错误、套餐限制、客户端重试风暴、平台 Incident。
- 问题要求根据证据判断，不允许只复述排障手册。

## 7. 知识与规则覆盖

### 7.1 100 份文档

- 每份 Published 文档至少被 1 道题列为 Required Evidence。
- 核心 Published Business Rules 与关键 API 文档至少被 3 道题覆盖。
- Troubleshooting、Release Notes 和 Support Cases 不得只在同一 split 出现；相同文档可被不同独立 Family 使用，但故事和实体不得复用。
- 同一题若只把文档作为无关干扰项，不计覆盖。

### 7.2 110 条 Canonical Rules

- 每条规则至少映射到 1 个 Required Assertion、Negative Assertion 或场景前置校验。
- 可运行规则必须同时映射到模拟器 Policy / Validator。
- 纯知识治理规则可以通过语料校验题或静态构建测试覆盖，不强行制造业务 SQL 行。
- 高风险规则应覆盖正例与反例：租户隔离、环境隔离、终态、退款额度、版本时间、套餐硬限制、Invoice 重试和 Webhook 410。

### 7.3 Tool Operation

- 9 个逻辑工具必须都有 Required Tool 题。
- 每个结构化 operation 至少 3 题：正常结果、空/边界结果、错误或历史结果。
- 至少 20% 的题只需 Vector，至少 30% 的题必须调用 SQL / Runtime；其余按题型配额自然分配。

所有覆盖记录进入 `coverage_matrix.md`，矩阵行是 Question，列包括 Rule、Doc、Tool Operation、Source、Product Area、Version、Region、Plan 和 Environment。

## 8. 反猜测与干扰设计

至少 30% 的问题包含用户提出的错误假设或一个强干扰项：

- 把 429 误认为套餐变化。
- 把历史 Support Case 当作当前账户事实。
- 把相同 Email 当作 Customer 唯一键。
- 用当前版本解释旧版本字段。
- 把 `pending` Refund 忽略后错误计算可退余额。
- 把 410 当作普通可重试 4xx。
- 把 Webhook 重试当作 Merchant API Rate Limit 流量。
- 把数据库存在的旧日志误认为 Tool 在保留期内可见。

背景数据需提供相似 ID、相邻时间、相同错误码但不同根因等干扰，不能只靠无关随机噪声。

## 9. 防止数据与语料泄漏

- Published 文档不得出现 Question ID、Scenario ID、预留实体或 Ground Truth 文本。
- Support Case 不得复刻 Benchmark Scenario 的完整因果链。
- Test Family 不得由 Dev Family 仅替换一个数字或实体前缀得到。
- Hidden Ground Truth、Evidence Selector 和 Scenario Specs 不进入 Vector DB 或 Agent 上下文；模拟用户事实也只能按追问逐项进入对话。
- 文件名、时间戳和 ID 前缀不编码答案类别。
- Question Authoring 和 Data Build 使用不同目录；发布前扫描相互泄漏字符串。

## 10. Dev / Test 发布方式

### 10.1 Dev 60 题

公开：

- 问题、标准答案、Required Assertions。
- Required Tools、Expected Hops 和 Evidence IDs。
- 完整工具 Trace 示例与评分解释。

用途是开发 Retriever、Tool Router、Agent Loop 和 evaluator。

### 10.2 Test 240 题

Agent 可见：模糊首轮问题，以及模拟用户按追问逐步提供的正常产品上下文。  
评分侧隐藏：标准答案、Required/Negative Assertions、Required Tools、Evidence Selectors、Evidence IDs、Expected Hops 和 Scenario Specs。

Test Snapshot 可以公开给工具服务，但不得直接暴露与题目对应的隐藏标签。

## 11. 评分维度

| 维度 | 说明 |
| --- | --- |
| Answer Correctness | Required Assertions 命中、Negative Assertions 未触发 |
| Evidence Recall | 必要证据是否取得 |
| Citation Precision | 引用是否真正支持相邻结论 |
| Tool Selection | 必要工具是否调用、是否误用来源 |
| Hop Completion | 中间实体和依赖步骤是否完整 |
| Temporal Accuracy | 是否使用正确 `as_of`、版本和历史配置 |
| Stop Accuracy | 证据充分后停止，缺失时不猜测 |
| Unnecessary Calls | 重复、无关或低信息增益调用 |
| Cost / Latency | Token、调用数和端到端耗时 |

### 11.1 建议评分结构

- Final Answer：40%。
- Evidence + Citation：25%。
- Tool Selection + Hop：20%。
- Stop / Efficiency：10%。
- Temporal / Safety Penalty：5%，高风险错误可设置硬失败。

精确权重在实现 evaluator 时冻结；同一轮对照实验必须使用完全相同权重。

## 12. 对照实验

同一 300 题和同一 Canonical Snapshot 至少运行：

1. Naive RAG：单次统一向量检索，不可访问 SQL / Runtime。
2. Routed RAG：按文档类型路由，但无多步工具循环。
3. Agentic RAG：可调用全部 typed tools，具备计划、反思和停止判断。

Simple Retrieval 上 Agentic 不必显著领先；Multi-hop、Multi-source、Temporal 和 Diagnostic 才是核心差异。报告必须同时呈现准确率、证据质量、调用成本与延迟。

## 13. 生成前验收门禁

只有以下条件全部满足，才能启动 Canonical Data Build：

- [ ] 恰好 300 个唯一问题，60 Dev / 240 Test。
- [ ] 恰好 75 个 Family，15 Dev / 60 Test，每个 4 题。
- [ ] 六类题数量与 split 配额精确吻合。
- [ ] 300 条自然语言问题和 Ground Truth Assertions 已冻结。
- [ ] 120 道单轮题无需澄清，180 道多轮题具有 2～4 次场景化澄清。
- [ ] 300 个首轮问题均不含 ISO 时间、Benchmark 实体 ID 或内部检索路线。
- [ ] 180 道多轮题均有完整的渐进披露事实池，所有 Selector 输入可在后续对话中取得。
- [ ] 100 份 Published 文档均有 Required Evidence 覆盖。
- [ ] 110 条规则均有覆盖映射。
- [ ] 所有 Required Tool / Operation 存在于 Tool Contract。
- [ ] 每道动态题都有可解析的 Evidence Contract。
- [ ] Reserved IDs 无冲突且不泄漏答案。
- [ ] Family 不跨 split，Test 与 Dev 无模板化近重复。
- [ ] 30% 以上题目含错误假设或强干扰项。
- [ ] 题目未引用尚未生成的物理表行或日志行号。

## 14. 生成后验收门禁

- [ ] 300 条 Evidence Contract 全部解析。
- [ ] 所有 Required / Negative Assertions 通过。
- [ ] 每条证据对 Agent 可见且遵守保留期。
- [ ] SQL、Runtime 与 Event Journal 追溯一致。
- [ ] 删除必要证据的反证测试按预期失败。
- [ ] 同输入重放文件 hash 一致。
- [ ] Hidden Test 工件与 Agent 运行环境隔离。
- [ ] Naive、Routed、Agentic 三种基线可在同一快照运行。

## 15. 本阶段交付边界

题集设计阶段已经完成，正式工件位于 `benchmark/design/`：

- `benchmark_blueprints.jsonl`：300 道已冻结题目及 Ground Truth / Evidence Contract。
- `scenario_specs.yaml`：75 个 Scenario Family 的声明式场景。
- `entity_reservations.json`：所有 Benchmark 实体的稳定预留 ID。
- `coverage_matrix.md`：100 份文档、110 条规则、9 个逻辑工具和全部 Operation 的覆盖证明。
- `design_manifest.json`：规则、知识文档、生成器和四个输出文件的 SHA-256。

这些文件不表示 SQL 或 Runtime 证据已经存在；其中 `resolved_evidence_ids` 仍为空。下一阶段是实现 Scenario Compiler 和确定性模拟器，运行场景后解析实际证据，再执行第 14 节的生成后验收门禁。
