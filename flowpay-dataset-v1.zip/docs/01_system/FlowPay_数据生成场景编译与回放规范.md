# FlowPay 数据生成、场景编译与回放规范

> 文档版本：V1.0  
> 文档性质：内部生成规范 / Dataset Build Contract  
> 上游设计：`docs/01_system/FlowPay_确定性模拟系统设计.md`  
> 数据模型：仓库上层的 `docs/DATABASE_SCHEMA.md`  
> 是否进入业务向量库：否

## 1. 目的

本文定义从“已冻结的 300 条问题设计”到“可复现的 SQL、Runtime、日志和 Ground Truth”的唯一生成流程。核心因果顺序是：

```text
规则与知识语料
      ↓
冻结问题 + Evidence Contract
      ↓
Scenario Specs + 预留实体
      ↓
编译命令 + 固定种子背景流量
      ↓
运行规则系统
      ↓
自然沉淀 SQL / Runtime / Logs
      ↓
解析证据 + 验证答案
```

禁止先随机生成一批数据，再根据已有异常“找题目”。数据必须由问题所需场景和独立背景分布共同驱动。

## 2. 输入工件

一次 Canonical Build 必须冻结以下输入：

| 工件 | 作用 |
| --- | --- |
| Canonical Rules | 可执行业务约束与状态机 |
| Knowledge Manifest | 100 份业务知识文档的 ID、版本、hash |
| `benchmark_blueprints.jsonl` | 300 条问题、答案断言和 Evidence Contract |
| `scenario_specs.yaml` | 场景前置条件、命令和期望结果 |
| `entity_reservations.json` | 问题中出现的稳定 Account / Payment / Request 等 ID |
| `background_profile.yaml` | 背景账户、流量和故障分布 |
| `rule_implementation_map.yaml` | 110 条规则到 Policy / Validator / 文档约束的映射 |
| Build Config | seed、时钟、模拟器版本、输出 schema 版本 |

任何输入发生变化都必须生成新的 `run_id` 和 manifest，不能覆盖已发布快照。

## 3. 问题冻结门禁

数据生成之前，300 条 Blueprint 必须满足：

- `question_id`、题目文本、split 和 Scenario Family 已固定。
- Ground Truth 使用事实断言表达，而不是依赖尚不存在的行号或数据库主键。
- Required Sources、Required Tools、Expected Hops 和 Stop Condition 已声明。
- Evidence Contract 已声明需要何种证据以及唯一性条件。
- 题目中出现的实体 ID、时间窗口、版本上下文已预留。
- 题目不得泄漏实现表名、随机种子、Scenario ID 或预期错误注入机制。

在冻结后，只允许修复拼写或无语义格式问题。若改动答案、实体、时间、版本、证据需求或推理路径，必须升版 Blueprint 并重跑整个数据构建。

## 4. Evidence Contract

Evidence Contract 不直接指定“在某表第几行”，而是声明可验证的语义选择器：

```yaml
question_id: FP-BM-MS-0042
as_of: 2026-08-12T10:02:00Z
selectors:
  - alias: plan_at_request
    source: sql
    entity: account_plan
    where:
      account_id: acct_bm_0042
      effective_at: "<= request.started_at"
    cardinality: exactly_one
  - alias: rate_bucket
    source: runtime
    entity: usage_bucket
    where:
      account_id: acct_bm_0042
      environment: production
      contains_request_id: req_bm_0042_09
    cardinality: exactly_one
  - alias: retry_chain
    source: runtime
    entity: api_request
    where:
      root_request_id: req_bm_0042_01
    cardinality: at_least_two
relations:
  - plan_at_request.account_id == rate_bucket.account_id
  - retry_chain[*].account_id == plan_at_request.account_id
```

生成后 Resolver 将选择器解析为稳定 Evidence ID。`exactly_one` 得到 0 或多条、`at_least_one` 得到 0 条、关系断言失败，整个 Build 必须失败。

## 5. Scenario Family 与 Scenario Spec

### 5.1 Scenario Family

Scenario Family 是共享同一因果故事、实体集合和生成命令的一组题。一个 Family 通常包含 4 道不同视角问题，例如：

- 规则资格判断。
- 当前业务对象状态。
- Runtime 根因诊断。
- 跨来源处置建议。

同一 Family 的所有题必须进入同一个 split，防止测试集通过开发集看到相同实体或因果链。

### 5.2 Scenario Spec

```yaml
scenario_id: sc_bm_rate_retry_0042
scenario_family_id: sf_rate_retry_11
split: test
entity_reservations:
  account_id: acct_bm_0042
  key_id: key_bm_0042_prod
  request_root_id: req_bm_0042_01
setup:
  - create_account:
      plan: Growth
      region: NA
      default_api_version: 2026-01-15
  - enable_production: {}
  - create_api_key:
      environment: production
commands:
  - at: 2026-08-12T10:00:00Z
    send_api_burst:
      route: /v1/payments
      count: 1600
      duration_seconds: 60
      retry_profile: immediate_fanout_5
expects:
  - error_code: FP-4291
  - account_plan_at_request: Growth
  - rate_limited_count: "> 0"
```

Spec 描述前置条件和业务动作，不允许直接插入最终 Payment、错误日志或 Usage Bucket。

## 6. 场景编译

Scenario Compiler 执行以下步骤：

1. 校验 Blueprint、Family、Scenario 和 Reserved IDs 一一关联。
2. 校验前置条件不会违反套餐、版本、地区和租户规则。
3. 将声明式 setup / commands 编译成时间排序的 Simulator Commands。
4. 为异步任务预估时间窗口，但不预写其结果。
5. 将 Evidence Selector 编译为生成后查询计划。
6. 检查不同 Scenario 不争用同一 ID、幂等键、限流桶或时间敏感资源。
7. 输出 `compiled_commands.jsonl` 和编译报告。

编译器可以拒绝不可能的题，例如 Starter 账户要求通过正常调用成功创建 Subscription，除非该题明确预期 `FP-4031`。

## 7. 背景数据生成

背景数据用于制造真实基数、近似案例和干扰项，目标占最终记录的 80%～90%。它必须：

- 使用固定 `canonical_seed = 20260827`。
- 为 Accounts、Payments、Subscriptions、Webhooks、Incidents 等使用独立 RNG Namespace。
- 仅生成符合 Canonical Rules 的命令。
- 使用独立 `bg_` ID 空间，不接触 Benchmark Reserved IDs。
- 生成相似但不完全相同的错误、时间、版本和套餐组合。
- 不读取 Ground Truth Answer 来伪造专用行。

背景分布是工程配置，不应追求真实商业预测；其目标是避免玩具式“一查只有一行”的数据，同时保持构建时间可控。

## 8. 命令合并与执行

Scenario Commands 和 Background Commands 合并后按以下稳定键排序：

```text
simulation_time
→ command_priority
→ scenario_or_batch_id
→ command_sequence
```

执行期间：

- 所有请求必须经过同一 API Gateway Pipeline。
- 所有领域变化必须追加 Event Journal。
- 异步结果必须由 Scheduler 到时执行。
- Request Logs、Usage 和 Delivery Attempts 必须由实际执行派生。
- Scenario 失败不得自动修补最终表；Build 立即失败并报告命令和规则。
- 背景命令失败若属于配置允许的业务结果可保留；违反不变量则失败。

## 9. 投影与证据解析

模拟完成后按顺序执行：

1. Event Journal 与领域状态投影到 SQLite。
2. 执行流投影到 Runtime JSONL。
3. 从 Request Logs 重算 Usage 并比对。
4. 对每道题运行 Evidence Resolver。
5. 用已解析事实执行 Ground Truth Assertions。
6. 写入 `evidence_ids`，保留原始语义选择器。
7. 生成开发集答案、隐藏测试答案和评分工件。

Evidence ID 只允许引用 Agent 可访问的 Published 文档、typed SQL Tool 记录或 Runtime Tool 记录。Event Journal 可以用于校验，但不能成为题目的直接证据。

## 10. 确定性与随机性隔离

### 10.1 Canonical Snapshot

- 固定 seed、冻结时钟和模拟器版本。
- 输入、命令、输出都纳入 hash。
- 相同输入必须产出相同排序、ID、时间和文件 hash。
- Canonical Snapshot 是 300 题的唯一正式事实环境。

### 10.2 Robustness Runs

可选使用额外背景 seed 检验 Agent 是否依赖数据巧合。Robustness Run：

- 不改变预留实体和 Scenario Commands。
- 不改变目标场景答案。
- 可以改变背景实体、背景顺序和无关干扰项。
- 不替代 Canonical Snapshot，也不用于修改冻结问题。

若改变背景 seed 会改变正式答案，说明场景隔离或 Evidence Contract 有缺陷。

## 11. LLM 使用边界

LLM 可以辅助：

- 在冻结前改写题目自然语言。
- 检查问法是否泄漏答案。
- 生成不携带事实的文本模板变体。
- 对最终答案进行可选语义评分。

LLM 不得：

- 直接生成 SQL 行、日志、Usage、Incident 或 Delivery Attempt。
- 决定随机执行结果。
- 在数据生成后根据已有行反向发明正式题目。
- 替代确定性断言验证金额、状态、时间或实体关联。

## 12. 校验阶段

### 12.1 静态校验

- 300 个唯一 Question ID。
- 75 个 Scenario Family，且 Family 不跨 split。
- 预留 ID 唯一并符合前缀。
- 所有 Source / Tool / Rule / Knowledge Doc 引用存在。
- 60 个 dev、240 个 test。

### 12.2 动态不变量

- 110 条规则实现映射完整。
- 状态机、金额、版本、套餐、地区和租户约束通过。
- Request → Business Object → Event → Delivery 可以追溯。
- Usage 与 Request Logs 聚合一致。
- Runtime 保留期正确。
- 所有 Evidence Contract 的 cardinality 和 relation 成立。

### 12.3 反证测试

对每题至少执行一种负向验证：

- 删除一条 Required Evidence 后证据完整性评分下降。
- 替换为相似实体后 Ground Truth Assertion 失败。
- 使用当前套餐替代历史套餐时，Temporal 题失败。
- 只用文档而不查动态数据时，Multi-source 题不能得到完整答案。

## 13. 发布目录

```text
benchmark/
├── design/
│   ├── benchmark_blueprints.jsonl
│   ├── scenario_specs.yaml
│   ├── entity_reservations.json
│   └── coverage_matrix.md
├── generated/
│   └── canonical/
│       ├── dev_questions.jsonl
│       ├── dev_ground_truth.jsonl
│       ├── test_questions.jsonl
│       ├── hidden_test_ground_truth.jsonl
│       └── evidence_resolution.jsonl
└── manifests/
    └── canonical_manifest.json
```

`hidden_test_ground_truth.jsonl` 不应进入被测 Agent 的工作目录或检索索引。

## 14. 失败与变更策略

- 编译失败：修改 Blueprint 或 Scenario Spec，升版后从头构建。
- 执行违反规则：优先修复模拟器或不合法场景，不直接改数据。
- Evidence 解析失败：修复选择器或场景，不降低 cardinality 掩盖问题。
- 规则或知识文档变更：重新检查 300 题答案和覆盖矩阵，生成新快照。
- 仅修复输出序列化：仍需重新计算 hash 和执行全部校验。

## 15. 验收标准

- 正式问题在任何结构化数据生成之前已冻结。
- 目标证据来自规则系统运行结果，不是直接插表。
- 背景数据与目标场景随机性隔离。
- 任意正式答案均可追溯到 Blueprint → Scenario → Command → Event → Agent 可见证据。
- Canonical Build 可字节级重放。
- 所有 300 条 Evidence Contract 与 Ground Truth Assertions 通过后才允许发布。
