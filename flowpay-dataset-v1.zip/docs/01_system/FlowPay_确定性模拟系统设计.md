# FlowPay 确定性模拟系统设计

> 文档版本：V1.0  
> 文档性质：系统设计 / Simulation Architecture  
> 上游事实源：`docs/00_foundation/FlowPay_业务规则总表.md`  
> 是否进入业务向量库：否  
> 目标实现：Python 3 + SQLite + 确定性事件队列

## 1. 目的

本系统不是一个面向真实用户的支付平台，也不是用 LLM 直接生成数据库行的脚本。它是一个小型、可执行、可回放的 FlowPay 领域模拟器：接收预先设计的业务命令和固定种子的背景流量，严格按照 Canonical Rules 运行状态机，并自然沉淀业务表、请求日志、Usage、Webhook Delivery 和 Service Status。

系统首先服务于 300 条 Benchmark 问题。问题和 Evidence Contract 在数据生成前冻结；模拟器负责产生问题所需的真实因果证据，而不是在数据生成后反向编写问题。

## 2. 核心设计原则

### 2.1 规则可执行

Canonical Rules 必须映射为代码中的 Policy、状态机、约束或调度规则。任何影响最终答案的业务行为都不能只存在于 Markdown 描述中。

### 2.2 单一事实流

所有业务状态、SQL 记录、Request Logs、Usage 和 Webhook Delivery 必须来自同一个命令执行与事件流。禁止为不同数据源分别编造记录。

### 2.3 问题先于数据

Benchmark 先声明场景、时间、预留实体 ID、必要证据和期望结果。Scenario Compiler 将这些声明编译成模拟器命令；数据是命令执行结果。

### 2.4 确定性优先

相同规则版本、模拟器版本、Scenario Specs、随机种子和冻结时钟必须产生字节级可复核的数据快照。随机数只用于生成受控背景数据和允许随机的业务分支。

### 2.5 目标场景与背景数据分离

系统接收两类输入：

- **Scenario Commands**：为 300 条问题确定性产生必要证据。
- **Background Commands**：使用固定种子生成自然流量、无关实体、相似错误和干扰项。

Scenario Commands 不能因背景随机数变化而改变结果。背景数据不得占用预留 ID 或破坏目标场景前置条件。

### 2.6 Agent 只读

Benchmark 运行期间，Agent 只能通过 Retriever、typed SQL tools 和 Runtime tools 读取冻结快照，不允许修改数据或执行任意 SQL。

## 3. V1 系统边界

### 3.1 纳入模块

- Account、Plan Change、Feature Flag。
- Sandbox / Production 与 API Key 生命周期。
- API Version 选择和参数兼容。
- Request ID、认证、幂等和 Rate Limit。
- Customer。
- Payment 与 Payment 状态机。
- Refund 与退款额度。
- Subscription、Invoice 和第 1/3/7 天重试。
- Webhook Endpoint、Event、Delivery 和重试。
- Request Logs、Usage Buckets 和 Service Incidents。

### 3.2 不纳入模块

- 真实银行卡网络和清算。
- 争议、拒付、税务、平台分账。
- PCI 全流程和真实敏感支付数据。
- 机器学习风控。
- Dashboard、用户界面和真实外部 HTTP 调用。
- 多节点一致性、真实消息中间件和生产级高可用。

## 4. 总体架构

```text
Canonical Rules + Versioned Config
                  │
Benchmark Blueprints + Scenario Specs
                  │
Background Generator + Reserved IDs
                  ↓
             Command Stream
                  ↓
┌──────────────── FlowPay Simulator ────────────────┐
│ Fixed Clock → API Gateway → Domain Command Handler │
│                         ↓                          │
│                    Domain State                    │
│                         ↓                          │
│                  Domain Event Journal              │
│                         ↓                          │
│              Scheduler / Async Event Queue         │
└─────────────────────────┬──────────────────────────┘
                          ↓
        ┌─────────────────┼─────────────────┐
        ↓                 ↓                 ↓
 Business SQL         Runtime JSONL      Audit Snapshot
 D5 / D6 / D7         D8 / Mock API      Validation Only
```

## 5. 核心组件

### 5.1 Simulation Clock

模拟器不读取系统当前时间。所有时间来自 `SimulationClock`：

- 支持跳转到下一计划任务时间。
- 支持固定 UTC 时间。
- 所有记录统一写 ISO 8601 UTC。
- Scenario Specs 可在绝对时间安排命令。
- 背景命令必须落在声明的模拟窗口内。

Canonical Snapshot 建议：

- 模拟历史起点：`2025-09-01T00:00:00Z`。
- 冻结观察时间：`2026-08-27T12:00:00Z`。
- Runtime 主要观察窗口：冻结时间之前 90 天。

较早的业务对象可以保留在 SQL 中；超出套餐日志保留期的 Runtime 记录不对 Agent 可见。

### 5.2 ID Registry

ID Registry 统一分配和验证：

- `acct_`、`key_`、`cus_`、`pay_`、`re_`、`sub_`、`in_`。
- `we_`、`evt_`、`del_`、`att_`。
- `req_`、`inc_`、`usage_`。

Benchmark 中出现的实体 ID 在模拟前写入 `entity_reservations.json`。背景生成器使用独立命名空间，遇到预留 ID 必须失败而不是自动覆盖。

### 5.3 API Gateway Pipeline

每个模拟 API 请求按固定顺序处理：

```text
allocate request_id
    ↓
resolve account + environment
    ↓
authenticate API key
    ↓
resolve FlowPay-Version
    ↓
apply service incident override
    ↓
apply rate limit
    ↓
resolve idempotency record
    ↓
validate request contract
    ↓
execute domain command
    ↓
append events + schedule async work
    ↓
write response, request log and usage
```

认证前失败仍须产生 Request ID。Webhook Delivery 不经过 Merchant API Rate Limit。

### 5.4 Account Module

职责：

- Account 创建和主地区。
- 默认 API Version。
- Production 启用与暂停。
- Starter / Growth / Scale 套餐。
- 升级立即生效、降级周期末生效。
- Feature Flag 硬边界。
- API Key 创建、轮换、expiring 和 revoked。

### 5.5 Customer Module

职责：

- Customer 创建、更新和软删除。
- Account + Environment 所有权。
- Email 非唯一。
- deleted Customer 禁止新建 Payment 和 Subscription。

### 5.6 Payment Module

状态机：

```text
requires_action → processing → succeeded
       │               └────→ failed
       └──────────────→ canceled
```

`succeeded`、`failed`、`canceled` 为终态。`requires_action` 仅对 `2026-01-15` 及以后版本可见。Payment 处理结果由 Scenario Spec 或受控 Payment Method Profile 决定，不使用自由文本生成。

### 5.7 Refund Module

职责：

- 验证 succeeded Payment。
- 验证 180 天窗口。
- 计算 succeeded + pending Refund 占用。
- 验证套餐是否支持部分退款。
- 验证 Instant Refund 的套餐、地区、Feature Flag 和金额。
- 处理同步 succeeded 或异步 pending 的版本差异。

### 5.8 Subscription / Invoice Module

职责：

- trialing、active、past_due、canceled。
- 每个周期生成 Invoice。
- Invoice 定稿后创建 Payment。
- 首次失败后在第 1、3、7 天调度新 Payment。
- 任一次成功恢复 active。
- 全部失败后 Invoice uncollectible、Subscription canceled。

### 5.9 Webhook Module

职责：

- Endpoint 状态和订阅集合。
- 根据 Event API Version 生成版本化 Event Type。
- 为符合 Account、Environment、状态和订阅条件的 Endpoint 创建 Delivery。
- 根据模拟 Merchant Response Profile 产生 2xx、3xx、4xx、5xx、410 或 timeout。
- 默认重试或 Scale 自定义重试。
- 至少一次投递和 `event_id` 去重场景。
- Signing Secret 轮换与签名版本。

### 5.10 Observability Module

从实际执行流派生：

- API Request Log。
- 分钟与小时 Usage Bucket。
- Webhook Delivery Attempt Log。
- Service Status 和 Incident Timeline。
- 延迟、HTTP 状态、错误码和目标服务。

Usage 不能由独立随机数生成；它必须是 Request Logs 的确定性聚合。

### 5.11 Scheduler

Scheduler 保存按时间排序的异步任务：

- Payment 完成。
- Refund 完成。
- Invoice 周期生成和重试。
- Webhook Delivery 重试。
- Key expiring 到期。
- 套餐降级生效。
- Service Incident 开始与结束。

相同时间任务使用稳定优先级和序列号排序，保证回放结果一致。

### 5.12 Event Journal 与 Projector

Event Journal 是生成审计的唯一事件来源，至少记录：

- `event_sequence`。
- `simulation_time`。
- `scenario_id` 或 `background_batch_id`。
- `aggregate_type` 和 `aggregate_id`。
- `event_type`。
- `payload`。
- `caused_by_request_id`。
- `rule_ids`。

Projector 从 Journal 和领域状态导出 SQL / JSONL。Event Journal 不提供给 Agent，也不进入向量库。

## 6. 输入模型

### 6.1 Scenario Command

```yaml
scenario_id: sc_rate_limit_retry_storm_01
at: 2026-08-12T10:00:00Z
actor: acct_example
command: send_api_burst
params:
  environment: production
  requests_per_minute: 1800
  duration_seconds: 90
  retry_policy: immediate_fanout_5
expects:
  error_code: FP-4291
  evidence_selectors:
    - account.current_plan_at
    - runtime.usage_bucket
    - runtime.request_retry_chain
```

### 6.2 Background Profile

背景生成使用参数化分布而非 LLM：

- Account 套餐、地区和版本分布。
- 每日 Payment 数量与状态比例。
- Refund、Subscription 和 Webhook 使用率。
- 请求到达过程和有限错误率。
- Merchant Webhook Response Profile。

每个模块使用独立 RNG Namespace，例如 `seed/accounts`、`seed/payments`、`seed/webhooks`，避免修改一个模块后重排全部数据。

## 7. Canonical Snapshot 建议规模

| 数据 | 目标规模 |
| --- | ---: |
| Accounts | 120 |
| API Keys | 240～320 |
| Customers | 2,500～3,500 |
| Payments | 18,000～24,000 |
| Refunds | 1,200～2,000 |
| Subscriptions | 800～1,200 |
| Invoices | 3,000～5,000 |
| Webhook Endpoints | 220～320 |
| Events | 12,000～20,000 |
| Delivery Attempts | 15,000～30,000 |
| API Request Logs | 50,000～80,000 |
| Service Incidents | 20～30 |

目标场景直接所需记录不超过总数据的 10%～20%，其余由背景命令产生。

## 8. 错误与故障注入

故障只能通过声明式 Profile 注入：

- Payment Method Profile：success、declined、insufficient、action_required、expired。
- Merchant Endpoint Profile：2xx、redirect、4xx、5xx、410、timeout、flaky。
- Service Incident：service、region、start、end、error_code、affected_ratio。
- Client Retry Profile：none、bounded_backoff、immediate、fanout。

禁止直接向最终表写入一行 `FP-5031` 或 Delivery failure。必须先创建 Incident 或 Endpoint Response Profile，让执行路径自然产生失败记录。

## 9. 可重复性

Canonical Run 固定：

- `canonical_seed = 20260827`。
- 规则文件 hash。
- 100 份知识文档 manifest hash。
- Benchmark blueprint hash。
- Scenario specs hash。
- Simulator version。
- Freeze time。

输出目录带 `run_id` 和 manifest。相同输入重跑后，各文件 hash 必须一致。

可选 Robustness Runs 使用额外种子，但不得用于替换 Canonical Benchmark Snapshot。

## 10. 验收标准

- 110 条 Canonical Rules 都映射到代码 Policy、Validator 或明确非运行时文档规则。
- Scenario Commands 与背景命令共享同一执行管线。
- SQL、Runtime 和 Event Journal 可互相追溯。
- 所有时间来自 Simulation Clock。
- 所有随机数来自声明的 seed namespace。
- 无 LLM 直接生成结构化事实。
- 300 条问题的 Evidence Contract 在生成后全部可解析。
- 删除任何一条必要证据时，对应问题验证必须失败。
- Agent 只读快照，不能修改模拟状态。

