# 回归测试：将场景规格编译为模拟计划，并校验输入及生成内容的标识。。测试中的固定输入用于复现边界，不作为业务答案来源。
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from flowpay_simulator.compiler import ScenarioCompiler
from flowpay_simulator.scenario_yaml import load_scenario_specs


ROOT = Path(__file__).resolve().parents[1]


class ScenarioCompilerTests(unittest.TestCase):
    def test_scenario_yaml_has_75_families_and_four_questions_each(self) -> None:
        specs = load_scenario_specs(ROOT / "benchmark" / "design" / "scenario_specs.yaml")
        self.assertEqual(75, len(specs["scenario_families"]))
        self.assertTrue(all(len(row["question_ids"]) == 4 for row in specs["scenario_families"]))

    def test_compile_is_deterministic_and_complete(self) -> None:
        compiler = ScenarioCompiler(ROOT)
        first = compiler.compile()
        second = compiler.compile()
        self.assertEqual(75, first.scenario_count)
        self.assertEqual(300, first.question_count)
        self.assertEqual(
            [command.to_dict() for command in first.commands],
            [command.to_dict() for command in second.commands],
        )
        self.assertGreater(len(first.commands), 350)
        self.assertEqual(75, sum(command.kind == "execute_scenario" for command in first.commands))

    def test_write_emits_parseable_jsonl_and_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "compiled"
            plan = ScenarioCompiler(ROOT).write(output)
            rows = [json.loads(line) for line in (output / "compiled_commands.jsonl").read_text().splitlines()]
            manifest = json.loads((output / "compile_manifest.json").read_text())
            self.assertEqual(len(plan.commands), len(rows))
            self.assertEqual(len(rows), manifest["command_count"])


if __name__ == "__main__":
    unittest.main()
