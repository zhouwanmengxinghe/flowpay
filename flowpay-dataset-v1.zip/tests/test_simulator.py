# 回归测试：simulator。测试中的固定输入用于复现边界，不作为业务答案来源。
from __future__ import annotations

import hashlib
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from flowpay_simulator.background import BackgroundGenerator, SMOKE_SCALE
from flowpay_simulator.compiler import ScenarioCompiler
from flowpay_simulator.engine import SimulationEngine
from flowpay_simulator.storage import project_snapshot
from flowpay_simulator.validation import validate_state


ROOT = Path(__file__).resolve().parents[1]


def run_smoke(output: Path) -> dict:
    plan = ScenarioCompiler(ROOT).compile()
    engine = SimulationEngine(run_id="run_test_smoke", seed=20260827)
    BackgroundGenerator(engine, SMOKE_SCALE).run()
    state = engine.run(plan.commands)
    report = validate_state(state, expected_scenarios=75)
    return project_snapshot(
        state, output, run_id=engine.run_id, seed=engine.seed,
        design_manifest_sha256=plan.design_manifest_sha256,
        validation_report=report,
    )


class SimulatorTests(unittest.TestCase):
    def test_target_scenarios_and_background_project(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "snapshot"
            manifest = run_smoke(output)
            self.assertEqual(75, manifest["counts"]["accounts"] - SMOKE_SCALE.accounts)
            self.assertEqual("passed", json.loads((output / "audit" / "invariant_report.json").read_text())["status"])
            with sqlite3.connect(output / "flowpay.sqlite") as conn:
                completed = conn.execute("SELECT COUNT(*) FROM scenario_executions WHERE status='completed'").fetchone()[0]
                event_count = conn.execute("SELECT COUNT(*) FROM event_journal").fetchone()[0]
                self.assertEqual(75, completed)
                self.assertGreater(event_count, 2_000)

    def test_same_seed_produces_identical_snapshot_hashes(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            first = run_smoke(base / "one")
            second = run_smoke(base / "two")
            first_hashes = {name: meta["sha256"] for name, meta in first["files"].items()}
            second_hashes = {name: meta["sha256"] for name, meta in second["files"].items()}
            self.assertEqual(first_hashes, second_hashes)

    def test_background_ids_do_not_use_benchmark_namespace(self) -> None:
        plan = ScenarioCompiler(ROOT).compile()
        engine = SimulationEngine(run_id="run_namespace_test")
        BackgroundGenerator(engine, SMOKE_SCALE).run()
        background_ids = set(engine.state.accounts) | set(engine.state.customers) | set(engine.state.payments)
        self.assertTrue(all("_bg_" in value for value in background_ids))
        engine.run(plan.commands)
        benchmark_accounts = {value for value in engine.state.accounts if "_bm_" in value}
        self.assertEqual(75, len(benchmark_accounts))


if __name__ == "__main__":
    unittest.main()

